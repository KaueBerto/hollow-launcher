# Parro — AveronSync 0.49

Pet e montaria **Parro Pet - Mister Spooky v1.0.1** (DepartmentQDE x Mister Spooky),
comprado pelo dono do servidor. Recriado de forma nativa no NeoForge 1.21.1: não instala
MCPets, MythicMobs, ModelEngine, ItemsAdder ou Nexo. Os YAMLs do pack foram lidos como
referência e portados à mão para `ParroEntity.java`. Nada do YAML é executado.

## Como ganhar e usar

- `/async parro dar <jogador>` (OP 2, console ou missão): dá o Parro de forma permanente.
  Dar de novo não zera o vínculo nem tira a sela.
- `/async parro remover <jogador>` e `/async parro info <jogador>`.
- O jogador usa **G → aba Parro** (Chamar/Guardar) ou `/parro chamar`, `/parro guardar`. `/parro` sozinho mostra o nível e as sementes para o próximo.
- Só um Parro chamado por dono. Ele é guardado ao sair do servidor, ao trocar de dimensão,
  quando o servidor desliga ou se ficar a mais de 96 blocos. Não fica salvo no mundo.
- Quando o Parro desmaia (morre), só pode ser chamado de novo depois de 30 segundos.

Salvo em `data/averonsync-parro.json` no mundo: dono, pontos de vínculo (o campo continua com o nome antigo `experience`) e se a sela fica (o `pr_saddle_kept`
do pack). A escrita é atômica. Se o arquivo for inválido, o Parro é desativado e o arquivo é mantido.

## Comportamento (do `parro.yml` e do `parro_skills.yml`)

| Pack | AveronSync |
|---|---|
| Níveis do MCPets 1/2/3 com 0/100/300 XP, vida, dano e resistência | **Substituído pelo vínculo** (próxima seção): 5 níveis por sementes, que aumentam velocidade e tamanho. Vida fixa em 20, regeneração 0,5 por segundo, sem resistência |
| +3 XP por acerto, barra e título "LEVEL UP!" | Substituído: +1 vínculo por semente, barra "Parro Lv.N • 7/15 sementes" e título "VÍNCULO AUMENTOU!" |
| Segue o dono aos saltos (`pr_pet_hop`) e plana na descida com Slow Falling | Igual, com as mesmas forças de salto e de impulso |
| Teleporta acima de 24 blocos; modo retorno acima de 20 até ficar a 12 | Igual |
| Ataca o alvo do dono, quem bate no dono e monstros num raio de 16; `attack1` e `attack2` | **Removido (decisão do servidor):** o Parro não ataca, não escolhe alvo e não reage quando o dono apanha. Clicar com o Parro montado não faz nada. As animações de ataque ficam sem uso |
| Clique: carinho (`petting1/2`), corações e sons | Igual (qualquer jogador; com sela, Shift + clique) |
| Sela na mão (dono): vira montaria (`transform` → `spawn`) | Igual; a sela é consumida |
| Tesoura (dono): tira a sela, que volta para o inventário | Igual |
| Shift + graveto (dono): zera o XP para o nível 1 | Zera o vínculo para o nível 1 (só o dono) |
| Montado: WASD, Espaço salta (0,85 + impulso de 1,2 e inclinação do olhar), plana a partir de 4 blocos de altura | Igual, mas limitado a 17 blocos/s e com planeio curto (ver abaixo); Shift desce |
| Rápido com sela: velocidade 0,29, perseguição 0,45 | Velocidade 0,29 (sem perseguição, já que não ataca); a montaria escala com o nível, ver vínculo |
| Água: nada, Dolphin's Grace e Water Breathing | Igual |
| Queda grande (8+): impacto com som e anel de partículas do bloco | Igual |
| Sem dano de queda; recebe 40% do dano com sela | Igual, exceto montado depois que o planeio de 3 s acaba (ver abaixo) |
| Sons ambientes, de passos (camel step) e de batida de asa ao planar | Iguais |

## Vínculo (decisão do servidor, no lugar do XP de combate)

O dono alimenta o Parro com **sementes** (clique direito segurando: trigo, beterraba, melancia, abóbora,
tocha-flor ou vagem de pitcher). Cada semente soma 1 ponto. Depois de comer, o Parro fica de
**barriga cheia por 30 minutos** (anti-spam): enquanto isso, ele recusa e mostra quanto falta. A espera
fica gravada no jogador: continua se o Parro for guardado e chamado de novo, se ele sair do servidor ou se o servidor reiniciar,
e conta o tempo real, inclusive offline.
Só o dono alimenta. No criativo a semente não é gasta.

Dez níveis, com 0, 2, 5, 9, 14, 20, 26, 31, 36 e 40 sementes (os intervalos crescem até o meio e voltam a diminuir). O nível 1 é o
tamanho do pack, a 12,5 blocos/s (o galope do cavalo). O nível 10 é 40% maior e vai a 17 blocos/s. Entre eles, cada nível soma
0,5 bloco/s e uns 4,4% de tamanho. O total de 40 sementes, com 30 minutos entre elas, dá cerca de 20 horas se o jogador alimentar sem falhar.

- A velocidade vale para o Parro montado. O teto de 17 blocos/s do nível 5 é o que ele tinha antes, e o nível 1 começa no galope do
  cavalo do AveronSync (12,5), com os níveis espaçados igualmente. Seguindo o dono, a velocidade é a mesma em todos os níveis.
- O tamanho muda o corpo, a hitbox, a sombra e a altura do assento. Ao subir de nível ele cresce
  devagar, em cerca de meio segundo, em vez de dar um salto.
- Ao subir de nível: som, título "VÍNCULO AUMENTOU!" e partículas verdes.
- Valores em `ParroLevels` (core): limiares, velocidade, tamanho, pontos por semente e a espera.
- Quem já tinha XP de combate nesse arquivo passa a ter esses mesmos pontos como vínculo (150 XP
  viram nível 5). Para zerar, remova o Parro do jogador (`/parro remover`) e dê de novo.

## Diferenças inevitáveis

- **Menu:** o menu do MCPets virou a aba Parro no menu G.
- **Velocidade máxima montado (decisão do servidor):** 17 blocos/s (0,85 bloco/tick) no chão, no
  salto e no planeio. Fica um pouco acima do cavalo do AveronSync a galope (12,5; 15 em estrada com
  vínculo máximo).
- **Planeio montado (decisão do servidor):** é só um quebra-galho. O `pr_ride_glide` do pack plana quase
  reto e soma 0,55 bloco/tick por tick; aqui ele só freia a queda (desce no máximo 0,3 bloco/tick,
  6 blocos/s) e avança no máximo 0,6 bloco/tick (12 blocos/s), sem Slow Falling. Rende uns 2 blocos
  para frente por bloco de queda.
- **Planeio montado limitado (decisão do servidor):** cada voo plana no máximo 3 segundos (60 ticks).
  Depois disso aparece "O Parro cansou de planar!" e ele cai sem planar. A queda a partir desse ponto
  conta como queda normal: o Parro e o cavaleiro tomam o mesmo dano de cavalo vanilla (3 blocos livres).
  O Parro recebe 40% por estar com sela e pode desmaiar (30 s para chamar de novo). Saltos comuns e o
  planeio dentro do tempo não dão dano. Sem cavaleiro, ele continua sem dano de queda (`pr_cancel_fall`).
- **Velocidade montado:** o pack dá Speed ao cavaleiro, e o ModelEngine usa a velocidade dele
  para mover a montaria. Aqui o mesmo bônus (Speed II/III/IV) é aplicado direto na montaria.
- **Assento:** o assento do servidor fica fixo no osso `mount` parado. Para o jogador não afundar no corpo
  quando ele balança (o `walk` e o `run` mexem o corpo até 8 px e inclinam uns 10°), o cliente desenha o
  jogador montado acompanhando o osso `mount` animado: ele desloca só o desenho, e todo cliente faz o mesmo,
  então os outros jogadores também veem. A posição real não muda. Na primeira pessoa a câmera continua no
  assento parado.
- **Valores que o pack não informa:** a regeneração por segundo e a espera de 30 segundos foram assumidas.

## Animações (correção depois da 0.49)

O renderer agora empilha os estados como o ModelEngine faz no pack:

- **Estado padrão (idle/walk/run/swim):** a troca tem transição de 4 ticks (6 no `run`), como os
  `defaultstate{li;lo}` do pack. Antes o clipe novo começava do zero sem transição, e o Parro
  tremia a cada salto. O servidor também espera 4 ticks parado antes de voltar ao idle.
- **Estados de ar:** `jump2`, `jump3` e `jump22` repetem em loop (`l=loop` no `pr_airstate`).
  Antes só o `jump3` repetia e os outros congelavam no último quadro. Entram e saem com o
  `li`/`lo` do pack (4/4, 6/6, 4/6), sem sumir de uma vez no pouso.
- **Ações:** cada clipe usa o lerp do pack (carinho 4/4, `jump1` 2, `summon` 2, `transform` 2/4,
  `transform_back` 4/4, `spawn` lo 4; o resto 1/2). Quando uma ação é trocada por outra, a
  anterior sai suavemente a partir da pose em que estava.
- **Sinais do Blockbench 5 (a causa das poses tortas):** os blueprints são do formato 5.0, em que a
  posição X e as rotações X e Y das animações são somadas direto ao osso. O renderer usa a
  convenção do 4.x, em que esses três valores entram com o sinal invertido; o próprio Blockbench 5
  os inverte ao abrir arquivos antigos. Antes, bico, pescoço, pernas e asas iam para o lado
  contrário. O `import_parro.py` agora converte esses valores para o 4.x.
- **Override:** como no preview do Blockbench, cada camada substitui só os canais que têm keyframe.
- **Tirar a sela:** durante o `transform` do modelo com sela, `saddle1` e `saddle2` ficam
  escondidos (`partvis` do `pr_untransform`).
- **Lockmodel:** durante o carinho, o `summon`/`spawn` e a sela, o corpo fica virado para onde
  estava, sem girar atrás de quem fez o carinho.

- **Física da cauda (segmentos do ModelEngine):** os ossos `seg_root1..N` (3 sem sela, 4 com sela)
  usam o comportamento *Segment* do ModelEngine (wiki: Bone Behaviors → Inverse Kinematics). Cada
  segmento é um elo de corrente: a frente fica presa ao osso pai, e a traseira (o pivô do `seg_`)
  fica parada no mundo, só sendo arrastada com o comprimento fixo ("menor movimento possível"). O
  elo desvia no máximo 50° do pai (`anglelimit=50`, padrão do ModelEngine, já que o pack não chama
  `segment{}`) e volta a ficar reto a 10% por tick. O padrão `extendrate=0.01` deixava a cauda
  dobrada tempo demais, então foi aumentado (decisão do servidor); ela endireita em cerca de 1 s. Tudo abaixo do segmento gira em volta
  do ponto de encaixe, então os pedaços não se separam. A simulação roda no cliente, em coordenadas
  do mundo.
- **Controle montado como o cavalo (decisão do servidor):** W/S andam, e **A/D viram o Parro**, como no
  cavalo do AveronSync: 5° por tick andando para frente, 4° parado e invertido de ré. A câmera fica livre
  e o Parro não anda de lado. O pack seguia a câmera e andava de lado com A/D. Virar também gira o impulso
  do salto e do planeio, então dá para guiar no ar.
- **Degrau da montaria:** o modelo com sela é criado com `model{step=1.125}`. Com sela, o Parro
  sobe blocos inteiros andando (`STEP_HEIGHT` 1,125; sem sela, 0,6).
- **Revisão do blueprint:** fora os segmentos, o único osso especial é o `mount` (assento); `hitbox` e
  `shadow` são metadados. Não há osso de cabeça que siga o olhar (`h_`), as texturas têm um quadro
  só, e as `mcmetas` do arquivo apontam para texturas que não existem nele (sobra do Blockbench).

O renderer compartilhado (`VipPetRenderer`) ganhou só um gancho opcional (`BoneSolver`), usado pela
cauda. Pets, cavalo e animações de entrada não o usam e ficam iguais.

## Importar o pack

```
python tools/import_parro.py "caminho/Parro Pet - Mister Spooky v1.0.1.zip"
```

Lê só os dois `.bbmodel` (formato Blockbench 5) e o ícone. Os ossos de metadado do ModelEngine
(`hitbox`, `shadow`, `mount`) não são desenhados; o `mount` dá a altura do assento (24,5 px).
Gera `assets/averonsync/parro/` e `textures/parro/`, ignorados pelo Git, mais um relatório com
os hashes. Cada modelo leva também `bones` (nome → id do osso), que o renderer usa para esconder a sela.
Blueprints do formato 5.0 ou mais novo têm os sinais das animações convertidos para a convenção 4.x. Os direitos da arte continuam com DepartmentQDE e Mister Spooky.

## Validação

- `.\gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build` (Java 21): build ok.
  `ParroTest` passa nos testes (níveis de vínculo, cadastro e leitura dos 2 modelos com todas as animações).
- No jogo (singleplayer, perfil Dev): idle, seguir com saltos e pouso, carinho e montar foram
  conferidos antes e depois da correção das animações. `ParroTest` agora também confere os ossos da sela e a conversão de sinal.
- **Ainda falta conferir no jogo:** vínculo (sementes, barriga cheia, tamanho e velocidade por nível), água, colocar e
  tirar a sela com o JAR novo, e servidor dedicado.
- O canal do menu mudou para `averonsync-mount-menu-6` e há um canal novo, `averonsync-parro-1`.
  Cliente e servidor precisam estar na mesma versão.

## Servidor sobrecarregado (vale também para o cavalo)

Em servidor dedicado, as montarias andam mais devagar quando o tick médio passa de 50 ms (abaixo de 20 TPS). A velocidade cai de
forma uniforme até 60% em 100 ms por tick (10 TPS) e fica nisso. Ela cai rápido (20% por tick) e volta devagar (2% por tick), para não
oscilar. O cavaleiro vê "Servidor sobrecarregado: a montaria está mais lenta." (no máximo a cada 10 s, e só abaixo de 90%). O objetivo é
não carregar chunks novos tão depressa quando o servidor já está lento. Não vale em singleplayer. Valores em `MountLoad` (core).
Não faz nada contra lag que não seja de carregar terreno.
