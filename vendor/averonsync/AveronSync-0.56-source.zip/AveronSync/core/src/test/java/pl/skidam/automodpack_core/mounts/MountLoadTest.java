package pl.skidam.automodpack_core.mounts;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MountLoadTest {
    @Test void healthyServerKeepsFullSpeed() {
        assertEquals(1, MountLoad.factor(0));
        assertEquals(1, MountLoad.factor(35));
        assertEquals(1, MountLoad.factor(50));
        assertEquals(1, MountLoad.factor(Double.NaN));
        assertEquals(1, MountLoad.factor(-5));
    }
    @Test void overloadSlowsEvenlyDownToTheFloor() {
        assertEquals(0.8, MountLoad.factor(75), 1e-9);
        assertEquals(0.6, MountLoad.factor(100), 1e-9);
        assertEquals(0.6, MountLoad.factor(900), 1e-9);
        assertTrue(MountLoad.factor(60) > MountLoad.factor(70));
    }
    @Test void smoothingSlowsFastAndRecoversSlowly() {
        double down = MountLoad.smooth(1, .6), up = MountLoad.smooth(.6, 1);
        assertEquals(1 - .4 * .2, down, 1e-9);
        assertEquals(.6 + .4 * .02, up, 1e-9);
        assertTrue(1 - down > up - .6);
    }
}
