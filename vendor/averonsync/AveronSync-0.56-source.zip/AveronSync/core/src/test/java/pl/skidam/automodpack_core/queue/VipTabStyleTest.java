package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class VipTabStyleTest {
    private record Entry(String shown, int level) {}

    @Test void colorsPerLevel() {
        assertEquals(0x55FFFF, VipTabStyle.color(1));
        assertEquals(0xFF8C00, VipTabStyle.color(2));
    }
    @Test void levelIsReadBackFromTheTagAndItsColor() {
        assertEquals(2, VipTabStyle.level("[VIP] ", VipTabStyle.COLOR_LEVEL_2));
        assertEquals(1, VipTabStyle.level("[VIP] ", VipTabStyle.COLOR_LEVEL_1));
        assertEquals(0, VipTabStyle.level("[VIP] ", 0xFFFFFF), "a tag in another color is not a VIP");
        assertEquals(0, VipTabStyle.level("Alice", VipTabStyle.COLOR_LEVEL_2), "a colored name without the tag is not a VIP");
        assertEquals(0, VipTabStyle.level(null, 0));
    }
    @Test void tabOrderIsVip2ThenVip1ThenOthersEachAlphabetical() {
        var entries = new ArrayList<>(List.of(
                new Entry("zed", 0), new Entry("[VIP] Bruno", 1), new Entry("Ana", 0), new Entry("[VIP] Zoe", 2),
                new Entry("[VIP] alice", 1), new Entry("[VIP] Caio", 2), new Entry("beto", 0)));
        entries.sort((a, b) -> VipTabStyle.compare(a.level(), VipTabStyle.sortKey(a.shown()), b.level(), VipTabStyle.sortKey(b.shown())));
        assertEquals(List.of("[VIP] Caio", "[VIP] Zoe", "[VIP] alice", "[VIP] Bruno", "Ana", "beto", "zed"),
                entries.stream().map(Entry::shown).toList());
    }
    @Test void sortKeyIgnoresTheTagAndCase() {
        assertEquals("arannis", VipTabStyle.sortKey("[VIP] Arannis"));
        assertEquals("[mage] arannis", VipTabStyle.sortKey("[VIP] [Mage] Arannis"));
        assertEquals("", VipTabStyle.sortKey(null));
    }
}
