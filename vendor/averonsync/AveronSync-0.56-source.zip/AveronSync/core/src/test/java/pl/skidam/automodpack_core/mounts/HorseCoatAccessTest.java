package pl.skidam.automodpack_core.mounts;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HorseCoatAccessTest {
    @Test void vipLevelsUnlockTwoCoatsEachAndOperatorsKeepTheRest() {
        for (HorseCoat coat : HorseCoat.values()) assertTrue(coat.allowed(true, 0), coat.name() + " is always open to operators");
        assertTrue(HorseCoat.BAY.allowed(false, 0));
        assertTrue(HorseCoat.BLACK.allowed(false, 1) && HorseCoat.CHESTNUT.allowed(false, 1));
        assertFalse(HorseCoat.BLACK.allowed(false, 0));
        assertFalse(HorseCoat.PALOMINO.allowed(false, 1) || HorseCoat.PIEBALD.allowed(false, 1));
        assertTrue(HorseCoat.PALOMINO.allowed(false, 2) && HorseCoat.PIEBALD.allowed(false, 2));
        assertTrue(HorseCoat.BLACK.allowed(false, 2), "VIP 2 keeps the VIP 1 coats");
        long open = java.util.Arrays.stream(HorseCoat.values()).filter(c -> c != HorseCoat.BAY && c.allowed(false, 1)).count();
        long open2 = java.util.Arrays.stream(HorseCoat.values()).filter(c -> c != HorseCoat.BAY && c.allowed(false, 2)).count();
        assertEquals(2, open);
        assertEquals(4, open2);
    }
    @Test void unicornZombieAndYakulStayOperatorOnly() {
        for (var coat : new HorseCoat[]{HorseCoat.UNICORN, HorseCoat.ZOMBIE, HorseCoat.YAKUL}) {
            assertFalse(coat.allowed(false, 2), coat.name());
            assertTrue(coat.allowed(true, 0), coat.name());
        }
    }
}
