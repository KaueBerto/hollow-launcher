package pl.skidam.automodpack_core.mounts;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HorseAppleBondTest {
    @Test void levelsOnlyAddSpeedUpToFifteenPercent() {
        assertEquals(1, HorseAppleBond.forApples(0).number());
        assertEquals(1, HorseAppleBond.forApples(1).number());
        assertEquals(2, HorseAppleBond.forApples(2).number());
        assertEquals(6, HorseAppleBond.forApples(20).number());
        assertEquals(10, HorseAppleBond.forApples(40).number());
        assertEquals(10, HorseAppleBond.forApples(9000).number());
        assertEquals(10, HorseAppleBond.LEVELS.length);
        assertEquals(1.0, HorseAppleBond.LEVELS[0].speed(), 1e-9, "level 1 keeps today's speed");
        assertEquals(1.15, HorseAppleBond.MAX.speed(), 1e-9);
        for (int i = 1; i < HorseAppleBond.LEVELS.length; i++)
            assertTrue(HorseAppleBond.LEVELS[i].speed() > HorseAppleBond.LEVELS[i - 1].speed());
        assertNull(HorseAppleBond.next(HorseAppleBond.MAX));
    }
    @Test void progressAndFullBelly() {
        assertEquals("Lv.1 • 0/2 maçãs", HorseAppleBond.progress(0));
        assertEquals("Lv.5 • 15/20 maçãs", HorseAppleBond.progress(15));
        assertEquals("Lv.10 • nível máximo", HorseAppleBond.progress(41));
        assertEquals(30 * 60_000L, HorseAppleBond.FULL_MILLIS);
    }
}
