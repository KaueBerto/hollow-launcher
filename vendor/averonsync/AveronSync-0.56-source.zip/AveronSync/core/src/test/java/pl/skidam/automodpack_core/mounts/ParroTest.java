package pl.skidam.automodpack_core.mounts;

import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import pl.skidam.automodpack_core.pets.CubeeModel;
import java.nio.file.*;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ParroTest {
    @TempDir Path temp;

    @Test void bondLevelsMakeItFasterAndBiggerUpToTheTopSpeed() {
        assertEquals(1, ParroLevels.forBond(0).number());
        assertEquals(1, ParroLevels.forBond(1.9).number());
        assertEquals(2, ParroLevels.forBond(2).number());
        assertEquals(6, ParroLevels.forBond(20).number());
        assertEquals(10, ParroLevels.forBond(5000).number());
        assertEquals(10, ParroLevels.LEVELS.length);
        assertEquals(40, ParroLevels.MAX.threshold());
        for (int i = 1; i < ParroLevels.LEVELS.length; i++) {
            assertTrue(ParroLevels.LEVELS[i].speed() > ParroLevels.LEVELS[i - 1].speed());
            assertTrue(ParroLevels.LEVELS[i].scale() > ParroLevels.LEVELS[i - 1].scale());
            assertTrue(ParroLevels.LEVELS[i].threshold() > ParroLevels.LEVELS[i - 1].threshold());
        }
        assertEquals(1.0, ParroLevels.MAX.speed(), 1e-9, "the top level runs at the full 17 blocks/s");
        assertEquals(12.5, ParroLevels.LEVELS[0].speed() * 17, 1e-9, "level 1 matches the horse's gallop");
        assertEquals(1.0, ParroLevels.LEVELS[0].scale(), 1e-9, "level 1 is the pack's original size");
        assertEquals(1.4, ParroLevels.MAX.scale(), 1e-9, "the top level is 40% bigger");
        assertNull(ParroLevels.next(ParroLevels.MAX));
        assertEquals("Parro Lv.2", ParroLevels.LEVELS[1].name());
    }
    @Test void progressShowsSeedsToTheNextLevel() {
        assertEquals("Lv.1 • 0/2 sementes", ParroLevels.progress(0));
        assertEquals("Lv.3 • 7/9 sementes", ParroLevels.progress(7));
        assertEquals("Lv.10 • nível máximo", ParroLevels.progress(80));
    }
    @Test void registryGrantIsIdempotentAndPersistsExperienceAndSaddle() throws Exception {
        var file = temp.resolve("parro.json"); var registry = new ParroRegistry(file); UUID player = UUID.randomUUID();
        assertTrue(registry.grant(player)); assertFalse(registry.grant(player));
        registry.setExperience(player, 150); registry.setSaddled(player, true);
        assertFalse(registry.grant(player), "a second grant keeps progress");
        var reloaded = new ParroRegistry(file).get(player).orElseThrow();
        assertEquals(150, reloaded.experience()); assertTrue(reloaded.saddled());
        assertTrue(registry.revoke(player)); assertFalse(new ParroRegistry(file).owns(player));
        assertThrows(IllegalStateException.class, () -> registry.setExperience(player, 1));
    }
    @Test void invalidRegistryIsPreserved() throws Exception {
        var file = temp.resolve("parro.json");
        String text = "{\"version\":1,\"players\":{\"" + UUID.randomUUID() + "\":{\"experience\":-5,\"saddled\":false}}}";
        Files.writeString(file, text);
        assertThrows(java.io.IOException.class, () -> new ParroRegistry(file));
        assertEquals(text, Files.readString(file));
    }
    @Test void importedModelsParseWithEveryStateTheSkillsUse() throws Exception {
        var root = Path.of("..", "src", "main", "resources", "assets", "averonsync", "parro");
        org.junit.jupiter.api.Assumptions.assumeTrue(Files.isDirectory(root), "Private Parro artwork must be imported for asset validation");
        var pet = CubeeModel.parseParro(JsonParser.parseString(Files.readString(root.resolve("parro.json"))).getAsJsonObject());
        var saddle = CubeeModel.parseParro(JsonParser.parseString(Files.readString(root.resolve("parro_saddle.json"))).getAsJsonObject());
        for (String clip : new String[]{"idle", "walk", "swim", "hurt", "jump1", "jump2", "jump3", "jump22", "petting1", "petting2",
                "attack1", "attack2", "transform", "transform_back", "summon", "death"}) assertTrue(pet.animations().containsKey(clip), clip);
        for (String clip : new String[]{"idle", "walk", "run", "swim", "hurt", "jump1", "jump2", "jump3", "jump22", "petting1", "petting2",
                "attack1", "attack2_r", "attack2_l", "transform", "spawn", "death"}) assertTrue(saddle.animations().containsKey(clip), clip);
        // The renderer hides these bones while the saddle is sheared off (pack partvis).
        var bones = JsonParser.parseString(Files.readString(root.resolve("parro_saddle.json"))).getAsJsonObject().getAsJsonObject("bones");
        assertTrue(bones.has("saddle1") && bones.has("saddle2"));
        // Blockbench 5 blueprint (petting1 opens the beak with mouth x = -45) converted to the 4.x signs the renderer uses.
        var mouth = saddle.animations().get("petting1").sample(bones.get("mouth").getAsString(), "rotation", 1);
        assertEquals(45, mouth.x(), 1e-6);
        // ModelEngine seg_ bones of the tail, root first, drive the client tail physics.
        assertEquals(4, JsonParser.parseString(Files.readString(root.resolve("parro_saddle.json"))).getAsJsonObject().getAsJsonArray("segments").size());
        assertEquals(3, JsonParser.parseString(Files.readString(root.resolve("parro.json"))).getAsJsonObject().getAsJsonArray("segments").size());
        assertThrows(IllegalArgumentException.class, () -> CubeeModel.parse(JsonParser.parseString(Files.readString(root.resolve("parro.json"))).getAsJsonObject()));
    }
}
