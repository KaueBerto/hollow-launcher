package pl.skidam.automodpack_core.mounts;

import com.google.gson.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Server-thread-only, world-specific Parro ownership: granted by an admin, permanent.
 * Keeps experience and whether the saddle stays on (the pack's pr_saddle_kept).
 * Writes are atomic; a failed write keeps the previous state in memory.
 */
public final class ParroRegistry {
    public record Entry(double experience, boolean saddled) {
        public Entry { if (!Double.isFinite(experience) || experience < 0) throw new IllegalArgumentException("Invalid experience"); }
    }
    private final Path file;
    private Map<UUID, Entry> entries = new TreeMap<>();

    public ParroRegistry(Path file) throws IOException {
        this.file = file.toAbsolutePath();
        if (!Files.exists(this.file)) return;
        try {
            if (Files.size(this.file) > 4_194_304) throw new IllegalArgumentException("Parro registry too large");
            JsonObject root = JsonParser.parseString(Files.readString(this.file)).getAsJsonObject();
            if (root.get("version").getAsInt() != 1) throw new IllegalArgumentException("Unknown version");
            Map<UUID, Entry> read = new TreeMap<>();
            for (var entry : root.getAsJsonObject("players").entrySet()) {
                var value = entry.getValue().getAsJsonObject();
                if (read.put(UUID.fromString(entry.getKey()), new Entry(value.get("experience").getAsDouble(),
                        value.get("saddled").getAsBoolean())) != null) throw new IllegalArgumentException("Duplicate player");
            }
            entries = read;
        } catch (RuntimeException e) { throw new IOException("Invalid Parro registry; original preserved: " + file, e); }
    }

    public Optional<Entry> get(UUID player) { return Optional.ofNullable(entries.get(player)); }
    public boolean owns(UUID player) { return entries.containsKey(player); }

    /** Idempotent grant: an existing Parro keeps its experience and saddle. */
    public boolean grant(UUID player) throws IOException {
        if (entries.containsKey(Objects.requireNonNull(player))) return false;
        update(player, new Entry(0, false)); return true;
    }
    public boolean revoke(UUID player) throws IOException {
        if (!entries.containsKey(player)) return false;
        var updated = new TreeMap<>(entries); updated.remove(player); save(updated); entries = updated; return true;
    }
    public void setExperience(UUID player, double experience) throws IOException {
        var entry = entries.get(player); if (entry == null) throw new IllegalStateException("No Parro");
        if (entry.experience() != experience) update(player, new Entry(experience, entry.saddled()));
    }
    public void setSaddled(UUID player, boolean saddled) throws IOException {
        var entry = entries.get(player); if (entry == null) throw new IllegalStateException("No Parro");
        if (entry.saddled() != saddled) update(player, new Entry(entry.experience(), saddled));
    }
    private void update(UUID player, Entry entry) throws IOException {
        var updated = new TreeMap<>(entries); updated.put(player, entry); save(updated); entries = updated;
    }
    private void save(Map<UUID, Entry> updated) throws IOException {
        Files.createDirectories(file.getParent());
        JsonObject root = new JsonObject(), players = new JsonObject();
        root.addProperty("version", 1);
        updated.forEach((id, entry) -> {
            JsonObject value = new JsonObject();
            value.addProperty("experience", entry.experience()); value.addProperty("saddled", entry.saddled());
            players.add(id.toString(), value);
        });
        root.add("players", players);
        Path temp = Files.createTempFile(file.getParent(), "averonsync-parro-", ".tmp");
        try {
            Files.writeString(temp, new GsonBuilder().setPrettyPrinting().create().toJson(root));
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
    }
}
