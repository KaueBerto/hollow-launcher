package pl.skidam.automodpack_core.mounts;

/**
 * Bond levels of the Parro (server design; the pack's combat levels were dropped). The owner feeds it seeds,
 * each seed adds one bond point, and every level makes it faster and bigger. Level 1 is the pack's size
 * and the AveronSync horse's gallop (12.5 blocks/s); the top level is 40% bigger and runs at 17 blocks/s. Points are stored under the registry's old "experience" name.
 */
public final class ParroLevels {
    /**
     * @param threshold bond points (seeds) needed to reach the level
     * @param speed     share of the mount's top speed (1 = 17 blocks/s)
     * @param scale     body size relative to the pack's model (1 = original size)
     */
    public record Level(int number, int threshold, double speed, double scale) {
        public String name() { return "Parro Lv." + number; }
    }
    /** Mount speed in blocks/s at level 1 and at the top; the levels in between are evenly spaced. */
    private static final double START_BLOCKS_PER_SECOND = 12.5, TOP_BLOCKS_PER_SECOND = 17, TOP_SCALE = 1.4;
    /** Seeds needed per level: 40 in total, with the biggest gaps in the middle. */
    private static final int[] THRESHOLDS = {0, 2, 5, 9, 14, 20, 26, 31, 36, 40};
    public static final Level[] LEVELS = build();
    private static Level[] build() {
        int n = THRESHOLDS.length;
        Level[] out = new Level[n];
        for (int i = 0; i < n; i++)
            out[i] = new Level(i + 1, THRESHOLDS[i], (START_BLOCKS_PER_SECOND + (TOP_BLOCKS_PER_SECOND - START_BLOCKS_PER_SECOND) * i / (n - 1)) / TOP_BLOCKS_PER_SECOND,
                    1 + (TOP_SCALE - 1) * i / (n - 1));
        return out;
    }
    public static final Level MAX = LEVELS[LEVELS.length - 1];
    /** The Parro is no combat pet: fixed health, slow regeneration per second. */
    public static final double MAX_HEALTH = 20, REGENERATION = .5;
    /** Bond points per seed, and how long it stays full ("barriga cheia") after eating. */
    public static final int BOND_PER_SEED = 1;
    public static final long FULL_MILLIS = 30 * 60_000L;

    public static Level forBond(double points) {
        Level result = LEVELS[0];
        for (Level level : LEVELS) if (points >= level.threshold()) result = level;
        return result;
    }
    /** Next level, or {@code null} at the top. */
    public static Level next(Level level) { return level.number() >= LEVELS.length ? null : LEVELS[level.number()]; }
    /** "Lv.2 • 7/15 sementes", or "Lv.5 • nível máximo". */
    public static String progress(double points) {
        Level level = forBond(points), next = next(level);
        long seeds = (long) Math.max(0, Math.floor(points));
        return "Lv." + level.number() + " • " + (next == null ? "nível máximo" : seeds + "/" + next.threshold() + " sementes");
    }
    private ParroLevels() {}
}
