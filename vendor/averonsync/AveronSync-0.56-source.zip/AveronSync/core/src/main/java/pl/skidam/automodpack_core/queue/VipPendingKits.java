package pl.skidam.automodpack_core.queue;

import com.google.gson.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Kits that were earned but did not fit in the inventory at redemption time, kept per nickname until {@code /kitvip}
 * delivers them. Server-thread only.
 */
public final class VipPendingKits {
    private final Path file;
    private Map<String, List<Integer>> players;

    public VipPendingKits(Path file) throws IOException {
        this.file = file.toAbsolutePath();
        this.players = read();
    }

    public List<Integer> levels(String nickname) {
        return players.getOrDefault(VipRegistry.normalize(nickname), List.of());
    }

    public void add(String nickname, int level) throws IOException {
        String name = VipRegistry.normalize(nickname);
        Map<String, List<Integer>> updated = copy();
        updated.computeIfAbsent(name, key -> new ArrayList<>()).add(level);
        save(updated);
        players = updated;
    }

    /** Removes one pending kit of this level after it was delivered. */
    public void remove(String nickname, int level) throws IOException {
        String name = VipRegistry.normalize(nickname);
        Map<String, List<Integer>> updated = copy();
        var list = updated.get(name);
        if (list == null || !list.remove(Integer.valueOf(level))) return;
        if (list.isEmpty()) updated.remove(name);
        save(updated);
        players = updated;
    }

    private Map<String, List<Integer>> copy() {
        Map<String, List<Integer>> result = new TreeMap<>();
        players.forEach((name, list) -> result.put(name, new ArrayList<>(list)));
        return result;
    }

    private Map<String, List<Integer>> read() throws IOException {
        if (!Files.exists(file)) return new TreeMap<>();
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.get("version").getAsInt() != 1) throw new IllegalArgumentException("Unknown pending kits file version");
            Map<String, List<Integer>> result = new TreeMap<>();
            for (var entry : root.getAsJsonObject("players").entrySet()) {
                List<Integer> list = new ArrayList<>();
                for (var level : entry.getValue().getAsJsonArray()) {
                    int value = level.getAsInt();
                    if (value < 1 || value > VipRegistry.MAX_LEVEL) throw new IllegalArgumentException("Invalid kit level");
                    list.add(value);
                }
                if (!list.isEmpty()) result.put(VipRegistry.normalize(entry.getKey()), list);
            }
            return result;
        } catch (RuntimeException e) {
            throw new IOException("Invalid pending kits file: " + file + "; original file preserved", e);
        }
    }

    private void save(Map<String, List<Integer>> updated) throws IOException {
        JsonObject root = new JsonObject(), list = new JsonObject();
        root.addProperty("version", 1);
        updated.forEach((name, levels) -> {
            JsonArray array = new JsonArray();
            levels.forEach(array::add);
            list.add(name, array);
        });
        root.add("players", list);
        AtomicJson.write(file, root);
    }
}
