package pl.skidam.automodpack_core.mounts;

/**
 * Apple bond of the AveronSync horse (server design, next to the older travel bond in {@link HorseBond}).
 * The owner feeds it apples; each apple adds one point, then the horse is full for half an hour. Every level
 * makes the ridden horse a little faster (only speed). Points are stored on the player, not on the horse.
 */
public final class HorseAppleBond {
    /** @param threshold apples needed to reach the level; @param speed ridden speed multiplier */
    public record Level(int number, int threshold, double speed) {}
    /** Apples needed per level (same curve as the Parro's seeds) and the extra speed at the top level. */
    private static final int[] THRESHOLDS = {0, 2, 5, 9, 14, 20, 26, 31, 36, 40};
    private static final double TOP_BONUS = .15;
    public static final Level[] LEVELS = build();
    private static Level[] build() {
        int n = THRESHOLDS.length;
        Level[] out = new Level[n];
        for (int i = 0; i < n; i++) out[i] = new Level(i + 1, THRESHOLDS[i], 1 + TOP_BONUS * i / (n - 1));
        return out;
    }
    public static final Level MAX = LEVELS[LEVELS.length - 1];
    /** How long the horse stays full ("barriga cheia") after an apple. */
    public static final long FULL_MILLIS = 30 * 60_000L;

    public static Level forApples(int apples) {
        Level result = LEVELS[0];
        for (Level level : LEVELS) if (apples >= level.threshold()) result = level;
        return result;
    }
    /** Next level, or {@code null} at the top. */
    public static Level next(Level level) { return level.number() >= LEVELS.length ? null : LEVELS[level.number()]; }
    /** "Lv.2 • 7/12 maçãs", or "Lv.5 • nível máximo". */
    public static String progress(int apples) {
        Level level = forApples(apples), next = next(level);
        return "Lv." + level.number() + " • " + (next == null ? "nível máximo" : Math.max(0, apples) + "/" + next.threshold() + " maçãs");
    }
    private HorseAppleBond() {}
}
