package pl.skidam.automodpack_core.mounts;

/**
 * Slows ridden mounts when the server is overloaded, so riding fast into new terrain does not pile chunk loading on top of
 * an already slow tick. Nothing changes while a tick takes {@link #START_MS} or less (20 TPS); the speed then falls evenly
 * to {@link #MIN_FACTOR} at {@link #FULL_MS} per tick (10 TPS) and stays there.
 */
public final class MountLoad {
    public static final double START_MS = 50, FULL_MS = 100, MIN_FACTOR = .6;
    /** Ridden speed multiplier for an average tick time in milliseconds. Invalid values count as a healthy server. */
    public static double factor(double averageTickMs) {
        if (!(averageTickMs > START_MS)) return 1;
        if (averageTickMs >= FULL_MS) return MIN_FACTOR;
        return 1 - (1 - MIN_FACTOR) * (averageTickMs - START_MS) / (FULL_MS - START_MS);
    }
    /** One smoothing step: slows down quickly (20% per tick) and recovers slowly (2% per tick), so it never flaps. */
    public static double smooth(double current, double target) {
        return current + (target - current) * (target < current ? .2 : .02);
    }
    private MountLoad() {}
}
