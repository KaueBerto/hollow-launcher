package pl.skidam.automodpack_core.queue;

import com.google.gson.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

/**
 * Single-use VIP redemption codes. Only the SHA-256 of each code is stored, so reading the file (or a leaked backup)
 * does not reveal a usable code. A code is {@code AVRN-XXXX-XXXX-XXXX}: 12 random characters from an alphabet without
 * look-alikes (no I, L, O, 0, 1), about 59 bits. Server-thread only.
 */
public final class VipCodes {
    static final String ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
    public static final int LENGTH = 12, MAX_BATCH = 20;
    private final Path file;
    private final SecureRandom random = new SecureRandom();
    private Map<String, int[]> codes; // hash -> {level}; createdAt kept in the file only

    public VipCodes(Path file) throws IOException {
        this.file = file.toAbsolutePath();
        this.codes = read();
    }

    /** Accepts lowercase, spaces and dashes; returns the 12 plain characters or throws on anything else. */
    public static String normalize(String input) {
        if (input == null) throw new IllegalArgumentException("Codigo invalido.");
        String text = input.toUpperCase(Locale.ROOT).replaceAll("[\\s-]", "");
        if (text.startsWith("AVRN") && text.length() == LENGTH + 4) text = text.substring(4);
        if (text.length() != LENGTH) throw new IllegalArgumentException("Codigo invalido.");
        for (char c : text.toCharArray()) if (ALPHABET.indexOf(c) < 0) throw new IllegalArgumentException("Codigo invalido.");
        return text;
    }

    public static String format(String plain) {
        return "AVRN-" + plain.substring(0, 4) + "-" + plain.substring(4, 8) + "-" + plain.substring(8, 12);
    }

    static String hash(String plain) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(plain.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (java.security.NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }

    /** Creates {@code count} new codes of a VIP level, saved in one write. The returned codes are shown once and never stored in clear. */
    public List<String> generate(int level, int count, long now) throws IOException {
        if (level < 1 || level > VipRegistry.MAX_LEVEL) throw new IllegalArgumentException("Nivel VIP invalido: use 1 a " + VipRegistry.MAX_LEVEL + ".");
        if (count < 1 || count > MAX_BATCH) throw new IllegalArgumentException("Quantidade invalida: use 1 a " + MAX_BATCH + ".");
        Map<String, int[]> updated = new TreeMap<>(codes);
        Map<String, Long> created = new TreeMap<>(createdAt);
        List<String> result = new ArrayList<>();
        while (result.size() < count) {
            StringBuilder plain = new StringBuilder();
            for (int i = 0; i < LENGTH; i++) plain.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
            String key = hash(plain.toString());
            if (updated.putIfAbsent(key, new int[]{level}) != null) continue;
            created.put(key, now);
            result.add(format(plain.toString()));
        }
        save(updated, created);
        codes = updated; createdAt = created;
        return result;
    }

    /** Level of an unused code, empty when it does not exist (nothing is consumed). */
    public OptionalInt peek(String plain) {
        int[] entry = codes.get(hash(plain));
        return entry == null ? OptionalInt.empty() : OptionalInt.of(entry[0]);
    }

    /** Consumes a code: the file is rewritten without it before the level is returned, so it can never be used twice. */
    public OptionalInt redeem(String plain) throws IOException {
        String key = hash(plain);
        int[] entry = codes.get(key);
        if (entry == null) return OptionalInt.empty();
        Map<String, int[]> updated = new TreeMap<>(codes); updated.remove(key);
        Map<String, Long> created = new TreeMap<>(createdAt); created.remove(key);
        save(updated, created);
        codes = updated; createdAt = created;
        return OptionalInt.of(entry[0]);
    }

    /** Puts a consumed code back when granting the VIP failed afterwards. */
    public void restore(String plain, int level, long now) throws IOException {
        Map<String, int[]> updated = new TreeMap<>(codes); updated.put(hash(plain), new int[]{level});
        Map<String, Long> created = new TreeMap<>(createdAt); created.put(hash(plain), now);
        save(updated, created);
        codes = updated; createdAt = created;
    }

    public boolean revoke(String plain) throws IOException { return redeem(plain).isPresent(); }

    /** Unused codes per level. */
    public Map<Integer, Integer> counts() {
        Map<Integer, Integer> result = new TreeMap<>();
        codes.values().forEach(entry -> result.merge(entry[0], 1, Integer::sum));
        return result;
    }

    private Map<String, Long> createdAt = new TreeMap<>();

    private Map<String, int[]> read() throws IOException {
        if (!Files.exists(file)) return new TreeMap<>();
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.get("version").getAsInt() != 1) throw new IllegalArgumentException("Unknown VIP codes file version");
            Map<String, int[]> result = new TreeMap<>();
            Map<String, Long> created = new TreeMap<>();
            for (var entry : root.getAsJsonObject("codes").entrySet()) {
                if (!entry.getKey().matches("[0-9a-f]{64}")) throw new IllegalArgumentException("Invalid code hash");
                JsonObject value = entry.getValue().getAsJsonObject();
                int level = value.get("level").getAsInt();
                if (level < 1 || level > VipRegistry.MAX_LEVEL) throw new IllegalArgumentException("Invalid code level");
                result.put(entry.getKey(), new int[]{level});
                created.put(entry.getKey(), value.has("createdAt") ? value.get("createdAt").getAsLong() : 0L);
            }
            createdAt = created;
            return result;
        } catch (RuntimeException e) {
            throw new IOException("Invalid VIP codes file: " + file + "; original file preserved", e);
        }
    }

    private void save(Map<String, int[]> updated, Map<String, Long> created) throws IOException {
        JsonObject root = new JsonObject(), list = new JsonObject();
        root.addProperty("version", 1);
        updated.forEach((key, entry) -> {
            JsonObject value = new JsonObject();
            value.addProperty("level", entry[0]);
            value.addProperty("createdAt", created.getOrDefault(key, 0L));
            list.add(key, value);
        });
        root.add("codes", list);
        AtomicJson.write(file, root);
    }
}
