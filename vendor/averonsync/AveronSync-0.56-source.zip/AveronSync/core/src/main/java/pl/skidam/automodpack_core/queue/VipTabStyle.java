package pl.skidam.automodpack_core.queue;

/**
 * Shared look and order of the TAB list: "[VIP]" before the name in the level's color (VIP 1 light blue, VIP 2 orange),
 * VIP 2 first, then VIP 1, then everyone else, each group alphabetical. The server writes the tag and color; the client
 * reads them back from the name it received to sort, so no extra network message is needed.
 */
public final class VipTabStyle {
    public static final String TAG = "[VIP]";
    public static final String PREFIX = TAG + " ";
    public static final int COLOR_LEVEL_1 = 0x55FFFF, COLOR_LEVEL_2 = 0xFF8C00;

    public static int color(int level) { return level >= 2 ? COLOR_LEVEL_2 : COLOR_LEVEL_1; }

    /** VIP level shown by a TAB name: its first text must be the tag and its color the level's color; otherwise 0. */
    public static int level(String firstText, int firstColor) {
        if (firstText == null || !firstText.startsWith(TAG)) return 0;
        if (firstColor == COLOR_LEVEL_2) return 2;
        return firstColor == COLOR_LEVEL_1 ? 1 : 0;
    }

    /** Alphabetical key: the shown name without the VIP tag, case-insensitive. */
    public static String sortKey(String shown) {
        String text = shown == null ? "" : shown.strip();
        if (text.startsWith(PREFIX)) text = text.substring(PREFIX.length());
        return text.toLowerCase(java.util.Locale.ROOT);
    }

    /** Order of two TAB entries: higher level first, then alphabetical. Negative means {@code a} comes first. */
    public static int compare(int levelA, String keyA, int levelB, String keyB) {
        if (levelA != levelB) return Integer.compare(levelB, levelA);
        return keyA.compareTo(keyB);
    }
    private VipTabStyle() {}
}
