package pl.skidam.automodpack_core.entrance;

import pl.skidam.automodpack_core.pets.CubeeModel;
import pl.skidam.automodpack_core.pets.PetAnimation.Vec;
import java.util.*;

/**
 * Builds the owner's skin cubes for a ModelEngine "player limb" bone, using the
 * vanilla 64x64 skin layout and Blockbench box-UV face order. Face texture -1
 * means "the owner's skin" for the renderer.
 */
public final class PlayerSkinBox {
    public static final int SKIN_TEXTURE = -1;
    public static final Set<String> LIMBS = Set.of("head", "body", "left_arm", "right_arm", "left_leg", "right_leg");
    private record Layout(int w, int h, int d, int u, int v, int overlayU, int overlayV, double overlayInflate) {}

    private static Layout layout(String limb, boolean slim) {
        int arm = slim ? 3 : 4;
        return switch (limb) {
            case "head" -> new Layout(8, 8, 8, 0, 0, 32, 0, .5);
            case "body" -> new Layout(8, 12, 4, 16, 16, 16, 32, .25);
            case "right_arm" -> new Layout(arm, 12, 4, 40, 16, 40, 32, .25);
            case "left_arm" -> new Layout(arm, 12, 4, 32, 48, 48, 48, .25);
            case "right_leg" -> new Layout(4, 12, 4, 0, 16, 0, 32, .25);
            case "left_leg" -> new Layout(4, 12, 4, 16, 48, 0, 48, .25);
            default -> throw new IllegalArgumentException("Unknown player limb");
        };
    }

    /** Box UV of a w×h×d cube at (u, v), in Blockbench face orientation. */
    public static Map<String, double[]> boxUv(int w, int h, int d, int u, int v) {
        Map<String, double[]> faces = new LinkedHashMap<>();
        faces.put("north", new double[]{u + d, v + d, u + d + w, v + d + h});
        faces.put("east", new double[]{u, v + d, u + d, v + d + h});
        faces.put("south", new double[]{u + 2 * d + w, v + d, u + 2 * d + 2 * w, v + d + h});
        faces.put("west", new double[]{u + d + w, v + d, u + 2 * d + w, v + d + h});
        faces.put("up", new double[]{u + d + w, v + d, u + d, v});
        faces.put("down", new double[]{u + d + 2 * w, v, u + d + w, v + d});
        return faces;
    }

    /**
     * Skin cube replacing the placeholder. Arms keep their inner edge (towards x=0)
     * and take the skin's arm width, so wide and slim skins both map correctly.
     */
    public static CubeeModel.Cube cube(CubeeModel.Cube placeholder, String limb, boolean slim, boolean overlay) {
        var l = layout(limb, slim);
        Vec from = placeholder.from(), to = placeholder.to();
        double x0 = Math.min(from.x(), to.x()), x1 = Math.max(from.x(), to.x());
        if (limb.endsWith("_arm")) {
            if (Math.abs(x0) < Math.abs(x1)) x1 = x0 + l.w; else x0 = x1 - l.w;
        }
        Map<String, CubeeModel.Face> faces = new HashMap<>();
        boxUv(l.w, l.h, l.d, overlay ? l.overlayU : l.u, overlay ? l.overlayV : l.v)
                .forEach((side, uv) -> faces.put(side, new CubeeModel.Face(SKIN_TEXTURE, uv, 0)));
        return new CubeeModel.Cube(new Vec(x0, Math.min(from.y(), to.y()), Math.min(from.z(), to.z())),
                new Vec(x1, Math.max(from.y(), to.y()), Math.max(from.z(), to.z())), placeholder.origin(), placeholder.rotation(),
                overlay ? l.overlayInflate : 0, Map.copyOf(faces), null);
    }
    private PlayerSkinBox() {}
}
