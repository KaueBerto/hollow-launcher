package pl.skidam.automodpack_core.pets;

import java.util.*;

/**
 * Pets by VIP level: level 1 has three pets, level 2 adds three more (six in total).
 * Other levels unlock nothing; operators may use the whole catalog.
 */
public final class VipPetAccess {
    public static final int MAX_LEVEL = 2;
    private static final List<String> LEVEL_ONE = List.of("badlands", "birch", "dripstone");
    private static final List<String> LEVEL_TWO = List.of("cherry_blossom", "deep_dark", "nether_portal");
    /** Lowest VIP level that unlocks {@code pet}, or 0 when no level does. */
    public static int requiredLevel(String pet) { return LEVEL_ONE.contains(pet) ? 1 : LEVEL_TWO.contains(pet) ? 2 : 0; }
    public static boolean allows(int level, String pet) {
        int required = requiredLevel(pet);
        return required > 0 && level >= required && level <= MAX_LEVEL;
    }
    /** Level 1 pets first, then level 2. */
    public static List<PetCatalog.Pet> available(int level) {
        List<PetCatalog.Pet> result = new ArrayList<>();
        for (var ids : List.of(LEVEL_ONE, LEVEL_TWO))
            for (var id : ids) PetCatalog.find(id).filter(p -> allows(level, p.id())).ifPresent(result::add);
        return List.copyOf(result);
    }
    public static String visibleSelection(int level, String selected) { return selected != null && allows(level,selected) ? selected : ""; }
    public static boolean allows(int level, String pet, boolean operator) {
        return operator ? PetCatalog.contains(pet) : allows(level,pet);
    }
    public static List<PetCatalog.Pet> available(int level, boolean operator) {
        return operator ? PetCatalog.ALL : available(level);
    }
    public static String visibleSelection(int level, String selected, boolean operator) {
        return selected!=null && allows(level,selected,operator) ? selected : "";
    }
    private VipPetAccess() {}
}
