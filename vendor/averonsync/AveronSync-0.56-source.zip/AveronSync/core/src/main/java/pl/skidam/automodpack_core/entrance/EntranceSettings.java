package pl.skidam.automodpack_core.entrance;

import com.google.gson.*;
import pl.skidam.automodpack_core.queue.VipRegistry;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Server-thread-only persistence for join/leave animations: who may use them
 * ({@code vip} or {@code todos}) and each player's choice, by nickname.
 * Writes are atomic; a failed write keeps the previous state in memory.
 */
public final class EntranceSettings {
    public enum Access { VIP("vip"), ALL("todos");
        public final String id; Access(String id) { this.id = id; }
        public static Optional<Access> parse(String id) { return Arrays.stream(values()).filter(a -> a.id.equals(id)).findFirst(); }
    }
    private final Path file;
    private Access access = Access.VIP;
    private Map<String, String> choices = new TreeMap<>();

    public EntranceSettings(Path file) throws IOException {
        this.file = file.toAbsolutePath();
        if (!Files.exists(file)) return;
        try {
            if (Files.size(file) > 1_048_576) throw new IllegalArgumentException("Entrance settings too large");
            var root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.get("version").getAsInt() != 1) throw new IllegalArgumentException("Unknown version");
            access = Access.parse(root.get("access").getAsString()).orElseThrow(() -> new IllegalArgumentException("Unknown access"));
            for (var entry : root.getAsJsonObject("players").entrySet()) {
                String name = VipRegistry.normalize(entry.getKey()), choice = entry.getValue().getAsString();
                if (!EntranceCatalog.validChoice(choice) || choices.putIfAbsent(name, choice) != null)
                    throw new IllegalArgumentException("Unknown animation or duplicate nickname");
            }
        } catch (RuntimeException e) { throw new IOException("Invalid entrance animation settings; original file preserved", e); }
    }
    public Access access() { return access; }
    /** Explicit choice of the player; empty means "use the default of their VIP level". */
    public Optional<String> storedChoice(String nickname) { return Optional.ofNullable(choices.get(VipRegistry.normalize(nickname))); }
    /** Stored choice, or the default for {@code vipLevel} (see {@link EntranceCatalog#defaultChoice}). */
    public String choice(String nickname, int vipLevel) { return storedChoice(nickname).orElse(EntranceCatalog.defaultChoice(vipLevel)); }
    /** {@code null} clears the choice so the VIP level default applies again. */
    public void setChoice(String nickname, String choice) throws IOException {
        if (choice != null && !EntranceCatalog.validChoice(choice)) throw new IllegalArgumentException("Unknown animation");
        var updated = new TreeMap<>(choices);
        if (choice == null) updated.remove(VipRegistry.normalize(nickname));
        else updated.put(VipRegistry.normalize(nickname), choice);
        save(access, updated);
    }
    public void setAccess(Access value) throws IOException { save(Objects.requireNonNull(value), choices); }

    private void save(Access newAccess, Map<String, String> newChoices) throws IOException {
        if (newAccess == access && newChoices.equals(choices) && Files.exists(file)) return;
        JsonObject root = new JsonObject(), players = new JsonObject();
        root.addProperty("version", 1); root.addProperty("access", newAccess.id);
        newChoices.forEach(players::addProperty); root.add("players", players);
        Files.createDirectories(file.getParent());
        Path temp = Files.createTempFile(file.getParent(), "averonsync-entrance-", ".tmp");
        try {
            Files.writeString(temp, new GsonBuilder().setPrettyPrinting().create().toJson(root));
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
            access = newAccess; choices = new TreeMap<>(newChoices);
        } finally { Files.deleteIfExists(temp); }
    }
}
