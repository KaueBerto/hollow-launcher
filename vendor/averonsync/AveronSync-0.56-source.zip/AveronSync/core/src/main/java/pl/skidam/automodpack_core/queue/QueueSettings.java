package pl.skidam.automodpack_core.queue;

/** Serialized under entryQueue in automodpack/automodpack-server.json. */
public final class QueueSettings {
    public boolean enabled = true;
    public int maxOnlinePlayers = 0; // 0 follows the native max-players setting
    public boolean opsOnly = false;

    public int effectivePlayerLimit(int nativeLimit) {
        if (opsOnly) return 0;
        return maxOnlinePlayers <= 0 ? Math.max(0, nativeLimit) : Math.max(0, Math.min(nativeLimit, maxOnlinePlayers));
    }

    public boolean hasRoom(int online, int admitted, int nativeLimit) {
        return (long) online + admitted < effectivePlayerLimit(nativeLimit);
    }
    public int maxQueuedPlayers = 100;
    /** Players let in at the same time while the server is healthy; falls back to 1 when ticks run long (see {@link #concurrencyFor}). */
    public int maxConcurrentAdmissions = 2;
    public int admissionIntervalSeconds = 5;
    public int maxWaitSeconds = 1800;
    public int admissionTimeoutSeconds = 120;

    /** Average tick time (ms) above which only one player is admitted at a time. 50 ms is a server running at 20 TPS. */
    public static final double BUSY_TICK_MS = 35;

    /** Smart admission: the configured concurrency on a healthy server, a single player at a time on a busy one. */
    public int concurrencyFor(double averageTickMs) {
        int configured = Math.max(1, Math.min(Math.max(1, Math.min(1000, maxQueuedPlayers)), maxConcurrentAdmissions));
        return averageTickMs > BUSY_TICK_MS ? 1 : configured;
    }

    public AdmissionQueue createQueue() {
        return createQueue(player -> false);
    }

    public AdmissionQueue createQueue(java.util.function.Predicate<String> priority) {
        int capacity = Math.max(1, Math.min(1000, maxQueuedPlayers));
        return new AdmissionQueue(capacity, Math.max(1, Math.min(capacity, maxConcurrentAdmissions)),
                Math.max(1, Math.min(300, admissionIntervalSeconds)) * 1000L,
                Math.max(10, Math.min(3600, maxWaitSeconds)) * 1000L,
                Math.max(10, Math.min(300, admissionTimeoutSeconds)) * 1000L, priority);
    }
}
