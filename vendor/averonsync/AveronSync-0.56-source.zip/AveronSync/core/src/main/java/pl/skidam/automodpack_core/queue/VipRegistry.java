package pl.skidam.automodpack_core.queue;

import com.google.gson.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Server-thread-only nickname registry. Expiration timestamps are UTC epoch milliseconds.
 * VIP levels (1 or 2) are kept in a separate "levels" object of the same version-1 file,
 * so older builds still read the expirations; a missing level means level 1.
 */
public final class VipRegistry {
    public static final long DURATION_MILLIS = 30L * 86_400_000L;
    public static final int MAX_LEVEL = 2;
    private final Path file;
    private Map<String, Long> entries;
    private Map<String, Integer> levels = new TreeMap<>();

    public VipRegistry(Path file) throws IOException {
        this.file = file.toAbsolutePath();
        this.entries = read();
    }

    public static String normalize(String nickname) {
        if (nickname == null || !nickname.matches("[A-Za-z0-9_]{1,16}"))
            throw new IllegalArgumentException("Nick invalido: use 1 a 16 letras, numeros ou underscore.");
        return nickname.toLowerCase(Locale.ROOT);
    }

    public boolean isVip(String nickname, long now) {
        return expiresAt(nickname) > now;
    }

    public long expiresAt(String nickname) { return entries.getOrDefault(normalize(nickname), 0L); }

    /** Stored level of a registered nick (active or expired), 0 when not registered. */
    public int storedLevel(String nickname) {
        String name = normalize(nickname);
        return entries.containsKey(name) ? levels.getOrDefault(name, 1) : 0;
    }

    /** Level of an active VIP, 0 when not VIP now. */
    public int level(String nickname, long now) { return isVip(nickname, now) ? storedLevel(nickname) : 0; }

    /** Grant or renew at level 1, keeping a higher level already stored for this nick. */
    public long grant(String nickname, long now) throws IOException {
        return grant(nickname, now, Math.max(1, storedLevel(nickname)));
    }

    /** Every grant or renewal expires exactly 30 days from now; remaining time does not accumulate. */
    public long grant(String nickname, long now, int level) throws IOException {
        if (level < 1 || level > MAX_LEVEL) throw new IllegalArgumentException("Nivel VIP invalido: use 1 a " + MAX_LEVEL + ".");
        String name = normalize(nickname);
        long expiry = Math.addExact(now, DURATION_MILLIS);
        Map<String, Long> updated = new TreeMap<>(entries);
        updated.put(name, expiry);
        Map<String, Integer> updatedLevels = new TreeMap<>(levels);
        if (level == 1) updatedLevels.remove(name); else updatedLevels.put(name, level);
        save(updated, updatedLevels);
        entries = updated; levels = updatedLevels;
        return expiry;
    }

    public boolean revoke(String nickname) throws IOException {
        String name = normalize(nickname);
        if (!entries.containsKey(name)) return false;
        Map<String, Long> updated = new TreeMap<>(entries);
        updated.remove(name);
        Map<String, Integer> updatedLevels = new TreeMap<>(levels);
        updatedLevels.remove(name);
        save(updated, updatedLevels);
        entries = updated; levels = updatedLevels;
        return true;
    }

    public Map<String, Long> active(long now) {
        Map<String, Long> result = new TreeMap<>();
        entries.forEach((name, expiry) -> { if (expiry > now) result.put(name, expiry); });
        return Collections.unmodifiableMap(result);
    }

    private Map<String, Long> read() throws IOException {
        if (!Files.exists(file)) return new TreeMap<>();
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.get("version").getAsInt() != 1) throw new IllegalArgumentException("Unknown VIP file version");
            Map<String, Long> result = new TreeMap<>();
            for (var entry : root.getAsJsonObject("players").entrySet()) {
                String name = normalize(entry.getKey());
                var value = entry.getValue().getAsJsonPrimitive();
                if (!value.isNumber()) throw new IllegalArgumentException("Non-numeric expiration");
                long expiry = value.getAsBigDecimal().longValueExact();
                if (expiry <= 0 || result.putIfAbsent(name, expiry) != null)
                    throw new IllegalArgumentException("Invalid/duplicate VIP entry");
            }
            Map<String, Integer> readLevels = new TreeMap<>();
            if (root.has("levels")) for (var entry : root.getAsJsonObject("levels").entrySet()) {
                String name = normalize(entry.getKey());
                int level = entry.getValue().getAsJsonPrimitive().getAsBigDecimal().intValueExact();
                if (level < 1 || level > MAX_LEVEL || !result.containsKey(name) || readLevels.putIfAbsent(name, level) != null)
                    throw new IllegalArgumentException("Invalid/duplicate VIP level");
                if (level == 1) readLevels.remove(name);
            }
            levels = readLevels;
            return result;
        } catch (RuntimeException e) {
            throw new IOException("Invalid VIP file: " + file + "; original file preserved", e);
        }
    }

    private void save(Map<String, Long> updated, Map<String, Integer> updatedLevels) throws IOException {
        Files.createDirectories(file.getParent());
        JsonObject root = new JsonObject(), players = new JsonObject();
        root.addProperty("version", 1);
        updated.forEach(players::addProperty);
        root.add("players", players);
        if (!updatedLevels.isEmpty()) {
            JsonObject levelsJson = new JsonObject();
            updatedLevels.forEach(levelsJson::addProperty);
            root.add("levels", levelsJson);
        }
        Path temp = Files.createTempFile(file.getParent(), "averonsync-vips-", ".tmp");
        try {
            Files.writeString(temp, new GsonBuilder().setPrettyPrinting().create().toJson(root));
            if (Files.exists(file) && Files.getFileAttributeView(file, java.nio.file.attribute.PosixFileAttributeView.class) != null)
                Files.setPosixFilePermissions(temp, Files.getPosixFilePermissions(file));
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
    }
}
