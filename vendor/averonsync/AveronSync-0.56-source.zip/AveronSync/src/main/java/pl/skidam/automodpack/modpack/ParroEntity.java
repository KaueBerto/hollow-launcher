package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.*;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.*;
import net.minecraft.network.syncher.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.*;
import pl.skidam.automodpack_core.mounts.ParroLevels;
import java.util.*;

/**
 * Native port of the DepartmentQDE x Mister Spooky "Parro" pet (MythicMobs/parro.yml and
 * skills/parro_skills.yml). Companion form follows its owner with hops and glides and can be petted;
 * a saddle turns it into a rideable mount that leaps and glides. It does not fight: the pack's attacks,
 * targeting and experience were replaced by a seed-fed bond that makes it faster and bigger (server
 * design, see PARRO-AVERONSYNC.md). Timings follow the skills file where they still apply.
 */
public final class ParroEntity extends PathfinderMob {
    public static final String[] ACTIONS = {"", "summon", "spawn", "transform", "transform_back", "jump1", "petting1", "petting2", "hurt", "death"};
    public static final String[] BASES = {"idle", "walk", "run", "swim"};
    public static final String[] AIRS = {"", "jump2", "jump3", "jump22"};
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Boolean> SADDLED = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> BASE = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> BASE_AT = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> ACTION = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> ACTION_AT = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> AIR = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> AIR_AT = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.LONG);
    /** ModelEngine hitboxes: companion 20x22 px, saddled 24x26 px. Seat = saddle "mount" bone. */
    private static final EntityDimensions PET_SIZE = EntityDimensions.scalable(1.25F, 1.375F), SADDLE_SIZE = EntityDimensions.scalable(1.5F, 1.625F);
    private static final double SEAT_Y = 24.5 / 16, SADDLE_STEP = 1.125;
    private static final int SUMMON_TICKS = 25;
    private static final double PET_SPEED = .25, SADDLE_SPEED = .29;
    /** Seeds the Parro eats; each one adds a bond point (once its belly empties). */
    private static final Set<Item> SEEDS = Set.of(Items.WHEAT_SEEDS, Items.BEETROOT_SEEDS, Items.MELON_SEEDS,
            Items.PUMPKIN_SEEDS, Items.TORCHFLOWER_SEEDS, Items.PITCHER_POD);
    /** Top speed of the mount (top level): 0.85 block/tick = 17 blocks/s, on the ground, leaping or gliding. Lower levels scale it. */
    static final double RIDE_MAX_SPEED = .85;
    private static final double RIDE_GLIDE_PUSH = .08, RIDE_GLIDE_SPEED = .6, RIDE_GLIDE_SINK = .3;
    /** Server choice: a mounted glide lasts 3 s per flight; then the Parro drops and takes fall damage. */
    static final int RIDE_GLIDE_TICKS = 60;
    private int rideGlide;

    private record Task(long at, Runnable run) {}
    private final List<Task> tasks = new ArrayList<>();
    private UUID session;
    /** Bond points (seeds eaten). Kept under the registry's original name "experience". */
    private double experience;
    private boolean experienceDirty;
    private ParroLevels.Level stage = ParroLevels.LEVELS[0];
    // Pack auras, as remaining ticks.
    private int lock, spawning, petting, pettingCd, followCd, air,
            landStop, noAirstate, ambientCd, flapCd, runCycle, jumpGlide, waterBoost, stillTicks;
    private float lastScale = 1;
    /** Body yaw held while the pack's "lockmodel" is on (petting, summon, saddle on/off). */
    private Float lockedYaw;
    private boolean inAir, highAir, bigAir, returning, swimMode;
    private ParroInput keys = ParroInput.NONE, lastKeys = ParroInput.NONE;
    private long inputAt = Long.MIN_VALUE;
    public record ParroInput(int front, int side, boolean jump, boolean sneak, boolean attack) {
        public static final ParroInput NONE = new ParroInput(0, 0, false, false, false);
    }

    public ParroEntity(EntityType<? extends PathfinderMob> type, Level world) {
        super(type, world);
        setPersistenceRequired();
    }

    // ---- synchronized state -------------------------------------------------------------
    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(OWNER, Optional.empty()); builder.define(SADDLED, false);
        builder.define(BASE, 0); builder.define(BASE_AT, 0L); builder.define(ACTION, 0); builder.define(ACTION_AT, 0L);
        builder.define(AIR, 0); builder.define(AIR_AT, 0L);
    }
    @Override public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (SADDLED.equals(key)) refreshDimensions();
    }
    public UUID owner() { return entityData.get(OWNER).orElse(null); }
    public boolean saddled() { return entityData.get(SADDLED); }
    public String baseClip() { return BASES[Math.clamp(entityData.get(BASE), 0, BASES.length - 1)]; }
    public long baseAt() { return entityData.get(BASE_AT); }
    public String action() { return ACTIONS[Math.clamp(entityData.get(ACTION), 0, ACTIONS.length - 1)]; }
    public long actionAt() { return entityData.get(ACTION_AT); }
    public String airClip() { return AIRS[Math.clamp(entityData.get(AIR), 0, AIRS.length - 1)]; }
    public long airAt() { return entityData.get(AIR_AT); }
    void setup(UUID owner, UUID session, double experience, boolean saddled) {
        entityData.set(OWNER, Optional.of(owner)); this.session = session; this.experience = experience;
        entityData.set(SADDLED, saddled);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(ParroLevels.MAX_HEALTH); setHealth((float) ParroLevels.MAX_HEALTH);
        applyLevel(ParroLevels.forBond(experience), true);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(saddled ? SADDLE_SPEED : PET_SPEED);
        stepHeight(saddled);
    }
    /** The saddled blueprint is spawned with model{step=1.125}: it walks up full blocks. */
    private void stepHeight(boolean saddled) { getAttribute(Attributes.STEP_HEIGHT).setBaseValue(saddled ? SADDLE_STEP : .6); }
    UUID session() { return session; }
    double experience() { return experience; }
    boolean takeExperienceDirty() { boolean dirty = experienceDirty; experienceDirty = false; return dirty; }
    public ParroLevels.Level stage() { return stage; }
    private void play(String action) {
        entityData.set(ACTION, Math.max(0, Arrays.asList(ACTIONS).indexOf(action)));
        entityData.set(ACTION_AT, level().getGameTime());
    }
    private void setAir(int air) {
        if (entityData.get(AIR) == air) return;
        entityData.set(AIR, air); entityData.set(AIR_AT, level().getGameTime());
    }
    private void setBase(int base) {
        if (entityData.get(BASE) == base) return;
        entityData.set(BASE, base); entityData.set(BASE_AT, level().getGameTime());
    }
    private void later(int ticks, Runnable run) { tasks.add(new Task(level().getGameTime() + ticks, run)); }

    @Override public EntityDimensions getDefaultDimensions(Pose pose) { return saddled() ? SADDLE_SIZE : PET_SIZE; }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 10));
    }

    // ---- helpers ------------------------------------------------------------------------
    private ServerPlayer ownerPlayer() {
        UUID id = owner();
        return id == null || !(level() instanceof ServerLevel server) ? null : server.getServer().getPlayerList().getPlayer(id);
    }
    private void sound(String id, float volume, float pitch) {
        level().playSound(null, getX(), getY(), getZ(), SoundEvent.createVariableRangeEvent(ResourceLocation.withDefaultNamespace(id)),
                SoundSource.NEUTRAL, volume, pitch);
    }
    private void particles(ParticleOptions type, double y, int count, double hs, double vs, double speed) {
        if (level() instanceof ServerLevel server) server.sendParticles(type, getX(), getY() + y, getZ(), count, hs, vs, hs, speed);
    }
    private void particleRing(ParticleOptions type, double radius, int points, int amount, double hs, double vs, double y) {
        if (!(level() instanceof ServerLevel server)) return;
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            server.sendParticles(type, getX() + Math.cos(a) * radius, getY() + y, getZ() + Math.sin(a) * radius, amount, hs, vs, hs, 0);
        }
    }
    private void effect(Holder<MobEffect> type, int ticks, int amplifier) { addEffect(new MobEffectInstance(type, ticks, amplifier, false, false, false)); }
    private void lockFor(int ticks) { lock = Math.max(lock, ticks); getNavigation().stop(); setDeltaMovement(0, getDeltaMovement().y, 0); }
    private boolean locked() { return lock > 0 || petting > 0 || spawning > 0 || landStop > 0; }
    private boolean inWater() { return isInWater() || level().getFluidState(BlockPos.containing(getX(), getY() - .2, getZ())).is(FluidTags.WATER); }
    private double altitude() {
        var hit = level().clip(new ClipContext(position(), position().add(0, -300, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, this));
        return hit.getType() == HitResult.Type.MISS ? 300 : position().y - hit.getLocation().y;
    }

    // ---- bond: seeds, levels, speed and size ------------------------------------------------
    private void applyLevel(ParroLevels.Level value, boolean initial) {
        stage = value;
        if (initial) { getAttribute(Attributes.SCALE).setBaseValue(value.scale()); refreshDimensions(); }
    }
    /** Grows (or shrinks) the body a little each tick towards the level's size instead of popping. */
    private void tickScale() {
        double have = getAttributeBaseValue(Attributes.SCALE), want = stage.scale();
        if (Math.abs(have - want) < 1e-4) return;
        getAttribute(Attributes.SCALE).setBaseValue(have + Math.clamp(want - have, -.004, .004));
        refreshDimensions();
    }
    void addBond(double amount) {
        var owner = ownerPlayer(); if (owner == null) return;
        var before = stage;
        experience = Math.max(0, experience + amount); experienceDirty = true;
        var after = ParroLevels.forBond(experience);
        owner.displayClientMessage(Component.literal("Parro ").withStyle(net.minecraft.ChatFormatting.WHITE)
                .append(Component.literal(ParroLevels.progress(experience)).withStyle(net.minecraft.ChatFormatting.GREEN)), true);
        if (after != before) {
            applyLevel(after, false);
            if (after.number() > before.number()) {
                owner.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, .9F, 1.3F);
                owner.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 10));
                owner.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(after.name()).withStyle(net.minecraft.ChatFormatting.GRAY)));
                owner.connection.send(new ClientboundSetTitleTextPacket(Component.literal("VÍNCULO AUMENTOU!").withStyle(net.minecraft.ChatFormatting.YELLOW, net.minecraft.ChatFormatting.BOLD)));
                particles(ParticleTypes.HAPPY_VILLAGER, 1, 24, .8, .6, 0);
            }
        }
    }
    /** The owner feeds a seed: +1 bond, then "barriga cheia" for half an hour (kept even if the Parro is stored and called again). */
    private void feed(ServerPlayer owner, ItemStack seed) {
        long wait = AveronSyncParro.fullMillis(owner);
        if (wait > 0) {
            owner.displayClientMessage(Component.literal("O Parro está de barriga cheia. Volte em " + (wait / 1000 + 1) / 60 + " min " + (wait / 1000 + 1) % 60 + "s.")
                    .withStyle(net.minecraft.ChatFormatting.YELLOW), true);
            sound("entity.parrot.ambient", .5F, 1.4F);
            return;
        }
        if (!owner.getAbilities().instabuild) seed.shrink(1);
        AveronSyncParro.markFed(owner);
        sound("entity.parrot.eat", .8F, 1); later(6, () -> sound("entity.parrot.eat", .8F, 1.2F));
        particles(ParticleTypes.HEART, 1, 5, .5, .4, 0);
        addBond(ParroLevels.BOND_PER_SEED);
    }

    // ---- hops and glide (pr_pet_hop / pr_hop / pr_hop_air / pr_hop_ride / pr_ride_glide) ---
    private void hop(Entity towards, double push) {
        followCd = 20; play("jump1");
        later(3, () -> {
            if (towards != null && towards.isAlive()) getLookControl().setLookAt(towards, 360, 360);
            if (towards != null) {
                float yaw = (float) Math.toDegrees(Math.atan2(-(towards.getX() - getX()), towards.getZ() - getZ()));
                setYRot(yaw); yBodyRot = yaw; yHeadRot = yaw;
            }
            double jump = saddled() ? .45 : towards != null && distanceTo(towards) <= 5 ? .28 : .4;
            Vec3 forward = Vec3.directionFromRotation(0, getYRot()).scale(push);
            setDeltaMovement(getDeltaMovement().add(forward.x, 0, forward.z).add(0, jump - getDeltaMovement().y, 0));
            hasImpulse = true; air = 100;
        });
    }
    private void petHop(ServerPlayer owner) {
        if (!onGround() || isVehicle() || followCd > 0 || locked()) return;
        boolean moving = getNavigation().isInProgress() || getDeltaMovement().horizontalDistanceSqr() > 1e-4;
        if (!moving) return;
        if (returning || distanceTo(owner) > 6) hop(owner, saddled() ? 1.2 : 1.15);
    }
    private void rideHop(ServerPlayer rider) {
        if (followCd > 0) return;
        followCd = 20; jumpGlide = 600; play("jump1");
        later(3, () -> {
            Vec3 forward = Vec3.directionFromRotation(0, getYRot()).scale(1.2);
            double lift = rider.getXRot() < 0 ? -rider.getXRot() * .0045 : 0;
            setDeltaMovement(getDeltaMovement().x + forward.x, .85 + lift, getDeltaMovement().z + forward.z);
            hasImpulse = true;
        });
    }
    private void airState(boolean ridden) {
        boolean ground = onGround(), water = inWater();
        if (!ground && !water && petting <= 0 && spawning <= 0 && noAirstate <= 0) {
            inAir = true;
            double alt = altitude();
            highAir = alt >= 4; bigAir |= alt >= 8;
            double vy = getDeltaMovement().y;
            if (ridden && rideGlide >= RIDE_GLIDE_TICKS) setAir(3); // worn out: wings tucked, no glide
            else if (highAir && vy > 0) setAir(1);
            else if (highAir && vy < 0 && alt >= 3) {
                setAir(2);
                if (flapCd <= 0) {
                    flapCd = saddled() ? 10 : 5;
                    later(12, () -> {
                        if (onGround()) return;
                        if (saddled()) { sound("entity.phantom.flap", 2.5F, 1.1F); sound("entity.phantom.flap", 2, 1.3F); sound("entity.parrot.fly", .7F, .5F); }
                        else { sound("entity.parrot.fly", 2.5F, 1.4F); sound("entity.parrot.fly", 2, 1.6F); }
                    });
                }
            } else if (!highAir && vy > 0 && alt >= 2) setAir(3);
        }
        if (!ridden && air > 0 && !ground && !water && getDeltaMovement().y < 0) {
            effect(MobEffects.SLOW_FALLING, 8, 0);
            Vec3 v = getDeltaMovement();
            double horizontal = v.horizontalDistance();
            setDeltaMovement(horizontal < 1.9 ? v.x * 1.16 : v.x, v.y - .06, horizontal < 1.9 ? v.z * 1.16 : v.z);
        }
        if (ridden && !ground && !water && highAir && rideGlide < RIDE_GLIDE_TICKS) {
            // The glide breaks the fall while it lasts; once it runs out the drop counts as a fall.
            resetFallDistance();
            if (++rideGlide == RIDE_GLIDE_TICKS && getControllingPassenger() instanceof Player rider)
                rider.displayClientMessage(Component.literal("O Parro cansou de planar!").withStyle(net.minecraft.ChatFormatting.RED), true);
            // Server choice: the mounted glide only breaks the fall (pack pr_ride_glide flew almost level).
            // It sinks at up to RIDE_GLIDE_SINK blocks/tick and drifts forward at most RIDE_GLIDE_SPEED.
            Vec3 forward = Vec3.directionFromRotation(0, getYRot()).scale(RIDE_GLIDE_PUSH);
            Vec3 v = getDeltaMovement().add(forward.x, 0, forward.z);
            double horizontal = v.horizontalDistance();
            if (horizontal > RIDE_GLIDE_SPEED) v = new Vec3(v.x * RIDE_GLIDE_SPEED / horizontal, v.y, v.z * RIDE_GLIDE_SPEED / horizontal);
            setDeltaMovement(v.x, Math.max(v.y, -RIDE_GLIDE_SINK), v.z);
        }
        if (ridden && !ground && !water && !highAir && jumpGlide > 0 && getDeltaMovement().y < 0)
            setDeltaMovement(getDeltaMovement().multiply(.85, 1, .85));
        if (ground || water || !ridden) rideGlide = 0;
        if (ground && !ridden) removeEffect(MobEffects.SLOW_FALLING);
        if (ground && ridden) { removeEffect(MobEffects.SLOW_FALLING); if (followCd <= 0) jumpGlide = 0; }
        if (ground && inAir && petting <= 0 && spawning <= 0) land(ridden);
        if (water && inAir) {
            clearAir();
            if (saddled() && bigAir) {
                particleRing(ParticleTypes.SPLASH, 1.5, 16, 4, .2, .2, .3); particleRing(ParticleTypes.SPLASH, 2.5, 24, 4, .2, .2, .3);
                particles(ParticleTypes.BUBBLE, 0, 30, 1, .5, 0);
                sound("entity.generic.splash", 1, .6F); sound("entity.player.splash.high_speed", .8F, .7F);
            }
            highAir = false; bigAir = false; jumpGlide = 0;
        }
    }
    private void clearAir() { inAir = false; air = 0; setAir(0); }
    private void land(boolean ridden) {
        clearAir();
        if (saddled() && bigAir) landingImpact();
        if (!highAir && !ridden) { landStop = 7; noAirstate = 20; }
        highAir = false; bigAir = false;
    }
    private void landingImpact() {
        BlockState below = level().getBlockState(BlockPos.containing(getX(), getY() - .2, getZ()));
        if (below.is(BlockTags.LEAVES) || below.is(Blocks.VINE) || below.is(Blocks.SCAFFOLDING) || below.is(Blocks.COBWEB)
                || below.is(Blocks.LILY_PAD) || below.is(Blocks.SNOW) || below.is(BlockTags.WALL_CORALS)) return;
        sound("entity.generic.big_fall", .5F, .8F); sound("block.rooted_dirt.fall", .5F, .5F); sound("block.gravel.break", .5F, .5F);
        BlockState crack = below.is(Blocks.GRASS_BLOCK) ? Blocks.GRASS_BLOCK.defaultBlockState()
                : below.is(BlockTags.SAND) ? Blocks.SAND.defaultBlockState()
                : below.is(Blocks.SNOW_BLOCK) || below.is(Blocks.POWDER_SNOW) ? Blocks.SNOW_BLOCK.defaultBlockState()
                : below.is(BlockTags.BASE_STONE_OVERWORLD) || below.is(Blocks.COBBLESTONE) || below.is(Blocks.STONE_BRICKS) ? Blocks.STONE.defaultBlockState()
                : below.is(BlockTags.DIRT) || below.is(Blocks.DIRT_PATH) || below.is(Blocks.FARMLAND) ? Blocks.DIRT.defaultBlockState() : null;
        if (crack == null) return;
        var particle = new BlockParticleOption(ParticleTypes.BLOCK, crack);
        particleRing(particle, 1.5, 16, 3, .2, .1, .1); particleRing(particle, 2.5, 24, 3, .2, .1, .1);
    }

    // ---- saddle (pr_transform / pr_restore_saddle_apply / pr_untransform) ----------------
    /** Called companion: {@code summon} (pr_pet_spawn). Called saddled: {@code spawn}, as in the pack. */
    void spawnAnimation() {
        if (saddled()) restoreSaddle(); else { spawning = SUMMON_TICKS; lockFor(SUMMON_TICKS); play("summon"); }
    }
    private void restoreSaddle() {
        entityData.set(SADDLED, true); refreshDimensions();
        spawning = 38; lockFor(38); play("spawn");
        later(17, () -> { sound("entity.phantom.flap", 1.2F, 1.1F); sound("entity.phantom.flap", 1, 1.3F); });
        later(26, () -> { sound("entity.phantom.flap", 1.2F, 1.1F); sound("entity.phantom.flap", 1, 1.3F); });
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(SADDLE_SPEED); stepHeight(true);
    }
    private void transform(ServerPlayer player, InteractionHand hand) {
        spawning = 43; lockFor(43); play("transform");
        later(10, () -> {
            ItemStack held = player.getItemInHand(hand);
            if (held.is(Items.SADDLE) && player.isAlive() && player.distanceTo(this) < 8) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                AveronSyncParro.saddleChanged(player, true);
                restoreSaddle();
                sound("entity.camel.saddle", 1, .9F); sound("entity.parrot.ambient", 2, .5F); sound("entity.parrot.fly", 1.5F, .5F);
            } else {
                play("transform_back"); later(10, () -> { spawning = 0; lock = 0; });
            }
        });
    }
    private void untransform(ServerPlayer player) {
        sound("entity.sheep.shear", 1, 1);
        ItemStack saddle = new ItemStack(Items.SADDLE);
        if (!player.getInventory().add(saddle)) player.drop(saddle, false);
        AveronSyncParro.saddleChanged(player, false);
        particles(new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(Items.SADDLE)), SEAT_Y, 20, .3, .3, .05);
        ejectPassengers();
        spawning = 30; lockFor(30); play("transform");
        later(10, () -> {
            entityData.set(SADDLED, false); refreshDimensions(); play("transform_back");
            getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(PET_SPEED); stepHeight(false);
        });
    }

    // ---- petting (pr_pet_petting / pr_petting1 / pr_petting2) ----------------------------
    private void pet(Player player) {
        if (!onGround() || inWater() || pettingCd > 0) return;
        pettingCd = 50;
        boolean first = random.nextBoolean(), saddled = saddled();
        petting = first ? 52 : 47; lockFor(petting); clearAir();
        play(first ? "petting1" : "petting2");
        for (int i = 0; i < 4; i++) later(i * 10, () -> particles(ParticleTypes.HEART, 1, 4, .5, .5, 0));
        if (!saddled) sound("entity.parrot.eat", .7F, 1);
        later(15, () -> sound("entity.sniffer.happy", .6F, 1.5F));
        if (first) {
            if (!saddled) for (int i = 0; i < 3; i++) later(10 + i * 7, () -> { sound("entity.parrot.fly", .5F, 1.2F); sound("entity.parrot.fly", .4F, 1.4F); });
            else for (int i = 0; i < 4; i++) later(18 + i * 4, () -> sound("entity.parrot.fly", .5F, .7F));
        } else {
            later(42, () -> sound("entity.parrot.fly", saddled ? .5F : .3F, saddled ? .7F : 1.4F));
            if (saddled) for (int i = 0; i < 2; i++) later(22 + i * 11, () -> { sound("entity.phantom.flap", .9F, 1.1F); sound("entity.phantom.flap", .7F, 1.3F); });
        }
    }

    // ---- interaction ----------------------------------------------------------------------
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hasPassenger(player)) return InteractionResult.PASS;
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer) || !AveronSyncParro.authenticated(serverPlayer)) return InteractionResult.FAIL;
        boolean isOwner = player.getUUID().equals(owner());
        ItemStack held = player.getItemInHand(hand);
        if (isOwner && player.isSecondaryUseActive() && held.is(Items.STICK)) {
            // Pack debug action: sneak + stick resets the bond to level 1.
            addBond(-experience);
            player.displayClientMessage(Component.literal("Vínculo do Parro zerado -> Lv.1").withStyle(net.minecraft.ChatFormatting.GREEN), true);
            return InteractionResult.CONSUME;
        }
        if (isOwner && SEEDS.contains(held.getItem())) {
            if (spawning <= 0 && !isVehicle()) feed(serverPlayer, held);
            return InteractionResult.CONSUME;
        }
        if (!saddled()) {
            if (held.is(Items.SADDLE)) {
                if (isOwner && spawning <= 0 && onGround() && !inWater()) transform(serverPlayer, hand);
                return InteractionResult.CONSUME;
            }
            if (!isVehicle()) pet(player);
            return InteractionResult.CONSUME;
        }
        if (held.is(Items.SHEARS)) {
            if (isOwner && spawning <= 0 && onGround() && !inWater()) untransform(serverPlayer);
            return InteractionResult.CONSUME;
        }
        if (player.isSecondaryUseActive()) { if (spawning <= 0 && !isVehicle()) pet(player); return InteractionResult.CONSUME; }
        if (isOwner && spawning <= 0 && !player.isPassenger() && player.startRiding(this)) {
            lock = 0; getNavigation().stop();
            sound("entity.camel.saddle", .5F, 1);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.FAIL;
    }

    // ---- riding (pr_mount / pr_saddle_controller / pr_ride_speed) ------------------------
    public boolean acceptInput(ServerPlayer player, ParroInput input) {
        if (getControllingPassenger() != player || !AveronSyncParro.authenticated(player)) return false;
        keys = input; inputAt = level().getGameTime(); return true;
    }
    @Override public LivingEntity getControllingPassenger() {
        return saddled() && getFirstPassenger() instanceof Player player && player.getUUID().equals(owner()) ? player : null;
    }
    @Override public boolean isControlledByLocalInstance() { return !level().isClientSide; }
    @Override protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().isEmpty() && passenger instanceof Player player && player.getUUID().equals(owner()) && saddled();
    }
    @Override protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (!level().isClientSide) {
            keys = ParroInput.NONE; inputAt = Long.MIN_VALUE;
            // pr_restore_goals: settle, calm down and resume walking.
            setDeltaMovement(0, getDeltaMovement().y, 0); getNavigation().stop(); lockFor(10);
            setBase(0);
        }
    }
    private ParroInput input() { return inputAt == Long.MIN_VALUE || level().getGameTime() - inputAt > 10 ? ParroInput.NONE : keys; }
    /**
     * A/D turn the mount like the AveronSync horse (5 degrees per tick moving forward, 4 standing, mirrored in reverse),
     * and the camera stays free. The pack's driver controls followed the camera instead (server choice).
     */
    @Override protected void tickRidden(Player player, Vec3 travel) {
        var in = input();
        float turn = (spawning > 0 || lock > 0 || in.side() == 0) ? 0 : (in.front() > 0 ? -5 : in.front() < 0 ? 5 : -4) * in.side();
        if (turn != 0) {
            setYRot(getYRot() + turn);
            setDeltaMovement(getDeltaMovement().yRot((float) -Math.toRadians(turn))); // keeps the leap and glide on the new heading
        }
        setXRot(0); yBodyRot = getYRot(); yHeadRot = getYRot();
    }
    @Override protected Vec3 getRiddenInput(Player player, Vec3 vanilla) {
        var in = input();
        if (spawning > 0 || lock > 0) return Vec3.ZERO;
        double front = in.front();
        // In the air without forward input the glide still carries the mount forward.
        if (!onGround() && front == 0 && jumpGlide > 0 && !highAir) front = 1;
        if (highAir && front > 0) front = 0;
        return new Vec3(0, 0, front < 0 ? front * .5 : front); // A/D turn instead of strafing (see tickRidden)
    }
    @Override protected float getRiddenSpeed(Player player) {
        double speed = getAttributeValue(Attributes.MOVEMENT_SPEED) * stage.speed() * MountLoadGuard.factor(this);
        if (inWater()) return (float) (speed * .4);
        // The pack gives the driver Speed II on the ground, Speed IV right after a leap and
        // Speed III/IV while gliding; ModelEngine moves the mount with the driver's speed.
        int amplifier = onGround() ? 1 : followCd > 0 || (highAir && jumpGlide > 0) ? 3 : highAir ? 2 : 1;
        return (float) (speed * (1 + .2 * (amplifier + 1)));
    }
    @Override public void move(MoverType type, Vec3 delta) {
        if (type == MoverType.SELF && getControllingPassenger() != null) {
            double limit = RIDE_MAX_SPEED * stage.speed() * MountLoadGuard.factor(this), horizontal = delta.horizontalDistance();
            if (horizontal > limit) {
                double scale = limit / horizontal;
                delta = new Vec3(delta.x * scale, delta.y, delta.z * scale);
                Vec3 v = getDeltaMovement();
                if (v.horizontalDistance() > limit) {
                    double keep = limit / v.horizontalDistance();
                    setDeltaMovement(v.x * keep, v.y, v.z * keep);
                }
            }
        }
        super.move(type, delta);
    }
    @Override protected Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dimensions, float scale) {
        return new Vec3(0, SEAT_Y * scale, 0);
    }

    // ---- damage ---------------------------------------------------------------------------
    @Override public boolean hurt(DamageSource source, float amount) {
        // Only a ridden drop hurts (see causeFallDamage); the companion never takes fall damage, like the pack.
        if (source.is(DamageTypeTags.IS_FALL) && (getControllingPassenger() == null || rideGlide < RIDE_GLIDE_TICKS)) return false;
        Entity attacker = source.getEntity();
        if (attacker != null && attacker.getUUID().equals(owner())) return false;
        if (attacker instanceof Player) return false;
        if (!level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            if (saddled()) amount *= .4F;
        }
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide && isAlive()) {
            play("hurt"); sound("entity.parrot.hurt", .9F, saddled() ? .5F : 1);
        }
        return hit;
    }
    /** Ridden drop after the glide ran out hurts the Parro and its rider, like a vanilla horse. Otherwise none (pr_cancel_fall). */
    @Override public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        // Only after the glide ran out: ordinary leaps and short drops stay harmless.
        if (level().isClientSide || getControllingPassenger() == null || rideGlide < RIDE_GLIDE_TICKS) return false;
        int damage = calculateFallDamage(distance, multiplier);
        if (damage <= 0) return false;
        var riders = List.copyOf(getPassengers());
        hurt(source, damage);
        for (Entity rider : riders) rider.hurt(source, damage);
        playBlockFallSound();
        return true;
    }
    @Override public void die(DamageSource source) {
        if (!level().isClientSide) { play("death"); AveronSyncParro.parroDied(this); }
        super.die(source);
    }
    @Override protected void dropEquipment() {}
    @Override protected void dropCustomDeathLoot(ServerLevel server, DamageSource source, boolean recent) {}
    @Override public boolean shouldDropExperience() { return false; }
    @Override public boolean canBeLeashed() { return false; }
    @Override protected SoundEvent getAmbientSound() { return null; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return null; }
    @Override protected SoundEvent getDeathSound() { return SoundEvent.createVariableRangeEvent(ResourceLocation.withDefaultNamespace("entity.parrot.death")); }
    @Override protected void playStepSound(BlockPos pos, BlockState state) {}
    @Override public boolean removeWhenFarAway(double distance) { return false; }

    // ---- main loop ------------------------------------------------------------------------
    @Override public void tick() {
        super.tick();
        if (level().isClientSide) {
            // The scale attribute reaches the client without a dimensions refresh.
            if (Math.abs(getScale() - lastScale) > 1e-4) { lastScale = getScale(); refreshDimensions(); }
            return;
        }
        if (!isAlive()) return;
        tickScale();
        long now = level().getGameTime();
        for (var task : List.copyOf(tasks)) if (task.at <= now) { tasks.remove(task); if (isAlive()) task.run.run(); }
        countDown();
        var owner = ownerPlayer();
        if (owner == null) return;
        boolean ridden = getControllingPassenger() instanceof ServerPlayer;
        if (ridden) tickRiddenState((ServerPlayer) getControllingPassenger());
        else tickCompanion(owner);
        if (locked()) { getNavigation().stop(); setDeltaMovement(0, getDeltaMovement().y, 0); }
        airState(ridden);
        tickWater(ridden);
        if (tickCount % 20 == 0 && getHealth() < getMaxHealth()) heal((float) ParroLevels.REGENERATION);
        tickSounds(now);
        Vec3 motion = getDeltaMovement();
        boolean moving = motion.horizontalDistanceSqr() > 1e-5 || (getNavigation().isInProgress() && !locked());
        // A few still ticks before idle, so a one-tick stop between hops does not restart idle and walk.
        stillTicks = moving ? 0 : Math.min(stillTicks + 1, 100);
        int current = entityData.get(BASE);
        boolean wasMoving = current == 1 || current == 2;
        if (!moving && wasMoving && stillTicks < 4) moving = true;
        setBase(swimMode ? 3 : !moving ? 0 : saddled() && ridden ? 2 : 1);
        holdModelYaw(ridden);
    }
    private void holdModelYaw(boolean ridden) {
        if (ridden || (petting <= 0 && spawning <= 0)) { lockedYaw = null; return; }
        if (lockedYaw == null) lockedYaw = yBodyRot;
        setYRot(lockedYaw); yBodyRot = lockedYaw; yBodyRotO = lockedYaw; yHeadRot = lockedYaw;
    }
    private void countDown() {
        lock--; spawning--; petting--; pettingCd--; followCd--; air--;
        landStop--; noAirstate--; ambientCd--; flapCd--; runCycle--; jumpGlide--; waterBoost--;
    }
    private void tickRiddenState(ServerPlayer rider) {
        var in = input();
        if (in.sneak()) { rider.stopRiding(); return; }
        MountLoadGuard.notify(this, rider);
        if (in.jump() && onGround() && !inWater() && spawning <= 0) rideHop(rider);
        // The attack key is still sent by the client; the Parro does not fight.
        lastKeys = in;
    }
    private void tickCompanion(ServerPlayer owner) {
        lastKeys = ParroInput.NONE;
        if (owner.level() != level()) return;
        double distance = distanceTo(owner);
        if (tickCount % 20 == 0 && distance > 24) {
            Vec3 spot = owner.position().add(random.nextDouble() * 10 - 5, 0, random.nextDouble() * 10 - 5);
            BlockPos pos = BlockPos.containing(spot);
            for (int dy = 2; dy >= -2; dy--) {
                BlockPos at = pos.offset(0, dy, 0);
                if (level().getBlockState(at.below()).isFaceSturdy(level(), at.below(), net.minecraft.core.Direction.UP)
                        && level().noCollision(this, getBoundingBox().move(at.getX() + .5 - getX(), at.getY() - getY(), at.getZ() + .5 - getZ()))) {
                    teleportTo(at.getX() + .5, at.getY(), at.getZ() + .5); getNavigation().stop(); break;
                }
            }
            distance = distanceTo(owner);
        }
        if (!returning && distance > 20) returning = true;
        else if (returning && distance <= 12) returning = false;
        if (locked()) return;
        faceOwner(owner, distance);
        if (tickCount % 8 == 0 && distance > 6) getNavigation().moveTo(owner, 1);
        if (tickCount % 12 == 0) petHop(owner);
        if (air > 0 && !onGround() && !inWater()) getLookControl().setLookAt(owner, 360, 360);
    }
    /**
     * A hop carries the Parro past its owner (about 12 blocks), so it used to land and stand with its back to them.
     * Standing still near the owner it now turns to face them (server choice, the pack only looks with the head).
     */
    private void faceOwner(ServerPlayer owner, double distance) {
        if (!onGround() || inWater() || stillTicks < 6 || distance > 16) return;
        double dx = owner.getX() - getX(), dz = owner.getZ() - getZ();
        if (dx * dx + dz * dz < 2.25) return;
        float diff = net.minecraft.util.Mth.wrapDegrees((float) Math.toDegrees(Math.atan2(-dx, dz)) - getYRot());
        if (Math.abs(diff) < 25) return;
        setYRot(getYRot() + Math.clamp(diff, -10F, 10F)); yBodyRot = getYRot(); yHeadRot = getYRot();
    }
    private void tickWater(boolean ridden) {
        boolean water = inWater();
        if (water != swimMode) swimMode = water;
        if (water && tickCount % 5 == 0 && waterBoost <= 0) {
            waterBoost = 8;
            if (!ridden) effect(MobEffects.DOLPHINS_GRACE, 8, 2);
            effect(MobEffects.WATER_BREATHING, 8, 0);
        }
    }
    private void tickSounds(long now) {
        boolean moving = getDeltaMovement().horizontalDistanceSqr() > 1e-4;
        if (inWater() && moving && tickCount % (saddled() ? 6 : 10) == 0) sound("entity.generic.swim", .2F, saddled() ? .6F : 1.2F);
        if (saddled() && onGround() && moving && runCycle <= 0) {
            runCycle = 19;
            later(9, () -> { if (onGround() && getDeltaMovement().horizontalDistanceSqr() > 1e-4) sound("entity.camel.step", .9F, 1); });
            later(19, () -> { if (onGround() && getDeltaMovement().horizontalDistanceSqr() > 1e-4) sound("entity.camel.step", .9F, 1); });
        }
        if (tickCount % 30 == 0 && random.nextFloat() < .7F && petting <= 0 && spawning <= 0 && ambientCd <= 0) {
            ambientCd = 160;
            int pick = random.nextInt(3);
            if (!saddled()) { if (pick == 2) sound("entity.parrot.fly", .4F, 1); else sound("entity.parrot.ambient", .5F, pick == 0 ? 1.1F : .9F); }
            else { if (pick == 2) sound("entity.parrot.fly", .5F, .5F); else sound("entity.parrot.ambient", .6F, .5F); }
        }
    }
    @Override public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (session != null) tag.putUUID("AveronParroSession", session);
    }
    @Override public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        session = tag.hasUUID("AveronParroSession") ? tag.getUUID("AveronParroSession") : null;
    }
}
/*?}*/
