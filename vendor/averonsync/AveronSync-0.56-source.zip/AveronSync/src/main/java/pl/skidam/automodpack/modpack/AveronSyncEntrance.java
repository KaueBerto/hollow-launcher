package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import pl.skidam.automodpack.networking.server.AveronSyncEntryQueue;
import pl.skidam.automodpack_core.entrance.EntranceCatalog;
import pl.skidam.automodpack_core.entrance.EntranceSettings;
import java.util.*;
import static net.minecraft.commands.Commands.*;
import static pl.skidam.automodpack_core.GlobalVariables.*;

/**
 * Join/leave animations (EliteAnimations v1 Halloween, redrawn natively on the client).
 * The join animation plays once per connection, when the player is authenticated
 * (EasyLogin, or native authentication when EasyLogin is absent). The leave animation
 * plays on logout only for players whose join was announced, so unauthenticated
 * connections never show either. Purely cosmetic: no entity is spawned on the server.
 */
public final class AveronSyncEntrance {
    private static final double RANGE = 64;
    private static final long TEST_COOLDOWN_MS = 10_000;
    private static final Map<MinecraftServer, State> SERVERS = new IdentityHashMap<>();
    private static final Random RANDOM = new Random();
    private static final class State {
        EntranceSettings settings;
        final Set<UUID> announced = new HashSet<>();
        final Map<UUID, Long> lastTest = new HashMap<>();
        /** Players waiting for their login who will get a join animation; sent to clients so they are not drawn meanwhile. */
        Set<UUID> hidden = Set.of();
        State() {
            try { settings = new EntranceSettings(serverConfigFile.resolveSibling("averonsync-entrance.json")); }
            catch (java.io.IOException e) { LOGGER.error("Entrance animations disabled: invalid settings file; original preserved", e); }
        }
    }
    private static State state(MinecraftServer server) { return SERVERS.computeIfAbsent(server, ignored -> new State()); }

    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("averonsync-entrance-2").optional().playToClient(AveronSyncEntrancePayload.TYPE, AveronSyncEntrancePayload.CODEC,
                (data, context) -> context.enqueueWork(() -> pl.skidam.automodpack.client.entrance.EntranceClient.accept(data)))
                .playToClient(AveronSyncEntranceHiddenPayload.TYPE, AveronSyncEntranceHiddenPayload.CODEC,
                (data, context) -> context.enqueueWork(() -> pl.skidam.automodpack.client.entrance.EntranceClient.acceptHidden(data)));
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("animacao")
                .executes(ctx -> info(ctx.getSource()))
                .then(literal("listar").executes(ctx -> info(ctx.getSource())))
                .then(literal("desligar").executes(ctx -> choose(ctx.getSource(), EntranceCatalog.OFF)))
                .then(literal("usar").then(argument("tema", StringArgumentType.word())
                        .suggests((ctx, builder) -> {
                            for (var t : EntranceCatalog.ALL) if (t.id().startsWith(builder.getRemaining())) builder.suggest(t.id());
                            for (var extra : List.of(EntranceCatalog.RANDOM, EntranceCatalog.DEFAULT))
                                if (extra.startsWith(builder.getRemaining())) builder.suggest(extra);
                            return builder.buildFuture();
                        })
                        .executes(ctx -> choose(ctx.getSource(), StringArgumentType.getString(ctx, "tema")))))
                .then(literal("testar").executes(ctx -> test(ctx.getSource(), true))
                        .then(literal("entrada").executes(ctx -> test(ctx.getSource(), true)))
                        .then(literal("saida").executes(ctx -> test(ctx.getSource(), false))))
                .then(literal("acesso").requires(s -> s.hasPermission(3))
                        .executes(ctx -> access(ctx.getSource(), null))
                        .then(literal("vip").executes(ctx -> access(ctx.getSource(), EntranceSettings.Access.VIP)))
                        .then(literal("todos").executes(ctx -> access(ctx.getSource(), EntranceSettings.Access.ALL)))));
    }

    private static boolean authenticated(ServerPlayer player) {
        try { return AveronSyncVipKitCommand.authenticated(player); }
        catch (ReflectiveOperationException | RuntimeException e) { return false; }
    }
    private static boolean allowed(ServerPlayer player, State state) {
        if (state.settings == null) return false;
        if (state.settings.access() == EntranceSettings.Access.ALL) return true;
        if (player.server.getPlayerList().isOp(player.getGameProfile())) return true;
        var vips = AveronSyncEntryQueue.get(player.server).vips();
        return vips != null && EntranceCatalog.vipAllowed(vips.level(player.getGameProfile().getName(), System.currentTimeMillis()));
    }
    /** Active VIP level; operators without a VIP record count as level 1. */
    private static int vipLevel(ServerPlayer player) {
        var vips = AveronSyncEntryQueue.get(player.server).vips();
        int level = vips == null ? 0 : vips.level(player.getGameProfile().getName(), System.currentTimeMillis());
        return level == 0 && player.server.getPlayerList().isOp(player.getGameProfile()) ? 1 : level;
    }
    private static String choice(ServerPlayer player, State state) {
        return state.settings.choice(player.getGameProfile().getName(), vipLevel(player));
    }
    private static boolean visible(ServerPlayer player) { return player.isAlive() && !player.isSpectator() && !player.isInvisible(); }

    /** Sends the animation to players near {@code subject}, in its dimension; never to clients without the channel. */
    private static void play(ServerPlayer subject, String choice, boolean in, boolean includeSubject) {
        var theme = EntranceCatalog.resolve(choice, RANDOM); if (theme.isEmpty()) return;
        var payload = new AveronSyncEntrancePayload(subject.getUUID(), theme.get().id(), in, subject.getX(), subject.getY(), subject.getZ(), subject.getYRot(),
                Math.clamp(subject.getScale(), 0.0625f, 16f));
        for (var viewer : subject.server.getPlayerList().getPlayers()) {
            if (viewer.level() != subject.level() || viewer.distanceToSqr(subject) > RANGE * RANGE) continue;
            if (viewer == subject && !includeSubject) continue;
            if (!viewer.connection.hasChannel(AveronSyncEntrancePayload.TYPE)) continue;
            viewer.connection.send(payload);
        }
    }

    public static void tick(MinecraftServer server) {
        if (server.getTickCount() % 5 != 0) return;
        State state = state(server); Set<UUID> online = new HashSet<>(), waiting = new HashSet<>();
        for (var player : server.getPlayerList().getPlayers()) {
            online.add(player.getUUID());
            if (state.announced.contains(player.getUUID())) continue;
            if (!authenticated(player)) {
                // Not logged in yet: it will get an animation, so keep it out of sight until the animation starts.
                if (state.settings != null && allowed(player, state) && visible(player)
                        && !EntranceCatalog.OFF.equals(choice(player, state)) && waiting.size() < 256) waiting.add(player.getUUID());
                continue;
            }
            state.announced.add(player.getUUID());
            if (allowed(player, state) && visible(player))
                play(player, choice(player, state), true, true);
        }
        state.announced.retainAll(online); state.lastTest.keySet().retainAll(online);
        // Sent after the animations above, so the animation is already running when the player is shown again.
        boolean changed = !waiting.equals(state.hidden);
        state.hidden = waiting;
        if (changed || (!waiting.isEmpty() && server.getTickCount() % 20 == 0)) {
            var payload = new AveronSyncEntranceHiddenPayload(List.copyOf(waiting));
            for (var viewer : server.getPlayerList().getPlayers())
                if (viewer.connection.hasChannel(AveronSyncEntranceHiddenPayload.TYPE)) viewer.connection.send(payload);
        }
    }

    public static void loggedOut(ServerPlayer player) {
        State state = SERVERS.get(player.server); if (state == null) return;
        if (!state.announced.remove(player.getUUID()) || !player.server.isRunning()) return;
        if (allowed(player, state) && visible(player))
            play(player, choice(player, state), false, false);
    }

    private static int fail(CommandSourceStack source, String text) { source.sendFailure(Component.literal(text)); return 0; }
    private static int info(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException(); State state = state(source.getServer());
        if (state.settings == null) return fail(source, "Animacoes de entrada indisponiveis. Avise a administracao.");
        String choice = choice(player, state);
        boolean byLevel = state.settings.storedChoice(player.getGameProfile().getName()).isEmpty();
        String current = EntranceCatalog.find(choice).map(EntranceCatalog.Theme::name)
                .orElse(EntranceCatalog.OFF.equals(choice) ? "desligada" : "aleatoria") + (byLevel ? " (padrao do seu VIP)" : "");
        source.sendSuccess(() -> Component.literal("[AveronSync] Animacao de entrada/saida: " + current
                + (allowed(player, state) ? "" : " (exclusiva para VIP 2)")), false);
        for (var t : EntranceCatalog.ALL) source.sendSuccess(() -> Component.literal(" - " + t.id() + ": " + t.name()), false);
        source.sendSuccess(() -> Component.literal("Use /animacao usar <tema|aleatoria|padrao>, /animacao desligar ou /animacao testar."), false);
        return 1;
    }
    private static int choose(CommandSourceStack source, String choice) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException(); State state = state(source.getServer());
        if (!authenticated(player)) return fail(source, "Entre no EasyLogin antes de escolher sua animacao.");
        if (state.settings == null) return fail(source, "Animacoes de entrada indisponiveis. Avise a administracao.");
        boolean reset = EntranceCatalog.DEFAULT.equals(choice);
        if (!reset && !EntranceCatalog.validChoice(choice)) return fail(source, "Animacao desconhecida. Use /animacao listar.");
        try { state.settings.setChoice(player.getGameProfile().getName(), reset ? null : choice); }
        catch (java.io.IOException | RuntimeException e) {
            LOGGER.error("Could not save entrance animation for {}", player.getGameProfile().getName(), e);
            return fail(source, "Nao foi possivel salvar. Escolha anterior preservada.");
        }
        player.displayClientMessage(Component.literal(EntranceCatalog.OFF.equals(choice) ? "Animacao de entrada desligada." : "Animacao de entrada atualizada."), true);
        return 1;
    }
    private static int test(CommandSourceStack source, boolean in) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException(); State state = state(source.getServer());
        if (!authenticated(player)) return fail(source, "Entre no EasyLogin antes de testar.");
        if (!allowed(player, state)) return fail(source, "Animacoes de entrada sao exclusivas para VIP 2.");
        String choice = choice(player, state);
        if (EntranceCatalog.OFF.equals(choice)) return fail(source, "Sua animacao esta desligada. Use /animacao usar <tema>.");
        long now = System.currentTimeMillis();
        if (now - state.lastTest.getOrDefault(player.getUUID(), 0L) < TEST_COOLDOWN_MS) return fail(source, "Aguarde alguns segundos para testar de novo.");
        state.lastTest.put(player.getUUID(), now);
        play(player, choice, in, true);
        return 1;
    }
    private static int access(CommandSourceStack source, EntranceSettings.Access value) {
        State state = state(source.getServer());
        if (state.settings == null) return fail(source, "[AveronSync] Arquivo averonsync-entrance.json invalido; corrija e reinicie.");
        if (value != null) {
            try { state.settings.setAccess(value); }
            catch (java.io.IOException e) { LOGGER.error("Could not save entrance access", e); return fail(source, "[AveronSync] Nao foi possivel salvar."); }
        }
        String now = state.settings.access().id;
        source.sendSuccess(() -> Component.literal("[AveronSync] Animacoes de entrada/saida: " + now), value != null);
        return 1;
    }
    public static void shutdown(MinecraftServer server) { SERVERS.remove(server); }
    private AveronSyncEntrance() {}
}
/*?}*/
