package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import pl.skidam.automodpack_core.mounts.MountLoad;
import java.util.*;

/** Speed multiplier for ridden mounts on an overloaded dedicated server (see {@link MountLoad}). One value per server tick. */
final class MountLoadGuard {
    private static final Map<MinecraftServer, State> STATES = new WeakHashMap<>();
    private static final class State { double factor = 1; long tick = -1; final Map<UUID, Long> told = new HashMap<>(); }
    /** 1 when the server is healthy, on the client, or in singleplayer; lower while ticks run long. */
    static double factor(Entity mount) {
        if (!(mount.level() instanceof net.minecraft.server.level.ServerLevel level)) return 1;
        MinecraftServer server = level.getServer();
        if (!server.isDedicatedServer()) return 1;
        State state = STATES.computeIfAbsent(server, ignored -> new State());
        long tick = server.getTickCount();
        if (tick != state.tick) {
            state.tick = tick;
            state.factor = MountLoad.smooth(state.factor, MountLoad.factor(server.getAverageTickTimeNanos() / 1_000_000.0));
        }
        return state.factor;
    }
    /** Tells the rider, at most every 10 seconds, why the mount is slower. */
    static void notify(Entity mount, ServerPlayer rider) {
        double factor = factor(mount);
        if (factor > .9 || !(mount.level() instanceof net.minecraft.server.level.ServerLevel level)) return;
        State state = STATES.get(level.getServer());
        long now = System.currentTimeMillis();
        if (state == null || now - state.told.getOrDefault(rider.getUUID(), 0L) < 10_000) return;
        state.told.put(rider.getUUID(), now);
        rider.displayClientMessage(Component.literal("Servidor sobrecarregado: a montaria está mais lenta.")
                .withStyle(net.minecraft.ChatFormatting.YELLOW), true);
    }
    private MountLoadGuard() {}
}
/*?}*/
