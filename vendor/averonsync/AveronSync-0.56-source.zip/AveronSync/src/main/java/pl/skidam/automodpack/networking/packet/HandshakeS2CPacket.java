package pl.skidam.automodpack.networking.packet;

import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import net.minecraft.network.Connection;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.login.ClientboundLoginDisconnectPacket;
import net.minecraft.server.*;
import net.minecraft.server.network.ServerLoginPacketListenerImpl;
import pl.skidam.automodpack.client.ui.versioned.VersionedText;
import pl.skidam.automodpack.init.Common;
import pl.skidam.automodpack.mixin.core.ServerLoginNetworkHandlerAccessor;
import pl.skidam.automodpack.modpack.GameHelpers;
import pl.skidam.automodpack.networking.content.DataPacket;
import pl.skidam.automodpack.networking.content.HandshakePacket;
import pl.skidam.automodpack.networking.PacketSender;
import pl.skidam.automodpack.networking.server.ServerLoginNetworking;
import pl.skidam.automodpack_core.auth.Secrets;
import pl.skidam.automodpack_core.auth.SecretsStore;
import pl.skidam.automodpack_core.utils.AutoModpackProtocol;
import pl.skidam.automodpack_core.utils.SemanticVersion;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

import static pl.skidam.automodpack.networking.ModPackets.DATA;
import static pl.skidam.automodpack_core.GlobalVariables.*;

public class HandshakeS2CPacket {

    public static void receive(MinecraftServer server, ServerLoginPacketListenerImpl handler, boolean understood, FriendlyByteBuf buf, ServerLoginNetworking.LoginSynchronizer loginSynchronizer, PacketSender sender) {
        loginSynchronizer.waitFor(server.submit(() -> handlePacket(handler, understood, buf, sender)));
    }

    private static void handlePacket(ServerLoginPacketListenerImpl handler, boolean understood, FriendlyByteBuf buf, PacketSender sender) {
        Connection connection = ((ServerLoginNetworkHandlerAccessor) handler).getConnection();

        GameProfile profile = ((ServerLoginNetworkHandlerAccessor) handler).getGameProfile();
        String playerName = GameHelpers.getPlayerName(profile);

        if (playerName == null) {
            throw new IllegalStateException("Player name is null");
        }

        if (GameHelpers.getPlayerUUID(profile) == null) {
//            if (server.isOnlineMode()) { This may happen with mods like 'easyauth', its possible to have an offline mode player join an online server
//                throw new IllegalStateException("Player: " + playerName + " doesn't have UUID");
//            }

            // Generate profile with offline uuid
            UUID offlineUUID = UUID.nameUUIDFromBytes(("OfflinePlayer:" + playerName).getBytes(StandardCharsets.UTF_8));
            profile = new GameProfile(offlineUUID, playerName);
        }

//        if (!connection.isEncrypted()) {
//            LOGGER.warn("Connection is not encrypted for player: {}", playerName);
//        }

        if (!GameHelpers.isPlayerAuthorized(connection.getRemoteAddress(), profile)) {
            return;
        }

        if (!understood) {
            Common.players.put(playerName, false);
            LOGGER.warn("{} has not installed AutoModpack.", playerName);
            if (serverConfig.requireAutoModpackOnClient) {
                Component reason = VersionedText.literal("[AveronSync] Voce precisa entrar pelo Averon Launcher para jogar neste servidor. Baixe e abra o Averon Launcher e tente de novo.");
                connection.send(new ClientboundLoginDisconnectPacket(reason));
                connection.disconnect(reason);
            }
        } else {
            Common.players.put(playerName, true);
            handleHandshake(connection, profile, buf, sender);
        }
    }

    private static void handleHandshake(Connection connection, GameProfile profile, FriendlyByteBuf buf, PacketSender sender) {
        try {
            LOGGER.info("{} has installed AutoModpack.", GameHelpers.getPlayerName(profile));

            String clientResponse = buf.readUtf(Short.MAX_VALUE);
            HandshakePacket clientHandshakePacket = HandshakePacket.fromJson(clientResponse);

            boolean isAcceptedLoader = false;
            for (String loader : serverConfig.acceptedLoaders) {
                if (clientHandshakePacket.loaders.contains(loader)) {
                    isAcceptedLoader = true;
                    break;
                }
            }

            boolean isAcceptedVersion = AutoModpackProtocol.acceptsClient(
                    AM_VERSION,
                    clientHandshakePacket.amVersion
            );

            if (!isAcceptedLoader || !isAcceptedVersion) {
                // Plain Portuguese text: players do not know what AutoModpack is, only the Averon Launcher.
                Component reason;
                if (!isAcceptedLoader) {
                    reason = VersionedText.literal("[AveronSync] Versao do jogo incompativel com o servidor. Entre pelo Averon Launcher.");
                } else if (isClientVersionHigher(clientHandshakePacket.amVersion)) {
                    reason = VersionedText.literal("[AveronSync] O servidor ainda esta sendo atualizado. Aguarde alguns minutos e tente entrar de novo. Se continuar assim, avise a administracao.");
                } else {
                    reason = VersionedText.literal("[AveronSync] Seu Averon Launcher esta desatualizado. Feche o jogo, abra o Averon Launcher para atualizar e entre novamente. (servidor " + AM_VERSION + ", voce " + clientHandshakePacket.amVersion + ")");
                }
                connection.send(new ClientboundLoginDisconnectPacket(reason));
                connection.disconnect(reason);
                return;
            }

            if (!hostServer.isRunning() && serverConfig.portToSend == -1) {
                LOGGER.info("Host server is not running. Modpack will not be sent to {}", GameHelpers.getPlayerName(profile));
                return;
            }

            if (modpackExecutor.isGenerating()) {
                Component reason = VersionedText.literal("[AveronSync] O servidor esta preparando os arquivos do modpack. Aguarde um momento e tente de novo.");
                connection.send(new ClientboundLoginDisconnectPacket(reason));
                connection.disconnect(reason);
                return;
            }

            // now we know player is authenticated, packets are encrypted and player is whitelisted
            // regenerate unique secret
            Secrets.Secret secret = Secrets.generateSecret();
            SecretsStore.saveHostSecret(GameHelpers.getPlayerUUID(profile).toString(), secret);

            String addressToSend = serverConfig.addressToSend;
            int portToSend = serverConfig.portToSend;
            boolean requiresMagic = (serverConfig.bindPort == -1 && hostServer.isRunning()) || serverConfig.requireMagicPackets;

            LOGGER.info("Sending {} modpack host address: {}:{}", GameHelpers.getPlayerName(profile), addressToSend, portToSend);

            DataPacket dataPacket = new DataPacket(addressToSend, portToSend, serverConfig.modpackName, secret, serverConfig.requireAutoModpackOnClient, requiresMagic);
            String packetContentJson = dataPacket.toJson();

            FriendlyByteBuf outBuf = new FriendlyByteBuf(Unpooled.buffer());
            outBuf.writeUtf(packetContentJson, Short.MAX_VALUE);
            sender.sendPacket(DATA, outBuf);
        } catch (Exception e) {
            LOGGER.error("Error while handling handshake for {}", GameHelpers.getPlayerName(profile), e);
        }
    }


    private static boolean isClientVersionHigher(String clientVersion) {
        try {
            return SemanticVersion.parse(clientVersion).compareTo(SemanticVersion.parse(AM_VERSION)) > 0;
        } catch (IllegalArgumentException exception) {
            return false;
        }
    }
}
