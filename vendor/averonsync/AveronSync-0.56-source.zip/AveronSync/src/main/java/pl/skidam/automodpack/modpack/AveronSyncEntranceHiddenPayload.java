package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Server-to-client: the players that are still waiting for their login (EasyLogin) and will get a join animation.
 * Clients do not draw them until the animation starts, so the player does not stand there visible first. The server
 * resends the list about once a second; a client that stops receiving it shows everyone again after a few seconds.
 */
public record AveronSyncEntranceHiddenPayload(List<UUID> players) implements CustomPacketPayload {
    private static final int MAX = 256;
    public static final Type<AveronSyncEntranceHiddenPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath("averonsync", "entrance_hidden"));
    public static final StreamCodec<RegistryFriendlyByteBuf, AveronSyncEntranceHiddenPayload> CODEC =
            StreamCodec.of(AveronSyncEntranceHiddenPayload::write, AveronSyncEntranceHiddenPayload::read);
    public AveronSyncEntranceHiddenPayload {
        if (players.size() > MAX) throw new IllegalArgumentException("Too many hidden players");
        players = List.copyOf(players);
    }
    private static void write(RegistryFriendlyByteBuf buf, AveronSyncEntranceHiddenPayload data) {
        buf.writeVarInt(data.players.size());
        for (UUID id : data.players) buf.writeUUID(id);
    }
    private static AveronSyncEntranceHiddenPayload read(RegistryFriendlyByteBuf buf) {
        int size = buf.readVarInt();
        if (size < 0 || size > MAX) throw new IllegalArgumentException("Too many hidden players");
        List<UUID> players = new ArrayList<>(size);
        for (int i = 0; i < size; i++) players.add(buf.readUUID());
        return new AveronSyncEntranceHiddenPayload(players);
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
/*?}*/
