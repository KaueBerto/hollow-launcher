package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.util.Mth;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.*;
import pl.skidam.automodpack.client.pets.VipPetRenderer;
import pl.skidam.automodpack.modpack.*;
import pl.skidam.automodpack_core.pets.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

/**
 * Draws the Parro's two ModelEngine blueprints with the shared Blockbench renderer, layering
 * the synced states like ModelEngine does: a default state (idle/walk/run/swim) crossfaded on
 * change, an air state (looped, lerped in and out) and an action state on top. Every layer
 * replaces the keyed channels like Blockbench's "override" preview. Blueprints are Blockbench 5, converted
 * to the 4.x animation signs by tools/import_parro.py.
 */
public final class ParroRenderer extends EntityRenderer<ParroEntity> {
    /** {@code seatBone}: parent of the pack's "mount" bone; {@code seat}: where the mount bone sits in the bind pose. */
    private record Loaded(CubeeModel model, CubeeModel.Clip hideSaddle, List<String> segments, String seatBone, PetAnimation.Vec seat) {}
    private static final Map<String, Optional<Loaded>> MODELS = new HashMap<>();
    private static final Map<ParroEntity, Anim> STATES = new WeakHashMap<>();
    /** ModelEngine "hold" clips keep their last pose; everything else plays once and lerps out. */
    private static final Set<String> HOLD = Set.of("transform", "death");
    /** Lerp-in / lerp-out in ticks, from the state{li;lo} and defaultstate{li;lo} calls in parro_skills.yml. */
    private static final Map<String, int[]> LERP = Map.ofEntries(
            Map.entry("idle", new int[]{4, 4}), Map.entry("walk", new int[]{4, 4}), Map.entry("swim", new int[]{4, 4}),
            Map.entry("run", new int[]{6, 6}), Map.entry("jump1", new int[]{2, 2}), Map.entry("jump2", new int[]{4, 4}),
            Map.entry("jump3", new int[]{6, 6}), Map.entry("jump22", new int[]{4, 6}), Map.entry("petting1", new int[]{4, 4}),
            Map.entry("petting2", new int[]{4, 4}), Map.entry("transform", new int[]{2, 4}), Map.entry("transform_back", new int[]{4, 4}),
            Map.entry("summon", new int[]{2, 2}), Map.entry("spawn", new int[]{1, 4}));
    private static final int[] DEFAULT_LERP = {1, 2};

    public static void init(IEventBus bus) {
        bus.addListener(ParroRenderer::register);
        bus.addListener(ParroRenderer::reload);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(net.neoforged.bus.api.EventPriority.LOWEST, ParroRenderer::riderPre);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(net.neoforged.bus.api.EventPriority.HIGHEST, ParroRenderer::riderPost);
    }
    private static void register(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(AveronSyncHorseContent.PARRO.get(), ParroRenderer::new);
    }
    private static void reload(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((ResourceManagerReloadListener) manager -> { MODELS.clear(); STATES.clear(); });
    }
    public ParroRenderer(EntityRendererProvider.Context context) { super(context); shadowRadius = .65F; }
    private static Loaded model(String id) {
        return MODELS.computeIfAbsent(id, key -> {
            try (var input = Minecraft.getInstance().getResourceManager().getResourceOrThrow(
                    ResourceLocation.fromNamespaceAndPath("averonsync", "parro/" + key + ".json")).open()) {
                byte[] bytes = input.readNBytes(4_000_001);
                if (bytes.length > 4_000_000) throw new java.io.IOException("Parro model too large");
                JsonObject root = JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject();
                List<String> segments = new ArrayList<>();
                if (root.has("segments")) for (var bone : root.getAsJsonArray("segments")) segments.add(bone.getAsString());
                String seatBone = root.has("bones") && root.getAsJsonObject("bones").has("saddle2") ? root.getAsJsonObject("bones").get("saddle2").getAsString() : null;
                PetAnimation.Vec seat = null;
                if (root.has("seat")) { var v = root.getAsJsonArray("seat"); seat = new PetAnimation.Vec(v.get(0).getAsDouble(), v.get(1).getAsDouble(), v.get(2).getAsDouble()); }
                return Optional.of(new Loaded(CubeeModel.parseParro(root), hideClip(root, "saddle1", "saddle2"), List.copyOf(segments), seatBone, seat));
            } catch (Exception e) {
                LOGGER.error("Could not load Parro artwork {}", key, e);
                return Optional.empty();
            }
        }).orElse(null);
    }
    /** A one-frame clip that scales the named bones to zero (the pack's partvis{v=false}). */
    private static CubeeModel.Clip hideClip(JsonObject root, String... bones) {
        if (!root.has("bones")) return null;
        var names = root.getAsJsonObject("bones");
        Map<String, Map<String, List<PetAnimation.Frame>>> tracks = new HashMap<>();
        for (String bone : bones) if (names.has(bone))
            tracks.put(names.get(bone).getAsString(), Map.of("scale", List.of(new PetAnimation.Frame(0, PetAnimation.Vec.ZERO, "step"))));
        return tracks.isEmpty() ? null : new CubeeModel.Clip(1, Map.copyOf(tracks));
    }

    /** What one state slot showed last, so a change can fade the old clip out instead of popping. */
    private static final class Slot {
        String clip = "", fading = "";
        long start, fadingStart;
        double fadeFrom = Double.NEGATIVE_INFINITY, fadingWeight;
        void update(String name, long at, double age, double currentWeight) {
            if (name.equals(clip) && at == start) return;
            if (!clip.isEmpty()) { fading = clip; fadingStart = start; fadeFrom = age; fadingWeight = currentWeight; }
            clip = name; start = at;
        }
    }
    private static final class Anim {
        final Slot base = new Slot(), air = new Slot(), action = new Slot();
        boolean saddled;
        double airWeight, actionWeight;
        final SegmentChain tail = new SegmentChain();
    }
    /**
     * ModelEngine "seg_" bones (Bone Behaviors, Inverse Kinematics): a segment is a link whose front
     * stays attached to its parent while its back pivot keeps its place in the world and is only
     * dragged along at a fixed length ("least amount of movement"). The link may deviate at most
     * {@link #ANGLE_LIMIT} degrees from the parent (bounded=true, anglelimit=50) and straightens back
     * at {@link #EXTEND_RATE} per tick (anglelimit is the ModelEngine default; extendrate 0.01 was raised). Everything
     * under the segment (its cubes and the next tail piece) is turned around the attachment point,
     * so the pieces never come apart.
     */
    static final class SegmentChain implements VipPetRenderer.BoneSolver {
        static final double ANGLE_LIMIT = 50, EXTEND_RATE = .1; // server choice: ModelEngine default 0.01 felt too slow
        private final Map<String, Vector3d> back = new HashMap<>();
        private final Map<String, Quaternionf> turn = new HashMap<>();
        private final Map<String, Vector3f> anchor = new HashMap<>();
        private Set<String> segments = Set.of();
        private double lastAge = Double.NaN, dt;
        private Vec3 camera = Vec3.ZERO;
        void begin(List<String> ids, double age, Vec3 cameraPosition) {
            if (!Set.copyOf(ids).equals(segments)) { segments = Set.copyOf(ids); back.clear(); }
            dt = age - lastAge;
            if (!(dt >= 0) || dt > 10) { back.clear(); dt = 0; }
            lastAge = age; camera = cameraPosition;
        }
        @Override public void apply(CubeeModel.Node parent, CubeeModel.Node bone, PoseStack poses, boolean repeatPass) {
            if (!segments.contains(bone.id())) return;
            if (repeatPass) { var q = turn.get(bone.id()); if (q != null) rotate(poses, anchor.get(bone.id()), q); return; }
            Matrix4f pose = poses.last().pose();
            // Front: the parent's pivot. Back: this bone's own pivot, both as the animation places them.
            Vector3f front = pose.transformPosition(new Vector3f((float) parent.origin().x(), (float) parent.origin().y(), (float) parent.origin().z()));
            Vector3f rigidBack = pose.transformPosition(new Vector3f((float) bone.origin().x(), (float) bone.origin().y(), (float) bone.origin().z()));
            Vector3d frontWorld = new Vector3d(front).add(camera.x, camera.y, camera.z);
            Vector3d rest = new Vector3d(rigidBack).sub(front.x, front.y, front.z);
            double length = rest.length();
            if (length < 1e-6) return;
            rest.div(length);
            Vector3d previous = back.get(bone.id());
            Vector3d dir = previous == null ? new Vector3d(rest) : new Vector3d(previous).sub(frontWorld);
            // A teleport or a huge jump restarts the link straight.
            if (dir.length() < 1e-6 || dir.length() > length * 4) dir.set(rest); else dir.normalize();
            // extendrate: slowly straighten towards the animated (parent-aligned) direction.
            double extend = 1 - Math.pow(1 - EXTEND_RATE, dt);
            dir.lerp(rest, extend).normalize();
            // bounded / anglelimit: never deviate more than the limit from the parent.
            double angle = Math.toDegrees(Math.acos(Math.clamp(dir.dot(rest), -1, 1)));
            if (angle > ANGLE_LIMIT) dir = slerp(rest, dir, ANGLE_LIMIT / angle);
            back.put(bone.id(), new Vector3d(dir).mul(length).add(frontWorld));
            Quaternionf q = new Quaternionf().rotationTo((float) rest.x, (float) rest.y, (float) rest.z, (float) dir.x, (float) dir.y, (float) dir.z);
            turn.put(bone.id(), q); anchor.put(bone.id(), front);
            rotate(poses, front, q);
        }
        private static Vector3d slerp(Vector3d from, Vector3d to, double t) {
            double cos = Math.clamp(from.dot(to), -1, 1), theta = Math.acos(cos);
            if (theta < 1e-6) return new Vector3d(to);
            double sin = Math.sin(theta), a = Math.sin((1 - t) * theta) / sin, b = Math.sin(t * theta) / sin;
            return new Vector3d(from).mul(a).add(new Vector3d(to).mul(b)).normalize();
        }
        /** Turns the current pose around {@code pivot} (camera space) by {@code q}. */
        private static void rotate(PoseStack poses, Vector3f pivot, Quaternionf q) {
            var last = poses.last();
            last.pose().mulLocal(new Matrix4f().translation(pivot).rotate(q).translate(-pivot.x, -pivot.y, -pivot.z));
            last.normal().mulLocal(new Matrix3f().rotation(q));
        }
    }

    /** One frame of the layered pose, shared by drawing the Parro and placing its rider. */
    private record Frame(Loaded loaded, CubeeModel model, Anim anim, String base, double baseTime, double age, float heading, List<VipPetRenderer.ModelLayer> layers) {}
    private static Frame frame(ParroEntity parro, float partial) {
        boolean saddled = parro.saddled();
        Loaded loaded = model(saddled ? "parro_saddle" : "parro");
        if (loaded == null) return null;
        CubeeModel model = loaded.model();
        double age = PetRenderTime.ticks(parro.level().getGameTime(), partial);
        Anim anim = STATES.computeIfAbsent(parro, ignored -> new Anim());
        if (anim.saddled != saddled) {
            // The pack swaps the whole blueprint: start the new model cleanly, without fading clips of the old one.
            STATES.put(parro, anim = new Anim()); anim.saddled = saddled;
        }
        List<VipPetRenderer.ModelLayer> layers = new ArrayList<>();

        String base = parro.baseClip();
        if (!model.animations().containsKey(base)) base = base.equals("run") ? "walk" : "idle";
        anim.base.update(base, parro.baseAt(), age, 1);
        double baseTime = Math.max(0, (age - parro.baseAt()) / 20.0);
        fadingBase(layers, model, anim.base, age);

        String air = parro.airClip();
        anim.air.update(air, air.isEmpty() ? anim.air.start : parro.airAt(), age, anim.airWeight);
        fadingOut(layers, model, anim.air, age, true);
        anim.airWeight = air.isEmpty() ? 0 : layer(layers, model, air, age - parro.airAt(), true, true);

        String action = parro.action();
        anim.action.update(action, parro.actionAt(), age, anim.actionWeight);
        fadingOut(layers, model, anim.action, age, false);
        anim.actionWeight = action.isEmpty() ? 0 : layer(layers, model, action, age - parro.actionAt(), HOLD.contains(action), false);

        // pr_untransform hides the saddle parts while the saddled model shrinks away.
        if (saddled && action.equals("transform") && loaded.hideSaddle() != null && age - parro.actionAt() >= 0)
            layers.add(new VipPetRenderer.ModelLayer(loaded.hideSaddle(), 0, 1));
        return new Frame(loaded, model, anim, base, baseTime, age, Mth.rotLerp(partial, parro.yBodyRotO, parro.yBodyRot), layers);
    }

    @Override public void render(ParroEntity parro, float yaw, float partial, PoseStack poses, MultiBufferSource buffers, int light) {
        shadowRadius = (parro.saddled() ? .8F : .65F) * parro.getScale();
        Frame frame = parro.isInvisible() ? null : frame(parro, partial);
        if (frame != null) {
            poses.pushPose();
            frame.anim().tail.begin(frame.loaded().segments(), frame.age(), Minecraft.getInstance().gameRenderer.getMainCamera().getPosition());
            poses.mulPose(Axis.YP.rotationDegrees(180 - frame.heading()));
            float size = parro.getScale() / 16; // bond level: the body grows with it
            poses.scale(size, size, size);
            VipPetRenderer.renderModel(poses, buffers, frame.model(), frame.base(), frame.baseTime(), frame.age(), light, frame.layers(), null, frame.anim().tail);
            poses.popPose();
        }
        super.render(parro, yaw, partial, poses, buffers, light);
    }

    // ---- rider: follows the animated "mount" bone -------------------------------------------
    /**
     * How far the animation has moved the pack's "mount" bone from its bind pose, in world axes around the Parro.
     * The seat itself is fixed, so without this the rider sinks into the body whenever it sways.
     */
    private static Vec3 riderOffset(ParroEntity parro, float partial) {
        if (!parro.saddled() || parro.isInvisible()) return null;
        Frame frame = frame(parro, partial);
        if (frame == null || frame.loaded().seatBone() == null || frame.loaded().seat() == null) return null;
        var model = frame.model();
        var clip = model.animations().getOrDefault(frame.base(), model.animations().get("idle"));
        var bind = VipPetRenderer.bonePoint(model, new CubeeModel.Clip(1, Map.of()), 0, List.of(), frame.loaded().seatBone(), frame.loaded().seat());
        var now = VipPetRenderer.bonePoint(model, clip, frame.baseTime() % clip.length(), frame.layers(), frame.loaded().seatBone(), frame.loaded().seat());
        if (bind == null || now == null) return null;
        Vector3f delta = new Vector3f((float) (now.x() - bind.x()), (float) (now.y() - bind.y()), (float) (now.z() - bind.z()));
        delta.rotateY((float) Math.toRadians(180 - frame.heading())).mul(parro.getScale() / 16F);
        return new Vec3(delta.x, delta.y, delta.z);
    }
    private static PoseStack shifted;
    /** Runs last, so it only pushes for riders no other handler canceled (Post only follows a real render). */
    private static void riderPre(RenderPlayerEvent.Pre event) {
        shifted = null;
        if (!(event.getEntity().getVehicle() instanceof ParroEntity parro)) return;
        Vec3 offset = riderOffset(parro, event.getPartialTick());
        if (offset == null) return;
        event.getPoseStack().pushPose();
        event.getPoseStack().translate(offset.x, offset.y, offset.z);
        shifted = event.getPoseStack();
    }
    private static void riderPost(RenderPlayerEvent.Post event) {
        if (shifted == null || shifted != event.getPoseStack()) return;
        shifted.popPose(); shifted = null;
    }
    private static int[] lerp(String clip) { return LERP.getOrDefault(clip, DEFAULT_LERP); }
    /** Previous default state, crossfaded out over the new state's lerp-in (defaultstate li/lo). */
    private static void fadingBase(List<VipPetRenderer.ModelLayer> layers, CubeeModel model, Slot slot, double age) {
        var clip = model.animations().get(slot.fading);
        if (clip == null) return;
        double ticks = Math.max(lerp(slot.fading)[1], lerp(slot.clip)[0]);
        double weight = 1 - (age - slot.fadeFrom) / ticks;
        if (weight <= 0) { slot.fading = ""; return; }
        double time = Math.max(0, (age - slot.fadingStart) / 20.0) % clip.length();
        layers.add(new VipPetRenderer.ModelLayer(clip, time, weight));
    }
    /** An air or action clip that was replaced or cleared, lerped out from the pose it had. */
    private static void fadingOut(List<VipPetRenderer.ModelLayer> layers, CubeeModel model, Slot slot, double age, boolean loop) {
        var clip = model.animations().get(slot.fading);
        if (clip == null || slot.fadingWeight <= 0) return;
        double weight = slot.fadingWeight * (1 - (age - slot.fadeFrom) / lerp(slot.fading)[1]);
        if (weight <= 0) { slot.fading = ""; return; }
        double time = Math.max(0, (slot.fadeFrom - slot.fadingStart) / 20.0);
        time = loop ? time % clip.length() : Math.min(time, clip.length() - 1e-4);
        layers.add(new VipPetRenderer.ModelLayer(clip, time, weight));
    }
    /**
     * Adds a state clip {@code ticks} after it started. Loop clips repeat; hold clips keep their
     * last frame; the rest play once and lerp out after their end. Returns the weight used.
     */
    private static double layer(List<VipPetRenderer.ModelLayer> layers, CubeeModel model, String name, double ticks, boolean hold, boolean loop) {
        var clip = model.animations().get(name);
        if (clip == null || ticks < 0) return 0;
        int[] lerp = lerp(name);
        double time = ticks / 20.0, end = clip.length() * 20;
        double weight = lerp[0] <= 0 ? 1 : Math.min(1, ticks / lerp[0]);
        if (!hold && !loop) {
            if (ticks > end + lerp[1]) return 0;
            if (ticks > end) weight *= 1 - (ticks - end) / lerp[1];
        }
        double at = loop ? time % clip.length() : Math.min(time, clip.length() - 1e-4);
        if (weight <= 0) return 0;
        layers.add(new VipPetRenderer.ModelLayer(clip, at, weight));
        return weight;
    }
    @Override public ResourceLocation getTextureLocation(ParroEntity parro) {
        return ResourceLocation.parse("averonsync:textures/parro/" + (parro.saddled() ? "parro_saddle" : "parro") + "/0.png");
    }
}
/*?}*/
