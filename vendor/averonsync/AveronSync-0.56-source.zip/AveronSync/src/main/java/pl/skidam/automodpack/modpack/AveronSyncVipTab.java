package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.PlayerTeam;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import pl.skidam.automodpack.networking.server.AveronSyncEntryQueue;
import pl.skidam.automodpack_core.queue.VipNameStyle;
import pl.skidam.automodpack_core.queue.VipTabStyle;
import java.util.*;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

/**
 * Server-side decoration of the final TAB name: "[VIP]" first, name in the level's color (VIP 1 light blue, VIP 2
 * orange). The client sorts the list from that name (see VipTabOrderMixin). Never changes chat, teams or character data.
 */
public final class AveronSyncVipTab {
    private static final Map<MinecraftServer, Map<UUID, Integer>> STATUS = new IdentityHashMap<>();
    private static boolean integrationErrorLogged;

    /** Active VIP level of the player, 0 when not VIP now. */
    private static int level(ServerPlayer player) {
        var vips = AveronSyncEntryQueue.get(player.server).vips();
        return vips == null ? 0 : vips.level(player.getGameProfile().getName(), System.currentTimeMillis());
    }

    public static void format(PlayerEvent.TabListNameFormat event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !player.server.isDedicatedServer()) return;
        int level = level(player);
        if (level == 0) return;
        int color = VipTabStyle.color(level);
        try {
            String name = displayName(player);
            if (name == null || name.isEmpty()) return;
            Component original = event.getDisplayName();
            if (original == null) original = PlayerTeam.formatNameForTeam(player.getTeam(), Component.literal(player.getGameProfile().getName()));
            List<VipNameStyle.Part<Style>> parts = new ArrayList<>();
            original.visit((style, text) -> {
                parts.add(new VipNameStyle.Part<>(text, style));
                return Optional.empty();
            }, Style.EMPTY);
            var colored = VipNameStyle.color(parts, name, style -> style.withColor(color));
            if (colored == parts) return;
            var result = Component.empty();
            result.append(Component.literal(VipTabStyle.PREFIX).setStyle(Style.EMPTY.withColor(color)));
            for (var part : colored) result.append(Component.literal(part.text()).setStyle(part.style()));
            event.setDisplayName(result);
        } catch (ReflectiveOperationException | RuntimeException e) {
            if (!integrationErrorLogged) {
                integrationErrorLogged = true;
                LOGGER.error("VIP TAB color disabled for incompatible AveronOrigins profile API; original name preserved", e);
            }
        }
    }

    private static String displayName(ServerPlayer player) throws ReflectiveOperationException {
        Class<?> storeType;
        try { storeType = Class.forName("net.hollowsmp.averonorigins.common.persistence.ProfileStore"); }
        catch (ClassNotFoundException absent) { return player.getGameProfile().getName(); }
        Object store = storeType.getMethod("get", MinecraftServer.class).invoke(null, player.server);
        Object profile = storeType.getMethod("find", UUID.class).invoke(store, player.getUUID());
        // Respect AveronOrigins creation requirements; do not synthesize a character name.
        if (profile == null || !Boolean.TRUE.equals(profile.getClass().getMethod("complete").invoke(profile))) return null;
        return (String) profile.getClass().getMethod("name").invoke(profile);
    }

    public static void refresh(ServerPlayer player) {
        if (!player.server.isDedicatedServer()) return;
        STATUS.computeIfAbsent(player.server, ignored -> new HashMap<>()).put(player.getUUID(), level(player));
        player.refreshTabListName();
    }

    public static void refresh(MinecraftServer server, String nickname) {
        for (var player : server.getPlayerList().getPlayers())
            if (player.getGameProfile().getName().equalsIgnoreCase(nickname)) refresh(player);
    }

    public static void tick(MinecraftServer server) {
        if (!server.isDedicatedServer() || server.getTickCount() % 20 != 0) return;
        var statuses = STATUS.computeIfAbsent(server, ignored -> new HashMap<>());
        Set<UUID> online = new HashSet<>();
        for (var player : server.getPlayerList().getPlayers()) {
            online.add(player.getUUID());
            int current = level(player);
            if (!Objects.equals(statuses.get(player.getUUID()), current)) refresh(player);
        }
        statuses.keySet().retainAll(online);
    }

    public static void shutdown(MinecraftServer server) { STATUS.remove(server); }
    private AveronSyncVipTab() {}
}
/*?}*/
