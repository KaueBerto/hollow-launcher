package pl.skidam.automodpack.modpack;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.core.HolderLookup;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import pl.skidam.automodpack_core.queue.VipKitConfig;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/** Turns the owner's {@code config/averonsync-vip-kits.json} into item stacks and puts them in an inventory. */
public final class AveronSyncVipKits {
    public static final Path FILE = Path.of("config", "averonsync-vip-kits.json");

    /** The stacks of one VIP level. The file is read on every call, so edits apply without a restart. */
    public static List<ItemStack> build(HolderLookup.Provider registries, int level) throws IOException {
        var entries = VipKitConfig.load(FILE).getOrDefault(level, List.of());
        var ops = registries.createSerializationContext(JsonOps.INSTANCE);
        List<ItemStack> result = new ArrayList<>();
        for (JsonObject entry : entries) {
            int count = entry.has("count") ? entry.get("count").getAsInt() : 1;
            JsonObject single = entry.deepCopy();
            single.addProperty("count", 1);
            ItemStack stack;
            try {
                stack = ItemStack.CODEC.parse(ops, single).getOrThrow(IllegalArgumentException::new);
            } catch (RuntimeException e) {
                throw new IOException("Item invalido no kit " + level + " (" + entry.get("id") + "): " + e.getMessage(), e);
            }
            if (stack.isEmpty()) throw new IOException("Item invalido no kit " + level + ": " + entry.get("id"));
            for (int left = count; left > 0; left -= stack.getMaxStackSize())
                result.add(stack.copyWithCount(Math.min(left, stack.getMaxStackSize())));
        }
        return result;
    }

    /** Adds the whole kit or nothing: false (and the inventory untouched) when it does not fit. */
    public static boolean give(ServerPlayer player, List<ItemStack> kit) {
        if (kit.isEmpty()) return true;
        List<ItemStack> before = new ArrayList<>();
        for (int i = 0; i < 36; i++) before.add(player.getInventory().getItem(i).copy());
        var planned = AveronSyncVipKitCommand.plan(before, kit);
        if (planned.isEmpty()) return false;
        try { AveronSyncVipKitCommand.setInventory(player, planned.get()); }
        catch (RuntimeException e) { AveronSyncVipKitCommand.setInventory(player, before); throw e; }
        return true;
    }
    private AveronSyncVipKits() {}
}
