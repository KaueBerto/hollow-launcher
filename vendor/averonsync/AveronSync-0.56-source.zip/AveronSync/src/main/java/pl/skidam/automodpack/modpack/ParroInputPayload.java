package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

/** Keys only (ModelEngine's meg:front/side/jump/sneak and the rider's swing); the server moves the Parro. */
public record ParroInputPayload(int entityId, ParroEntity.ParroInput input) implements CustomPacketPayload {
    public static final Type<ParroInputPayload> TYPE = new Type<>(ResourceLocation.parse("averonsync:parro_keys"));
    public static final StreamCodec<RegistryFriendlyByteBuf, ParroInputPayload> CODEC = StreamCodec.of((buf, data) -> {
        buf.writeVarInt(data.entityId); buf.writeByte(data.input.front()); buf.writeByte(data.input.side());
        buf.writeByte((data.input.jump() ? 1 : 0) | (data.input.sneak() ? 2 : 0) | (data.input.attack() ? 4 : 0));
    }, buf -> {
        int id = buf.readVarInt(), front = buf.readByte(), side = buf.readByte(), flags = buf.readUnsignedByte();
        if (id < 0 || flags > 7 || Math.abs(front) > 1 || Math.abs(side) > 1) throw new IllegalArgumentException("Invalid Parro input");
        return new ParroInputPayload(id, new ParroEntity.ParroInput(front, side, (flags & 1) != 0, (flags & 2) != 0, (flags & 4) != 0));
    });
    public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("averonsync-parro-1").playToServer(TYPE, CODEC, (data, context) -> context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player && player.getVehicle() instanceof ParroEntity parro
                    && parro.getId() == data.entityId) parro.acceptInput(player, data.input);
        }));
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
/*?}*/
