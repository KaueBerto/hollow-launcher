package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import pl.skidam.automodpack.modpack.*;

/** Sends the rider's keys to the server, which moves the Parro (ModelEngine-style driver controls). */
public final class ParroKeys {
    private static java.util.UUID lastMount;
    public static void update(MovementInputUpdateEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.getEntity() != mc.player) return;
        if (!(mc.player.getVehicle() instanceof ParroEntity parro) || parro.getControllingPassenger() != mc.player) { lastMount = null; return; }
        if (!parro.getUUID().equals(lastMount)) {
            lastMount = parro.getUUID();
            mc.player.displayClientMessage(Component.literal("W/S: andar • A/D: virar • Espaço: saltar e planar • Shift: descer"), true);
        }
        var options = mc.options;
        boolean enabled = mc.screen == null;
        var input = !enabled ? ParroEntity.ParroInput.NONE : new ParroEntity.ParroInput(
                (options.keyUp.isDown() ? 1 : 0) - (options.keyDown.isDown() ? 1 : 0),
                (options.keyLeft.isDown() ? 1 : 0) - (options.keyRight.isDown() ? 1 : 0),
                options.keyJump.isDown(), options.keyShift.isDown(), options.keyAttack.isDown());
        PacketDistributor.sendToServer(new ParroInputPayload(parro.getId(), input));
        event.getInput().jumping = false;
    }
    private ParroKeys() {}
}
/*?}*/
