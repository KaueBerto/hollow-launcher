package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import pl.skidam.automodpack_core.entrance.EntranceCatalog;
import java.util.UUID;

/**
 * Server-to-client: play a join ({@code in}) or leave animation for {@code player} at a fixed spot.
 * {@code scale} is the player's vanilla {@code minecraft:scale} (AveronOrigins races use it).
 */
public record AveronSyncEntrancePayload(UUID player, String theme, boolean in, double x, double y, double z, float yaw, float scale)
        implements CustomPacketPayload {
    public static final Type<AveronSyncEntrancePayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath("averonsync", "entrance"));
    public static final StreamCodec<RegistryFriendlyByteBuf, AveronSyncEntrancePayload> CODEC = StreamCodec.of(AveronSyncEntrancePayload::write, AveronSyncEntrancePayload::read);
    public AveronSyncEntrancePayload {
        if (!EntranceCatalog.contains(theme) || !Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z) || !Float.isFinite(yaw)
                || !(scale >= 0.0625f && scale <= 16f))
            throw new IllegalArgumentException("Invalid entrance animation");
    }
    private static void write(RegistryFriendlyByteBuf buf, AveronSyncEntrancePayload data) {
        buf.writeUUID(data.player); buf.writeUtf(data.theme, 32); buf.writeBoolean(data.in);
        buf.writeDouble(data.x); buf.writeDouble(data.y); buf.writeDouble(data.z); buf.writeFloat(data.yaw); buf.writeFloat(data.scale);
    }
    private static AveronSyncEntrancePayload read(RegistryFriendlyByteBuf buf) {
        return new AveronSyncEntrancePayload(buf.readUUID(), buf.readUtf(32), buf.readBoolean(), buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readFloat(), buf.readFloat());
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
/*?}*/
