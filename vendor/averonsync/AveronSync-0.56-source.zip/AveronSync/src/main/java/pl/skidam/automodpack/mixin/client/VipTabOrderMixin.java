package pl.skidam.automodpack.mixin.client;

/*? if neoforge {*/
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Style;
import net.minecraft.world.level.GameType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.skidam.automodpack_core.queue.VipTabStyle;
import java.util.*;

/**
 * Orders the TAB list as VIP 2, VIP 1, then everyone else, each group alphabetical by the shown name. The rank is read
 * from the "[VIP]" tag and color the server wrote into the name (VipTabStyle), so servers need no extra packet.
 * Spectators stay last, as in vanilla.
 */
@Mixin(PlayerTabOverlay.class)
public abstract class VipTabOrderMixin {
    private record Row(PlayerInfo info, boolean spectator, int level, String key) {}

    @Inject(method = "getPlayerInfos", at = @At("RETURN"), cancellable = true, require = 0)
    private void averonsync$orderVips(CallbackInfoReturnable<List<PlayerInfo>> result) {
        List<PlayerInfo> original = result.getReturnValue();
        if (original == null || original.size() < 2) return;
        List<Row> rows = new ArrayList<>(original.size());
        boolean any = false;
        for (PlayerInfo info : original) {
            var shown = info.getTabListDisplayName();
            int level = 0;
            String text = shown == null ? info.getProfile().getName() : shown.getString();
            if (shown != null) {
                // First non-empty piece of text: the tag and its color when the player is a VIP.
                var first = new Object[]{null, 0};
                shown.visit((style, piece) -> {
                    if (piece.isEmpty()) return Optional.empty();
                    first[0] = piece;
                    first[1] = style.getColor() == null ? 0 : style.getColor().getValue();
                    return Optional.of(piece);
                }, Style.EMPTY);
                level = VipTabStyle.level((String) first[0], (Integer) first[1]);
            }
            any |= level > 0;
            rows.add(new Row(info, info.getGameMode() == GameType.SPECTATOR, level, VipTabStyle.sortKey(text)));
        }
        // Nobody is a VIP (or the server is not ours): keep the vanilla order untouched.
        if (!any) return;
        rows.sort((a, b) -> a.spectator() != b.spectator() ? Boolean.compare(a.spectator(), b.spectator())
                : VipTabStyle.compare(a.level(), a.key(), b.level(), b.key()));
        result.setReturnValue(rows.stream().map(Row::info).toList());
    }
}
/*?}*/
