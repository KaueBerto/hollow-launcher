package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.*;
import net.minecraft.core.registries.Registries;
import java.util.function.Supplier;

public final class AveronSyncHorseContent {
    private static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, "averonsync");
    private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("averonsync");
    public static final Supplier<EntityType<QuestHorseEntity>> HORSE = ENTITIES.register("quest_horse", () ->
            EntityType.Builder.of(QuestHorseEntity::new, MobCategory.CREATURE).sized(1.5F, 3F)
                    .clientTrackingRange(10).updateInterval(1).build("averonsync:quest_horse"));
    /** DepartmentQDE x Mister Spooky Parro (companion hitbox; saddled form resizes itself). */
    public static final Supplier<EntityType<ParroEntity>> PARRO = ENTITIES.register("parro", () ->
            EntityType.Builder.of(ParroEntity::new, MobCategory.CREATURE).sized(1.25F, 1.375F)
                    .clientTrackingRange(10).updateInterval(1).build("averonsync:parro"));
    public static final Supplier<HorseWhistleItem> WHISTLE = ITEMS.register("horse_whistle", () -> new HorseWhistleItem(new Item.Properties().stacksTo(1)));
    public static final Supplier<Item> BRUSH = ITEMS.register("horse_brush", () -> new Item(new Item.Properties().stacksTo(1)));

    public static void init(IEventBus bus) {
        ENTITIES.register(bus); ITEMS.register(bus);
        bus.addListener(AveronSyncHorseContent::attributes);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(AveronSyncQuestHorses.class);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(AveronSyncParro.class);
    }
    private static void attributes(EntityAttributeCreationEvent event) {
        event.put(HORSE.get(), Horse.createBaseHorseAttributes()
                .add(Attributes.MAX_HEALTH,24).add(Attributes.SAFE_FALL_DISTANCE,5).build());
        // MythicMobs "Parro": Health 20, Damage 4, MovementSpeed 0.25, FollowRange 32,
        // KnockbackResistance 0.3, WATER_MOVEMENT_EFFICIENCY 1.
        event.put(PARRO.get(), net.minecraft.world.entity.Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH,20).add(Attributes.ATTACK_DAMAGE,4).add(Attributes.MOVEMENT_SPEED,.25)
                .add(Attributes.FOLLOW_RANGE,32).add(Attributes.KNOCKBACK_RESISTANCE,.3)
                .add(Attributes.WATER_MOVEMENT_EFFICIENCY,1).add(Attributes.STEP_HEIGHT,1.125).build());
    }
    private AveronSyncHorseContent() {}
}
/*?}*/
