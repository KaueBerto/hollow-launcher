package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import pl.skidam.automodpack.modpack.*;
import pl.skidam.automodpack_core.mounts.HorseCoat;
import pl.skidam.automodpack_core.pets.VipPetAccess;
import pl.skidam.automodpack_core.pets.PetCatalog;
import java.util.List;

public final class MountScreen extends Screen {
    private final int screenId;
    private MountMenuState state;
    private QuestHorseEntity preview;
    private HorseCoat previewCoat=HorseCoat.BAY;
    private boolean pending;
    private boolean pets,lastPetAccess,parroTab;
    private int ticks,petPage;
    private int left,top,panelWidth,panelHeight;
    public MountScreen(int id) {this(id,false);}
    public MountScreen(int id,boolean pets) { super(Component.literal("Companheiros"));screenId=id;this.pets=pets; }
    int screenId(){return screenId;}
    void update(MountMenuState value){
        if(state==null || state.coat()!=value.coat() || !previewCoat.allowed(value.operatorCoats(),value.petLevel())) previewCoat=value.coat();
        state=value;pending=false;rebuildWidgets();
    }
    @Override protected void init() {
        panelWidth=Math.min(360,width-20);panelHeight=Math.min(252,height-20);
        left=(width-panelWidth)/2;top=(height-panelHeight)/2;
        int tabWidth=(panelWidth-40)/3;
        var horsesTab=Button.builder(Component.literal("Cavalos"),b->{pets=false;parroTab=false;pending=false;rebuildWidgets();})
                .bounds(left+12,top+31,tabWidth,20).build();horsesTab.active=pets||parroTab;addRenderableWidget(horsesTab);
        var petsTab=Button.builder(Component.literal("Pets"),b->{pets=true;parroTab=false;pending=false;rebuildWidgets();})
                .bounds(left+20+tabWidth,top+31,tabWidth,20).build();petsTab.active=!pets||parroTab;addRenderableWidget(petsTab);
        var parroButton=Button.builder(Component.literal("Parro"),b->{parroTab=true;pets=false;pending=false;rebuildWidgets();})
                .bounds(left+28+2*tabWidth,top+31,tabWidth,20).build();parroButton.active=!parroTab;addRenderableWidget(parroButton);
        lastPetAccess=petAccess();
        if(parroTab){initParro();return;}
        if(pets){initPets();return;}
        if(minecraft!=null && minecraft.level!=null && (preview==null || preview.level()!=minecraft.level)) {
            preview=AveronSyncHorseContent.HORSE.get().create(minecraft.level);
            if(preview!=null){preview.setTamed(true);QuestHorseRenderer.markPreview(preview);}
        }
        String label=pending?"Aguarde…":state==null?"Carregando…":"Selecionar";
        boolean canCycle=state!=null && state.unlocked() && (state.operatorCoats() || state.petLevel()>0);
        int buttonWidth=(panelWidth-(canCycle?40:32))/(canCycle?3:2);
        var button=Button.builder(Component.literal(label),b->{
            int action=MountMenuRequest.selectAction(previewCoat);
            pending=true;rebuildWidgets();MountMenuClient.send(screenId,action);
        }).bounds(left+12,top+panelHeight-32,buttonWidth,20).build();
        button.active=!pending && state!=null && state.enabled() && state.unlocked();
        if(state!=null && !button.active && !pending)button.setTooltip(Tooltip.create(Component.literal("Indisponível")));
        addRenderableWidget(button);
        if(canCycle) {
            var cycle=Button.builder(Component.literal("Pelagem ›"),b->{
                var coats=HorseCoat.values();
                // Next coat this player may use (VIP level or operator); there is always at least the bay one.
                for(int i=1;i<=coats.length;i++) {
                    var next=coats[(previewCoat.ordinal()+i)%coats.length];
                    if(next.allowed(state.operatorCoats(),state.petLevel())){previewCoat=next;break;}
                }
            }).bounds(left+20+buttonWidth,top+panelHeight-32,buttonWidth,20).build();
            cycle.active=!pending;
            addRenderableWidget(cycle);
        }
        int closeX=left+(canCycle?28+2*buttonWidth:20+buttonWidth);
        addRenderableWidget(Button.builder(Component.literal("Fechar"),b->onClose()).bounds(closeX,top+panelHeight-32,buttonWidth,20).build());
    }
    private boolean petAccess(){return state!=null && state.enabled() && state.petUntil()>System.currentTimeMillis();}
    private List<PetCatalog.Pet> petOptions() {
        return VipPetAccess.available(state==null?0:state.petLevel(),state!=null && state.operatorCoats());
    }
    private List<PetCatalog.Pet> pagePets() {
        var all=petOptions();
        petPage=Math.clamp(petPage,0,(all.size()-1)/3);
        int start=petPage*3;
        return all.subList(start,Math.min(start+3,all.size()));
    }
    private void initPets() {
        var available=pagePets();
        int step=available.isEmpty()?1:(panelWidth-24)/available.size(); // no pets for this player: nothing to lay out
        for(int i=0;i<available.size();i++) {
            var pet=available.get(i);
            String selected=state!=null && pet.id().equals(state.selectedPet())?"✓ ":"";
            var button=Button.builder(Component.literal(font.plainSubstrByWidth(selected+pet.name(),step-12)),b->sendPet("usar "+pet.id()))
                    .bounds(left+14+i*step,top+118,step-4,20).build();
            button.active=petAccess();
            if(!button.active)button.setTooltip(Tooltip.create(Component.literal("VIP ativo necessário.")));
            else button.setTooltip(Tooltip.create(Component.literal(pet.name())));
            addRenderableWidget(button);
        }
        int pages=(petOptions().size()+2)/3;
        if(pages>1) {
            var previous=Button.builder(Component.literal("‹"),b->{petPage--;rebuildWidgets();})
                    .bounds(left+12,top+panelHeight-59,26,20).build();
            previous.active=petPage>0;addRenderableWidget(previous);
            var next=Button.builder(Component.literal("›"),b->{petPage++;rebuildWidgets();})
                    .bounds(left+panelWidth-38,top+panelHeight-59,26,20).build();
            next.active=petPage<pages-1;addRenderableWidget(next);
        }
        int size=(panelWidth-42)/4;
        String[] labels={"Guardar","Carinho","Emote","Fechar"};String[] actions={"guardar","carinho","emote",""};
        for(int i=0;i<labels.length;i++) {
            final String action=actions[i];
            var button=Button.builder(Component.literal(labels[i]),b->{if(action.isEmpty())onClose();else sendPet(action);})
                    .bounds(left+12+i*(size+6),top+panelHeight-32,size,20).build();
            button.active=action.isEmpty() || (petAccess() && state!=null && !state.selectedPet().isEmpty());
            addRenderableWidget(button);
        }
    }
    private void initParro() {
        int size=(panelWidth-36)/3;
        int owned=state==null?0:state.parro();
        String[] labels={"Chamar","Guardar","Fechar"};String[] actions={"chamar","guardar",""};
        for(int i=0;i<labels.length;i++) {
            final String action=actions[i];
            var button=Button.builder(Component.literal(labels[i]),b->{
                if(!action.isEmpty() && minecraft!=null && minecraft.player!=null)minecraft.player.connection.sendCommand("parro "+action);
                onClose();
            }).bounds(left+12+i*(size+6),top+panelHeight-32,size,20).build();
            button.active=action.isEmpty() || (action.equals("chamar")?owned==1:owned==2);
            addRenderableWidget(button);
        }
    }
    private void renderParro(GuiGraphics g) {
        int owned=state==null?0:state.parro();
        g.pose().pushPose();g.pose().translate(left+panelWidth/2-24,top+72,0);g.pose().scale(3,3,1);
        g.blit(ResourceLocation.parse("averonsync:textures/parro/icon.png"),0,0,0,0,16,16,16,16);
        g.pose().popPose();
        String line=state==null?"Carregando…":owned==0?"Você ainda não tem o Parro.":state.parroStatus();
        g.drawCenteredString(font,font.plainSubstrByWidth(line,panelWidth-32),left+panelWidth/2,top+128,0xFFF1E7C9);
        if(owned>0)g.drawCenteredString(font,Component.literal(owned==2?"Chamado":"Guardado"),left+panelWidth/2,top+140,0xFF63DED0);
        String[] help={"Sela na mão: vira montaria • Tesoura: tira a sela","Clique: carinho • Montado: Espaço salta e plana"};
        for(int i=0;i<help.length;i++)g.drawCenteredString(font,font.plainSubstrByWidth(help[i],panelWidth-32),left+panelWidth/2,top+156+i*11,0xFF8BA5A6);
    }
    private void sendPet(String command) {
        if(minecraft!=null && minecraft.player!=null)minecraft.player.connection.sendCommand("petvip "+command);
        onClose();
    }
    @Override public void tick() {
        super.tick();
        if(minecraft==null || minecraft.player==null){onClose();return;}
        if(pets && petAccess()!=lastPetAccess)rebuildWidgets();
        if(++ticks%20==0)MountMenuClient.send(screenId,MountMenuRequest.QUERY);
    }
    @Override public boolean keyPressed(int key,int scan,int modifiers) {
        if(MountMenuClient.OPEN.matches(key,scan)){onClose();return true;}
        return super.keyPressed(key,scan,modifiers);
    }
    @Override public void renderBackground(GuiGraphics g,int mouseX,int mouseY,float partial) {
        // Screen's default background runs the vanilla blur post-process.
        // Keep this menu sharp without changing the player's global settings.
        g.fill(0,0,width,height,0x66000000);
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial) {
        renderBackground(g,mouseX,mouseY,partial);
        g.fill(left-1,top-1,left+panelWidth+1,top+panelHeight+1,0xFF285957);
        g.fill(left,top,left+panelWidth,top+panelHeight,0xF0142026);
        g.fill(left,top,left+panelWidth,top+2,0xFF63DED0);
        g.drawString(font,title,left+14,top+13,0xFFE8F8F4,false);
        g.drawString(font,Component.literal("G / Esc"),left+panelWidth-54,top+14,0xFF8BA5A6,false);
        int previewRight=left+panelWidth-12;
        int previewBottom=top+panelHeight-44;
        g.fill(left+12,top+60,previewRight,previewBottom,0xFF0D171D);
        if(parroTab)renderParro(g);
        else if(pets)renderPets(g);
        else {
            g.drawCenteredString(font,Component.literal(previewCoat.label()),left+panelWidth/2,top+67,0xFFF1E7C9);
            if(state!=null && state.unlocked())
                g.drawCenteredString(font,font.plainSubstrByWidth(state.message(),panelWidth-32),left+panelWidth/2,top+79,0xFF8BA5A6);
            if(preview!=null)preview.setCoat(previewCoat);
            if(preview!=null)InventoryScreen.renderEntityInInventoryFollowsMouse(g,left+12,top+91,previewRight,previewBottom,
                    Math.max(20,Math.min(32,(previewBottom-top-86)/3)),.0625F,mouseX,mouseY,preview);
        }
        super.render(g,mouseX,mouseY,partial);
    }
    private void renderPets(GuiGraphics g) {
        var available=pagePets();
        if(available.isEmpty()) {
            String text=state==null?"Carregando…":!petAccess()?"Pets exigem VIP ativo.":"Nenhum pet disponível para o seu nível.";
            g.drawCenteredString(font,font.plainSubstrByWidth(text,panelWidth-32),left+panelWidth/2,top+104,0xFFF1E7C9);
            return;
        }
        int step=(panelWidth-24)/available.size();
        for(int i=0;i<available.size();i++) {
            var pet=available.get(i);int x=left+12+i*step,center=x+step/2;
            boolean selected=state!=null && pet.id().equals(state.selectedPet());
            g.fill(x+2,top+64,x+step-2,top+panelHeight-49,selected?0xFF285957:0xFF17262E);
            g.pose().pushPose();g.pose().translate(center-16,top+76,0);g.pose().scale(2,2,1);
            g.blit(ResourceLocation.parse("averonsync:textures/pets/icons/"+pet.id()+".png"),0,0,0,0,16,16,16,16);
            g.pose().popPose();
            if(selected)g.drawCenteredString(font,Component.literal("Selecionado"),center,top+151,0xFF63DED0);
        }
        int pages=(petOptions().size()+2)/3;
        if(pages>1)g.drawCenteredString(font,Component.literal((petPage+1)+" / "+pages),
                left+panelWidth/2,top+panelHeight-53,0xFF8BA5A6);
    }
    @Override public boolean isPauseScreen(){return false;}
    @Override public void removed(){MountMenuClient.closed();super.removed();}
}
/*?}*/
