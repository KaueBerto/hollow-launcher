package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import pl.skidam.automodpack_core.mounts.HorseCoat;

public record MountMenuState(int screenId,boolean enabled,boolean unlocked,boolean whistle,boolean active,
                             boolean canStore,boolean close,String message,long petUntil,String selectedPet,
                             boolean operatorCoats,HorseCoat coat,int petLevel,int parro,String parroStatus) implements CustomPacketPayload {
    public MountMenuState(int id,boolean enabled,boolean unlocked,boolean whistle,boolean active,boolean canStore,boolean close,String message) {
        this(id,enabled,unlocked,whistle,active,canStore,close,message,0,"",false,HorseCoat.BAY,0,0,"");
    }
    public MountMenuState(int id,boolean enabled,boolean unlocked,boolean whistle,boolean active,boolean canStore,boolean close,
                          String message,long petUntil,String selectedPet,int petLevel,int parro,String parroStatus) {
        this(id,enabled,unlocked,whistle,active,canStore,close,message,petUntil,selectedPet,false,HorseCoat.BAY,petLevel,parro,parroStatus);
    }
    public static final Type<MountMenuState> TYPE=new Type<>(ResourceLocation.parse("averonsync:mount_menu_state"));
    public static final StreamCodec<RegistryFriendlyByteBuf,MountMenuState> CODEC=StreamCodec.of((buf,s)->{
        buf.writeVarInt(s.screenId);buf.writeByte((s.enabled?1:0)|(s.unlocked?2:0)|(s.whistle?4:0)|(s.active?8:0)|(s.canStore?16:0)|(s.close?32:0));buf.writeUtf(s.message,120);
        buf.writeLong(s.petUntil);buf.writeUtf(s.selectedPet,48);
        buf.writeBoolean(s.operatorCoats);buf.writeEnum(s.coat);buf.writeByte(s.petLevel);buf.writeByte(s.parro);buf.writeUtf(s.parroStatus,120);
    },buf->{
        int id=buf.readVarInt(),flags=buf.readUnsignedByte();String message=buf.readUtf(120);
        if(flags>63)throw new IllegalArgumentException("Invalid mount menu flags");
        return new MountMenuState(id,(flags&1)!=0,(flags&2)!=0,(flags&4)!=0,(flags&8)!=0,(flags&16)!=0,(flags&32)!=0,
                message,buf.readLong(),buf.readUtf(48),buf.readBoolean(),buf.readEnum(HorseCoat.class),buf.readUnsignedByte(),buf.readUnsignedByte(),buf.readUtf(120));
    });
    public MountMenuState {
        if(screenId<1 || message==null || message.length()>120 || (canStore&&!active) || (whistle&&!unlocked)
                || coat==null || !coat.allowed(operatorCoats,petLevel)
                || parro<0 || parro>2 || parroStatus==null || parroStatus.length()>120
                || petUntil<0 || petLevel<0 || petLevel>pl.skidam.automodpack_core.pets.VipPetAccess.MAX_LEVEL || selectedPet==null
                || (!selectedPet.isEmpty() && !pl.skidam.automodpack_core.pets.VipPetAccess.allows(petLevel,selectedPet,operatorCoats)))
            throw new IllegalArgumentException("Invalid mount menu state");
    }
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
}
/*?}*/
