package pl.skidam.automodpack.client.entrance;

/*? if neoforge {*/
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import org.joml.Vector3f;
import java.util.*;
import java.util.function.Supplier;

/**
 * Sounds and particles of the EliteAnimations v1 skills (SkillsFile_EA-Halloween.yml),
 * transcribed by hand. Not a MythicMobs interpreter: "totem" projectiles and
 * {@code @ModelPart} targets are approximated with fixed offsets around the spot.
 */
final class EntranceEffects {
    private sealed interface Fx permits Sound, Particles { int tick(); }
    private record Sound(int tick, String id, float volume, float pitch) implements Fx {}
    /** {@code forward}/{@code side} are in blocks relative to the player's facing; {@code up} above the feet. */
    private record Particles(int tick, int repeat, int interval, Supplier<ParticleOptions> type, int amount,
                             double hs, double vs, double speed, double forward, double side, double up) implements Fx {}

    private static Sound own(String model) { return new Sound(0, "averonsync:entrance." + model, 1, 1); }
    private static Sound vanilla(int tick, String id, float volume, float pitch) { return new Sound(tick, "minecraft:" + id, volume, pitch); }
    private static Particles at(int tick, Supplier<ParticleOptions> type, int amount, double hs, double vs, double speed, double up) {
        return new Particles(tick, 1, 1, type, amount, hs, vs, speed, 0, 0, up);
    }
    private static Particles repeat(int tick, int repeat, int interval, Supplier<ParticleOptions> type, int amount, double hs, double vs, double speed, double up) {
        return new Particles(tick, repeat, interval, type, amount, hs, vs, speed, 0, 0, up);
    }
    private static Particles offset(int tick, int repeat, int interval, Supplier<ParticleOptions> type, int amount, double hs, double vs, double speed,
                                    double forward, double side, double up) {
        return new Particles(tick, repeat, interval, type, amount, hs, vs, speed, forward, side, up);
    }
    private static Supplier<ParticleOptions> simple(SimpleParticleType type) { return () -> type; }
    private static Supplier<ParticleOptions> dust(int from, int to, float size) {
        return () -> new DustColorTransitionOptions(rgb(from), rgb(to), size);
    }
    private static Vector3f rgb(int color) { return new Vector3f((color >> 16 & 255) / 255f, (color >> 8 & 255) / 255f, (color & 255) / 255f); }
    private static final Supplier<ParticleOptions> REDSTONE = () -> new BlockParticleOption(ParticleTypes.BLOCK, Blocks.REDSTONE_BLOCK.defaultBlockState());
    private static final Supplier<ParticleOptions> DIRT = () -> new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState());
    private static final Supplier<ParticleOptions> STONE = () -> new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());

    private static List<Fx> midnightIn() {
        List<Fx> fx = new ArrayList<>(List.of(own("midnightlord_in"),
                at(0, simple(ParticleTypes.REVERSE_PORTAL), 40, 1.75, 1.75, .85, 1),
                vanilla(0, "entity.evoker.prepare_attack", 1, 1.4f),
                at(18, simple(ParticleTypes.SMOKE), 200, .1, .1, .8, 1),
                at(18, simple(ParticleTypes.CAMPFIRE_COSY_SMOKE), 50, .1, .1, .8, 1)));
        // Four "totems" around the player: forward ±5 and to each side ±5, 1–3 blocks up.
        for (double[] o : new double[][]{{5, 0}, {-5, 0}, {0, 5}, {0, -5}})
            fx.add(offset(0, 2, 4, simple(ParticleTypes.SMOKE), 40, .55, 1.75, .85, o[0], o[1], 2));
        return fx;
    }
    private static List<Fx> midnightOut() {
        return List.of(own("midnightlord_out"),
                repeat(0, 10, 3, dust(0x371115, 0xa27cb7, 3), 5, 1.5, 1, 0, 2.5),
                repeat(0, 10, 3, simple(ParticleTypes.LARGE_SMOKE), 5, 1.5, 1, 0, 2.5),
                vanilla(0, "entity.zoglin.death", 1, .1f));
    }
    private static List<Fx> hellGate(boolean in) {
        int repeat = in ? 20 : 18;
        List<Fx> fx = new ArrayList<>(List.of(own(in ? "hellgate_in" : "hellgate_out"),
                offset(0, repeat, 2, simple(ParticleTypes.SMOKE), 3, .75, 1.45, .4, -4, 0, .5),
                offset(0, repeat, 2, simple(ParticleTypes.LAVA), 3, .75, 1.45, .4, -4, 0, .5),
                offset(0, repeat, 2, simple(ParticleTypes.FLAME), 3, .75, .45, .4, -4, 0, .5),
                offset(0, repeat, 2, dust(0xfd7a5e, 0xb12832, 3), 7, .8, .15, 0, -6.5, 0, .5)));
        if (in) { fx.add(vanilla(0, "entity.allay.ambient_without_item", 1, .1f)); fx.add(vanilla(0, "entity.allay.ambient_with_item", 1, .1f)); }
        else fx.add(vanilla(0, "entity.piglin.converted_to_zombified", 1, .3f));
        return fx;
    }
    private static List<Fx> ragdoll(boolean in) {
        List<Fx> fx = new ArrayList<>(List.of(own(in ? "ragdollpossession_in" : "ragdollpossession_out"),
                repeat(0, in ? 15 : 10, 2, dust(0x31909e, 0x61ded3, 1.2f), 5, .2, .2, 0, 1.6),
                repeat(0, in ? 15 : 30, 2, simple(ParticleTypes.SOUL_FIRE_FLAME), 2, .1, .1, 0, 1.6),
                at(in ? 29 : 0, simple(ParticleTypes.SOUL_FIRE_FLAME), 40, .1, .1, 1, 1),
                at(in ? 28 : 0, simple(ParticleTypes.SOUL), 40, .2, .2, .15, 1),
                vanilla(in ? 28 : 11, "entity.vex.death", 1, 1.2f),
                vanilla(0, "entity.vex.charge", 1, 1)));
        return fx;
    }
    private static List<Fx> cadaverIn() {
        return List.of(own("cadavercurse_in"),
                vanilla(0, "entity.allay.death", 1, .5f),
                vanilla(32, "entity.zombie_villager.cure", 1, 1.6f),
                at(0, simple(ParticleTypes.SOUL), 20, .5, .2, .02, 1),
                at(33, simple(ParticleTypes.SMOKE), 200, .1, .7, 1, 1),
                at(33, simple(ParticleTypes.CLOUD), 50, .1, .7, 1, 1));
    }
    private static List<Fx> cadaverOut() {
        List<Fx> fx = new ArrayList<>(List.of(own("cadavercurse_out"),
                vanilla(3, "entity.ghast.hurt", .4f, .1f),
                vanilla(0, "entity.illusioner.prepare_blindness", 1, .8f)));
        // The curse breaks the limbs one by one: left arm, right arm, right leg, left leg, head.
        int[][] parts = {{1, 0}, {6, 0}, {13, 1}, {23, 1}, {30, 2}};
        double[] height = {1.4, .5, 1.7};
        double[] side = {.35, -.35, -.15, .15, 0};
        for (int i = 0; i < parts.length; i++) {
            int tick = parts[i][0]; double up = height[parts[i][1]];
            fx.add(offset(i == 4 ? 26 : tick, 1, 1, REDSTONE, 10, .1, .1, 0, 0, side[i], up));
            fx.add(offset(tick, 1, 1, simple(ParticleTypes.SMOKE), 10, .2, .2, .1, 0, side[i], up));
            fx.add(vanilla(tick, "entity.zombie.break_wooden_door", .15f, 1.3f));
        }
        return fx;
    }
    private static List<Fx> risen(boolean in) {
        List<Fx> fx = new ArrayList<>(List.of(own(in ? "risendread_in" : "risendread_out"),
                repeat(0, 16, 2, DIRT, 10, .6, .1, 0, 0),
                repeat(0, 16, 2, STONE, 10, .6, .1, 0, 0),
                repeat(0, 5, 6, simple(ParticleTypes.SOUL), 5, .8, .7, 0, 0)));
        if (!in) fx.add(vanilla(0, "entity.zombie_horse.death", 1, 1.3f));
        return fx;
    }
    private static final Map<String, List<Fx>> EFFECTS = Map.of(
            "midnightlord_in", midnightIn(), "midnightlord_out", midnightOut(),
            "hellgate_in", hellGate(true), "hellgate_out", hellGate(false),
            "ragdollpossession_in", ragdoll(true), "ragdollpossession_out", ragdoll(false),
            "cadavercurse_in", cadaverIn(), "cadavercurse_out", cadaverOut(),
            "risendread_in", risen(true), "risendread_out", risen(false));

    /** Runs every effect scheduled for {@code tick} (ticks since the animation started). */
    static void fire(ClientLevel level, String model, int tick, double x, double y, double z, float yaw, float scale) {
        RandomSource random = level.getRandom();
        double rad = yaw * Mth.DEG_TO_RAD;
        double fx = -Math.sin(rad), fz = Math.cos(rad), sx = -fz, sz = fx;
        for (var effect : EFFECTS.getOrDefault(model, List.of())) {
            if (effect instanceof Sound s) {
                if (s.tick != tick) continue;
                level.playLocalSound(x, y, z, SoundEvent.createVariableRangeEvent(ResourceLocation.parse(s.id)), SoundSource.PLAYERS, s.volume, s.pitch, false);
            } else if (effect instanceof Particles p) {
                int since = tick - p.tick;
                if (since < 0 || since % p.interval != 0 || since / p.interval >= p.repeat) continue;
                var options = p.type.get();
                double cx = x + (fx * p.forward + sx * p.side) * scale, cy = y + p.up * scale, cz = z + (fz * p.forward + sz * p.side) * scale;
                double hs = p.hs * scale, vs = p.vs * scale;
                for (int i = 0; i < p.amount; i++) {
                    level.addParticle(options, cx + random.nextGaussian() * hs, cy + random.nextGaussian() * vs, cz + random.nextGaussian() * hs,
                            random.nextGaussian() * p.speed, random.nextGaussian() * p.speed, random.nextGaussian() * p.speed);
                }
            }
        }
    }
    private EntranceEffects() {}
}
/*?}*/
