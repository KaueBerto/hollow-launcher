"""Import the user-supplied EliteAnimations (Halloween) pack for native join/leave animations.

Reads only the .bbmodel files and the .ogg sounds from the ZIP. Plugin configs
(MythicMobs, ModelEngine, AnimationsCore, ItemsAdder, Oraxen) are not executed
or copied; their effects were transcribed by hand into EntranceEffects.java.
Generated artwork is kept outside Git; importing does not change the rights of
the original authors.

ModelEngine "player limb" bones (phead_, pbody_, plarm_, prarm_, plleg_, prleg_)
become cubes tagged with "skin": the client draws the owner's skin there.
"""
from pathlib import Path
import argparse, base64, hashlib, json, math, re, struct, zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'src/main/resources/assets/averonsync'
THEMES = ['cadavercurse', 'hellgate', 'midnightlord', 'ragdollpossession', 'risendread']
LIMBS = {'phead_': 'head', 'pbody_': 'body', 'plarm_': 'left_arm', 'prarm_': 'right_arm',
         'plleg_': 'left_leg', 'prleg_': 'right_leg'}

def vector(value, default):
    value = value if value is not None else default
    result = [float(v) for v in value]
    if len(result) != 3 or not all(math.isfinite(v) for v in result):
        raise ValueError('Invalid model vector')
    return result

def convert(raw, model_id):
    textures = []
    for index, texture in enumerate(raw['textures']):
        source = texture.get('source', '')
        if not source.startswith('data:image/png;base64,'): raise ValueError('External texture rejected')
        data = base64.b64decode(source.split(',', 1)[1], validate=True)
        if data[:8] != b'\x89PNG\r\n\x1a\n': raise ValueError('Invalid PNG')
        width, height = struct.unpack('>II', data[16:24])
        uvw, uvh = float(texture['uv_width']), float(texture['uv_height'])
        if not (0 < uvw <= 2048 and 0 < uvh <= 4096 and width <= 2048 and height <= 4096): raise ValueError('Invalid texture bounds')
        path = f'textures/entrance/{model_id}/{index}.png'
        destination = OUT / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        # Width/height are written in UV units: the renderer divides V by "height".
        frames = max(1, round((height * uvw) / (width * uvh)))
        textures.append(dict(path='averonsync:' + path, width=uvw, height=uvh * frames, uvWidth=uvw,
                             uvHeight=uvh, frameTime=max(1, texture.get('frame_time', 1)),
                             frames=frames, emissive=-1))
    cubes = {}
    for cube in raw['elements']:
        if cube.get('type', 'cube') != 'cube': raise ValueError('Unsupported mesh')
        if not cube.get('export', True): continue
        faces = {}
        for direction, face in cube.get('faces', {}).items():
            texture = face.get('texture')
            if texture is None: continue
            if not isinstance(texture, int) or not 0 <= texture < len(textures): raise ValueError('Invalid face texture')
            uv = [float(v) for v in face['uv']]
            if len(uv) != 4 or not all(math.isfinite(v) for v in uv): raise ValueError('Invalid UV')
            faces[direction] = dict(texture=texture, uv=uv, rotation=face.get('rotation', 0))
        cubes[cube['uuid']] = dict(from_=vector(cube['from'], [0, 0, 0]), to=vector(cube['to'], [0, 0, 0]),
            origin=vector(cube.get('origin'), [0, 0, 0]), rotation=vector(cube.get('rotation'), [0, 0, 0]),
            inflate=float(cube.get('inflate', 0)), faces=faces)
    limbs = set()
    def node(value):
        if isinstance(value, str):
            if value not in cubes: return None
            return dict(id=value, origin=[0, 0, 0], rotation=[0, 0, 0], cubes=[cubes[value]], children=[])
        limb = next((l for prefix, l in LIMBS.items() if value['name'].startswith(prefix)), None)
        result = dict(id=value['uuid'], origin=vector(value.get('origin'), [0, 0, 0]),
                      rotation=vector(value.get('rotation'), [0, 0, 0]), cubes=[], children=[])
        if limb:
            # The grey placeholder cube gives the limb box; its texture is replaced by the skin.
            boxes = [cubes[c] for c in value.get('children', []) if isinstance(c, str) and c in cubes]
            # Limbs may repeat (Ragdoll's ghost wears a second copy of the player's head).
            if len(boxes) != 1: raise ValueError('Unexpected player limb ' + value['name'])
            limbs.add(limb)
            box = boxes[0]
            low = [min(a, b) for a, b in zip(box['from_'], box['to'])]
            high = [max(a, b) for a, b in zip(box['from_'], box['to'])]
            result['cubes'].append(dict(from_=low, to=high, origin=box['origin'], rotation=box['rotation'],
                                        inflate=0.0, faces={}, skin=limb))
            return result
        for child in value.get('children', []):
            if isinstance(child, dict) and not child.get('export', True): continue
            converted = node(child)
            if converted: result['children'].append(converted)
        return result
    nodes = [n for n in (node(n) for n in raw['outliner']) if n]
    if limbs != set(LIMBS.values()): raise ValueError('Missing player limbs')
    animations = {}
    for animation in raw.get('animations', []):
        tracks = {}
        for ident, animator in animation.get('animators', {}).items():
            if animator.get('type') != 'bone':
                if animator.get('keyframes'): raise ValueError('Unsupported effect animator')
                continue
            channels = {}
            for key in animator.get('keyframes', []):
                channel = key['channel']; interpolation = key.get('interpolation', 'linear')
                if channel not in ['position', 'rotation', 'scale'] or interpolation not in ['linear', 'step', 'catmullrom']:
                    raise ValueError(f'Unsupported animation {channel}/{interpolation}')
                if len(key['data_points']) != 1 or key.get('easing', 'linear') != 'linear':
                    raise ValueError('Unsupported animation easing')
                point = key['data_points'][0]
                frames = channels.setdefault(channel, {})
                frames[round(float(key['time']), 4)] = dict(time=round(float(key['time']), 4),
                    value=vector([point.get(k, 1 if channel == 'scale' else 0) for k in ['x', 'y', 'z']], [0, 0, 0]),
                    interpolation=interpolation)
            tracks[ident] = {k: sorted(v.values(), key=lambda f: f['time']) for k, v in channels.items()}
        animations['play'] = dict(length=float(animation['length']), tracks=tracks)
    if list(animations) != ['play'] or len(raw.get('animations', [])) != 1: raise ValueError('Expected one animation')
    return dict(id=model_id, textures=textures, nodes=nodes, animations=animations)

def run(archive):
    report = []
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        for theme in THEMES:
            for phase in ['in', 'out']:
                entry = next(n for n in names if n.endswith(f'/anim-{phase}-{theme}.bbmodel'))
                if z.getinfo(entry).file_size > 4_000_000: raise ValueError('Model too large')
                data = z.read(entry)
                model_id = f'{theme}_{phase}'
                model = convert(json.loads(data), model_id)
                destination = OUT / f'entrance/{model_id}.json'; destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(json.dumps(model, separators=(',', ':')), encoding='utf-8')
                sound = next(n for n in names if '/Oraxen/' in n and n.endswith(f'/fx_{theme}-{phase}.ogg'))
                sound_data = z.read(sound)
                if sound_data[:4] != b'OggS': raise ValueError('Invalid sound')
                destination = OUT / f'sounds/entrance/{model_id}.ogg'; destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(sound_data)
                report.append(dict(id=model_id, sourceArchive=Path(archive).name, modelSha256=hashlib.sha256(data).hexdigest(),
                                   soundSha256=hashlib.sha256(sound_data).hexdigest(), textures=len(model['textures']),
                                   length=model['animations']['play']['length']))
    (OUT / 'entrance/import-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({'importedAnimations': len(report), 'output': str(OUT)}))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('archive', type=Path)
    run(parser.parse_args().archive)
