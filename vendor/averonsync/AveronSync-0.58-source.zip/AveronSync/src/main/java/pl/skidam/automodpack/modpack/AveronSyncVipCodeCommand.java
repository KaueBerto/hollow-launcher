package pl.skidam.automodpack.modpack;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import pl.skidam.automodpack.networking.server.AveronSyncEntryQueue;
import pl.skidam.automodpack_core.queue.VipCodes;
import pl.skidam.automodpack_core.queue.VipRegistry;
import java.util.*;
import static net.minecraft.commands.Commands.*;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

/**
 * {@code /averon codigo <codigo>} turns a single-use code into VIP (30 days from now) and hands over the kit at once.
 * Admins create codes with {@code /async vip codigo gerar <nivel> [quantidade]}. Every redemption, including a renewal,
 * delivers the kit again; a kit that does not fit is kept for {@code /kitvip}.
 */
public final class AveronSyncVipCodeCommand {
    private static final int MAX_FAILURES = 5;
    private static final long LOCK_MILLIS = 10 * 60_000L;
    private record Failures(int count, long lockedUntil) {}
    private static final Map<UUID, Failures> FAILURES = new HashMap<>();

    /**
     * {@code /averon codigo}. Other mods register the same {@code /averon} root as "operator only", so this must run after
     * all of them (see {@link AveronCommandRoot}); NeoForge calls it from a lowest-priority RegisterCommandsEvent listener.
     */
    public static void registerRedeem(CommandDispatcher<CommandSourceStack> dispatcher) {
        try {
            AveronCommandRoot.addOpenSubcommand(dispatcher, literal("codigo")
                    .requires(source -> source.getServer().isDedicatedServer())
                    .then(argument("codigo", StringArgumentType.greedyString())
                            .executes(ctx -> redeem(ctx.getSource(), StringArgumentType.getString(ctx, "codigo")))));
        } catch (ReflectiveOperationException | RuntimeException e) {
            LOGGER.error("/averon codigo could not be registered for players; falling back to the plain registration", e);
            dispatcher.register(literal("averon").then(literal("codigo").then(argument("codigo", StringArgumentType.greedyString())
                    .executes(ctx -> redeem(ctx.getSource(), StringArgumentType.getString(ctx, "codigo"))))));
        }
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("async").then(literal("vip").requires(source -> source.hasPermission(3))
                .then(literal("codigo")
                        .then(literal("gerar").then(argument("nivel", IntegerArgumentType.integer(1, VipRegistry.MAX_LEVEL))
                                .executes(ctx -> generate(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "nivel"), 1))
                                .then(argument("quantidade", IntegerArgumentType.integer(1, VipCodes.MAX_BATCH))
                                        .executes(ctx -> generate(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "nivel"),
                                                IntegerArgumentType.getInteger(ctx, "quantidade"))))))
                        .then(literal("contar").executes(ctx -> count(ctx.getSource())))
                        .then(literal("revogar").then(argument("codigo", StringArgumentType.greedyString())
                                .executes(ctx -> revoke(ctx.getSource(), StringArgumentType.getString(ctx, "codigo"))))))
                .then(literal("kit").then(literal("verificar").executes(ctx -> verifyKits(ctx.getSource())))))
                .then(literal("inv").requires(source -> source.hasPermission(3))
                        .then(literal("vip").then(argument("nivel", IntegerArgumentType.integer(1, VipRegistry.MAX_LEVEL))
                                .executes(ctx -> saveInventoryAsKit(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "nivel")))))));
    }

    private static int redeem(CommandSourceStack source, String typed) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        String name = player.getGameProfile().getName();
        try {
            if (!AveronSyncVipKitCommand.authenticated(player)) return fail(source, "Entre no EasyLogin antes de resgatar um codigo.");
            var manager = AveronSyncEntryQueue.get(source.getServer());
            var vips = manager.vips(); var codes = manager.codes(); var pending = manager.pendingKits();
            if (vips == null || codes == null || pending == null) return fail(source, "Cadastro VIP indisponivel. Avise a administracao.");
            long now = System.currentTimeMillis();
            var failures = FAILURES.get(player.getUUID());
            if (failures != null && failures.lockedUntil() > now)
                return fail(source, "Muitas tentativas erradas. Tente de novo em " + ((failures.lockedUntil() - now + 59_999) / 60_000) + " min.");
            String plain;
            try { plain = VipCodes.normalize(typed); }
            catch (IllegalArgumentException e) { return wrong(source, player, now); }
            var peeked = codes.peek(plain);
            if (peeked.isEmpty()) return wrong(source, player, now);
            int level = peeked.getAsInt();
            // Check the kit before spending the code: a broken kit file must never eat a code the buyer paid for.
            var kit = AveronSyncVipKits.build(source.getServer().registryAccess(), level);
            if (codes.redeem(plain).isEmpty()) return wrong(source, player, now);
            FAILURES.remove(player.getUUID());
            int result = Math.max(level, vips.level(name, now));
            long expiry;
            try { expiry = vips.grant(name, now, result); }
            catch (java.io.IOException | RuntimeException e) {
                codes.restore(plain, level, now);
                throw e;
            }
            /*? if neoforge {*/
            AveronSyncVipTab.refresh(source.getServer(), name);
            /*?}*/
            boolean delivered;
            try { delivered = AveronSyncVipKits.give(player, kit); }
            catch (RuntimeException e) { LOGGER.error("VIP kit delivery failed for {}; kept as pending", name, e); delivered = false; }
            if (!delivered) pending.add(name, level);
            LOGGER.info("VIP code redeemed by {}: level {}, valid until {}, kit {}", name, result, java.time.Instant.ofEpochMilli(expiry),
                    delivered ? "delivered" : "pending");
            boolean now2 = delivered;
            reply(source, Component.literal("[AveronSync] VIP " + result + " ativado por 30 dias! "
                    + (kit.isEmpty() ? "" : now2 ? "Seu kit ja esta no inventario."
                    : "Seu inventario esta cheio: libere espaco e use /kitvip para receber o kit.")));
            return 1;
        } catch (Exception e) {
            LOGGER.error("VIP code redemption failed for {}", name, e);
            return fail(source, "Nao foi possivel resgatar agora. Seu codigo nao foi gasto; avise a administracao.");
        }
    }

    private static int wrong(CommandSourceStack source, ServerPlayer player, long now) {
        var previous = FAILURES.getOrDefault(player.getUUID(), new Failures(0, 0));
        int count = previous.count() + 1;
        boolean lock = count >= MAX_FAILURES;
        FAILURES.put(player.getUUID(), new Failures(lock ? 0 : count, lock ? now + LOCK_MILLIS : 0));
        LOGGER.warn("Wrong VIP code from {} ({} in a row)", player.getGameProfile().getName(), count);
        return fail(source, lock ? "Muitas tentativas erradas. Tente de novo em 10 min." : "Codigo invalido ou ja usado.");
    }

    private static int generate(CommandSourceStack source, int level, int count) {
        var codes = AveronSyncEntryQueue.get(source.getServer()).codes();
        if (codes == null) return fail(source, "Arquivo de codigos invalido ou inacessivel. Consulte o log e reinicie apos corrigir.");
        try {
            var list = codes.generate(level, count, System.currentTimeMillis());
            // Codes are only shown to the admin who asked (not to other ops, not in the log) and are stored hashed.
            // Sent as direct messages: sendSuccess would hide them when the sendCommandFeedback gamerule is false.
            reply(source, Component.literal("[AveronSync] " + list.size() + " codigo(s) VIP " + level
                    + " (guarde agora, nao aparecem de novo). Clique em um codigo para copiar:"));
            list.forEach(code -> reply(source, copyable(code)));
            LOGGER.info("{} VIP {} code(s) generated", list.size(), level);
            return list.size();
        } catch (java.io.IOException | RuntimeException e) {
            LOGGER.error("Unable to generate VIP codes", e);
            return fail(source, "Nao foi possivel gerar os codigos. Estado anterior preservado.");
        }
    }

    /** Shown to the player who ran the command even when the sendCommandFeedback gamerule is off; console gets it normally. */
    private static void reply(CommandSourceStack source, Component message) {
        if (source.getEntity() instanceof ServerPlayer player) player.sendSystemMessage(message);
        else source.sendSuccess(() -> message, false);
    }

    /** The code as green text that copies itself to the clipboard on click. */
    private static Component copyable(String code) {
        return Component.literal(code).withStyle(style -> style
                .withColor(net.minecraft.ChatFormatting.GREEN)
                /*? if >=1.21.5 {*/
                /*.withHoverEvent(new net.minecraft.network.chat.HoverEvent.ShowText(Component.translatable("chat.copy.click")))
                .withClickEvent(new net.minecraft.network.chat.ClickEvent.CopyToClipboard(code)));
                *//*?} else {*/
                .withHoverEvent(new net.minecraft.network.chat.HoverEvent(net.minecraft.network.chat.HoverEvent.Action.SHOW_TEXT, Component.translatable("chat.copy.click")))
                .withClickEvent(new net.minecraft.network.chat.ClickEvent(net.minecraft.network.chat.ClickEvent.Action.COPY_TO_CLIPBOARD, code)));
                /*?}*/
    }

    private static int count(CommandSourceStack source) {
        var codes = AveronSyncEntryQueue.get(source.getServer()).codes();
        if (codes == null) return fail(source, "Arquivo de codigos invalido ou inacessivel.");
        var counts = codes.counts();
        reply(source, Component.literal("[AveronSync] Codigos nao usados: VIP 1 = " + counts.getOrDefault(1, 0)
                + ", VIP 2 = " + counts.getOrDefault(2, 0)));
        return 1;
    }

    private static int revoke(CommandSourceStack source, String typed) {
        var codes = AveronSyncEntryQueue.get(source.getServer()).codes();
        if (codes == null) return fail(source, "Arquivo de codigos invalido ou inacessivel.");
        try {
            boolean removed = codes.revoke(VipCodes.normalize(typed));
            reply(source, Component.literal("[AveronSync] " + (removed ? "Codigo revogado." : "Codigo nao encontrado.")));
            return removed ? 1 : 0;
        } catch (IllegalArgumentException e) {
            return fail(source, e.getMessage());
        } catch (java.io.IOException e) {
            LOGGER.error("Unable to revoke VIP code", e);
            return fail(source, "Nao foi possivel salvar. Estado anterior preservado.");
        }
    }

    /**
     * {@code /async inv vip <nivel>}: the admin's 36 inventory slots (hotbar + backpack, not armor or off hand) become the
     * kit of that VIP level in config/averonsync-vip-kits.json. The previous file is kept as .bak.
     */
    private static int saveInventoryAsKit(CommandSourceStack source, int level) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        var ops = player.registryAccess().createSerializationContext(com.mojang.serialization.JsonOps.INSTANCE);
        List<com.google.gson.JsonObject> items = new ArrayList<>();
        int total = 0;
        try {
            for (int slot = 0; slot < 36; slot++) {
                var stack = player.getInventory().getItem(slot);
                if (stack.isEmpty()) continue;
                var json = net.minecraft.world.item.ItemStack.CODEC.encodeStart(ops, stack).getOrThrow(IllegalStateException::new);
                items.add(json.getAsJsonObject());
                total += stack.getCount();
            }
            if (items.isEmpty()) return fail(source, "Seu inventario esta vazio: nada foi salvo e o kit " + level + " continua como estava.");
            pl.skidam.automodpack_core.queue.VipKitConfig.save(AveronSyncVipKits.FILE, level, items);
            int stacks = items.size(), sum = total;
            reply(source, Component.literal("[AveronSync] Kit VIP " + level + " salvo com seu inventario: " + stacks + " pilha(s), " + sum
                    + " item(ns). Armadura e mao secundaria nao entram. O kit anterior ficou em averonsync-vip-kits.json.bak."));
            LOGGER.info("VIP kit {} saved from {}'s inventory ({} stacks)", level, player.getGameProfile().getName(), stacks);
            return stacks;
        } catch (java.io.IOException | RuntimeException e) {
            LOGGER.error("Unable to save VIP kit {} from inventory", level, e);
            return fail(source, "Nao foi possivel salvar o kit: " + e.getMessage());
        }
    }

    private static int verifyKits(CommandSourceStack source) {
        try {
            for (int level = 1; level <= VipRegistry.MAX_LEVEL; level++) {
                int lv = level;
                var kit = AveronSyncVipKits.build(source.getServer().registryAccess(), level);
                int total = kit.stream().mapToInt(net.minecraft.world.item.ItemStack::getCount).sum();
                reply(source, Component.literal("[AveronSync] Kit VIP " + lv + ": " + kit.size() + " pilha(s), " + total + " item(ns). OK"));
            }
            return 1;
        } catch (java.io.IOException e) {
            return fail(source, e.getMessage());
        }
    }

    private static int fail(CommandSourceStack source, String message) {
        source.sendFailure(Component.literal("[AveronSync] " + message)); return 0;
    }
    private AveronSyncVipCodeCommand() {}
}
