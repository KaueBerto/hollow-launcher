package pl.skidam.automodpack.init;

/*? if neoforge {*/
/*? if >1.20.5 {*/
import net.neoforged.fml.common.EventBusSubscriber;
/*?}*/
import pl.skidam.automodpack.client.ScreenImpl;
import pl.skidam.automodpack.client.audio.AudioManager;
import pl.skidam.automodpack.modpack.Commands;
import pl.skidam.automodpack.networking.ModPackets;
import pl.skidam.automodpack_core.loader.LoaderManagerService;
import pl.skidam.automodpack_loader_core.screen.ScreenManager;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import static pl.skidam.automodpack_core.GlobalVariables.*;

@Mod(MOD_ID + "_mod")
public class NeoForgeInit {
    public NeoForgeInit(IEventBus eventBus) {
         pl.skidam.automodpack.modpack.AveronSyncHorseContent.init(eventBus);
         pl.skidam.automodpack.modpack.AveronSyncHorseSound.init(eventBus);
         eventBus.addListener(pl.skidam.automodpack.modpack.HorseInputPayload::register);
         eventBus.addListener(pl.skidam.automodpack.modpack.MountMenuPayloads::register);
         eventBus.addListener(pl.skidam.automodpack.modpack.AveronSyncVipPets::registerPayloads);
         eventBus.addListener(pl.skidam.automodpack.modpack.AveronSyncEntrance::registerPayloads);
         eventBus.addListener(pl.skidam.automodpack.modpack.ParroInputPayload::register);
         preload = false;
         ScreenManager.INSTANCE = new ScreenImpl();

         long start = System.currentTimeMillis();
         LOGGER.info("Launching AutoModpack...");

         Common.init();

         if (LOADER_MANAGER.getEnvironmentType() == LoaderManagerService.EnvironmentType.SERVER) {
            Common.serverInit();
         } else {
             ModPackets.registerC2SPackets();
             new AudioManager(eventBus);
             pl.skidam.automodpack.client.pets.VipPetClient.init(eventBus);
             pl.skidam.automodpack.client.entrance.EntranceClient.init(eventBus);
             pl.skidam.automodpack.client.mounts.ParroRenderer.init(eventBus);
             net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(pl.skidam.automodpack.client.mounts.ParroKeys::update);
             pl.skidam.automodpack.client.mounts.QuestHorseRenderer.init(eventBus);
             pl.skidam.automodpack.client.mounts.MountMenuClient.init(eventBus);
             net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(pl.skidam.automodpack.client.mounts.HorseKeys::update);
             net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(pl.skidam.automodpack.client.mounts.HorseKeys::inventory);
         }


         LOGGER.info("AutoModpack launched! took " + (System.currentTimeMillis() - start) + "ms");
    }

/*? if >1.20.5 {*/
   @EventBusSubscriber(modid = MOD_ID + "_mod")
/*?} else {*/
   /*@Mod.EventBusSubscriber(modid = MOD_ID + "_mod")
*//*?}*/
    public static class events {
        @SubscribeEvent(priority = net.neoforged.bus.api.EventPriority.LOWEST)
        public static void onTabName(net.neoforged.neoforge.event.entity.player.PlayerEvent.TabListNameFormat event) {
            pl.skidam.automodpack.modpack.AveronSyncVipTab.format(event);
        }

        @SubscribeEvent(priority = net.neoforged.bus.api.EventPriority.LOWEST)
        public static void onPlayerLogin(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent event) {
            if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player)
                pl.skidam.automodpack.modpack.AveronSyncVipTab.refresh(player);
            if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player)
                pl.skidam.automodpack.modpack.AveronSyncVipPets.joined(player);
        }

        @SubscribeEvent
        public static void onServerTick(net.neoforged.neoforge.event.tick.ServerTickEvent.Post event) {
            pl.skidam.automodpack.modpack.AveronSyncVipTab.tick(event.getServer());
            pl.skidam.automodpack.modpack.AveronSyncVipPets.tick(event.getServer());
            pl.skidam.automodpack.modpack.AveronSyncEntrance.tick(event.getServer());
        }

        @SubscribeEvent
        public static void onPlayerLogout(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent event) {
            if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player)
                pl.skidam.automodpack.modpack.AveronSyncEntrance.loggedOut(player);
        }

        @SubscribeEvent
        public static void onServerStopped(net.neoforged.neoforge.event.server.ServerStoppedEvent event) {
            pl.skidam.automodpack.modpack.AveronSyncVipTab.shutdown(event.getServer());
            pl.skidam.automodpack.modpack.AveronSyncVipPets.shutdown(event.getServer());
            pl.skidam.automodpack.modpack.AveronSyncEntrance.shutdown(event.getServer());
        }

        @SubscribeEvent
        public static void onCommandsRegister(RegisterCommandsEvent event) {
            Commands.register(event.getDispatcher());
        }

        /** After every other mod: they share the /averon root and the first one registered sets who may see it. */
        @SubscribeEvent(priority = net.neoforged.bus.api.EventPriority.LOWEST)
        public static void onCommandsRegisterLast(RegisterCommandsEvent event) {
            pl.skidam.automodpack.modpack.AveronSyncVipCodeCommand.registerRedeem(event.getDispatcher());
        }
    }
}
/*?}*/
