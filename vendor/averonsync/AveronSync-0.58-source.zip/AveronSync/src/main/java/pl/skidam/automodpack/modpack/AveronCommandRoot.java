package pl.skidam.automodpack.modpack;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.CommandNode;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.function.Predicate;

/**
 * Several mods share the {@code /averon} command root, and the first one registered decides who may see the whole root:
 * AveronAvisos and the claim commands register it with "operator only", which also hid {@code /averon codigo} from
 * players. Run this after every other mod has registered (lowest-priority listener): it moves the root's requirement
 * down onto each existing subcommand (so those stay operator-only) and opens the root itself, then adds a subcommand
 * that has its own, open requirement.
 */
final class AveronCommandRoot {
    private static final String ROOT = "averon";

    static <S> void addOpenSubcommand(CommandDispatcher<S> dispatcher, LiteralArgumentBuilder<S> subcommand) throws ReflectiveOperationException {
        CommandNode<S> root = dispatcher.getRoot().getChild(ROOT);
        if (root == null) {
            dispatcher.register(LiteralArgumentBuilder.<S>literal(ROOT).then(subcommand));
            return;
        }
        Predicate<S> rootRequirement = root.getRequirement();
        for (CommandNode<S> child : new ArrayList<>(root.getChildren())) {
            Predicate<S> own = child.getRequirement();
            setRequirement(child, source -> rootRequirement.test(source) && own.test(source));
        }
        setRequirement(root, source -> true);
        root.addChild(subcommand.build());
    }

    private static <S> void setRequirement(CommandNode<S> node, Predicate<S> requirement) throws ReflectiveOperationException {
        Field field = CommandNode.class.getDeclaredField("requirement");
        field.setAccessible(true);
        field.set(node, requirement);
    }
    private AveronCommandRoot() {}
}
