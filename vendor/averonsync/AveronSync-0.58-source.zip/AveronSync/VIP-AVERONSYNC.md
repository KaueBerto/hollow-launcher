# Prioridade VIP na fila

Implementação para Minecraft 1.21.1 NeoForge. A versão 0.14 restringe os pets do VIP nível 1
cosméticos ao VIP existente; veja [PETS-AVERONSYNC.md](PETS-AVERONSYNC.md).

## Comandos

Console ou OP de nível 3+, no servidor dedicado:

- `/async vip add SnowA32`: concede ou renova o VIP por exatamente 30 dias a partir de agora, sem acumular o prazo restante.
- `/async vip add SnowA32 2`: concede ou renova como VIP nível 2 (aceita 1 ou 2). Sem o número, mantém o nível já salvo (novos VIPs entram no nível 1).
- `/async vip remove SnowA32`: remove o cadastro VIP.
- `/async vip info SnowA32`: consulta validade e estado.
- `/async vip list`: lista os VIPs ativos e seus vencimentos em UTC.

Não exige que o jogador esteja online ou já tenha entrado no servidor.
Nicks são tratados sem diferença entre maiúsculas e minúsculas. A validade
é fixa em 30 dias de 24 horas e continua passando com o servidor desligado.
O comando não aceita outra duração. Renovar define um novo vencimento de
30 dias a partir da renovação; não soma os dias que restavam.

## Fila

VIPs aguardando passam antes dos demais; dentro de cada grupo, vale a ordem
de chegada. Cadastro, renovação, remoção e expiração afetam a posição sem
reconectar. Admissões já liberadas não são interrompidas. O intervalo entre
entradas, timeout, capacidade da fila e limite de jogadores continuam valendo.
VIP não entra em servidor cheio e não ignora `/async limite 0` (somente OPs).
OPs mantêm o bypass existente, sem depender de VIP.

## Códigos VIP e kit (0.51)

O VIP é vendido como **código de uso único**. O jogador digita `/averon codigo <codigo>`
(logado no EasyLogin). Na hora: o VIP do nível do código é ativado por 30 dias a partir
de agora e o **kit cai no inventário**. Quem renova com outro código ganha o kit de novo
(a renovação reinicia os 30 dias, não soma). Se já é VIP 2 e usa um código de VIP 1,
continua VIP 2. O kit entregue é o do nível do código.

`/averon codigo` funciona para qualquer jogador, sem ser OP. Vários mods usam a raiz `/averon`
e o primeiro a registrar decide quem a enxerga (AveronAvisos e os comandos de claim a deixam só
para OP). Por isso o mod registra o subcomando por último e abre apenas o `codigo`; os demais
subcomandos mantêm a exigência original. Se isso falhar, o erro aparece no log.

Admin (permissão 3):

| Comando | O que faz |
| --- | --- |
| `/async vip codigo gerar <nivel> [quantidade]` | cria 1 a 20 códigos (aparecem só para quem pediu, uma vez) |
| `/async vip codigo contar` | quantos códigos sem uso existem por nível |
| `/async vip codigo revogar <codigo>` | invalida um código |
| `/async vip kit verificar` | confere o arquivo de kits e mostra o resumo de cada nível |
| `/async inv vip <nivel>` | salva o **seu inventário** (36 slots: barra e mochila) como o kit desse nível; armadura e mão secundária não entram. O arquivo anterior fica em `averonsync-vip-kits.json.bak` |

Códigos têm o formato `AVRN-XXXX-XXXX-XXXX` (sem letras parecidas). Ficam em
`automodpack/averonsync-vip-codes.json` **só como hash**: o arquivo não revela códigos
válidos. 5 erros seguidos bloqueiam o jogador por 10 minutos. O código só é gasto se o
kit estiver válido e o VIP for salvo; se algo falhar, ele é devolvido.

### Kits (`config/averonsync-vip-kits.json`)

Criado com um exemplo na primeira vez. Cada nível é uma lista de itens com os campos de
um item do jogo: `id`, `count` (acima do tamanho da pilha vira várias pilhas) e
`components` opcional (nome, encantamentos...). O arquivo é lido a cada resgate, então
editar não exige reiniciar. O kit do VIP 2 vem sozinho: repita os itens do VIP 1 se
quiser que ele receba os dois. Use `/async vip kit verificar` depois de editar.

```json
{ "version": 1, "kits": { "1": [ { "id": "minecraft:diamond", "count": 8 } ], "2": [] } }
```

Sem espaço no inventário, o kit inteiro fica guardado em
`automodpack/averonsync-vip-pending-kits.json` e o jogador recebe com `/kitvip` depois de
liberar espaço. O kit nunca substitui itens, armadura ou mão secundária. O Starter Kit
não é mais necessário. `/async vip add` continua dando VIP sem kit.

## TAB: tag, cor e ordem (0.53)

VIP ativo aparece no TAB com **[VIP]** antes do nome (igual para VIP 1 e VIP 2). A tag e o
nome ganham a cor do nível: **VIP 1 azul claro** (`#55FFFF`), **VIP 2 laranja** (`#FF8C00`).
O cadastro continua vinculado ao nick da conta, sem alterar nome de personagem, chat, nome
sobre a cabeça ou equipes do scoreboard. O servidor decora o nome em `TabListNameFormat` com
prioridade `LOWEST`; preserva prefixos, sufixos, negrito, hover e clique, e só troca a cor do
trecho do nome. Com AveronOrigins, usa o nome do perfil completo; perfis incompletos ficam sem
decoração.

**Ordem:** VIP 2, depois VIP 1, depois os demais, cada grupo em ordem alfabética pelo nome
mostrado (sem contar a tag, sem diferenciar maiúsculas). Espectadores continuam por último.
Quem ordena é o cliente (`VipTabOrderMixin`), lendo a tag e a cor do próprio nome, sem pacote
extra. Se nenhum VIP estiver online, a ordem do jogo não muda. Se o mixin não puder ser
aplicado, só a ordem volta ao normal; cor e tag continuam. A lista só é reordenada para quem
roda o cliente com este mod (0.53 ou mais novo).

## Armazenamento

Arquivo servidor `automodpack/averonsync-vips.json`, separado do manifesto e
da configuração do modpack. Só é criado no primeiro cadastro. Escritas usam
substituição atômica quando disponível e só atualizam o estado em memória
depois de salvar. Arquivo inválido desativa a prioridade VIP sem apagá-lo;
o log informa o erro. Após corrigir o arquivo, reinicie o servidor para carregá-lo.
Edição manual com o servidor aberto não é recarregada; use os comandos.

## Identidade

A fila usa o nick anunciado na conexão, antes da entrada no mundo. Em
`online-mode=false`, essa fase ainda não confirma a senha do EasyLogin:
alguém que use o mesmo nick pode receber sua prioridade na fila, mas ainda
precisa passar pela autenticação normal para jogar. O kit, ao contrário da fila,
consulta o EasyLogin antes de entregar itens. Não concede OP ou pets nem altera
o funcionamento do login.

## Validação

Testes cobrem prioridade e posições, FIFO em cada grupo, concessão/revogação
durante a espera, vencimento, persistência, falha de gravação e arquivos inválidos,
além de capacidade, timeout e intervalo de admissão.

## Nível 2 (0.49)

O cadastro guarda um nível por nick: 1 (padrão) ou 2. O nível fica no objeto
`levels` de `automodpack/averonsync-vips.json`, ainda na versão 1 do arquivo.
Versões anteriores do AveronSync continuam lendo os vencimentos, ignoram o nível
e, se gravarem o arquivo, o descartam (todos voltam ao nível 1). `/async vip info`
e `/async vip list` mostram o nível. Remover o VIP apaga também o nível.

VIP 2 tem todos os benefícios do nível 1 (fila, kit, TAB e os mesmos pets).
A diferença é a animação de entrada e saída, que é exclusiva do VIP 2 (o VIP 1 não tem).
Sem escolha própria, usa **Possessão do Boneco** (`ragdollpossession`). O jogador ainda pode escolher outra
com `/animacao usar <tema>` e voltar ao padrão do nível com `/animacao usar padrao`.
Veja [ANIMACOES-AVERONSYNC.md](ANIMACOES-AVERONSYNC.md).
