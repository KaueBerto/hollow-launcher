package pl.skidam.automodpack_core.queue;

import com.google.gson.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * The VIP kits, edited by the server owner in {@code config/averonsync-vip-kits.json}. Each entry uses the same fields
 * as a vanilla item stack ({@code id}, {@code count}, optional {@code components} for names, enchantments and so on),
 * which the mod side decodes. Here only the structure is checked, so a typo is reported before any code is spent.
 */
public final class VipKitConfig {
    public static final int MAX_ENTRIES = 36, MAX_COUNT = 2304;

    /** Valid example written when the file does not exist yet. */
    public static String template() {
        return """
                {
                  "version": 1,
                  "_ajuda": "Cada nivel e uma lista de itens. id = item do jogo, count = quantidade (acima do tamanho da pilha vira varias pilhas). 'components' e opcional (nome, encantamentos...). O kit do VIP 2 vem sozinho: repita os itens do VIP 1 se quiser que ele receba os dois.",
                  "kits": {
                    "1": [
                      { "id": "minecraft:golden_apple", "count": 8 },
                      { "id": "minecraft:diamond", "count": 8 }
                    ],
                    "2": [
                      { "id": "minecraft:golden_apple", "count": 16 },
                      { "id": "minecraft:diamond", "count": 16 }
                    ]
                  }
                }
                """;
    }

    /** Reads the file, creating the template first when it is missing. Throws {@link IOException} with a readable reason. */
    public static Map<Integer, List<JsonObject>> load(Path file) throws IOException {
        if (!Files.exists(file)) {
            Files.createDirectories(file.toAbsolutePath().getParent());
            Files.writeString(file, template());
        }
        if (Files.size(file) > 1_048_576) throw new IOException("Arquivo de kits grande demais");
        try {
            return parse(Files.readString(file));
        } catch (RuntimeException e) {
            throw new IOException("Arquivo de kits invalido (" + file.getFileName() + "): " + e.getMessage(), e);
        }
    }

    /**
     * Replaces the kit of one level and keeps everything else in the file (other level, help text). The previous file is
     * copied to {@code <name>.bak} first. Throws {@link IllegalArgumentException} when the items are not a valid kit.
     */
    public static void save(Path file, int level, List<JsonObject> items) throws IOException {
        JsonObject root;
        if (Files.exists(file)) {
            try { root = JsonParser.parseString(Files.readString(file)).getAsJsonObject(); }
            catch (RuntimeException e) { throw new IOException("Arquivo de kits invalido; corrija ou apague antes de salvar: " + e.getMessage(), e); }
        } else root = JsonParser.parseString(template()).getAsJsonObject();
        if (!root.has("kits") || !root.get("kits").isJsonObject()) root.add("kits", new JsonObject());
        JsonArray array = new JsonArray();
        items.forEach(array::add);
        root.getAsJsonObject("kits").add(Integer.toString(level), array);
        parse(root.toString()); // refuses an invalid result before anything is written
        if (Files.exists(file)) Files.copy(file, file.resolveSibling(file.getFileName() + ".bak"), StandardCopyOption.REPLACE_EXISTING);
        AtomicJson.write(file, root);
    }

    public static Map<Integer, List<JsonObject>> parse(String source) {
        JsonObject root = JsonParser.parseString(source).getAsJsonObject();
        if (!root.has("version") || root.get("version").getAsInt() != 1) throw new IllegalArgumentException("version deve ser 1");
        if (!root.has("kits") || !root.get("kits").isJsonObject()) throw new IllegalArgumentException("falta o objeto \"kits\"");
        Map<Integer, List<JsonObject>> result = new TreeMap<>();
        for (var kit : root.getAsJsonObject("kits").entrySet()) {
            int level;
            try { level = Integer.parseInt(kit.getKey()); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("nivel \"" + kit.getKey() + "\" invalido"); }
            if (level < 1 || level > VipRegistry.MAX_LEVEL) throw new IllegalArgumentException("nivel " + level + " fora de 1 a " + VipRegistry.MAX_LEVEL);
            if (!kit.getValue().isJsonArray()) throw new IllegalArgumentException("o kit " + level + " deve ser uma lista");
            var array = kit.getValue().getAsJsonArray();
            if (array.size() > MAX_ENTRIES) throw new IllegalArgumentException("o kit " + level + " passa de " + MAX_ENTRIES + " itens");
            List<JsonObject> items = new ArrayList<>();
            for (var element : array) {
                if (!element.isJsonObject()) throw new IllegalArgumentException("item invalido no kit " + level);
                JsonObject item = element.getAsJsonObject();
                if (!item.has("id") || !item.get("id").isJsonPrimitive()) throw new IllegalArgumentException("item sem id no kit " + level);
                int count = item.has("count") ? item.get("count").getAsInt() : 1;
                if (count < 1 || count > MAX_COUNT) throw new IllegalArgumentException("quantidade de " + item.get("id").getAsString() + " deve ficar entre 1 e " + MAX_COUNT);
                items.add(item);
            }
            result.put(level, List.copyOf(items));
        }
        return result;
    }
    private VipKitConfig() {}
}
