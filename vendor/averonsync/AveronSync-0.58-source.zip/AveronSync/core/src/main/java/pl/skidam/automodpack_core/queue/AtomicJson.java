package pl.skidam.automodpack_core.queue;

import com.google.gson.*;
import java.io.IOException;
import java.nio.file.*;

/** Crash-safe JSON writes for the small VIP data files: write a temp file, then move it over the target. */
final class AtomicJson {
    static void write(Path file, JsonObject root) throws IOException {
        Files.createDirectories(file.getParent());
        Path temp = Files.createTempFile(file.getParent(), "averonsync-", ".tmp");
        try {
            Files.writeString(temp, new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create().toJson(root));
            if (Files.exists(file) && Files.getFileAttributeView(file, java.nio.file.attribute.PosixFileAttributeView.class) != null)
                Files.setPosixFilePermissions(temp, Files.getPosixFilePermissions(file));
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
    }
    private AtomicJson() {}
}
