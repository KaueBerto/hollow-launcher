package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class VipCodesTest {
    @TempDir Path temp;

    @Test void generatedCodesAreUniqueFormattedAndRedeemOnlyOnce() throws Exception {
        var codes = new VipCodes(temp.resolve("codes.json"));
        var batch = codes.generate(2, 20, 1000);
        assertEquals(20, new HashSet<>(batch).size());
        for (String code : batch) assertTrue(code.matches("AVRN-[A-HJKMNP-Z2-9]{4}-[A-HJKMNP-Z2-9]{4}-[A-HJKMNP-Z2-9]{4}"), code);
        String code = batch.get(0);
        assertEquals(2, codes.redeem(VipCodes.normalize(code)).getAsInt());
        assertTrue(codes.redeem(VipCodes.normalize(code)).isEmpty(), "a code works once");
        assertEquals(19, codes.counts().get(2));
    }
    @Test void fileKeepsOnlyHashesAndSurvivesRestart() throws Exception {
        Path file = temp.resolve("codes.json");
        var codes = new VipCodes(file);
        String code = codes.generate(1, 1, 5).get(0);
        String stored = Files.readString(file);
        assertFalse(stored.contains(VipCodes.normalize(code)), "the plain code is never written");
        var reopened = new VipCodes(file);
        assertEquals(1, reopened.peek(VipCodes.normalize(code)).getAsInt());
        reopened.redeem(VipCodes.normalize(code));
        assertTrue(new VipCodes(file).peek(VipCodes.normalize(code)).isEmpty(), "redeeming is saved before it returns");
    }
    @Test void typedCodesAreForgivingButStrict() {
        String plain = VipCodes.normalize("AVRN-ABCD-EFGH-JKMN");
        assertEquals("ABCDEFGHJKMN", plain);
        assertEquals(plain, VipCodes.normalize("  avrn abcd efgh jkmn "));
        assertEquals(plain, VipCodes.normalize("abcdefghjkmn"));
        assertThrows(IllegalArgumentException.class, () -> VipCodes.normalize("ABCD"));
        assertThrows(IllegalArgumentException.class, () -> VipCodes.normalize("ABCDEFGHJKM0"), "0 is not in the alphabet");
        assertThrows(IllegalArgumentException.class, () -> VipCodes.normalize(null));
    }
    @Test void restoreBringsBackACodeWhenTheVipCouldNotBeGranted() throws Exception {
        var codes = new VipCodes(temp.resolve("codes.json"));
        String plain = VipCodes.normalize(codes.generate(1, 1, 1).get(0));
        assertEquals(1, codes.redeem(plain).getAsInt());
        codes.restore(plain, 1, 2);
        assertEquals(1, codes.peek(plain).getAsInt());
    }
    @Test void revokeAndInvalidArguments() throws Exception {
        var codes = new VipCodes(temp.resolve("codes.json"));
        String plain = VipCodes.normalize(codes.generate(1, 1, 1).get(0));
        assertTrue(codes.revoke(plain)); assertFalse(codes.revoke(plain));
        assertThrows(IllegalArgumentException.class, () -> codes.generate(3, 1, 1));
        assertThrows(IllegalArgumentException.class, () -> codes.generate(1, 0, 1));
        assertThrows(IllegalArgumentException.class, () -> codes.generate(1, 21, 1));
    }
    @Test void corruptFileIsPreserved() throws Exception {
        Path file = temp.resolve("codes.json");
        Files.writeString(file, "{\"version\":1,\"codes\":{\"zz\":{\"level\":1}}}");
        assertThrows(IOException.class, () -> new VipCodes(file));
        assertEquals("{\"version\":1,\"codes\":{\"zz\":{\"level\":1}}}", Files.readString(file));
    }
    @Test void pendingKitsPersistPerNickname() throws Exception {
        Path file = temp.resolve("pending.json");
        var pending = new VipPendingKits(file);
        pending.add("Alice", 2); pending.add("ALICE", 1); pending.add("Alice", 2);
        assertEquals(List.of(2, 1, 2), new VipPendingKits(file).levels("alice"));
        pending.remove("Alice", 2);
        assertEquals(List.of(1, 2), new VipPendingKits(file).levels("Alice"));
        pending.remove("Alice", 1); pending.remove("Alice", 2);
        assertTrue(new VipPendingKits(file).levels("Alice").isEmpty());
    }
    @Test void savingAKitKeepsTheOtherLevelBacksUpAndRefusesInvalidKits() throws Exception {
        Path file = temp.resolve("kits.json");
        var item = com.google.gson.JsonParser.parseString("{\"id\":\"minecraft:apple\",\"count\":3,\"components\":{\"minecraft:custom_name\":\"\\\"A=B <x>\\\"\"}}").getAsJsonObject();
        VipKitConfig.save(file, 2, List.of(item));
        var kits = VipKitConfig.load(file);
        assertEquals(1, kits.get(2).size()); assertEquals(2, kits.get(1).size(), "level 1 from the template stays");
        assertEquals("minecraft:apple", kits.get(2).get(0).get("id").getAsString());
        assertTrue(Files.readString(file).contains("A=B <x>"), "no HTML escaping in item names");
        assertFalse(Files.exists(temp.resolve("kits.json.bak")), "nothing to back up on the first write");
        String before = Files.readString(file);
        VipKitConfig.save(file, 1, List.of(item, item));
        assertEquals(before, Files.readString(temp.resolve("kits.json.bak")));
        assertEquals(2, VipKitConfig.load(file).get(1).size()); assertEquals(1, VipKitConfig.load(file).get(2).size());
        var tooMany = new java.util.ArrayList<com.google.gson.JsonObject>(); for (int i = 0; i < 37; i++) tooMany.add(item);
        assertThrows(IllegalArgumentException.class, () -> VipKitConfig.save(file, 1, tooMany));
        assertEquals(2, VipKitConfig.load(file).get(1).size(), "a refused kit leaves the file as it was");
        assertThrows(IllegalArgumentException.class, () -> VipKitConfig.save(file, 3, List.of(item)));
    }
    @Test void kitConfigTemplateIsValidAndMistakesAreExplained() throws Exception {
        var kits = VipKitConfig.parse(VipKitConfig.template());
        assertEquals(2, kits.get(1).size()); assertEquals(2, kits.get(2).size());
        Path file = temp.resolve("sub").resolve("kits.json");
        assertEquals(kits.keySet(), VipKitConfig.load(file).keySet());
        assertTrue(Files.exists(file), "a template is written when the file is missing");
        assertThrows(IllegalArgumentException.class, () -> VipKitConfig.parse("{\"version\":1,\"kits\":{\"3\":[]}}"));
        assertThrows(IllegalArgumentException.class, () -> VipKitConfig.parse("{\"version\":1,\"kits\":{\"1\":[{\"count\":2}]}}"));
        assertThrows(IllegalArgumentException.class, () -> VipKitConfig.parse("{\"version\":1,\"kits\":{\"1\":[{\"id\":\"minecraft:dirt\",\"count\":0}]}}"));
        Files.writeString(file, "{ not json");
        var error = assertThrows(IOException.class, () -> VipKitConfig.load(file));
        assertTrue(error.getMessage().contains("kits.json"));
    }
}
