package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import java.util.UUID;
import java.util.Optional;
import net.minecraft.network.syncher.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.core.particles.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import pl.skidam.automodpack_core.mounts.HorseControls;
import pl.skidam.automodpack_core.mounts.HorseSeatPose;
import pl.skidam.automodpack_core.mounts.HorseMotion;
import pl.skidam.automodpack_core.mounts.HorsePoseBlend;
import pl.skidam.automodpack_core.mounts.HorseLeanBlend;
import pl.skidam.automodpack_core.mounts.HorseBond;
import pl.skidam.automodpack_core.mounts.HorseCoat;

/** Temporary quest mount with an owner driver and room for one passenger. */
public final class QuestHorseEntity extends Horse {
    // LittleRoom's seven rainbow locators are spaced by three model pixels, red at the top.
    private static final DustParticleOptions[] RAINBOW = java.util.Arrays.stream(
            new int[]{0xff1100,0xffaa00,0xfff900,0xb1ff00,0x00e7ff,0x004aff,0x8c00ff})
            .mapToObj(rgb -> new DustParticleOptions(new org.joml.Vector3f(
                    (rgb>>>16)/255F,((rgb>>>8)&255)/255F,(rgb&255)/255F),.75F))
            .toArray(DustParticleOptions[]::new);
    private static final int PASSENGER_SEAT_OFFSET = 14;
    private static final float MIN_DAMAGING_FALL = 6F;
    private static final float SAFE_FALL_DISTANCE = 5F;
    private static final TagKey<net.minecraft.world.level.block.Block> ROADS =
            TagKey.create(Registries.BLOCK,ResourceLocation.parse("averonsync:horse_roads"));
    private static final EntityDataAccessor<Integer> BASE=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> BASE_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> ACTION=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> ACTION_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> LEAN=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> LEAN_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> TWITCH=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> TWITCH_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Boolean> DIRTY=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<String> COAT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Optional<UUID>> OWNER=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Long> GROOM_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private UUID session;
    private static final java.util.Map<String,Optional<HorseSeatPose>> SEAT_MODELS=new java.util.HashMap<>();
    private ItemStack whistle=ItemStack.EMPTY;
    private final HorseControls controls=new HorseControls();
    private HorseControls.Input keys=HorseControls.Input.NONE;
    private HorseControls.Output output;
    private long inputAt=Long.MIN_VALUE;
    private double lastStepAge;
    private int approachTicks;
    private boolean playerNearby;
    private long greetingAt=-40;
    private final HorsePoseBlend seatBlend=new HorsePoseBlend();
    private final HorseLeanBlend seatLean=new HorseLeanBlend();
    private long tailAt=-40, headAt=-40, snortAt=-200;
    public void storeWhistle(ItemStack stack) { whistle=stack; }
    public ItemStack takeWhistle() { ItemStack result=whistle;whistle=ItemStack.EMPTY;return result; }
    @Override protected void registerGoals() { /* Only the whistle may start autonomous movement. */ }
    void beginApproach() { approachTicks=180; }
    boolean isApproaching() { return approachTicks>0; }

    private void endApproach() {
        approachTicks=0;
        getNavigation().stop();
        setSpeed(0);
    }

    private void tickApproach() {
        if (!isApproaching()) return;
        var owner=((ServerLevel)level()).getServer().getPlayerList().getPlayer(getOwnerUUID());
        if (owner==null || owner.level()!=level() || !owner.isAlive() || owner.isSpectator()) {
            endApproach();
            return;
        }
        double distance=distanceTo(owner);
        if (distance<=2.4 || distance>20 || --approachTicks==0) {
            endApproach();
            return;
        }
        double pace=.35+.7*Math.clamp((distance-2.4)/2.6,0,1);
        if (approachTicks%10==9) getNavigation().moveTo(owner,pace);
        getNavigation().setSpeedModifier(pace);
    }
    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(BASE,0);builder.define(BASE_AT,0L);builder.define(ACTION,0);builder.define(ACTION_AT,0L);
        builder.define(LEAN,0);builder.define(LEAN_AT,0L);builder.define(TWITCH,0);builder.define(TWITCH_AT,0L);
        builder.define(DIRTY,false);builder.define(COAT,HorseCoat.BAY.id());builder.define(GROOM_AT,-100L);builder.define(OWNER,Optional.empty());
    }
    public String baseClip() { return new String[]{"idle","walk","gallop","backpedal","swim"}[entityData.get(BASE)]; }
    public long baseAt() { return entityData.get(BASE_AT); }
    public HorseControls.Action action() { return HorseControls.Action.values()[entityData.get(ACTION)]; }
    public long actionAt() { return entityData.get(ACTION_AT); }
    public int lean() { return entityData.get(LEAN); }
    public long leanAt() { return entityData.get(LEAN_AT); }
    public int twitches() { return entityData.get(TWITCH); }
    public long twitchAt() { return entityData.get(TWITCH_AT); }
    void setDirty(boolean dirty) { entityData.set(DIRTY,dirty); }
    public boolean isDirty() { return entityData.get(DIRTY); }
    public HorseCoat coat() { return HorseCoat.fromId(entityData.get(COAT)); }
    public void setCoat(HorseCoat coat) { entityData.set(COAT,coat.id()); }
    public long groomAt() { return entityData.get(GROOM_AT); }
    public boolean acceptInput(ServerPlayer player,HorseControls.Input input) {
        if (level().isClientSide || getFirstPassenger()!=player || !player.getUUID().equals(getOwnerUUID())
                || !AveronSyncQuestHorses.authenticated(player)) return false;
        long now=level().getGameTime();
        if (inputAt==now && keys.equals(input)) return false;
        // Coalesce arriving keys: the latest valid input wins; physics runs once per tick.
        keys=input;inputAt=now;return true;
    }
    @Override public boolean isControlledByLocalInstance() { return !level().isClientSide; }
    @Override protected Vec3 getRiddenInput(Player player,Vec3 vanilla) { return new Vec3(0,0,output==null?0:output.front()); }
    @Override protected float getRiddenSpeed(Player player) {
        BlockPos ground=getBlockPosBelowThatAffectsMyMovement();
        var surface=level().getBlockState(ground);
        double friction=Math.clamp(surface.getFriction(level(),ground,this),.05,1);
        double speed=output==null?.1:output.speed();
        if (output!=null && output.front()>0 && onGround() && !isInWater() && surface.is(ROADS))
            speed*=HorseBond.roadMultiplier(AveronSyncQuestHorses.bondTicks(player));
        if (isDirty()) speed*=.85;
        return (float)HorseMotion.riddenSpeed(speed,friction);
    }
    @Override public boolean isInvulnerableTo(DamageSource source) {
        return !source.is(DamageTypeTags.IS_FALL) && super.isInvulnerableTo(source);
    }
    @Override protected void checkFallDamage(double verticalTravel, boolean grounded,
            net.minecraft.world.level.block.state.BlockState state, BlockPos pos) {
        // Vanilla does not count the last, collision-clipped step when it lands.
        if (grounded && fallDistance>0 && verticalTravel<0) fallDistance-=(float)verticalTravel;
        super.checkFallDamage(verticalTravel,grounded,state,pos);
    }
    @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource source) {
        if (level().isClientSide) return false;
        if (distance>1) playSound(SoundEvents.HORSE_LAND,.4F,1F);
        if (distance+1e-5F<MIN_DAMAGING_FALL) return false;
        distance=Math.max(distance,MIN_DAMAGING_FALL);
        // Snapshot both riders before a fatal hit can unseat them.
        var riders=getPassengers();
        float[] impact=net.neoforged.neoforge.common.CommonHooks.onLivingFall(this,distance,multiplier);
        int damage=impact==null?0:calculateFallDamage(impact[0],impact[1]);
        boolean horseHit=damage>0 && hurt(source,damage);
        if (horseHit) playBlockFallSound();
        // Players normally have three safe blocks. Shift their curve by two,
        // preserving player-specific fall protection and the landing surface.
        boolean hit=horseHit;
        for (Entity rider:riders) {
            hit|=rider.causeFallDamage(distance-(SAFE_FALL_DISTANCE-3F),multiplier,source);
        }
        return hit;
    }
    @Override public void die(DamageSource source) {
        if (!level().isClientSide && isDeadOrDying()) AveronSyncQuestHorses.horseDied(this);
        super.die(source);
    }
    @Override protected void dropEquipment() { /* The summoned saddle is not a collectible item. */ }
    @Override protected void tickRidden(Player player,Vec3 input) { setXRot(0);yHeadRot=getYRot();yBodyRot=getYRot(); }
    @Override public void onPlayerJump(int strength) { /* Space is handled by the meta-controller, not charged horse jumps. */ }
    @Override public boolean canJump() { return false; }
    @Override public boolean canBeRiddenUnderFluidType(net.neoforged.neoforge.fluids.FluidType type,Entity rider) {
        return type==net.neoforged.neoforge.common.NeoForgeMod.WATER_TYPE.value();
    }
    @Override protected void playStepSound(BlockPos pos,net.minecraft.world.level.block.state.BlockState state) { /* Timeline-synchronized below. */ }
    @Override protected net.minecraft.sounds.SoundEvent getAmbientSound() { return null; }
    @Override public void tick() {
        if (isDeadOrDying()) { super.tick();return; }
        Vec3 start=position();
        if (!level().isClientSide) {
            long now=level().getGameTime();
            if (getControllingPassenger() instanceof ServerPlayer player) {
                HorseControls.Input input=inputAt==Long.MIN_VALUE || now-inputAt>10?HorseControls.Input.NONE:keys;
                var floor=level().clip(new ClipContext(position(),position().add(0,-4,0),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,this));
                boolean high=!onGround() && getDeltaMovement().y<.2 && (floor.getType()==HitResult.Type.MISS || floor.getLocation().distanceTo(position())>3);
                Vec3 ahead=Vec3.directionFromRotation(0,getYRot());
                Vec3 from=position().add(0,.75,0);
                var hit=level().clip(new ClipContext(from,from.add(ahead.scale(4)),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,this));
                boolean fence=hit.getType()==HitResult.Type.BLOCK && level().getBlockState(hit.getBlockPos()).is(Blocks.OAK_FENCE);
                output=controls.tick(input,new HorseControls.Environment(onGround(),isInWater(),high,fence));
                if (output.dismiss() && onGround()) { AveronSyncQuestHorses.dismissOwned(player,this);return; }
                // Vanilla retains horizontal momentum from the previous tick. Turn that
                // momentum with the mount so ordinary steering does not slide sideways.
                // The explicit jump+turn drift keeps its original inertia.
                if (output.yawDelta()!=0 && !output.drift())
                    setDeltaMovement(getDeltaMovement().yRot((float)-Math.toRadians(output.yawDelta())));
                setYRot(getYRot()+output.yawDelta());yBodyRot=getYRot();yHeadRot=getYRot();
                if (output.vertical()>0) {
                    Vec3 direction=Vec3.directionFromRotation(0,getYRot()).scale(output.lunge());
                    setDeltaMovement(direction.x,output.vertical(),direction.z);hasImpulse=true;
                } else if (output.braking()>0) setDeltaMovement(getDeltaMovement().add(Vec3.directionFromRotation(0,getYRot()).scale(output.braking())));
                if (isInWater()) setDeltaMovement(getDeltaMovement().x,Math.max(getDeltaMovement().y,.025),getDeltaMovement().z);
                int lean=output.lean()*(output.gait()==HorseControls.Gait.GALLOP?2:1);
                if (lean!=entityData.get(LEAN)) {entityData.set(LEAN,lean);entityData.set(LEAN_AT,now);}
                if (output.action()!=HorseControls.Action.NONE) {
                    entityData.set(ACTION,output.action().ordinal());entityData.set(ACTION_AT,now);
                    if (output.action()==HorseControls.Action.REAR) playSound(AveronSyncHorseSound.NEIGH.get(),1,.9F+random.nextFloat()*.3F);
                }
                if(isInWater() && (action()==HorseControls.Action.JUMP || action()==HorseControls.Action.FALLING)) entityData.set(ACTION,0);
                if(action()==HorseControls.Action.OUT_WATER) {
                    long elapsed=now-actionAt();
                    if(elapsed==10 || elapsed==15 || elapsed==20) ((ServerLevel)level()).sendParticles(ParticleTypes.FALLING_WATER,getX(),getY()+1.5,getZ(),3,.3,.5,.4,.01);
                }
                if (output.drift()) ((ServerLevel)level()).sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,getX(),getY(),getZ(),1,.15,.15,.15,.01);
            } else tickApproach();
        }
        super.tick();
        if (level().isClientSide) {
            if (hasRainbowTrail() && !isInvisible()) emitRainbow();
        } else if (isAlive()) {
            Vec3 displacement=position().subtract(start);
            Vec3 forward=Vec3.directionFromRotation(0,getYRot());
            boolean ridden=output!=null && getControllingPassenger() instanceof ServerPlayer;
            // Both navigation and riding publish the gait after collision and inertia.
            String clip=ridden
                    ? HorseMotion.travelClip(output.animation(),onGround(),displacement.horizontalDistance(),displacement.dot(forward))
                    : displacement.horizontalDistance()>=.003 ? "walk" : "idle";
            long now=level().getGameTime();
            updateBase(clip,now);
            timelineSteps(now);
            if (getControllingPassenger() instanceof ServerPlayer rider && onGround()
                    && !isInWater() && displacement.horizontalDistance()>.015) {
                AveronSyncQuestHorses.recordBondTravel(rider);
                setDirty(AveronSyncQuestHorses.dirtTicks(rider)>=AveronSyncQuestHorses.DIRTY_AT);
            }
            if (isDirty() && tickCount%15==0) ((ServerLevel)level()).sendParticles(
                    new BlockParticleOption(ParticleTypes.FALLING_DUST,Blocks.DIRT.defaultBlockState()),
                    getX(),getY()+1.3,getZ(),3,.4,.35,.45,0);
            if (clip.equals("idle") && !isApproaching()) tickIdle(now);
        }
    }
    public boolean hasRainbowTrail() {
        return isAlive() && coat()==HorseCoat.UNICORN && entityData.get(BASE)==2;
    }
    private void emitRainbow() {
        // Each tracking client draws its own trail from the synchronized gait.
        Vec3 tail=Vec3.directionFromRotation(0,getYRot()).scale(-13.0/16);
        for (int i=0;i<RAINBOW.length;i++) {
            level().addParticle(RAINBOW[i],
                    getX()+tail.x+(random.nextDouble()-.5)*.12,
                    getY()+(29-3*i)/16.0+(random.nextDouble()-.5)*.08,
                    getZ()+tail.z+(random.nextDouble()-.5)*.12,0,0,0);
        }
    }
    private void updateBase(String clip,long now) {
        int base=switch(clip) {case "walk"->1;case "gallop"->2;case "backpedal"->3;case "swim"->4;default->0;};
        if (base==entityData.get(BASE)) return;
        long at=HorsePoseBlend.phaseStart(baseClip(),baseAt(),clip,now);
        entityData.set(BASE,base);entityData.set(BASE_AT,at);lastStepAge=now-at;
    }

    private void tickIdle(long now) {
        if (now-groomAt()<25) return;
        if (tickCount%5==0) {
            boolean nearby=level().getNearestPlayer(this,playerNearby?5:4)!=null;
            if (nearby && !playerNearby && now-greetingAt>=40) {
                greetingAt=now;
                headAt=now;
                entityData.set(TWITCH,2|4|8);entityData.set(TWITCH_AT,now);
                playSound(AveronSyncHorseSound.SNORT.get(),.45F,1F);
                snortAt=now;
            }
            playerNearby=nearby;
        }
        if (tickCount%20!=0 || now-greetingAt<20) return;
        int twitch=random.nextBoolean()?2:4;
        if (now-tailAt>=40 && random.nextFloat()<.25) {twitch|=1;tailAt=now;}
        if (now-headAt>=40 && random.nextFloat()<.25) {twitch|=8;headAt=now;}
        entityData.set(TWITCH,twitch);entityData.set(TWITCH_AT,now);
        if (now-snortAt>=200 && random.nextFloat()<.1) {
            playSound(AveronSyncHorseSound.SNORT.get(),.5F,.9F+random.nextFloat()*.3F);
            snortAt=now;
        }
    }
    private void timelineSteps(long now) {
        int base=entityData.get(BASE);if (base!=1 && base!=2) return;
        double rate=HorsePoseBlend.rate(base==2?"gallop":"walk");
        double length=(base==2?10:20)/rate,age=now-baseAt();
        double[] cues=base==2?new double[]{.833333,3.333333,8.333333}:new double[]{1.666667,5,11.666667,15.833333};
        for (double originalCue:cues) {
            double cue=originalCue/rate;
            double at=Math.floor(age/length)*length+cue;
            if (at>lastStepAge && at<=age && onGround()) {
                playSound(AveronSyncHorseSound.STEP.get(),.5F,.9F+random.nextFloat()*.3F);
                if (base==2 && coat()!=HorseCoat.UNICORN) ((ServerLevel)level()).sendParticles(new BlockParticleOption(ParticleTypes.BLOCK,Blocks.DIRT.defaultBlockState()),getX(),getY()+.1,getZ(),4,.35,.05,.5,.02);
            }
        }
        lastStepAge=age;
    }
    public QuestHorseEntity(EntityType<? extends Horse> type, Level level) {
        super(type, level);
        setInvulnerable(true);
        setPersistenceRequired();
    }
    void session(UUID value) { session = value; }
    UUID session() { return session; }
    @Override public UUID getOwnerUUID() {
        // AbstractHorse stores ownership in a plain field, so remote clients need a tracked copy.
        return level().isClientSide ? entityData.get(OWNER).orElse(null) : super.getOwnerUUID();
    }
    @Override public void setOwnerUUID(UUID owner) {
        super.setOwnerUUID(owner);
        if (!level().isClientSide) entityData.set(OWNER,Optional.ofNullable(owner));
    }
    @Override public LivingEntity getControllingPassenger() {
        return isSaddled() && getFirstPassenger() instanceof Player player
                && player.getUUID().equals(getOwnerUUID()) ? player : null;
    }
    @Override protected boolean canAddPassenger(Entity passenger) {
        if (!(passenger instanceof Player player) || !isAlive() || !player.isAlive() || player.isSpectator()) return false;
        if (!level().isClientSide && (!(player instanceof ServerPlayer serverPlayer)
                || !AveronSyncQuestHorses.authenticated(serverPlayer))) return false;
        if (player.getUUID().equals(getOwnerUUID())) return getPassengers().isEmpty();
        return getPassengers().size()==1 && getControllingPassenger()!=null && onGround();
    }
    @Override protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (!level().isClientSide && passenger.getUUID().equals(getOwnerUUID())) {
            ejectPassengers();
            keys=HorseControls.Input.NONE;
            inputAt=Long.MIN_VALUE;
        }
    }
    @Override public boolean canBeLeashed() { return false; }
    @Override protected net.minecraft.world.phys.Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dimensions, float scale) {
        var seatModel=loadSeatModel(coat().modelId());
        double age=level().getGameTime();
        UUID owner=getOwnerUUID();
        boolean front=owner==null ? passenger==getFirstPassenger() : passenger.getUUID().equals(owner);
        int offset=front?0:PASSENGER_SEAT_OFFSET;
        var seat=seatModel==null?new pl.skidam.automodpack_core.pets.PetAnimation.Vec(0,29,2+offset):
                seatModel.sample(baseClip(),Math.max(0,age-baseAt())/20*HorsePoseBlend.rate(baseClip()),action().name().toLowerCase(java.util.Locale.ROOT),Math.max(0,age-actionAt())/20,lean(),Math.max(0,age-leanAt())/20,
                        seatBlend.update(seatModel.model(),baseClip(),baseAt(),age),seatLean.update(lean(),age),offset);
        return new Vec3(seat.x()/16*scale,seat.y()/16*scale,seat.z()/16*scale).yRot((180-getYRot())*(float)Math.PI/180);
    }
    private static synchronized HorseSeatPose loadSeatModel(String id) {
        return SEAT_MODELS.computeIfAbsent(id,key -> {
            try(var in=QuestHorseEntity.class.getResourceAsStream("/assets/averonsync/mounts/"+key+".json")) {
                return Optional.of(HorseSeatPose.parse(com.google.gson.JsonParser.parseReader(
                        new java.io.InputStreamReader(in,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject()));
            } catch(Exception e) {
                pl.skidam.automodpack_core.GlobalVariables.LOGGER.error("Could not load animated horse seat for {}",key,e);
                return Optional.empty();
            }
        }).orElse(null);
    }
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (player.getItemInHand(hand).is(AveronSyncHorseContent.BRUSH.get())) return brush(player);
        if (player.isPassenger() || player.isSecondaryUseActive() || !player.startRiding(this)) return InteractionResult.FAIL;
        endApproach();
        return InteractionResult.CONSUME;
    }
    private InteractionResult brush(Player player) {
        if (!(player instanceof ServerPlayer owner) || !owner.getUUID().equals(getOwnerUUID())
                || !owner.isAlive() || owner.isSpectator() || !AveronSyncQuestHorses.authenticated(owner)
                || owner.isPassenger() || isVehicle() || !isAlive() || !onGround() || isApproaching()
                || getDeltaMovement().horizontalDistanceSqr()>.0025) return InteractionResult.FAIL;
        long now=level().getGameTime();
        if (now-groomAt()<30) return InteractionResult.CONSUME;
        boolean earnedBond=AveronSyncQuestHorses.groom(owner);
        setDirty(false);
        entityData.set(GROOM_AT,now);
        entityData.set(TWITCH,2|4);entityData.set(TWITCH_AT,now);
        ((ServerLevel)level()).sendParticles(ParticleTypes.HEART,getX(),getY()+1.7,getZ(),3,.35,.3,.4,.04);
        playSound(AveronSyncHorseSound.SNORT.get(),.65F,1F);
        owner.displayClientMessage(net.minecraft.network.chat.Component.literal(
                earnedBond?"Cavalo limpo • +Vínculo":"Cavalo limpo"),true);
        return InteractionResult.CONSUME;
    }
    @Override public void openCustomInventoryScreen(Player player) { /* No transferable inventory. */ }
    @Override public boolean isFood(ItemStack stack) { return false; }
    @Override public boolean canMate(Animal other) { return false; }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (session != null) tag.putUUID("AveronQuestSession", session);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        session = tag.hasUUID("AveronQuestSession") ? tag.getUUID("AveronQuestSession") : null;
    }
}
/*?}*/
