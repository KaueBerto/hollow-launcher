package pl.skidam.automodpack.modpack;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import pl.skidam.automodpack.networking.server.AveronSyncEntryQueue;
import pl.skidam.automodpack_core.queue.VipInventoryPlan;
import java.util.*;
import static net.minecraft.commands.Commands.literal;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

/**
 * {@code /kitvip} hands over VIP kits that were earned by redeeming a code but did not fit in the inventory at that
 * moment. Kits normally arrive with the code itself; the contents come from {@code config/averonsync-vip-kits.json}.
 */
public final class AveronSyncVipKitCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("kitvip")
                .requires(source -> source.getServer().isDedicatedServer())
                .executes(ctx -> claim(ctx.getSource())));
    }

    static boolean authenticated(ServerPlayer player) throws ReflectiveOperationException {
        // Singleplayer/LAN worlds have no EasyLogin and the integrated server may report offline mode.
        if (!player.server.isDedicatedServer()) return true;
        try {
            Class<?> auth = Class.forName("com.easylogin.auth.AuthManager");
            Object manager = auth.getField("INSTANCE").get(null);
            return manager != null && Boolean.TRUE.equals(auth.getMethod("isAuthenticated", ServerPlayer.class).invoke(manager, player));
        } catch (ClassNotFoundException e) {
            // Offline nicknames require EasyLogin. Never treat missing integration as authenticated.
            return player.getServer().usesAuthentication();
        }
    }

    /** Stage a full inventory result without touching the player's current items. */
    static Optional<List<ItemStack>> plan(List<ItemStack> inventory, List<ItemStack> rewards) {
        var current = inventory.stream().map(AveronSyncVipKitCommand::stack).toList();
        var extra = rewards.stream().map(AveronSyncVipKitCommand::stack).toList();
        return VipInventoryPlan.plan(current, extra, ItemStack::isSameItemSameComponents)
                .map(slots -> slots.stream().map(slot -> slot.count() == 0 ? ItemStack.EMPTY
                        : slot.kind().copyWithCount(slot.count())).toList());
    }

    private static VipInventoryPlan.Stack<ItemStack> stack(ItemStack item) {
        return item.isEmpty() ? new VipInventoryPlan.Stack<>(null, 0, 64)
                : new VipInventoryPlan.Stack<>(item.copy(), item.getCount(), item.getMaxStackSize());
    }

    static void setInventory(ServerPlayer player, List<ItemStack> slots) {
        for (int i = 0; i < 36; i++) player.getInventory().setItem(i, slots.get(i).copy());
        player.getInventory().setChanged();
        player.containerMenu.broadcastChanges();
    }

    private static int claim(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        var player = source.getPlayerOrException();
        String name = player.getGameProfile().getName();
        try {
            if (!authenticated(player)) return fail(source, "Entre no EasyLogin antes de resgatar o kit.");
            var pending = AveronSyncEntryQueue.get(source.getServer()).pendingKits();
            if (pending == null) return fail(source, "Cadastro de kits indisponivel. Avise a administracao.");
            var levels = List.copyOf(pending.levels(name));
            if (levels.isEmpty()) return fail(source, "Voce nao tem kit VIP pendente. O kit vem junto com o codigo: /averon codigo <codigo>.");
            int delivered = 0;
            for (int level : levels) {
                if (!AveronSyncVipKits.give(player, AveronSyncVipKits.build(source.getServer().registryAccess(), level))) break;
                pending.remove(name, level); // saved only after the items are in the inventory
                delivered++;
            }
            if (delivered == 0) return fail(source, "Falta espaco no inventario. Libere espaco e tente novamente.");
            LOGGER.info("Pending VIP kit delivered to {} ({} of {})", name, delivered, levels.size());
            int left = levels.size() - delivered, sent = delivered;
            source.sendSuccess(() -> Component.literal("[AveronSync] " + (sent == 1 ? "Kit VIP recebido!" : sent + " kits VIP recebidos!")
                    + (left > 0 ? " Ainda falta espaco para " + left + ": libere espaco e use /kitvip de novo." : "")), false);
            return 1;
        } catch (Exception e) {
            LOGGER.error("VIP kit claim failed for {}", name, e);
            return fail(source, "Nao foi possivel entregar o kit VIP. Avise a administracao; seu kit continua guardado.");
        }
    }
    private static int fail(CommandSourceStack source, String message) {
        source.sendFailure(Component.literal("[AveronSync] " + message)); return 0;
    }
    private AveronSyncVipKitCommand() {}
}
