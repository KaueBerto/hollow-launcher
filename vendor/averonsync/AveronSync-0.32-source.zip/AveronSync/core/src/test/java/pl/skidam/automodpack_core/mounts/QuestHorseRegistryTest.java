package pl.skidam.automodpack_core.mounts;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class QuestHorseRegistryTest {
    @TempDir Path temp;
    @Test void questUnlockPersistsAndRepeatedRewardsCannotCreateAnotherMount() throws Exception {
        var file = temp.resolve("horses.json"); var owner = UUID.randomUUID();
        var registry = new QuestHorseRegistry(file);
        assertNull(registry.token(owner));
        var token = registry.unlock(owner);
        assertEquals(token, registry.unlock(owner));
        assertEquals(token, new QuestHorseRegistry(file).token(owner));
        assertFalse(registry.owns(UUID.randomUUID(), token));
        assertFalse(registry.owns(owner, UUID.randomUUID()));
        assertFalse(registry.owns(owner, null));
        assertTrue(registry.owns(owner, token));
    }
    @Test void brokenRegistryIsNotSilentlyReset() throws Exception {
        var file = temp.resolve("horses.json"); Files.writeString(file, "{broken");
        assertThrows(java.io.IOException.class, () -> new QuestHorseRegistry(file));
        assertEquals("{broken", Files.readString(file));
    }
    @Test void failedUnlockDoesNotGrantInMemory() throws Exception {
        var folder = temp.resolve("folder"); Files.createDirectory(folder);
        var registry = new QuestHorseRegistry(folder.resolve("horses.json"));
        Files.delete(folder); Files.writeString(folder, "blocked");
        var owner = UUID.randomUUID();
        assertThrows(java.io.IOException.class, () -> registry.unlock(owner));
        assertNull(registry.token(owner));
    }
}
