package pl.skidam.automodpack_core.mounts;

import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;
import java.nio.file.*;
import java.util.List;
import pl.skidam.automodpack_core.pets.CubeeModel;
import static org.junit.jupiter.api.Assertions.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.*;

class QuestHorseModelTest {
    private final Path asset = Path.of("..", "src/main/resources/assets/averonsync/mounts/horse_bay.json");
    @Test void importedHorseHasRealGeometryAndEveryAnimationParses() throws Exception {
        org.junit.jupiter.api.Assumptions.assumeTrue(Files.isRegularFile(asset), "Import owner's horse RAR first");
        var model = CubeeModel.parseHorse(JsonParser.parseString(Files.readString(asset)).getAsJsonObject());
        assertEquals("horse_bay", model.id()); assertEquals(44, count(model.nodes()));
        assertEquals(3, model.textures().size()); assertEquals(20, model.animations().size());
        for (var clip : model.animations().values()) for (var track : clip.tracks().values())
            for (var channel : track.entrySet()) for (double time : new double[]{0, clip.length()/2, clip.length()})
                assertNotNull(sample(channel.getValue(), time, Vec.ZERO));
        // Mount IDs/assets must never leak into the VIP pet catalog/parser.
        assertThrows(IllegalArgumentException.class, () -> CubeeModel.parse(JsonParser.parseString(Files.readString(asset)).getAsJsonObject()));
    }
    @Test void horseParserRejectsTexturesOutsideItsOwnAssetFolder() throws Exception {
        org.junit.jupiter.api.Assumptions.assumeTrue(Files.isRegularFile(asset), "Import owner's horse RAR first");
        var root = JsonParser.parseString(Files.readString(asset)).getAsJsonObject();
        root.getAsJsonArray("textures").get(0).getAsJsonObject().addProperty("path", "othermod:textures/foreign.png");
        assertThrows(IllegalArgumentException.class, () -> CubeeModel.parseHorse(root));
    }
    @Test void riderSeatUsesOriginalLocatorAndMovesWithRearAnimation() throws Exception {
        org.junit.jupiter.api.Assumptions.assumeTrue(Files.isRegularFile(asset), "Import owner's horse RAR first");
        var pose=HorseSeatPose.parse(JsonParser.parseString(Files.readString(asset)).getAsJsonObject());
        assertEquals(new Vec(0,29,2),pose.seat());assertEquals(2,pose.parents().size());
        var idle=pose.sample("idle",0,"none",0,0,0);
        var rear=pose.sample("idle",0,"rear",.5,0,0);
        assertTrue(Math.abs(rear.y()-idle.y())+Math.abs(rear.z()-idle.z())>1,"Rider follows the animated saddle instead of floating at a fixed point");
    }
    @Test void seatTransformRotatesAroundTheAuthoredPivot() {
        var value=HorseSeatPose.transform(new Vec(0,2,0),new Vec(0,1,0),new Vec(90,0,0),Vec.ONE,Vec.ZERO);
        assertEquals(0,value.x(),1e-9);assertEquals(1,value.y(),1e-9);assertEquals(1,value.z(),1e-9);
    }
    private int count(List<CubeeModel.Node> nodes) { return nodes.stream().mapToInt(n -> n.cubes().size()+count(n.children())).sum(); }
}
