package pl.skidam.automodpack_core.mounts;

import pl.skidam.automodpack_core.pets.CubeeModel;
import org.junit.jupiter.api.Test;
import java.util.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.*;
import static org.junit.jupiter.api.Assertions.*;

class HorsePoseBlendTest {
    private CubeeModel model() {
        var node=new CubeeModel.Node("leg",Vec.ZERO,Vec.ZERO,List.of(),List.of());
        var clips=new HashMap<String,CubeeModel.Clip>();
        for(var entry:Map.of("idle",0,"walk",10,"gallop",20).entrySet())
            clips.put(entry.getKey(),new CubeeModel.Clip(1,Map.of("leg",Map.of("position",List.of(new Frame(0,new Vec(entry.getValue(),0,0),"linear"))))));
        return new CubeeModel("test",List.of(),List.of(node),clips);
    }
    private double shown(CubeeModel model,String clip,HorsePoseBlend.Transition blend) {
        Vec current=model.animations().get(clip).sample("leg","position",0);
        return (blend==null?current:HorsePoseBlend.mix(current,blend.pose().sample("leg","position",0),blend.weight())).x();
    }
    @Test void changingGaitStartsFromPreviousPoseAndBlendsOverFourTicks() {
        var m=model();var b=new HorsePoseBlend();b.update(m,"idle",100,100);
        assertEquals(0,shown(m,"walk",b.update(m,"walk",101,101)),1e-9);
        assertEquals(5,shown(m,"walk",b.update(m,"walk",101,103)),1e-9);
        assertEquals(10,shown(m,"walk",b.update(m,"walk",101,105)),1e-9);
    }
    @Test void interruptedBlendRetainsThePoseAlreadyOnScreen() {
        var m=model();var b=new HorsePoseBlend();b.update(m,"idle",100,100);b.update(m,"walk",101,101);
        assertEquals(5,shown(m,"gallop",b.update(m,"gallop",103,103)),1e-9);
    }
    @Test void gaitChangeRetainsTheStridePhase() {
        long at=HorsePoseBlend.phaseStart("walk",0,"gallop",8);
        assertEquals(.4,(8-at)/10.0,1e-9);
        assertEquals(8,HorsePoseBlend.phaseStart("idle",0,"walk",8));
    }
    @Test void changingTurnDirectionFadesPreviousLeanInsteadOfDroppingIt() {
        var b=new HorseLeanBlend();b.update(1,100);b.update(1,105);
        var layers=b.update(-1,106);
        assertEquals(.8,layers.stream().filter(l->l.lean()==1).findFirst().orElseThrow().weight(),1e-9);
        assertEquals(.2,layers.stream().filter(l->l.lean()==-1).findFirst().orElseThrow().weight(),1e-9);
        assertEquals(List.of(new HorseLeanBlend.Layer(-1,1)),b.update(-1,111));
    }
}
