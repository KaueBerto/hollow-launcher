package pl.skidam.automodpack_core.mounts;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static pl.skidam.automodpack_core.mounts.HorseControls.*;

class HorseControlsTest {
    private static final Environment GROUND = new Environment(true,false,false,false);
    private static Input keys(int front,int side,boolean jump,boolean sprint) { return new Input(front,side,jump,false,sprint); }
    private HorseControls fast() {
        var c=new HorseControls();c.tick(keys(1,0,false,true),GROUND);
        for(int i=0;i<20;i++)c.tick(keys(1,0,false,false),GROUND);
        return c;
    }
    @Test void ctrlForwardUsesTheExactTwoTickAccelerationSteps() {
        var c=new HorseControls();assertEquals(.25,c.tick(keys(1,0,false,true),GROUND).speed());
        for(double speed:new double[]{.5,.65,.65,.8,.8,.95,.95,1.10,1.10,1.25})
            assertEquals(speed*.5,c.tick(keys(1,0,false,false),GROUND).speed(),1e-9);
        var out=c.tick(keys(1,0,false,false),GROUND);assertEquals(Gait.GALLOP,out.gait());assertFalse(out.dismiss());
    }
    @Test void shiftDismissesWhileCtrlOnlyChangesGait() {
        assertTrue(new HorseControls().tick(new Input(0,0,false,true,false),GROUND).dismiss());
        assertFalse(new HorseControls().tick(keys(0,0,false,true),GROUND).dismiss());
        assertFalse(new HorseControls().tick(keys(1,0,false,true),GROUND).dismiss());
        assertEquals(.1,new HorseControls().tick(new Input(1,0,false,true,false),GROUND).speed());
    }
    @Test void tankSteeringReversesAndCanTurnWhileStationary() {
        var c=new HorseControls();assertEquals(-4,c.tick(keys(1,1,false,false),GROUND).yawDelta());
        assertEquals(4,c.tick(keys(-1,1,false,false),GROUND).yawDelta());
        assertEquals(-3,c.tick(keys(0,1,false,false),GROUND).yawDelta());
    }
    @Test void reverseUsesPointOneInsteadOfVanillaQuarterSpeed() {
        var out=new HorseControls().tick(keys(-1,0,false,false),GROUND);
        assertEquals(.05,out.speed());assertEquals(-1,out.front());assertEquals(Gait.BACKPEDAL,out.gait());
    }
    @Test void jumpingAtRestRearsAndDoesNotLaunch() {
        var out=new HorseControls().tick(keys(0,0,true,false),GROUND);
        assertEquals(Action.REAR,out.action());assertEquals(0,out.vertical());
    }
    @Test void gallopSpaceLaunchesButTrotDoesNot() {
        assertEquals(.6,fast().tick(keys(1,0,true,false),GROUND).vertical());
        assertEquals(0,new HorseControls().tick(keys(1,0,true,false),GROUND).vertical());
    }
    @Test void gallopSpaceAndSideDriftsInsteadOfJumping() {
        var out=fast().tick(keys(1,1,true,false),GROUND);
        assertTrue(out.drift());assertEquals(-7,out.yawDelta());assertEquals(0,out.vertical());
    }
    @Test void oakFenceUsesItsOwnLungeAndJumpCooldown() {
        var c=fast();var fence=new Environment(true,false,false,true);
        var out=c.tick(keys(1,0,false,false),fence);
        assertEquals(.425,out.lunge());assertEquals(.65,out.vertical());
        assertEquals(0,c.tick(keys(1,0,false,false),fence).vertical());
    }
    @Test void stoppingGallopBrakesForSixTicksAndResetsToTrot() {
        var c=fast();
        for(int i=0;i<6;i++){var out=c.tick(Input.NONE,GROUND);assertEquals(.0375,out.braking());assertEquals(.1,out.speed());}
        assertEquals(0,c.tick(Input.NONE,GROUND).braking());
    }
    @Test void waterResetsGaitBlocksToggleAndSignalsExit() {
        var c=fast();var out=c.tick(keys(1,0,true,true),new Environment(false,true,false,false));
        assertEquals(.25,out.speed());assertEquals(Gait.TROT,out.gait());assertEquals(0,out.vertical());
        assertEquals(Action.OUT_WATER,c.tick(Input.NONE,GROUND).action());
    }
    @Test void cliffFallBlocksSteeringAndLandingSignalsOnce() {
        var c=new HorseControls();var out=c.tick(keys(1,1,false,false),new Environment(false,false,true,false));
        assertEquals(Action.FALLING,out.action());assertEquals(0,out.yawDelta());
        assertEquals(Action.LAND,c.tick(Input.NONE,GROUND).action());
        assertEquals(Action.NONE,c.tick(Input.NONE,GROUND).action());
    }
    @Test void invalidNetworkAxesCannotCreateExtraSpeed() { assertThrows(IllegalArgumentException.class,()->keys(2,0,false,false)); }
    @Test void holdingCtrlDoesNotOscillateBetweenGaits() {
        var c=new HorseControls();c.tick(keys(1,0,false,true),GROUND);
        for(int i=0;i<120;i++) {
            var out=c.tick(keys(1,0,false,true),GROUND);
            if(i>=10) {assertEquals(Gait.GALLOP,out.gait());assertEquals(.625,out.speed());}
        }
        c.tick(keys(1,0,false,false),GROUND);
        assertEquals(.55,c.tick(keys(1,0,false,true),GROUND).speed());
    }
}
