package pl.skidam.automodpack_core.mounts;

/** Tick-based port of LittleRoom horse_bay_mcpet's meta-controller and metaskills.
 * Values/timers come from horse_bay.yml; input contains keys, never positions. */
public final class HorseControls {
    public static final double SPEED_SCALE = .5;
    public enum Gait { TROT, GALLOP, BACKPEDAL }
    public enum Action { NONE, REAR, JUMP, FALLING, LAND, OUT_WATER }
    public record Input(int front, int side, boolean jump, boolean sneak, boolean sprint) {
        public static final Input NONE = new Input(0, 0, false, false, false);
        public Input { if (front < -1 || front > 1 || side < -1 || side > 1) throw new IllegalArgumentException("Invalid horse keys"); }
    }
    public record Environment(boolean grounded, boolean water, boolean highFall, boolean oakFenceAhead) {}
    public record Output(double speed, int front, float yawDelta, int lean, double lunge, double vertical,
                         double braking, boolean drift, boolean dismiss, Gait gait, Action action, boolean falling, String animation) {}
    private static final double[] FAST = {.5, .65, .8, .95, 1.10, 1.25};
    private static final double[] SLOW = {1.10, .95, .8, .65, .5, .2};
    private Gait gait = Gait.TROT;
    private double speed = .2;
    private int toggleCooldown, globalCooldown, jumpCooldown, rearTicks, airDelay, brakeTicks, rampTick;
    private Boolean speedingUp;
    private boolean falling, wasWater;
    private boolean previousSprint;

    public Output tick(Input input, Environment env) {
        boolean pressedSprint=input.sprint && !previousSprint;
        previousSprint=input.sprint;
        if (toggleCooldown > 0) toggleCooldown--;
        if (globalCooldown > 0) globalCooldown--;
        if (jumpCooldown > 0) jumpCooldown--;
        if (rearTicks > 0) rearTicks--;
        if (airDelay > 0 && --airDelay == 0) falling = true;
        Action action = Action.NONE;
        boolean drift = false;
        double lunge = 0, vertical = 0;
        if (speedingUp != null) {
            rampTick++;
            int index = Math.min(5, rampTick / 2);
            speed = (speedingUp ? FAST : SLOW)[index];
            if (rampTick >= 10) { gait = speedingUp ? Gait.GALLOP : Gait.TROT; speedingUp = null; }
        }
        if (env.water) {
            if (!wasWater) { speed = .5; gait = Gait.TROT; speedingUp = null; }
            falling = false; airDelay = 0;
        } else if (wasWater) action = Action.OUT_WATER;
        wasWater = env.water;
        if (!env.water && falling && env.grounded) {
            falling = false; airDelay = 0; globalCooldown = 10; action = Action.LAND;
        } else if (!env.water && !falling && airDelay == 0 && env.highFall && !env.grounded) {
            falling = true; action = Action.FALLING;
        }
        if (!env.water && input.front == 0 && gait == Gait.GALLOP) {
            gait = Gait.TROT; speed = .2; speedingUp = null; brakeTicks = 6; globalCooldown = 10;
        }
        if (!env.water && globalCooldown == 0 && speedingUp == null) {
            if (input.front < 0 && gait != Gait.BACKPEDAL) { gait = Gait.BACKPEDAL; speed = .1; globalCooldown = 5; }
            else if (input.front > 0 && gait == Gait.BACKPEDAL) { gait = Gait.TROT; speed = .2; globalCooldown = 5; }
        }
        if (pressedSprint && input.front > 0 && !env.water && toggleCooldown == 0 && globalCooldown == 0) {
            speedingUp = gait != Gait.GALLOP; rampTick = 0;
            speed = (speedingUp ? FAST : SLOW)[0]; toggleCooldown = 20; globalCooldown = 10;
        }
        float yaw = 0; int lean = 0;
        if (!falling && input.side != 0) {
            if (input.front > 0) { yaw = -4 * input.side; lean = input.side; }
            else if (!env.water) yaw = (input.front < 0 ? 4 : -3) * input.side;
        }
        if (input.jump && input.side != 0 && gait == Gait.GALLOP) {
            yaw -= 3 * input.side; globalCooldown = 10; drift = true;
        }
        if (input.jump && input.side == 0 && !env.water && env.grounded && globalCooldown == 0 && jumpCooldown == 0) {
            jumpCooldown = 20;
            if (input.front == 0) { rearTicks = 20; globalCooldown = 20; action = Action.REAR; }
            else if (gait == Gait.GALLOP) { lunge = .6; vertical = .6; airDelay = 5; action = Action.JUMP; }
        }
        if (!env.water && env.grounded && env.oakFenceAhead && gait == Gait.GALLOP && jumpCooldown == 0) {
            lunge = .85; vertical = .65; airDelay = 5; jumpCooldown = 20; action = Action.JUMP;
        }
        double braking = brakeTicks > 0 ? .075 : 0;
        if (brakeTicks > 0) brakeTicks--;
        boolean gallopAnimation=speedingUp==null?gait==Gait.GALLOP:speedingUp?rampTick>=4:rampTick<4;
        String animation=env.water?"swim":(rearTicks>0 || input.front==0)?"idle":gait==Gait.BACKPEDAL?"backpedal":gallopAnimation?"gallop":"walk";
        return new Output(speed*SPEED_SCALE, rearTicks > 0 ? 0 : input.front, yaw, lean, lunge*SPEED_SCALE, vertical, braking*SPEED_SCALE, drift,
                input.sneak && input.front == 0, gait, action, falling,animation);
    }
}
