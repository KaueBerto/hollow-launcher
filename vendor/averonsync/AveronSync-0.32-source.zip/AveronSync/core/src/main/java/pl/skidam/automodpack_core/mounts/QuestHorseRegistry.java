package pl.skidam.automodpack_core.mounts;

import com.google.gson.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Server-thread-only, world-specific quest unlocks. No dependency on VIP expiration. */
public final class QuestHorseRegistry {
    private final Path file;
    private Map<UUID, UUID> whistles;

    public QuestHorseRegistry(Path file) throws IOException {
        this.file = file.toAbsolutePath();
        whistles = new HashMap<>();
        if (Files.exists(this.file)) {
            try {
                JsonObject root = JsonParser.parseString(Files.readString(this.file)).getAsJsonObject();
                if (root.get("version").getAsInt() != 1) throw new IllegalArgumentException("Unknown version");
                for (var entry : root.getAsJsonObject("players").entrySet())
                    whistles.put(UUID.fromString(entry.getKey()), UUID.fromString(entry.getValue().getAsString()));
            } catch (RuntimeException e) { throw new IOException("Invalid horse registry; original preserved: " + file, e); }
        }
    }

    public UUID token(UUID player) { return whistles.get(player); }
    public boolean owns(UUID player, UUID token) { return token != null && token.equals(whistles.get(player)); }

    /** Idempotent quest reward. Commit before delivering the item; reissue recovers lost delivery. */
    public UUID unlock(UUID player) throws IOException {
        Objects.requireNonNull(player);
        UUID existing = whistles.get(player);
        if (existing != null) return existing;
        Map<UUID, UUID> updated = new HashMap<>(whistles);
        UUID token = UUID.randomUUID(); updated.put(player, token);
        save(updated); whistles = updated;
        return token;
    }

    private void save(Map<UUID, UUID> updated) throws IOException {
        Files.createDirectories(file.getParent());
        JsonObject root = new JsonObject(), players = new JsonObject();
        root.addProperty("version", 1);
        updated.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .forEach(e -> players.addProperty(e.getKey().toString(), e.getValue().toString()));
        root.add("players", players);
        Path temp = Files.createTempFile(file.getParent(), "quest-horses-", ".tmp");
        try {
            Files.writeString(temp, new GsonBuilder().setPrettyPrinting().create().toJson(root));
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
    }
}
