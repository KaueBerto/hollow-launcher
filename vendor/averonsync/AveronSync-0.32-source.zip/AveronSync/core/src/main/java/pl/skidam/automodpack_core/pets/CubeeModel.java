package pl.skidam.automodpack_core.pets;

import com.google.gson.*;
import java.util.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.*;

public record CubeeModel(String id, List<Texture> textures, List<Node> nodes, Map<String, Clip> animations) {
    public record Texture(String path, double width, double height, double uvWidth, double uvHeight, int frameTime, int frames, int emissive) {}
    public record Face(int texture, double[] uv, int rotation) {}
    public record Cube(Vec from, Vec to, Vec origin, Vec rotation, double inflate, Map<String, Face> faces) {}
    public record Node(String id, Vec origin, Vec rotation, List<Cube> cubes, List<Node> children) {}
    public record Clip(double length, Map<String, Map<String, List<Frame>>> tracks) {
        public Vec sample(String node, String channel, double time) {
            return PetAnimation.sample(tracks.getOrDefault(node, Map.of()).getOrDefault(channel, List.of()), time,
                    channel.equals("scale") ? Vec.ONE : Vec.ZERO);
        }
    }
    public static CubeeModel parse(JsonObject root) {
        return parse(root, false);
    }
    public static CubeeModel parseHorse(JsonObject root) {
        return parse(root, true);
    }
    private static CubeeModel parse(JsonObject root, boolean horse) {
        String id = root.get("id").getAsString();
        if (horse ? !id.equals("horse_bay") : !PetCatalog.contains(id)) throw new IllegalArgumentException("Unknown model");
        List<Texture> textures = new ArrayList<>();
        for (var value : root.getAsJsonArray("textures")) {
            var t = value.getAsJsonObject();
            String path = t.get("path").getAsString();
            if (!path.matches(horse ? "averonsync:textures/mounts/horse_bay/[0-9]+\\.png" : "averonsync:textures/pets/[a-z_]+/[0-9]+\\.png")) throw new IllegalArgumentException("Invalid texture path");
            textures.add(new Texture(path, number(t, "width"), number(t, "height"), number(t, "uvWidth"), number(t, "uvHeight"),
                    t.get("frameTime").getAsInt(), t.get("frames").getAsInt(), t.get("emissive").getAsInt()));
        }
        if (textures.isEmpty() || textures.size() > 16) throw new IllegalArgumentException("Invalid textures");
        for (var t : textures) if (t.width < 1 || t.height < 1 || t.uvWidth < 1 || t.uvHeight < 1 || t.frameTime < 1 || t.frames < 1
                || t.emissive < -1 || t.emissive >= textures.size()) throw new IllegalArgumentException("Invalid texture dimensions");
        List<Node> nodes = new ArrayList<>();
        for (var value : root.getAsJsonArray("nodes")) nodes.add(node(value.getAsJsonObject(), textures.size(), 0));
        Map<String, Clip> animations = new HashMap<>();
        for (var entry : root.getAsJsonObject("animations").entrySet()) {
            var a = entry.getValue().getAsJsonObject();
            double length = number(a, "length"); if (length <= 0) throw new IllegalArgumentException("Invalid animation length");
            Map<String, Map<String, List<Frame>>> tracks = new HashMap<>();
            for (var track : a.getAsJsonObject("tracks").entrySet()) {
                Map<String, List<Frame>> channels = new HashMap<>();
                for (var channel : track.getValue().getAsJsonObject().entrySet()) {
                    if (!Set.of("position", "rotation", "scale").contains(channel.getKey())) throw new IllegalArgumentException("Unknown channel");
                    List<Frame> frames = new ArrayList<>();
                    for (var value : channel.getValue().getAsJsonArray()) {
                        var frame = value.getAsJsonObject();
                        frames.add(new Frame(number(frame, "time"), vec(frame.getAsJsonArray("value")), frame.get("interpolation").getAsString()));
                    }
                    for (int i = 1; i < frames.size(); i++) if (frames.get(i).time() <= frames.get(i-1).time()) throw new IllegalArgumentException("Unordered/duplicate frames");
                    channels.put(channel.getKey(), List.copyOf(frames));
                }
                tracks.put(track.getKey(), Map.copyOf(channels));
            }
            animations.put(entry.getKey(), new Clip(length, Map.copyOf(tracks)));
        }
        if (!animations.keySet().containsAll(horse ? Set.of("idle", "walk", "gallop", "jump", "falling") : Set.of("idle", "walk", "pet", "emote"))) throw new IllegalArgumentException("Missing animation");
        return new CubeeModel(id, List.copyOf(textures), List.copyOf(nodes), Map.copyOf(animations));
    }
    private static Node node(JsonObject n, int textureCount, int depth) {
        if (depth > 32) throw new IllegalArgumentException("Model tree too deep");
        List<Cube> cubes = new ArrayList<>(); List<Node> children = new ArrayList<>();
        for (var value : n.getAsJsonArray("cubes")) {
            var c = value.getAsJsonObject(); Map<String, Face> faces = new HashMap<>();
            for (var entry : c.getAsJsonObject("faces").entrySet()) {
                if (!Set.of("north", "south", "east", "west", "up", "down").contains(entry.getKey())) throw new IllegalArgumentException("Invalid face");
                var f = entry.getValue().getAsJsonObject(); int texture = f.get("texture").getAsInt();
                if (texture < 0 || texture >= textureCount) throw new IllegalArgumentException("Invalid texture index");
                var uv = f.getAsJsonArray("uv"); if (uv.size() != 4) throw new IllegalArgumentException("Invalid UV");
                double[] coords = new double[4]; for (int i = 0; i < 4; i++) coords[i] = finite(uv.get(i).getAsDouble());
                int rotation = f.get("rotation").getAsInt(); if (rotation % 90 != 0) throw new IllegalArgumentException("Invalid UV rotation");
                faces.put(entry.getKey(), new Face(texture, coords, rotation));
            }
            cubes.add(new Cube(vec(c.getAsJsonArray("from_")), vec(c.getAsJsonArray("to")), vec(c.getAsJsonArray("origin")),
                    vec(c.getAsJsonArray("rotation")), number(c, "inflate"), Map.copyOf(faces)));
        }
        for (var value : n.getAsJsonArray("children")) children.add(node(value.getAsJsonObject(), textureCount, depth + 1));
        return new Node(n.get("id").getAsString(), vec(n.getAsJsonArray("origin")), vec(n.getAsJsonArray("rotation")), List.copyOf(cubes), List.copyOf(children));
    }
    private static double finite(double v) { if (!Double.isFinite(v)) throw new IllegalArgumentException("Non-finite model value"); return v; }
    private static double number(JsonObject o, String key) { return finite(o.get(key).getAsDouble()); }
    private static Vec vec(JsonArray a) { if (a.size() != 3) throw new IllegalArgumentException("Invalid vector"); return new Vec(a.get(0).getAsDouble(), a.get(1).getAsDouble(), a.get(2).getAsDouble()); }
}
