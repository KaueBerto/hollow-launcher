package pl.skidam.automodpack_core.mounts;

import com.google.gson.JsonObject;
import pl.skidam.automodpack_core.pets.*;
import java.util.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.*;

/** Transforms the authored p_seat through its animated parent bones. */
public record HorseSeatPose(CubeeModel model, List<CubeeModel.Node> parents, Vec seat) {
    public static HorseSeatPose parse(JsonObject root) {
        var model=CubeeModel.parseHorse(root);var parents=new ArrayList<CubeeModel.Node>();
        var nodes=model.nodes();
        for(var id:root.getAsJsonArray("seatChain")) {
            var node=nodes.stream().filter(n->n.id().equals(id.getAsString())).findFirst().orElseThrow();
            parents.add(node);nodes=node.children();
        }
        var v=root.getAsJsonArray("seat");
        return new HorseSeatPose(model,List.copyOf(parents),new Vec(v.get(0).getAsDouble(),v.get(1).getAsDouble(),v.get(2).getAsDouble()));
    }
    public Vec sample(String base,double baseTime,String action,double actionTime,int lean,double leanTime) {
        return sample(base,baseTime,action,actionTime,lean,leanTime,null);
    }
    public Vec sample(String base,double baseTime,String action,double actionTime,int lean,double leanTime,HorsePoseBlend.Transition transition) {
        return sample(base,baseTime,action,actionTime,lean,leanTime,transition,
                lean==0?List.of():List.of(new HorseLeanBlend.Layer(lean,Math.min(1,leanTime*4))));
    }
    public Vec sample(String base,double baseTime,String action,double actionTime,int lean,double leanTime,HorsePoseBlend.Transition transition,List<HorseLeanBlend.Layer> leanLayers) {
        var baseClip=model.animations().get(base);
        var actionClip=model.animations().get(action);
        if(actionClip!=null && actionTime>actionClip.length()+.2 && !Set.of("jump","falling").contains(action)) actionClip=null;
        Vec point=seat;
        for(int i=parents.size()-1;i>=0;i--) {
            var node=parents.get(i);var values=new HashMap<String,Vec>();
            for(String channel:List.of("position","rotation","scale")) {
                Vec value=baseClip.sample(node.id(),channel,baseTime%baseClip.length());
                if(transition!=null)value=HorsePoseBlend.mix(value,transition.pose().sample(node.id(),channel,0),transition.weight());
                if(actionClip!=null && actionClip.tracks().getOrDefault(node.id(),Map.of()).containsKey(channel)) {
                    double weight=Math.min(1,Math.max(0,actionTime*10));
                    if(!Set.of("jump","falling").contains(action))weight*=Math.min(1,Math.max(0,(actionClip.length()+.2-actionTime)/.2));
                    value=HorsePoseBlend.mix(value,actionClip.sample(node.id(),channel,Math.min(actionTime,actionClip.length())),weight);
                }
                for(var layer:leanLayers) {
                    var leanClip=model.animations().get(HorseLeanBlend.clip(layer.lean()));
                    if(leanClip!=null && leanClip.tracks().getOrDefault(node.id(),Map.of()).containsKey(channel))
                        value=HorsePoseBlend.mix(value,leanClip.sample(node.id(),channel,0),layer.weight());
                }
                values.put(channel,value);
            }
            point=transform(point,node.origin(),BlockbenchPose.rotation(node.rotation(),values.get("rotation")),values.get("scale"),BlockbenchPose.position(values.get("position")));
        }
        return point;
    }
    public static Vec transform(Vec point,Vec origin,Vec rotation,Vec scale,Vec move) {
        double x=(point.x()-origin.x())*scale.x(),y=(point.y()-origin.y())*scale.y(),z=(point.z()-origin.z())*scale.z();
        double r=Math.toRadians(rotation.x()),c=Math.cos(r),s=Math.sin(r),ny=y*c-z*s;z=y*s+z*c;y=ny;
        r=Math.toRadians(rotation.y());c=Math.cos(r);s=Math.sin(r);double nx=x*c+z*s;z=z*c-x*s;x=nx;
        r=Math.toRadians(rotation.z());c=Math.cos(r);s=Math.sin(r);nx=x*c-y*s;y=x*s+y*c;x=nx;
        return new Vec(x+origin.x()+move.x(),y+origin.y()+move.y(),z+origin.z()+move.z());
    }
}
