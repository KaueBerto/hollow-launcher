package pl.skidam.automodpack_core.mounts;

/** Progress counts ticks spent actually travelling on the mount. */
public final class HorseBond {
    public static final int COMPANION = 5 * 60 * 20;
    public static final int TRUSTED = 15 * 60 * 20;

    public static int level(int travelTicks) {
        if (travelTicks >= TRUSTED) return 3;
        return travelTicks >= COMPANION ? 2 : 1;
    }

    public static int nextThreshold(int travelTicks) {
        return level(travelTicks) == 1 ? COMPANION : TRUSTED;
    }

    public static double roadMultiplier(int travelTicks) {
        return 1 + (level(travelTicks) - 1) * .1;
    }

    private HorseBond() {}
}
