package pl.skidam.automodpack_core.mounts;

import java.util.*;

/** Authored leaning clips are constant poses: crossfade their weights over five
 * ticks, retaining the previous side when a turn is released or reversed. */
public final class HorseLeanBlend {
    public record Layer(int lean,double weight) {}
    private static final int[] POSES={1,2,-1,-2};
    private final double[] weights=new double[4];
    private double age=Double.NaN;
    public List<Layer> update(int target,double now) {
        double delta=Double.isNaN(age)?0:Math.max(0,Math.min(20,now-age));age=now;
        var result=new ArrayList<Layer>();
        for(int i=0;i<4;i++) {
            double desired=POSES[i]==target?1:0;
            weights[i]+=Math.max(-delta/5,Math.min(delta/5,desired-weights[i]));
            if(weights[i]>1e-8)result.add(new Layer(POSES[i],weights[i]));
        }
        return List.copyOf(result);
    }
    public static String clip(int lean) { return (lean>0?"lean_left":"lean_right")+(Math.abs(lean)==1?"_trot":""); }
}
