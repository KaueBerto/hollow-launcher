package pl.skidam.automodpack_core.pets;

import static pl.skidam.automodpack_core.pets.PetAnimation.Vec;

/** Cosmetic spring following. No world entities, collisions or gameplay movement. */
public final class PetFollowMotion {
    public record Settings(double scale, double side, double forward, double height, double speed, boolean crouchToFaceOwner) {}
    public static Settings settings(String id) {
        boolean biomesII=PetCatalog.find(id).orElseThrow().category().equals("Biomas II");
        return new Settings(biomesII ? .4875 : .42, .7, -.3, .75, 7, biomesII);
    }
    public static Vec target(Vec owner, double yaw, Settings settings, boolean crouching) {
        double side=crouching && settings.crouchToFaceOwner ? -.95 : settings.side;
        double forward=crouching && settings.crouchToFaceOwner ? 1.5 : settings.forward;
        double height=crouching && settings.crouchToFaceOwner ? .3 : settings.height;
        double angle=Math.toRadians(yaw), sin=Math.sin(angle), cos=Math.cos(angle);
        return new Vec(owner.x()+cos*side-sin*forward,owner.y()+height,owner.z()+sin*side+cos*forward);
    }
    public static Vec step(Vec current, Vec target, double deltaSeconds, double speed) {
        double dx=target.x()-current.x(),dy=target.y()-current.y(),dz=target.z()-current.z();
        if(dx*dx+dy*dy+dz*dz>36) return target;
        double alpha=1-Math.exp(-speed*Math.max(0,Math.min(deltaSeconds,.25)));
        return new Vec(current.x()+dx*alpha,current.y()+dy*alpha,current.z()+dz*alpha);
    }
    private PetFollowMotion() {}
}
