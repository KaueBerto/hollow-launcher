package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.*;
import net.minecraft.core.registries.Registries;
import java.util.function.Supplier;

public final class AveronSyncHorseContent {
    private static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, "averonsync");
    private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems("averonsync");
    public static final Supplier<EntityType<QuestHorseEntity>> HORSE = ENTITIES.register("quest_horse", () ->
            EntityType.Builder.of(QuestHorseEntity::new, MobCategory.CREATURE).sized(1.5F, 3F)
                    .clientTrackingRange(10).updateInterval(1).build("averonsync:quest_horse"));
    public static final Supplier<HorseWhistleItem> WHISTLE = ITEMS.register("horse_whistle", () -> new HorseWhistleItem(new Item.Properties().stacksTo(1)));

    public static void init(IEventBus bus) {
        ENTITIES.register(bus); ITEMS.register(bus);
        bus.addListener(AveronSyncHorseContent::attributes);
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.register(AveronSyncQuestHorses.class);
    }
    private static void attributes(EntityAttributeCreationEvent event) {
        event.put(HORSE.get(), Horse.createBaseHorseAttributes().add(Attributes.MAX_HEALTH,24).build());
    }
    private AveronSyncHorseContent() {}
}
/*?}*/
