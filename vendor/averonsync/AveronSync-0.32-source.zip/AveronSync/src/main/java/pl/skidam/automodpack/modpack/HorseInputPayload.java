package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import pl.skidam.automodpack_core.mounts.HorseControls;

/** Keys only: clients cannot choose velocity, yaw, position, owner or entitlement. */
public record HorseInputPayload(int entityId, HorseControls.Input input) implements CustomPacketPayload {
    public static final Type<HorseInputPayload> TYPE = new Type<>(ResourceLocation.parse("averonsync:horse_keys"));
    public static final StreamCodec<RegistryFriendlyByteBuf,HorseInputPayload> CODEC = StreamCodec.of((buf,data) -> {
        buf.writeVarInt(data.entityId); buf.writeByte(data.input.front()); buf.writeByte(data.input.side());
        buf.writeByte((data.input.jump()?1:0)|(data.input.sneak()?2:0)|(data.input.sprint()?4:0));
    }, buf -> {
        int id=buf.readVarInt(), front=buf.readByte(), side=buf.readByte(), flags=buf.readUnsignedByte();
        if (id < 0 || flags > 7) throw new IllegalArgumentException("Invalid horse input");
        return new HorseInputPayload(id,new HorseControls.Input(front,side,(flags&1)!=0,(flags&2)!=0,(flags&4)!=0));
    });
    public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("averonsync-horse-2").playToServer(TYPE,CODEC,(data,context) -> context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player && player.getVehicle() instanceof QuestHorseEntity horse
                    && horse.getId()==data.entityId) horse.acceptInput(player,data.input);
        }));
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
/*?}*/
