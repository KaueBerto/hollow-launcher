package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.*;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.*;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;
import pl.skidam.automodpack.modpack.*;

public final class MountMenuClient {
    public static final KeyMapping OPEN=new KeyMapping("key.averonsync.mounts",KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_G,"key.categories.averonsync");
    private static int sequence;
    private static boolean waitForRelease;
    public static void init(IEventBus bus) {
        bus.addListener(MountMenuClient::keys);
        NeoForge.EVENT_BUS.addListener(MountMenuClient::tick);
    }
    private static void keys(RegisterKeyMappingsEvent event) { event.register(OPEN); }
    private static void tick(ClientTickEvent.Post event) {
        Minecraft mc=Minecraft.getInstance();
        while(OPEN.consumeClick()) {
            if(waitForRelease || mc.player==null || mc.level==null || mc.screen!=null)continue;
            open(false);
        }
        if(waitForRelease && !OPEN.isDown())waitForRelease=false;
    }
    static void closed(){waitForRelease=true;}
    public static void openPets(){open(true);}
    private static void open(boolean pets) {
        Minecraft mc=Minecraft.getInstance();if(mc.player==null || mc.level==null)return;
        sequence=sequence==Integer.MAX_VALUE?1:sequence+1;
        mc.setScreen(new MountScreen(sequence,pets));send(sequence,MountMenuRequest.QUERY);
    }
    static void send(int id,int action) {
        if(Minecraft.getInstance().getConnection()!=null)PacketDistributor.sendToServer(new MountMenuRequest(id,action));
    }
    public static void accept(MountMenuState state) {
        Minecraft mc=Minecraft.getInstance();
        // A reply cannot resurrect a closed menu, or update a later opening.
        if(mc.screen instanceof MountScreen screen && screen.screenId()==state.screenId()) {
            if(state.close())mc.setScreen(null);
            else screen.update(state);
        }
    }
    private MountMenuClient() {}
}
/*?}*/
