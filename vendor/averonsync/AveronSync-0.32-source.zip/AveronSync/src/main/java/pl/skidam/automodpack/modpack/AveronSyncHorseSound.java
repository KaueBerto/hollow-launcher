package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;

public final class AveronSyncHorseSound {
    private static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, "averonsync");
    public static final Supplier<SoundEvent> WHISTLE = SOUNDS.register("horse_whistle", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.parse("averonsync:horse_whistle")));
    public static final Supplier<SoundEvent> STEP = register("horse_step"), NEIGH = register("horse_neigh"), SNORT = register("horse_snort"), SKID = register("horse_skid");
    private static Supplier<SoundEvent> register(String id) { return SOUNDS.register(id, () -> SoundEvent.createVariableRangeEvent(ResourceLocation.parse("averonsync:"+id))); }
    public static void init(IEventBus bus) { SOUNDS.register(bus); }
    private AveronSyncHorseSound() {}
}
/*?}*/
