package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record MountMenuState(int screenId,boolean enabled,boolean unlocked,boolean whistle,boolean active,
                             boolean canStore,boolean close,String message,long petUntil,String selectedPet) implements CustomPacketPayload {
    public MountMenuState(int id,boolean enabled,boolean unlocked,boolean whistle,boolean active,boolean canStore,boolean close,String message) {
        this(id,enabled,unlocked,whistle,active,canStore,close,message,0,"");
    }
    public static final Type<MountMenuState> TYPE=new Type<>(ResourceLocation.parse("averonsync:mount_menu_state"));
    public static final StreamCodec<RegistryFriendlyByteBuf,MountMenuState> CODEC=StreamCodec.of((buf,s)->{
        buf.writeVarInt(s.screenId);buf.writeByte((s.enabled?1:0)|(s.unlocked?2:0)|(s.whistle?4:0)|(s.active?8:0)|(s.canStore?16:0)|(s.close?32:0));buf.writeUtf(s.message,120);
        buf.writeLong(s.petUntil);buf.writeUtf(s.selectedPet,48);
    },buf->{
        int id=buf.readVarInt(),flags=buf.readUnsignedByte();String message=buf.readUtf(120);
        if(flags>63)throw new IllegalArgumentException("Invalid mount menu flags");
        return new MountMenuState(id,(flags&1)!=0,(flags&2)!=0,(flags&4)!=0,(flags&8)!=0,(flags&16)!=0,(flags&32)!=0,message,buf.readLong(),buf.readUtf(48));
    });
    public MountMenuState {
        if(screenId<1 || message==null || message.length()>120 || (canStore&&!active) || (whistle&&!unlocked)
                || petUntil<0 || selectedPet==null || (!selectedPet.isEmpty() && !pl.skidam.automodpack_core.pets.VipPetAccess.allows(1,selectedPet)))
            throw new IllegalArgumentException("Invalid mount menu state");
    }
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
}
/*?}*/
