package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Only an action on the sender's own mount; never a player, entity or grant ID. */
public record MountMenuRequest(int screenId,int action) implements CustomPacketPayload {
    public static final int QUERY=0,SUMMON=1,STORE=2,RECOVER=3,SELECT=4;
    public static final Type<MountMenuRequest> TYPE=new Type<>(ResourceLocation.parse("averonsync:mount_menu_request"));
    public static final StreamCodec<RegistryFriendlyByteBuf,MountMenuRequest> CODEC=StreamCodec.of(
            (buf,value)->{buf.writeVarInt(value.screenId);buf.writeByte(value.action);},
            buf->new MountMenuRequest(buf.readVarInt(),buf.readUnsignedByte()));
    public MountMenuRequest { if(screenId<1 || action<QUERY || action>SELECT)throw new IllegalArgumentException("Invalid mount menu request"); }
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
}
/*?}*/
