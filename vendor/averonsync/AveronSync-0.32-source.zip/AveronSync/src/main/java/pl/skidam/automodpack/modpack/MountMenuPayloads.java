package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

public final class MountMenuPayloads {
    public static void register(RegisterPayloadHandlersEvent event) {
        var registrar=event.registrar("averonsync-mount-menu-3");
        registrar.playToServer(MountMenuRequest.TYPE,MountMenuRequest.CODEC,(request,context)->context.enqueueWork(()->{
            if(context.player() instanceof ServerPlayer player) {
                var reply=AveronSyncQuestHorses.menuAction(player,request);
                if(reply!=null)PacketDistributor.sendToPlayer(player,reply);
            }
        }));
        registrar.playToClient(MountMenuState.TYPE,MountMenuState.CODEC,(reply,context)->context.enqueueWork(()->
                pl.skidam.automodpack.client.mounts.MountMenuClient.accept(reply)));
    }
    private MountMenuPayloads() {}
}
/*?}*/
