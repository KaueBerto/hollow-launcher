package pl.skidam.automodpack.mixin.compat;

/*? if neoforge {*/
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.skidam.automodpack.modpack.QuestHorseEntity;

@Pseudo
@Mixin(targets = "io.socol.betterthirdperson.impl.PlayerAdapter", remap = false)
public abstract class BetterThirdPersonMountMixin {
    @Shadow @Final private Player player;

    @Inject(method = "hasAllowedVehicle", at = @At("HEAD"), cancellable = true, require = 0)
    private void averonsync$useVanillaCameraForQuestHorse(CallbackInfoReturnable<Boolean> result) {
        // The custom camera also changes rider orientation and movement input.
        if (player.getVehicle() instanceof QuestHorseEntity) {
            result.setReturnValue(false);
        }
    }
}
/*?}*/
