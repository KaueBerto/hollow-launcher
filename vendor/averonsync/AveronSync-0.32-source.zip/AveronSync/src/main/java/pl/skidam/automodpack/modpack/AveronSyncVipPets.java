package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import pl.skidam.automodpack.networking.server.AveronSyncEntryQueue;
import pl.skidam.automodpack_core.pets.*;
import java.util.*;
import static net.minecraft.commands.Commands.*;
import static pl.skidam.automodpack_core.GlobalVariables.*;

public final class AveronSyncVipPets {
    private static final Map<MinecraftServer, State> SERVERS = new IdentityHashMap<>();
    private static final class State {
        VipPetSelections selections;
        Map<UUID, List<AveronSyncPetPayload.Entry>> sent = new HashMap<>();
        Map<UUID, Action> actions = new HashMap<>();
        Map<UUID, Long> lastAction = new HashMap<>();
        State() {
            try { selections = new VipPetSelections(serverConfigFile.resolveSibling("averonsync-vip-pets.json")); }
            catch (java.io.IOException e) { LOGGER.error("VIP pets disabled: invalid selection file; original preserved", e); }
        }
    }
    private record Action(String name, long time) {}
    private static State state(MinecraftServer server) { return SERVERS.computeIfAbsent(server, ignored -> new State()); }
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("averonsync-pets-1").playToClient(AveronSyncPetPayload.TYPE, AveronSyncPetPayload.CODEC,
                (data, context) -> context.enqueueWork(() -> pl.skidam.automodpack.client.pets.VipPetClient.accept(data)));
    }
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("petvip").requires(s -> s.getServer().isDedicatedServer())
                .executes(ctx -> command(ctx.getSource(), "menu", null))
                .then(literal("listar").executes(ctx -> command(ctx.getSource(), "list", null)))
                .then(literal("guardar").executes(ctx -> command(ctx.getSource(), "hide", null)))
                .then(literal("carinho").executes(ctx -> command(ctx.getSource(), "pet", null)))
                .then(literal("emote").executes(ctx -> command(ctx.getSource(), "emote", null)))
                .then(literal("usar").then(argument("pet", StringArgumentType.word())
                        .suggests((ctx, builder) -> { VipPetAccess.available(VipPetAccess.CURRENT_VIP_LEVEL).forEach(p -> { if (p.id().startsWith(builder.getRemaining())) builder.suggest(p.id()); }); return builder.buildFuture(); })
                        .executes(ctx -> command(ctx.getSource(), "select", StringArgumentType.getString(ctx, "pet"))))));
    }
    private static boolean authenticated(ServerPlayer player) {
        try { return AveronSyncVipKitCommand.authenticated(player); }
        catch (ReflectiveOperationException | RuntimeException e) { return false; }
    }
    private static long entitlement(ServerPlayer player) {
        var vips = AveronSyncEntryQueue.get(player.server).vips();
        if (vips == null || !player.isAlive() || player.isSpectator() || !authenticated(player)) return 0;
        return vips.expiresAt(player.getGameProfile().getName());
    }
    public static long menuEntitlement(ServerPlayer player) {
        if(!player.server.isDedicatedServer() || state(player.server).selections==null)return 0;
        return entitlement(player);
    }
    public static String menuSelection(ServerPlayer player) {
        if(menuEntitlement(player)<=System.currentTimeMillis())return "";
        return VipPetAccess.visibleSelection(VipPetAccess.CURRENT_VIP_LEVEL,state(player.server).selections.get(player.getGameProfile().getName()));
    }
    private static int fail(CommandSourceStack source, String text) {
        if(source.getEntity() instanceof ServerPlayer player)player.displayClientMessage(Component.literal(text),true);
        else source.sendFailure(Component.literal("[AveronSync] " + text));
        return 0;
    }
    private static int command(CommandSourceStack source, String operation, String pet) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (!authenticated(player)) return fail(source, "Entre no EasyLogin antes de usar seus pets.");
        State state = state(player.server);
        if (state.selections == null) return fail(source, "Cadastro de pets indisponivel. Avise a administracao.");
        long now = System.currentTimeMillis(); String name = player.getGameProfile().getName();
        if (!operation.equals("hide") && entitlement(player) <= now) return fail(source, "Voce precisa de um VIP ativo para usar pets cosmeticos.");
        try {
            if (operation.equals("menu")) {
                PacketDistributor.sendToPlayer(player, new AveronSyncPetPayload(roster(player.server), true, VipPetAccess.visibleSelection(VipPetAccess.CURRENT_VIP_LEVEL,state.selections.get(name))));
            } else if (operation.equals("list")) {
                source.sendSuccess(() -> Component.literal("[AveronSync] Pets do VIP nivel 1: use /petvip para abrir o menu, ou /petvip usar <id>."), false);
                for (var p : VipPetAccess.available(VipPetAccess.CURRENT_VIP_LEVEL)) source.sendSuccess(() -> Component.literal(p.id() + " - " + p.name()), false);
            } else if (operation.equals("select") || operation.equals("hide")) {
                if (pet != null && !PetCatalog.contains(pet)) return fail(source, "Pet desconhecido. Use /petvip listar.");
                if (pet != null && !VipPetAccess.allows(VipPetAccess.CURRENT_VIP_LEVEL,pet)) return fail(source, "Este pet nao faz parte do VIP nivel 1. Use /petvip para ver os pets disponiveis.");
                state.selections.set(name, operation.equals("hide") ? null : pet); state.actions.remove(player.getUUID());
                player.displayClientMessage(Component.literal(operation.equals("hide")?"Pet guardado.":"Pet selecionado."),true);
                sync(player.server);
            } else {
                if (VipPetAccess.visibleSelection(VipPetAccess.CURRENT_VIP_LEVEL,state.selections.get(name)).isEmpty()) return fail(source, "Escolha um pet do seu VIP com /petvip.");
                if (now - state.lastAction.getOrDefault(player.getUUID(), 0L) < 2_000) return fail(source, "Aguarde dois segundos entre animacoes.");
                state.lastAction.put(player.getUUID(), now); state.actions.put(player.getUUID(), new Action(operation, now)); sync(player.server);
            }
            return 1;
        } catch (java.io.IOException | RuntimeException e) {
            LOGGER.error("VIP pet command failed for {}", name, e); return fail(source, "Nao foi possivel atualizar o pet. Estado anterior preservado.");
        }
    }
    private static List<AveronSyncPetPayload.Entry> roster(MinecraftServer server) {
        State state = state(server); if (state.selections == null) return List.of();
        long now = System.currentTimeMillis(); List<AveronSyncPetPayload.Entry> entries = new ArrayList<>();
        for (var player : server.getPlayerList().getPlayers()) {
            long expiry = entitlement(player); if (expiry <= now) continue;
            String selected = state.selections.get(player.getGameProfile().getName()); if (selected == null) continue;
            if (!VipPetAccess.allows(VipPetAccess.CURRENT_VIP_LEVEL,selected)) continue;
            Action action = state.actions.getOrDefault(player.getUUID(), new Action("idle", 0));
            entries.add(new AveronSyncPetPayload.Entry(player.getUUID(), selected, expiry, action.name, action.time));
            if (entries.size() == 256) break;
        }
        return List.copyOf(entries);
    }
    private static void sync(MinecraftServer server) {
        State state = state(server); var entries = roster(server); Set<UUID> online = new HashSet<>();
        for (var player : server.getPlayerList().getPlayers()) {
            online.add(player.getUUID());
            if (!entries.equals(state.sent.get(player.getUUID()))) {
                PacketDistributor.sendToPlayer(player, new AveronSyncPetPayload(entries, false, "")); state.sent.put(player.getUUID(), entries);
            }
        }
        state.sent.keySet().retainAll(online); state.actions.keySet().retainAll(online); state.lastAction.keySet().retainAll(online);
    }
    public static void tick(MinecraftServer server) { if (server.isDedicatedServer() && server.getTickCount() % 20 == 0) sync(server); }
    public static void joined(ServerPlayer player) { State s = SERVERS.get(player.server); if (s != null) s.sent.remove(player.getUUID()); }
    public static void shutdown(MinecraftServer server) { SERVERS.remove(server); }
    private AveronSyncVipPets() {}
}
/*?}*/
