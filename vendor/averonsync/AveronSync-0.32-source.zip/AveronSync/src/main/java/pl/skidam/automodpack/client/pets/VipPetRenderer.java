package pl.skidam.automodpack.client.pets;

/*? if neoforge {*/
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import pl.skidam.automodpack_core.pets.*;
import java.util.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.*;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

/** Pure visuals: no entity, hitbox, pathfinding, inventory, combat or chunk tickets. */
public final class VipPetRenderer {
    private static final Set<String> FAILED = new HashSet<>();
    private static final Map<UUID, Follow> FOLLOW = new HashMap<>();
    private record Follow(Object level, String pet, Vec position, double age, float yaw) {}
    static void reset() { FAILED.clear(); FOLLOW.clear(); }
    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        Minecraft mc = Minecraft.getInstance(); if (mc.level == null || mc.player == null) return;
        var camera = event.getCamera().getPosition();
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        double age = PetRenderTime.ticks(mc.level.getGameTime(), partial);
        long now = System.currentTimeMillis();
        var buffers = mc.renderBuffers().bufferSource(); Set<RenderType> used = new HashSet<>();
        Set<UUID> visible = new HashSet<>();
        int rendered = 0;
        for (var entry : VipPetClient.entries) {
            if (entry.expiresAt() <= now || FAILED.contains(entry.pet())) continue;
            var player = mc.level.getPlayerByUUID(entry.owner());
            if (player == null || !player.isAlive() || player.isSpectator() || player.isInvisible() || player.distanceToSqr(mc.player) > 32*32) continue;
            if (!event.getFrustum().isVisible(player.getBoundingBox().inflate(3))) continue;
            var optional = VipPetClient.model(entry.pet()); if (optional.isEmpty()) continue;
            if (++rendered > 32) break;
            CubeeModel model = optional.get();
            var settings = PetFollowMotion.settings(entry.pet());
            float yaw = Mth.rotLerp(partial, player.yRotO, player.getYRot());
            Vec owner = new Vec(Mth.lerp(partial, player.xo, player.getX()), Mth.lerp(partial, player.yo, player.getY()), Mth.lerp(partial, player.zo, player.getZ()));
            Vec target = PetFollowMotion.target(owner, yaw, settings, player.isCrouching());
            Follow previous = FOLLOW.get(entry.owner());
            boolean reset = previous == null || previous.level != mc.level || !previous.pet.equals(entry.pet()) || age < previous.age;
            Vec position = reset ? target : PetFollowMotion.step(previous.position, target, (age-previous.age)/20, settings.speed());
            if (player.isCrouching() && !settings.crouchToFaceOwner() && !reset) {
                double dx=previous.position.x()-owner.x(),dy=previous.position.y()-owner.y(),dz=previous.position.z()-owner.z();
                if (dx*dx+dy*dy+dz*dz<=36) position = previous.position;
                yaw=previous.yaw;
            }
            FOLLOW.put(entry.owner(), new Follow(mc.level, entry.pet(), position, age, yaw)); visible.add(entry.owner());
            boolean moving = Math.abs(position.x()-target.x()) + Math.abs(position.z()-target.z()) > .03
                    || Math.abs(player.getX()-player.xo) + Math.abs(player.getZ()-player.zo) > .015;
            String clipName = moving ? "walk" : "idle";
            double time = age / 20.0;
            if (!entry.action().equals("idle")) {
                double elapsed = Math.max(0, (now - entry.actionAt()) / 1000.0);
                var action = model.animations().get(entry.action());
                if (action != null && elapsed < action.length()) { clipName = entry.action(); time = elapsed; }
            }
            var clip = model.animations().get(clipName); time %= clip.length();
            // Restore original pack offsets/scale; follow catches up instead of being rigidly attached.
            if (player.isCrouching() && settings.crouchToFaceOwner()) yaw += 207;
            PoseStack poses = event.getPoseStack(); poses.pushPose();
            try {
                poses.translate(position.x()-camera.x, position.y()-camera.y, position.z()-camera.z);
                poses.mulPose(Axis.YP.rotationDegrees(180-yaw));
                float scale=(float)settings.scale()/16; poses.scale(scale,scale,scale);
                int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(player.position()));
                for (var node : model.nodes()) node(poses, buffers, used, model, node, clip, time, age, light);
            } catch (RuntimeException e) {
                if (FAILED.add(entry.pet())) LOGGER.error("Failed to render cosmetic pet {}; disabled for this client session", entry.pet(), e);
            } finally { poses.popPose(); }
        }
        for (var type : used) buffers.endBatch(type);
        FOLLOW.keySet().retainAll(visible);
    }
    private static void node(PoseStack poses, MultiBufferSource buffers, Set<RenderType> used, CubeeModel model,
                             CubeeModel.Node node, CubeeModel.Clip clip, double time, double age, int light) {
        node(poses,buffers,used,model,node,clip,time,age,light,List.of());
    }
    public record ModelLayer(CubeeModel.Clip clip,double time,double weight) {}
    private static PetAnimation.Vec sample(CubeeModel.Clip clip,double time,List<ModelLayer> layers,String id,String channel) {
        var value=clip.sample(id,channel,time);
        for (var layer:layers) {
            if (!layer.clip.tracks().getOrDefault(id,Map.of()).containsKey(channel)) continue;
            var target=layer.clip.sample(id,channel,layer.time);double weight=Math.clamp(layer.weight,0,1);
            value=new PetAnimation.Vec(value.x()+(target.x()-value.x())*weight,value.y()+(target.y()-value.y())*weight,value.z()+(target.z()-value.z())*weight);
        }
        return value;
    }
    private static void node(PoseStack poses,MultiBufferSource buffers,Set<RenderType> used,CubeeModel model,
                             CubeeModel.Node node,CubeeModel.Clip clip,double time,double age,int light,List<ModelLayer> layers) {
        var move = BlockbenchPose.position(sample(clip,time,layers,node.id(),"position"));
        var rotation = BlockbenchPose.rotation(node.rotation(),sample(clip,time,layers,node.id(),"rotation"));
        var scale = sample(clip,time,layers,node.id(),"scale");
        if (Math.abs(scale.x()) < 1e-7 || Math.abs(scale.y()) < 1e-7 || Math.abs(scale.z()) < 1e-7) return;
        poses.pushPose();
        poses.translate(move.x(), move.y(), move.z());
        pivot(poses, node.origin(), rotation, scale);
        for (var cube : node.cubes()) {
            poses.pushPose(); pivot(poses, cube.origin(), cube.rotation(), Vec.ONE);
            double f = cube.inflate(); double x0=cube.from().x()-f, y0=cube.from().y()-f, z0=cube.from().z()-f;
            double x1=cube.to().x()+f, y1=cube.to().y()+f, z1=cube.to().z()+f;
            for (var entry : cube.faces().entrySet()) {
                Vec[] vertices = BlockbenchPose.face(entry.getKey(),new Vec(x0,y0,z0),new Vec(x1,y1,z1));
                float nx=0,ny=0,nz=0;
                switch (entry.getKey()) {
                    case "north" -> nz=-1;
                    case "south" -> nz=1;
                    case "east" -> nx=1;
                    case "west" -> nx=-1;
                    case "up" -> ny=1;
                    case "down" -> ny=-1;
                    default -> throw new IllegalArgumentException("Unknown model face");
                }
                var face = entry.getValue(); var texture = model.textures().get(face.texture());
                draw(poses, buffers, used, face, texture, vertices, nx, ny, nz, age, light, false);
                if (texture.emissive() >= 0) draw(poses, buffers, used, face, model.textures().get(texture.emissive()), vertices, nx, ny, nz, age, LightTexture.FULL_BRIGHT, true);
            }
            poses.popPose();
        }
        for (var child : node.children()) node(poses, buffers, used, model, child, clip, time, age, light,layers);
        poses.popPose();
    }
    /** Shared Blockbench geometry renderer; caller owns position, scale and buffer flushing. */
    public static void renderModel(PoseStack poses, MultiBufferSource buffers, CubeeModel model,
                                   String animation, double time, double age, int light) {
        renderModel(poses,buffers,model,animation,time,age,light,List.of());
    }
    public static void renderModel(PoseStack poses,MultiBufferSource buffers,CubeeModel model,
                                   String animation,double time,double age,int light,List<ModelLayer> layers) {
        var clip = model.animations().getOrDefault(animation, model.animations().get("idle"));
        Set<RenderType> used = new HashSet<>();
        for (var node : model.nodes()) node(poses, buffers, used, model, node, clip, time % clip.length(), age, light,layers);
    }
    private static void pivot(PoseStack poses, Vec origin, Vec rotation, Vec scale) {
        poses.translate(origin.x(), origin.y(), origin.z());
        poses.mulPose(Axis.ZP.rotationDegrees((float)rotation.z())); poses.mulPose(Axis.YP.rotationDegrees((float)rotation.y())); poses.mulPose(Axis.XP.rotationDegrees((float)rotation.x()));
        poses.scale((float)scale.x(), (float)scale.y(), (float)scale.z());
        poses.translate(-origin.x(), -origin.y(), -origin.z());
    }
    private static void draw(PoseStack poses, MultiBufferSource buffers, Set<RenderType> used, CubeeModel.Face face, CubeeModel.Texture texture,
                             Vec[] vertices, float nx, float ny, float nz, double age, int light, boolean glow) {
        ResourceLocation location = ResourceLocation.parse(texture.path());
        RenderType type = glow ? RenderType.eyes(location) : RenderType.entityTranslucent(location);
        used.add(type); VertexConsumer consumer = buffers.getBuffer(type);
        int frame = (int)(age / texture.frameTime()) % texture.frames();
        double[][] corners = BlockbenchPose.uv(face.uv(),face.rotation());
        for (int i=0;i<4;i++) {
            var point = vertices[i]; var tex = corners[i];
            consumer.addVertex(poses.last(), (float)point.x(), (float)point.y(), (float)point.z())
                    .setColor(255,255,255,255).setUv((float)(tex[0]/texture.uvWidth()), (float)((tex[1]+frame*texture.uvHeight())/texture.height()))
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(poses.last(), nx,ny,nz);
        }
    }
    private VipPetRenderer() {}
}
/*?}*/
