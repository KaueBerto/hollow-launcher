package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import java.util.List;

public final class HorseWhistleItem extends Item {
    public HorseWhistleItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer)
            AveronSyncQuestHorses.whistle(serverPlayer, stack);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
    @Override public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack, context, lines, flag);
        lines.add(Component.literal("Use para chamar e montar seu cavalo."));
        lines.add(Component.literal("Ctrl: correr. Shift parado: sair."));
        lines.add(Component.literal("Recompensa de missão. Vinculado ao dono."));
    }
}
/*?}*/
