package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import pl.skidam.automodpack.modpack.*;
import pl.skidam.automodpack_core.mounts.HorseControls;

public final class HorseKeys {
    private static java.util.UUID lastMount;
    public static void update(MovementInputUpdateEvent event) {
        Minecraft mc=Minecraft.getInstance();
        if (event.getEntity()!=mc.player) return;
        if (!(event.getEntity().getVehicle() instanceof QuestHorseEntity horse)) { lastMount=null;return; }
        if (!horse.getUUID().equals(lastMount)) {
            lastMount=horse.getUUID();
            // Vanilla action bar expires/fades after 60 ticks. Never refresh per tick.
            mc.player.displayClientMessage(net.minecraft.network.chat.Component.literal("Ctrl: correr • Shift parado: sair"),true);
        }
        var options=mc.options;
        boolean enabled=mc.screen==null;
        var input=enabled ? new HorseControls.Input((options.keyUp.isDown()?1:0)-(options.keyDown.isDown()?1:0),
                (options.keyLeft.isDown()?1:0)-(options.keyRight.isDown()?1:0),options.keyJump.isDown(),options.keyShift.isDown(),options.keySprint.isDown()) : HorseControls.Input.NONE;
        PacketDistributor.sendToServer(new HorseInputPayload(horse.getId(),input));
        // Vanilla shift dismount/charged horse jumping are replaced by the pack's
        // meta-controller. The camera remains free; A/D steers the mount.
        event.getInput().shiftKeyDown=false;
        event.getInput().jumping=false;
    }
    private HorseKeys() {}
}
/*?}*/
