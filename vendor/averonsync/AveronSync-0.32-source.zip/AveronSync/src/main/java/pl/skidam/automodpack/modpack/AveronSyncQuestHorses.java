package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.server.*;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import pl.skidam.automodpack_core.mounts.QuestHorseRegistry;
import pl.skidam.automodpack_core.mounts.HorseBond;
import java.io.IOException;
import java.util.*;
import static net.minecraft.commands.Commands.*;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

public final class AveronSyncQuestHorses {
    private static final String BOND_TICKS = "averonsync_horse_bond_ticks";
    private static final Map<MinecraftServer, State> SERVERS = new IdentityHashMap<>();
    private static final class State {
        final UUID session = UUID.randomUUID();
        final Map<UUID, QuestHorseEntity> active = new HashMap<>();
        final Map<UUID,Long> menuQueries=new HashMap<>(),menuActions=new HashMap<>();
        QuestHorseRegistry registry;
        State(MinecraftServer server) {
            try { registry = new QuestHorseRegistry(server.getWorldPath(LevelResource.ROOT).resolve("data/averonsync-quest-horses.json")); }
            catch (IOException e) { LOGGER.error("Quest horses disabled: cannot read unlock registry", e); }
        }
    }
    private static State state(MinecraftServer server) { return SERVERS.computeIfAbsent(server, State::new); }
    static boolean authenticated(ServerPlayer player) {
        try { return AveronSyncVipKitCommand.authenticated(player); }
        catch (ReflectiveOperationException | RuntimeException e) { return false; }
    }
    static int bondTicks(Player player) {
        return Math.clamp(player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG).getInt(BOND_TICKS),
                0, HorseBond.TRUSTED);
    }
    static void recordBondTravel(ServerPlayer player) {
        int before=bondTicks(player);
        if (before>=HorseBond.TRUSTED) return;
        var persisted=player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        int after=before+1;
        persisted.putInt(BOND_TICKS,after);
        player.getPersistentData().put(Player.PERSISTED_NBT_TAG,persisted);
        int level=HorseBond.level(after);
        if (level!=HorseBond.level(before)) player.displayClientMessage(
                Component.literal("Vínculo "+level+"/3 • +"+((level-1)*10)+"% em estradas"),true);
    }
    private static String bondStatus(Player player) {
        int ticks=bondTicks(player);
        int level=HorseBond.level(ticks);
        if (level==3) return "Vínculo 3/3 (+20% em estradas)";
        int start=level==1?0:HorseBond.COMPANION;
        int percent=100*(ticks-start)/(HorseBond.nextThreshold(ticks)-start);
        return "Vínculo "+level+"/3 ("+percent+"% para o próximo)";
    }
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("async").then(literal("cavalo").requires(s -> s.hasPermission(2))
                .then(literal("recompensar").then(argument("jogador", EntityArgument.player()).executes(c ->
                        reward(c.getSource(), EntityArgument.getPlayer(c, "jogador"), false))))));
        dispatcher.register(literal("cavalo").then(literal("apito").executes(c ->
                reward(c.getSource(), c.getSource().getPlayerOrException(), true))));
    }
    private static int fail(CommandSourceStack source, String message) {
        if(source.getEntity() instanceof ServerPlayer player)player.displayClientMessage(Component.literal(message),true);
        else source.sendFailure(Component.literal("[AveronSync] " + message));
        return 0;
    }
    private static void feedback(CommandSourceStack source,String message) {
        if(source.getEntity() instanceof ServerPlayer player)player.displayClientMessage(Component.literal(message),true);
        else source.sendSuccess(()->Component.literal("[AveronSync] "+message),false);
    }
    private static int reward(CommandSourceStack source, ServerPlayer player, boolean reissue) {
        if (!authenticated(player)) return fail(source, "O jogador precisa concluir o login primeiro.");
        State state = state(player.server);
        if (state.registry == null) return fail(source, "Cadastro de cavalos indisponível. Avise a administração.");
        UUID token = state.registry.token(player.getUUID());
        if (state.active.containsKey(player.getUUID())) {
            feedback(source,"Apito em uso.");return 1;
        }
        if (reissue && token == null) return fail(source, "Conclua a missão para receber seu primeiro apito.");
        if (token != null) {
            for (int i = 0; i < player.getInventory().getContainerSize(); i++)
                if (validWhistle(player.getInventory().getItem(i), player.getUUID(), state.registry)) {
                    feedback(source,"Apito já recebido.");return 1;
                }
        }
        int slot = player.getInventory().getFreeSlot();
        if (slot < 0) return fail(source, "Libere um espaço no inventário e tente novamente.");
        try {
            token = state.registry.unlock(player.getUUID());
            ItemStack whistle = new ItemStack(AveronSyncHorseContent.WHISTLE.get());
            CompoundTag tag = new CompoundTag(); tag.putUUID("Owner", player.getUUID()); tag.putUUID("Token", token);
            whistle.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
            player.getInventory().setItem(slot, whistle);
            player.inventoryMenu.broadcastChanges();
            feedback(source,"Apito entregue a "+player.getGameProfile().getName()+".");
            return 1;
        } catch (IOException e) { LOGGER.error("Could not unlock quest horse for {}", player.getUUID(), e); return fail(source, "Não foi possível salvar a recompensa. Nenhum apito entregue."); }
    }
    private static boolean validWhistle(ItemStack stack, UUID owner, QuestHorseRegistry registry) {
        if (!stack.is(AveronSyncHorseContent.WHISTLE.get())) return false;
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        return tag.hasUUID("Owner") && tag.hasUUID("Token") && owner.equals(tag.getUUID("Owner")) && registry.owns(owner, tag.getUUID("Token"));
    }
    private static ItemStack inventoryWhistle(ServerPlayer player,QuestHorseRegistry registry) {
        for(int i=0;i<player.getInventory().getContainerSize();i++) {
            ItemStack stack=player.getInventory().getItem(i);
            if(validWhistle(stack,player.getUUID(),registry))return stack;
        }
        return ItemStack.EMPTY;
    }
    private static boolean storable(ServerPlayer player,QuestHorseEntity horse) {
        return horse!=null && !horse.isRemoved() && horse.isAlive() && !horse.isApproaching() && horse.level()==player.level()
                && horse.distanceToSqr(player)<=64*64 && horse.onGround() && horse.getDeltaMovement().horizontalDistanceSqr()<.0025
                && (!horse.isVehicle() || horse.getFirstPassenger()==player);
    }
    public static MountMenuState menuState(ServerPlayer player,int screenId) {
        if(!authenticated(player))return new MountMenuState(screenId,false,false,false,false,false,false,"Faça login para usar suas montarias.");
        State state=state(player.server);
        long petUntil=AveronSyncVipPets.menuEntitlement(player);
        String selectedPet=AveronSyncVipPets.menuSelection(player);
        if(state.registry==null)return new MountMenuState(screenId,true,false,false,false,false,false,"Montarias indisponíveis.",petUntil,selectedPet);
        boolean unlocked=state.registry.token(player.getUUID())!=null;
        QuestHorseEntity horse=state.active.get(player.getUUID());
        boolean active=horse!=null && !horse.isRemoved() && horse.isAlive();
        boolean whistle=unlocked && !inventoryWhistle(player,state.registry).isEmpty();
        String message=!unlocked?"Conclua a missão para desbloquear.":active?"Montaria em uso.":whistle?"Pronto para chamar.":"Recupere seu apito para chamar.";
        if (unlocked) message=bondStatus(player);
        return new MountMenuState(screenId,true,unlocked,whistle,active,active&&storable(player,horse),false,message,petUntil,selectedPet);
    }
    public static MountMenuState menuAction(ServerPlayer player,MountMenuRequest request) {
        if(!authenticated(player) || !player.isAlive() || player.isSpectator())return new MountMenuState(request.screenId(),false,false,false,false,false,false,"Montarias indisponíveis agora.");
        State state=state(player.server);
        var limits=request.action()==MountMenuRequest.QUERY?state.menuQueries:state.menuActions;
        long now=player.server.overworld().getGameTime();
        if(now-limits.getOrDefault(player.getUUID(),-1000L)<(request.action()==MountMenuRequest.QUERY?5:10))return null;
        limits.put(player.getUUID(),now);
        boolean close=false;
        if(state.registry!=null && state.registry.token(player.getUUID())!=null) {
            if(request.action()==MountMenuRequest.SELECT) {
                var persisted=player.getPersistentData().getCompound(net.minecraft.world.entity.player.Player.PERSISTED_NBT_TAG);
                persisted.putString("averonsync_selected_mount","horse_bay");
                player.getPersistentData().put(net.minecraft.world.entity.player.Player.PERSISTED_NBT_TAG,persisted);
                close=true;
            } else if(request.action()==MountMenuRequest.SUMMON) {
                QuestHorseEntity previous=state.active.get(player.getUUID());
                ItemStack stack=inventoryWhistle(player,state.registry);
                if(!stack.isEmpty())whistle(player,stack);
                close=state.active.get(player.getUUID())!=previous;
            } else if(request.action()==MountMenuRequest.STORE) {
                QuestHorseEntity horse=state.active.get(player.getUUID());
                if(storable(player,horse)) {dismiss(state,player.getUUID(),player);close=true;}
                else player.displayClientMessage(Component.literal("Pare no chão para guardar."),true);
            } else if(request.action()==MountMenuRequest.RECOVER) reward(player.createCommandSourceStack(),player,true);
        }
        var result=menuState(player,request.screenId());
        return new MountMenuState(result.screenId(),result.enabled(),result.unlocked(),result.whistle(),result.active(),result.canStore(),close,result.message(),result.petUntil(),result.selectedPet());
    }
    public static void whistle(ServerPlayer player, ItemStack stack) {
        if (!authenticated(player) || !player.isAlive() || player.isSpectator()) return;
        State state = state(player.server);
        if (state.registry == null || !validWhistle(stack, player.getUUID(), state.registry)) {
            player.displayClientMessage(Component.literal("Este apito pertence a outro jogador."),true); return;
        }
        if (player.getCooldowns().isOnCooldown(stack.getItem())) return;
        player.getCooldowns().addCooldown(stack.getItem(), 30);
        QuestHorseEntity current = state.active.get(player.getUUID());
        if (current != null && !current.isRemoved()) {
            player.displayClientMessage(Component.literal("Você já tem um cavalo ativo."),true); return;
        }
        if (player.isPassenger() || player.isFallFlying()) {
            player.displayClientMessage(Component.literal("Desmonte e fique no chão."),true); return;
        }
        QuestHorseEntity horse = AveronSyncHorseContent.HORSE.get().create(player.serverLevel());
        if (horse == null) return;
        horse.setOwnerUUID(player.getUUID()); horse.setTamed(true); horse.session(state.session);
        horse.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.20);
        horse.getAttribute(Attributes.JUMP_STRENGTH).setBaseValue(0.50);
        horse.equipSaddle(new ItemStack(net.minecraft.world.item.Items.SADDLE), null);
        if (!place(player, horse)) {
            player.displayClientMessage(Component.literal("Sem espaço para o cavalo."),true); return;
        }
        state.active.put(player.getUUID(), horse);
        if (!player.serverLevel().addFreshEntity(horse)) { state.active.remove(player.getUUID()); horse.discard(); return; }
        horse.storeWhistle(stack.copyWithCount(1));
        stack.shrink(1);
        player.inventoryMenu.broadcastChanges();
        horse.beginApproach();
        whistleSound(player);
        horse.playSound(AveronSyncHorseSound.NEIGH.get(),1F,.9F+horse.getRandom().nextFloat()*.3F);
    }
    private static void whistleSound(ServerPlayer player) {
        player.serverLevel().playSound(null, player.blockPosition(), AveronSyncHorseSound.WHISTLE.get(), SoundSource.PLAYERS, 1F, 1F+player.getRandom().nextFloat()*.2F);
    }
    private static boolean place(ServerPlayer player, QuestHorseEntity horse) {
        ServerLevel level = player.serverLevel(); BlockPos origin = player.blockPosition();
        for (int radius : new int[]{6, 8, 4, 3}) for (int i = 0; i < 8; i++) for (int dy : new int[]{0, 1, -1, 2, -2}) {
            double angle = Math.toRadians(player.getYRot() + 90) + i * Math.PI / 4;
            BlockPos pos = origin.offset((int)Math.round(Math.cos(angle)*radius), dy, (int)Math.round(Math.sin(angle)*radius));
            // Never generate/load chunks for a summon or put the rider in a wall/fluid.
            if (!level.hasChunkAt(pos) || !level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) continue;
            double x=pos.getX()+.5, z=pos.getZ()+.5;
            float yaw=(float)Math.toDegrees(Math.atan2(x-player.getX(),player.getZ()-z));
            horse.moveTo(x, pos.getY(), z, yaw, 0);
            var box = horse.getBoundingBox().expandTowards(0, .8, 0).inflate(.1, 0, .1);
            if (!level.hasChunkAt(BlockPos.containing(box.minX, box.minY, box.minZ))
                    || !level.hasChunkAt(BlockPos.containing(box.maxX, box.minY, box.maxZ))) continue;
            if (!level.getWorldBorder().isWithinBounds(box) || level.containsAnyLiquid(box) || !level.noCollision(horse, box)) continue;
            if (!level.getEntities(horse, box).isEmpty()) continue;
            return true;
        }
        return false;
    }
    @SubscribeEvent public static void joining(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide || !(event.getEntity() instanceof QuestHorseEntity horse)) return;
        State state = state(((ServerLevel)event.getLevel()).getServer());
        QuestHorseEntity expected = state.active.get(horse.getOwnerUUID());
        if (!state.session.equals(horse.session()) || expected == null || !expected.getUUID().equals(horse.getUUID())) event.setCanceled(true);
    }
    @SubscribeEvent public static void interacting(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof QuestHorseEntity horse)) return;
        // Bypass vanilla item interactions (name tags, horse armor, leads, feeding)
        // so every interaction follows the same owner-only mount policy.
        event.setCancellationResult(horse.mobInteract(event.getEntity(), event.getHand()));
        event.setCanceled(true);
    }
    public static void dismissOwned(ServerPlayer player, QuestHorseEntity horse) {
        State state=state(player.server);
        if (state.active.get(player.getUUID())==horse) dismiss(state,player.getUUID(),player);
    }
    static void horseDied(QuestHorseEntity horse) {
        ServerLevel level=(ServerLevel)horse.level();
        State state=SERVERS.get(level.getServer());
        if (state==null || !state.active.remove(horse.getOwnerUUID(),horse)) return;
        horse.takeWhistle();
        ServerPlayer owner=level.getServer().getPlayerList().getPlayer(horse.getOwnerUUID());
        if (owner!=null) owner.displayClientMessage(Component.literal("Seu cavalo morreu. Novo apito: /cavalo apito"),true);
    }
    private static void dismiss(State state, UUID owner, ServerPlayer player) {
        QuestHorseEntity horse = state.active.remove(owner);
        if (horse != null) {
            ItemStack whistle=horse.takeWhistle();
            if (player!=null && !whistle.isEmpty()) {
                if (!player.getInventory().add(whistle)) player.drop(whistle,false);
                player.inventoryMenu.broadcastChanges();
            }
            if (!horse.isRemoved()) {
                ((ServerLevel)horse.level()).sendParticles(net.minecraft.core.particles.ParticleTypes.POOF,horse.getX(),horse.getY()+1,horse.getZ(),50,1,1,1,.03);
                horse.ejectPassengers(); horse.discard();
            }
        }
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            State state = SERVERS.get(player.server); if (state != null) {
                dismiss(state, player.getUUID(),player);state.menuQueries.remove(player.getUUID());state.menuActions.remove(player.getUUID());
            }
        }
    }
    @SubscribeEvent public static void tick(ServerTickEvent.Post event) {
        State state = SERVERS.get(event.getServer());
        if (state == null || event.getServer().getTickCount() % 20 != 0) return;
        for (UUID owner : List.copyOf(state.active.keySet())) {
            var player = event.getServer().getPlayerList().getPlayer(owner);
            var horse = state.active.get(owner);
            if (player == null || !player.isAlive() || player.isSpectator() || !authenticated(player)
                    || horse.isRemoved() || !horse.isAlive() || horse.level() != player.level() || horse.distanceToSqr(player) > 64*64)
                dismiss(state, owner,player);
        }
    }
    @SubscribeEvent public static void stopping(ServerStoppingEvent event) {
        State state = SERVERS.get(event.getServer());
        if (state != null) for (UUID owner : List.copyOf(state.active.keySet())) dismiss(state, owner,event.getServer().getPlayerList().getPlayer(owner));
    }
    @SubscribeEvent public static void stopped(ServerStoppedEvent event) { SERVERS.remove(event.getServer()); }
    private AveronSyncQuestHorses() {}
}
/*?}*/
