"""Import only the basic bay horse from the owner's LittleRoom RAR.

Plugin scripts are read as data only and never executed. MythicMobs timeline
commands and ModelEngine metadata bones are omitted; native horse code controls
movement and sounds. Proprietary generated artwork stays outside Git.
"""
from pathlib import Path
import argparse, base64, hashlib, json, struct, subprocess
from import_cubees import vector

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'src/main/resources/assets/averonsync'
MODEL = 'plugins/ModelEngine/blueprints/littleroom/horse_pack/lrd_horse_bay.bbmodel'

def run(archive):
    def read(name):
        data = subprocess.check_output(['tar', '-xOf', str(archive), name])
        if len(data) > 4_000_000: raise ValueError('Oversized asset')
        return data
    source = read(MODEL)
    raw = json.loads(source)
    textures = []
    for i, texture in enumerate(raw['textures']):
        if not texture['source'].startswith('data:image/png;base64,'): raise ValueError('External texture rejected')
        data = base64.b64decode(texture['source'].split(',', 1)[1], validate=True)
        if data[:8] != b'\x89PNG\r\n\x1a\n': raise ValueError('Invalid PNG')
        width, height = struct.unpack('>II', data[16:24])
        if not 0 < width <= 2048 or not 0 < height <= 2048: raise ValueError('Oversized texture')
        path = f'textures/mounts/horse_bay/{i}.png'
        destination = OUT / path; destination.parent.mkdir(parents=True, exist_ok=True); destination.write_bytes(data)
        textures.append(dict(path='averonsync:'+path, width=width, height=height,
            uvWidth=texture['uv_width'], uvHeight=texture['uv_height'], frameTime=1, frames=1, emissive=-1))
    cubes = {}
    for cube in raw['elements']:
        if cube.get('type','cube') != 'cube': raise ValueError('Unsupported mesh')
        faces = {}
        for direction, face in cube.get('faces',{}).items():
            t = face.get('texture')
            if t is None: continue
            if not isinstance(t,int) or not 0 <= t < len(textures): raise ValueError('Invalid texture')
            faces[direction] = dict(texture=t, uv=face['uv'], rotation=face.get('rotation',0))
        cubes[cube['uuid']] = dict(from_=vector(cube['from'],[0,0,0]), to=vector(cube['to'],[0,0,0]),
            origin=vector(cube.get('origin'),[0,0,0]), rotation=vector(cube.get('rotation'),[0,0,0]),
            inflate=cube.get('inflate',0), faces=faces)
    used = set()
    def node(value):
        if isinstance(value,str):
            used.add(value)
            return dict(id=value,origin=[0,0,0],rotation=[0,0,0],cubes=[cubes[value]],children=[])
        children = [node(c) for c in value.get('children',[]) if not isinstance(c,dict) or
                    (c.get('export',True) and c.get('name') not in ['hitbox','p_seat'])]
        return dict(id=value['uuid'],origin=vector(value.get('origin'),[0,0,0]),
            rotation=vector(value.get('rotation'),[0,0,0]),cubes=[],children=children)
    nodes = [node(n) for n in raw['outliner'] if not isinstance(n,dict) or n.get('name') != 'hitbox']
    animations = {}; omitted_effects = 0; duplicate_keys = 0
    for animation in raw.get('animations',[]):
        tracks = {}
        for ident, animator in animation.get('animators',{}).items():
            if animator.get('type') != 'bone':
                omitted_effects += len(animator.get('keyframes',[])); continue
            channels = {}
            for key in animator.get('keyframes',[]):
                channel = key['channel']; interpolation = key.get('interpolation','linear')
                if channel not in ['position','rotation','scale'] or interpolation not in ['linear','step','catmullrom']:
                    raise ValueError('Unsupported keyframe')
                if len(key['data_points']) != 1: raise ValueError('Unsupported datapoints')
                point = key['data_points'][0]
                channels.setdefault(channel,[]).append(dict(time=float(key['time']),
                    value=vector([point.get(k,1 if channel=='scale' else 0) for k in ['x','y','z']],[0,0,0]),interpolation=interpolation))
            tracks[ident] = {}
            for channel, keys in channels.items():
                # Two swim tracks contain conflicting time=0 keys in the original.
                # Preserve the last authored value at each time, deterministically.
                unique = {frame['time']:frame for frame in keys}
                duplicate_keys += len(keys)-len(unique)
                tracks[ident][channel] = sorted(unique.values(),key=lambda f:f['time'])
        animations[animation['name']] = dict(length=float(animation['length']),tracks=tracks)
    seat = None; seat_chain = []
    def locator(value, chain):
        nonlocal seat, seat_chain
        if not isinstance(value,dict): return
        if value['name']=='p_seat': seat=vector(value['origin'],[0,0,0]);seat_chain=chain;return
        for child in value.get('children',[]): locator(child,chain+[value['uuid']])
    for value in raw['outliner']: locator(value,[])
    if seat is None: raise ValueError('Missing original rider seat')
    result = dict(id='horse_bay',textures=textures,nodes=nodes,animations=animations,seat=seat,seatChain=seat_chain)
    path = OUT / 'mounts/horse_bay.json';path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(result,separators=(',',':')),encoding='utf-8')
    # The pack embeds shared item textures in the Appaloosa blueprint, including
    # the whistle; the bay blueprint alone does not contain them.
    shared = json.loads(read(MODEL.replace('lrd_horse_bay.bbmodel','lrd_horse_appaloosa.bbmodel')))
    whistle_texture = next(t for t in shared['textures'] if t['name'] == 'horse_whistle.png')
    texture_data = base64.b64decode(whistle_texture['source'].split(',',1)[1],validate=True)
    if not texture_data.startswith(b'\x89PNG\r\n\x1a\n'): raise ValueError('Invalid whistle PNG')
    # Item models use the block/item atlas. Unlike the direct entity renderer,
    # that atlas does not discover arbitrary textures/mounts/ directories.
    path=OUT/'textures/item/horse_whistle.png';path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(texture_data)
    whistle_model=json.loads(read('resourcepack/assets/littleroom_horsepack/models/horse_whistle.json'))
    whistle_model['textures']={k:'averonsync:item/horse_whistle' for k in whistle_model['textures']}
    path=OUT/'models/item/horse_whistle.json';path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(whistle_model,separators=(',',':')),encoding='utf-8')
    sounds = [f'whistle_{i}' for i in range(1,4)] + [f'horse_step_{i}' for i in range(1,7)] + [f'horse_neigh_{i}' for i in range(1,5)] + [f'horse_snort_{i}' for i in range(1,4)] + ['horse_skid']
    for name in sounds:
        path = OUT / f'sounds/mounts/{name}.ogg';path.parent.mkdir(parents=True,exist_ok=True)
        data = read(f'resourcepack/assets/littleroom_horsepack/sounds/{name}.ogg')
        if not data.startswith(b'OggS'): raise ValueError('Invalid OGG')
        path.write_bytes(data)
    report = dict(source=archive.name, modelSha256=hashlib.sha256(source).hexdigest(),
        horse='horse_bay',renderedCubes=len(used),textures=len(textures),animations=list(animations),
        omittedPluginTimelineKeys=omitted_effects, duplicateKeysResolvedLastWins=duplicate_keys, omittedMetadataBones=['hitbox','p_seat'],
        itemAppearance='Original 3D horse_whistle.json and horse_whistle.png embedded in Appaloosa blueprint',
        whistleTextureSha256=hashlib.sha256(texture_data).hexdigest(),sounds=sounds)
    (OUT/'mounts/import-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('archive',type=Path)
    run(parser.parse_args().archive)
