# Teste em servidor — AveronSync 0.4

Em 26/10/2026, o artefato `4.0.6-averonsync.0.4` foi instalado em um servidor
Minecraft 1.21.1 com NeoForge 21.1.253, com backup prévio do mundo, mods,
configurações e dados do AutoModpack anterior.

Resultados confirmados:

- O servidor carregou AveronSync 0.4 e concluiu a inicialização.
- O serviço de sincronização respondeu na porta do Minecraft.
- A conexão TLS 1.3 foi estabelecida com o certificado anterior preservado.
- Todos os 1.268 arquivos publicados tiveram SHA-256 conferido.
- Não houve arquivos adicionais publicados nem alteração dos hashes dos
  arquivos mantidos em comparação com o pack anterior.
- Os demais mods e os valores das propriedades do servidor foram preservados.
- O cliente foi reconhecido e recebeu o endereço do modpack.
- Na reconexão, o servidor confirmou o modpack instalado e registrou a entrada.
- O usuário confirmou que entrou sem repetir os termos.

A migração partiu do AutoModpack 5.0.0-rc.2. A configuração da base 4.0.6 foi
preparada a partir do conteúdo publicado; clientes precisam usar o AveronSync
compatível. O protocolo da versão 5 não é equivalente ao do fork.

O manifesto anterior continha 1.272 arquivos. A filtragem da base 4.0.6 omitiu
quatro arquivos vazios; eles permaneceram no servidor. Os 45 arquivos extras
do pack foram mantidos. Novos caminhos de configuração podem precisar ser
adicionados ao mapeamento explícito preparado para essa migração.

Limites: não foi simulada outra alteração de mods após o aceite neste teste.
Os logs ainda continham mensagens de outros mods e um aviso de carregamento
da classe cliente `Screen` no servidor dedicado, cuja origem não foi isolada.
A inicialização e a entrada funcionaram; isso não equivale a uma garantia de
ausência de erros em todas as combinações de mods.
