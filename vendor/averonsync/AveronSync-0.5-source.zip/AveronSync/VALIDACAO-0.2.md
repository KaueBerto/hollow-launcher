# AveronSync 0.2 — termos e aceite único

Data: 26/10/2026. Alvo: Minecraft 1.21.1 / NeoForge 21.1.169.
Versão: `4.0.6-averonsync.0.2`. Base e licença continuam as da versão 0.1.

## Comportamento entregue

- Termos próprios em português brasileiro e inglês, disponíveis em
  `TERMOS-AVERONSYNC.md` e dentro da tela do mod.
- Texto rolável, caixa de aceite e botões Aceitar/Não aceito, sem contagem
  regressiva e sem exigir esperar antes de marcar a caixa.
- Aceite salvo localmente em `automodpack/averonsync-consent.json`.
- Aceite independente de hashes, lista de mods, nome do pack, servidor ou
  versão do AveronSync. A autorização informa que vale para as futuras
  sincronizações dos servidores aos quais o jogador escolher se conectar.
- Atualizações seguintes não abrem novamente os termos nem o antigo aviso
  para cada JAR sem correspondência pública nas plataformas.
- Recusar não registra aceite e não inicia a atualização. Se salvar falhar,
  o erro aparece na tela e a atualização não começa.
- Sem aceite durante a inicialização antecipada, a atualização fica adiada
  até uma conexão interativa. Um pack já instalado usa seu manifesto local.
- Certificados, TLS e verificação SHA-256 permanecem ativos. A confirmação
  excepcional para ignorar a verificação de certificado é um fluxo separado
  e mantém seu temporizador anterior.

Para revogar o aceite, feche o jogo e apague o arquivo de consentimento.
Uma instalação diferente tem seu próprio aceite. Arquivo ausente/corrompido
ou mudança futura da versão dos termos requer um novo aceite; atualizar
mods ou o próprio AveronSync não altera a versão dos termos.

## Verificação

Comando: `./gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --console=plain`.

**42 testes passaram**: 33 no core e 9 no loader-core. Cinco testes novos
cobrem persistência entre instâncias/reinícios, revogação, estados inválidos,
falha de gravação e roteamento da atualização sem repetir a pergunta.
Os testes anteriores de SHA-256 e downloads continuam passando.

O roteamento é testado com uma tela e um início de download substituídos
por contadores, sem baixar mods de servidores reais. A nova interface foi
compilada, mas não foi inspecionada dentro do Minecraft.

O empacotamento também foi corrigido para selecionar os JARs pela versão
atual e regenerar os metadados quando as propriedades mudam. A verificação
do JAR final confere as versões do bootstrap e do mod interno, a classe de
consentimento, os textos nas duas línguas e a ausência do temporizador na
tela de termos. Os JARs da versão anterior foram mantidos na pasta de build
durante essa validação para exercitar a seleção da versão correta.

Ainda falta testar o fluxo completo em cliente/servidor reais e revisar a
aparência da tela nas escalas de interface do Minecraft. Os limites gerais
da primeira entrega continuam registrados em `VALIDACAO.md`.

Artefato: `averonsync-mc1.21.1-neoforge-4.0.6-averonsync.0.2.jar`.
O hash e as evidências desta versão ficam em `../SHA256SUMS-0.2.txt` e
`../evidencias-0.2/` na entrega local.
