plugins {
    id("dev.kikugie.stonecutter")
    kotlin("jvm") version "2.3.0" apply false
    id("net.fabricmc.fabric-loom-remap") version "1.17-SNAPSHOT" apply false
    id("net.fabricmc.fabric-loom") version "1.17-SNAPSHOT" apply false
    id("net.neoforged.moddev") version "2.0.142" apply false
    id("com.gradleup.shadow") version "9.6.1" apply false
    id("org.moddedmc.wiki.toolkit") version "0.4+"
}

wiki {
    docs.create("automodpack") {
        root = file("docs")
    }
}

stonecutter active "1.21.1-neoforge" /* [SC] DO NOT EDIT */

stonecutter.parameters {
    val (version, loader) = current.project.split('-', limit = 2)

    constants.match(loader, "fabric", "neoforge", "forge")
    properties.tags(version, loader)

    replacements {
        string(current.parsed >= "1.20.2") {
            replace("ServerboundCustomQueryPacket", "ServerboundCustomQueryAnswerPacket")
            replace(".SystemToastIds.", ".SystemToastId.")
        }

        regex(current.parsed >= "1.21.11") {
            replace("\\bResourceLocation\\b", "Identifier", "\\bIdentifier\\b", "ResourceLocation")
        }

        string(current.parsed >= "1.21.11") {
            replace("net.minecraft.Util", "net.minecraft.util.Util")
            replace("source.hasPermission(3))", "source.permissions().hasPermission(new Permission.HasCommandLevel(PermissionLevel.byId(3))))")
        }

        string(current.parsed >= "26.2") {
            replace("minecraft.setScreen(", "minecraft.gui.setScreen(")
            replace("minecraft.getToastManager()", "minecraft.gui.toastManager()")
        }
    }
}
