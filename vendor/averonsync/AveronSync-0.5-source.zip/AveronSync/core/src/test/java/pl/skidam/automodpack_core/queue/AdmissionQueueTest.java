package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AdmissionQueueTest {
    private AdmissionQueue queue() { return new AdmissionQueue(100, 1, 5000, 600000, 120000); }

    @Test void admitsFifoAndWaitsForJoinPlusSettlingInterval() {
        var q = queue(); var a = q.enqueue("Alice", 0); var b = q.enqueue("Bob", 0);
        q.advance(0, true);
        assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(a.id()).state());
        assertEquals(1, q.snapshot(b.id()).position());
        q.advance(10000, true);
        assertEquals(AdmissionQueue.State.WAITING, q.snapshot(b.id()).state());
        q.remove(a.id(), 10000);
        q.advance(14999, true);
        assertEquals(AdmissionQueue.State.WAITING, q.snapshot(b.id()).state());
        q.advance(15000, true);
        assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(b.id()).state());
    }

    @Test void disconnectedWaiterDoesNotBlockNextOrConsumeCooldown() {
        var q = queue(); var a = q.enqueue("A", 0); var b = q.enqueue("B", 0); var c = q.enqueue("C", 0);
        q.remove(a.id(), 0); q.advance(0, true);
        assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(b.id()).state());
        assertEquals(1, q.snapshot(c.id()).position());
    }

    @Test void activeDisconnectReleasesPermitAfterCooldown() {
        var q = queue(); var a = q.enqueue("A", 0); var b = q.enqueue("B", 0);
        q.advance(0, true); q.remove(a.id(), 1000); q.advance(5999, true);
        assertEquals(AdmissionQueue.State.WAITING, q.snapshot(b.id()).state());
        q.advance(6000, true); assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(b.id()).state());
    }

    @Test void duplicateNamesCannotCreateMorePositionsIncludingWhileActive() {
        var q = queue(); var a = q.enqueue("Alice", 0);
        assertEquals(AdmissionQueue.Rejection.DUPLICATE, q.rejection("ALICE"));
        q.advance(0, true);
        assertThrows(IllegalStateException.class, () -> q.enqueue("alice", 0));
        q.remove(a.id(), 1000); assertNull(q.rejection("alice"));
    }

    @Test void capacityIncludesAdmittedConnectionsAndCannotBeBypassedByRetry() {
        var q = new AdmissionQueue(2, 1, 5000, 600000, 120000);
        q.enqueue("A", 0); q.advance(0, true); q.enqueue("B", 0);
        assertEquals(AdmissionQueue.Rejection.FULL, q.rejection("C"));
        assertThrows(IllegalStateException.class, () -> q.enqueue("C", 0));
    }

    @Test void fullServerRetainsPositionUntilThereIsRoom() {
        var q = queue(); var a = q.enqueue("A", 0);
        q.advance(0, false); q.advance(9999, false);
        assertEquals(1, q.snapshot(a.id()).position());
        q.advance(10000, true); assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(a.id()).state());
    }

    @Test void stalledAdmissionExpiresAndDoesNotDeadlockFollowers() {
        var q = queue(); var a = q.enqueue("A", 0); var b = q.enqueue("B", 0);
        q.advance(0, true); var expired = q.advance(120000, true);
        assertEquals(a.id(), expired.get(0).id());
        assertEquals(AdmissionQueue.State.GONE, q.snapshot(a.id()).state());
        q.advance(125000, true); assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(b.id()).state());
    }

    @Test void waitingTimeoutRemovesEveryExpiredEntry() {
        var q = queue(); var a = q.enqueue("A", 0); q.enqueue("B", 0);
        assertEquals(2, q.advance(600000, false).size());
        assertEquals(AdmissionQueue.State.GONE, q.snapshot(a.id()).state()); assertNull(q.rejection("A"));
    }

    @Test void configurableParallelismStillSpacesAdmissions() {
        var q = new AdmissionQueue(10, 2, 5000, 600000, 120000);
        var a = q.enqueue("A", 0); var b = q.enqueue("B", 0); var c = q.enqueue("C", 0);
        q.advance(0, true); q.advance(4999, true); assertEquals(1, q.activeCount());
        q.advance(5000, true); assertEquals(2, q.activeCount());
        assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(a.id()).state());
        assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(b.id()).state());
        q.advance(10000, true); assertEquals(1, q.snapshot(c.id()).position());
    }

    @Test void largeBurstPreservesOrderAndAllPlayersEventuallyAdvance() {
        var q = queue(); var tickets = new java.util.ArrayList<AdmissionQueue.Ticket>();
        for (int i = 0; i < 100; i++) tickets.add(q.enqueue("Player" + i, 0));
        long now = 0;
        for (var ticket : tickets) {
            q.advance(now, true); assertEquals(AdmissionQueue.State.ACTIVE, q.snapshot(ticket.id()).state());
            assertEquals(1, q.activeCount()); q.remove(ticket.id(), now); now += 5000;
        }
        assertEquals(0, q.activeCount());
    }

    @Test void rateLimitResetsAndSharesAllowanceForSameAddress() {
        var limiter = new AttemptLimiter();
        for (int i = 0; i < 10; i++) assertTrue(limiter.allow("address", i));
        assertFalse(limiter.allow("address", 100)); assertTrue(limiter.allow("another", 100));
        assertTrue(limiter.allow("address", 60000));
    }

    @Test void settingsClampUnsafeValuesAndOldConfigGetsDefaults() {
        var config = new com.google.gson.Gson().fromJson("{}", pl.skidam.automodpack_core.config.Jsons.ServerConfigFieldsV2.class);
        assertTrue(config.entryQueue.enabled); assertEquals(5, config.entryQueue.admissionIntervalSeconds);
        var settings = new QueueSettings(); settings.maxQueuedPlayers = -1; settings.maxConcurrentAdmissions = 999;
        settings.admissionIntervalSeconds = -1; settings.maxWaitSeconds = 0;
        assertDoesNotThrow(settings::createQueue);
    }
}
