package pl.skidam.automodpack_core.utils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

/** AveronSync manifest integrity extension. SHA-1 remains the upstream transport key. */
public final class Sha256 {
    private Sha256() { }

    public static String hash(Path file) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream input = Files.newInputStream(file)) {
                byte[] buffer = new byte[65536];
                int read;
                while ((read = input.read(buffer)) != -1) digest.update(buffer, 0, read);
            }
            return HexFormat.of().formatHex(digest.digest());
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("Java must provide SHA-256", impossible);
        }
    }

    /** Only an absent field permits legacy fallback; blank/malformed values fail closed. */
    public static boolean matchesOptional(Path file, String expected) {
        if (expected == null) return true;
        if (!expected.matches("[0-9a-fA-F]{64}")) return false;
        try {
            return hash(file).equalsIgnoreCase(expected);
        } catch (IOException e) {
            return false;
        }
    }
}
