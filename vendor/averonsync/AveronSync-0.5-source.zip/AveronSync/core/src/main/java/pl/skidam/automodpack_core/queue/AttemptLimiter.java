package pl.skidam.automodpack_core.queue;

import java.util.LinkedHashMap;
import java.util.Map;

/** Bounded, per-address fixed-window admission limit. Shared addresses share the allowance. */
public final class AttemptLimiter {
    private record Window(long start, int attempts) {}
    private final Map<String, Window> windows = new LinkedHashMap<>();
    public boolean allow(String address, long now) {
        Window previous = windows.get(address);
        if (previous != null && now - previous.start() < 60_000) {
            if (previous.attempts() >= 10) return false;
            windows.put(address, new Window(previous.start(), previous.attempts() + 1));
            return true;
        }
        windows.remove(address);
        if (windows.size() >= 4096) windows.remove(windows.keySet().iterator().next());
        windows.put(address, new Window(now, 1));
        return true;
    }
}
