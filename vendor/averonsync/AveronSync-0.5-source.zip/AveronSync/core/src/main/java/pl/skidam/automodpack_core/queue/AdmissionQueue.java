package pl.skidam.automodpack_core.queue;

import java.util.*;

/** FIFO admission scheduler. Call from one server thread, using a monotonic clock. */
public final class AdmissionQueue {
    public enum State { WAITING, ACTIVE, GONE }
    public enum Rejection { FULL, DUPLICATE }
    public record Snapshot(State state, int position, int waiting) {}
    public record Ticket(UUID id, String player, long createdAt) {}
    private final LinkedHashMap<UUID, Ticket> waiting = new LinkedHashMap<>();
    private final Map<UUID, Ticket> active = new HashMap<>();
    private final Set<String> players = new HashSet<>();
    private final int capacity, concurrency;
    private final long interval, waitTimeout, admissionTimeout;
    private long nextAdmission = Long.MIN_VALUE;

    public AdmissionQueue(int capacity, int concurrency, long interval, long waitTimeout, long admissionTimeout) {
        if (capacity < 1 || concurrency < 1 || concurrency > capacity || interval < 0 || waitTimeout < 1 || admissionTimeout < 1)
            throw new IllegalArgumentException("Invalid admission queue settings");
        this.capacity = capacity; this.concurrency = concurrency; this.interval = interval;
        this.waitTimeout = waitTimeout; this.admissionTimeout = admissionTimeout;
    }

    public Rejection rejection(String player) {
        if (players.contains(player.toLowerCase(Locale.ROOT))) return Rejection.DUPLICATE;
        return waiting.size() + active.size() >= capacity ? Rejection.FULL : null;
    }

    public Ticket enqueue(String player, long now) {
        Rejection rejection = rejection(player);
        if (rejection != null) throw new IllegalStateException(rejection.name());
        Ticket ticket = new Ticket(UUID.randomUUID(), player.toLowerCase(Locale.ROOT), now);
        waiting.put(ticket.id(), ticket); players.add(ticket.player());
        return ticket;
    }

    /** Returns expired tickets so the integration can disconnect their connections. */
    public List<Ticket> advance(long now, boolean serverHasRoom) {
        List<Ticket> expired = new ArrayList<>();
        waiting.values().stream().filter(t -> now - t.createdAt() >= waitTimeout).forEach(expired::add);
        active.values().stream().filter(t -> now - t.createdAt() >= admissionTimeout).forEach(expired::add);
        expired.forEach(t -> remove(t.id(), now));
        if (serverHasRoom && !waiting.isEmpty() && active.size() < concurrency && now >= nextAdmission) {
            Ticket ticket = waiting.values().iterator().next();
            waiting.remove(ticket.id());
            active.put(ticket.id(), new Ticket(ticket.id(), ticket.player(), now));
            nextAdmission = now + interval;
        }
        return expired;
    }

    /** Also holds a settling interval after an admitted player joins or disconnects. */
    public void remove(UUID id, long now) {
        Ticket ticket = waiting.remove(id);
        Ticket admitted = active.remove(id);
        if (admitted != null) { ticket = admitted; nextAdmission = Math.max(nextAdmission, now + interval); }
        if (ticket != null) players.remove(ticket.player());
    }

    public Snapshot snapshot(UUID id) {
        if (active.containsKey(id)) return new Snapshot(State.ACTIVE, 0, waiting.size());
        int position = 0;
        for (UUID candidate : waiting.keySet()) { position++; if (candidate.equals(id)) return new Snapshot(State.WAITING, position, waiting.size()); }
        return new Snapshot(State.GONE, 0, waiting.size());
    }

    public int activeCount() { return active.size(); }
}
