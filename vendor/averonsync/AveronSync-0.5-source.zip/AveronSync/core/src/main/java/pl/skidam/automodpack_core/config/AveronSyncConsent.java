package pl.skidam.automodpack_core.config;

import java.io.IOException;
import java.nio.file.*;

/** Local installation consent, independent of mod hashes, pack names and mod releases. */
public final class AveronSyncConsent {
    public static final int TERMS_VERSION = 1;
    private final Path file;

    public AveronSyncConsent(Path file) {
        this.file = file.toAbsolutePath();
    }

    public boolean isAccepted() {
        try {
            Acceptance acceptance = ConfigTools.GSON.fromJson(Files.readString(file), Acceptance.class);
            return acceptance != null && acceptance.termsVersion == TERMS_VERSION;
        } catch (IOException | RuntimeException e) {
            return false;
        }
    }

    public synchronized void accept() throws IOException {
        Files.createDirectories(file.getParent());
        Path temporary = Files.createTempFile(file.getParent(), "averonsync-consent-", ".tmp");
        try {
            Files.writeString(temporary, ConfigTools.GSON.toJson(new Acceptance(TERMS_VERSION)));
            try {
                Files.move(temporary, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    private record Acceptance(int termsVersion) { }
}
