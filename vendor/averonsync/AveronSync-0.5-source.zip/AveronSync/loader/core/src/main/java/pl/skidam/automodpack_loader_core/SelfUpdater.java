package pl.skidam.automodpack_loader_core;

import pl.skidam.automodpack_core.config.Jsons;
import pl.skidam.automodpack_core.utils.CustomFileUtils;
import pl.skidam.automodpack_core.loader.LoaderManagerService;
import pl.skidam.automodpack_core.utils.SemanticVersion;
import pl.skidam.automodpack_loader_core.platforms.ModrinthAPI;
import pl.skidam.automodpack_loader_core.screen.ScreenManager;
import pl.skidam.automodpack_loader_core.utils.DownloadManager;
import pl.skidam.automodpack_loader_core.utils.UpdateType;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static pl.skidam.automodpack_core.GlobalVariables.*;

public class SelfUpdater {

    public static final String AUTOMODPACK_ID = "k68glP2e"; // AutoModpack modrinth id

    // Hardcoded floor: 4.0.0 Stable.
    // Logic: 4.0.0-beta1 < 4.0.0 Stable. This prevents downgrading to unsafe betas.
    private static final SemanticVersion MINIMUM_SAFE_VERSION = new SemanticVersion(4, 0, 0, "release", Integer.MAX_VALUE);

    public static boolean update() {
        return update(null);
    }

    public static boolean update(Jsons.ModpackContentFields serverModpackContent) {
        // AveronSync has no release channel yet. Never replace this fork with upstream jars,
        // including when an existing config enables selfUpdater or server version syncing.
        if (AM_VERSION != null && AM_VERSION.contains("-averonsync.")) {
            LOGGER.info("AveronSync: upstream self-updater disabled.");
            return false;
        }
        if (LOADER_MANAGER.isDevelopmentEnvironment()) return false;

        if (LOADER_MANAGER.getEnvironmentType() == LoaderManagerService.EnvironmentType.SERVER && !serverConfig.selfUpdater) {
            LOGGER.info("AutoModpack self-updater is disabled in server config.");
            return false;
        }

        boolean gettingServerVersion = serverModpackContent != null && serverModpackContent.automodpackVersion != null && !serverModpackContent.automodpackVersion.isBlank();

        if (!gettingServerVersion && LOADER_MANAGER.getEnvironmentType() == LoaderManagerService.EnvironmentType.CLIENT && !clientConfig.selfUpdater) {
            LOGGER.info("AutoModpack self-updater is disabled in client config.");
            return false;
        }

        // Identify Current Version
        SemanticVersion currentVersion;
        try {
            currentVersion = SemanticVersion.parse(AM_VERSION);
        } catch (IllegalArgumentException e) {
            LOGGER.error("Current installed AutoModpack version is corrupt/invalid: " + AM_VERSION);
            return false;
        }

        // Fetch Remote Info
        List<ModrinthAPI> modrinthAPIList = new ArrayList<>();

        if (gettingServerVersion) {
            if (serverModpackContent.automodpackVersion.equals(AM_VERSION)) {
                LOGGER.info("AutoModpack is up-to-date with server version: {}", serverModpackContent.automodpackVersion);
                return false;
            }

            if (!clientConfig.syncAutoModpackVersion) {
                LOGGER.warn("Version syncing disabled. Cannot sync to server version: {}", serverModpackContent.automodpackVersion);
                return false;
            }

            LOGGER.info("Syncing AutoModpack to server version: {}", serverModpackContent.automodpackVersion);
            modrinthAPIList.add(ModrinthAPI.getModSpecificVersion(AUTOMODPACK_ID, serverModpackContent.automodpackVersion, serverModpackContent.mcVersion));
        } else {
            LOGGER.info("Checking if AutoModpack is up-to-date...");
            modrinthAPIList = ModrinthAPI.getModInfosFromID(AUTOMODPACK_ID);
        }

        if (modrinthAPIList == null || modrinthAPIList.isEmpty()) {
            LOGGER.warn("Couldn't get version info from Modrinth API.");
            return false;
        }

        // Iterate & Validate
        for (ModrinthAPI automodpack : modrinthAPIList) {
            if (automodpack == null || automodpack.fileVersion() == null) continue;

            String rawRemoteVersion = automodpack.fileVersion();
            SemanticVersion remoteVersion;

            try {
                remoteVersion = SemanticVersion.parse(rawRemoteVersion);
            } catch (IllegalArgumentException e) {
                continue; // Skip malformed remote versions
            }

            // Exact Hash Match (Fastest check)
            if (automodpack.SHA1Hash().equals(CustomFileUtils.getHash(THIS_MOD_JAR))) {
                LOGGER.info("Already on the target version (Hash match): {}", AM_VERSION);
                return false;
            }

            // Version Comparison
            int comparison = remoteVersion.compareTo(currentVersion);

            // Never replace a newer installed client with the server's older
            // AutoModpack jar. The server may be an old compatible 4.0.x server.
            if (gettingServerVersion && comparison <= 0) {
                LOGGER.info("Keeping installed AutoModpack {} instead of server version {}.",
                        AM_VERSION, rawRemoteVersion);
                return false;
            }

            // If we are NOT forced to sync to server, and remote is older or equal
            if (!gettingServerVersion && comparison <= 0) {
                if (comparison == 0) {
                    LOGGER.info("No updates found. You are on the latest version: {}", rawRemoteVersion);
                } else {
                    LOGGER.info("Development check: Installed version {} is newer/different than release {}.", AM_VERSION, rawRemoteVersion);
                }
                // Since Modrinth lists are usually sorted latest-first, if the first is older, no newer exists.
                return false;
            }

            // Stable -> Beta Protection
            // If checking for updates (not syncing), do not update FROM Stable TO Beta.
            if (!gettingServerVersion && currentVersion.isStable() && !remoteVersion.isStable()) {
                LOGGER.info("Skipping update: You are on Stable ({}) and latest is Pre-release ({}).", AM_VERSION, rawRemoteVersion);
                continue; // Skip this beta, keep looking for a newer Stable version in the list
            }

            // Safety / Downgrade Check
            if (!validUpdate(remoteVersion)) {
                // If the specific version requested by server is unsafe, we abort.
                // If we are just scanning the list, we skip this invalid entry.
                if (gettingServerVersion) return false;
                continue;
            }

            // Install
            LOGGER.info("Update found! Updating from {} to {}", AM_VERSION, rawRemoteVersion);
            installModVersion(automodpack);
            return true;
        }

        if (!gettingServerVersion) LOGGER.info("No suitable updates found.");
        return false;
    }

    /**
     * Checks if the target update is safe.
     * Prevents downgrading below 4.0.0 Stable.
     * * Logic:
     * 4.0.0 (Stable) is SAFE.
     * 4.1.0 (Stable) is SAFE.
     * 4.0.0-betaX is UNSAFE (because it is < 4.0.0 Stable).
     */
    public static boolean validUpdate(SemanticVersion remoteVersion) {
        if (remoteVersion.compareTo(MINIMUM_SAFE_VERSION) < 0) {
            LOGGER.error("Downgrading AutoModpack to version {} is strongly discouraged/disabled due to security concerns (Target is older than 4.0.0 Stable).", remoteVersion);
            return false;
        }
        return true;
    }

    public static void installModVersion(ModrinthAPI automodpack) {
        Path automodpackUpdateJar = automodpackDir.resolve(automodpack.fileName());
        Path newAutomodpackJar;

        try {
            DownloadManager downloadManager = new DownloadManager();
            new ScreenManager().download(downloadManager, "AutoModpack " + automodpack.fileVersion());

            downloadManager.download(
                    automodpackUpdateJar,
                    automodpack.SHA1Hash(),
                    List.of(automodpack.downloadUrl()),
                    () -> LOGGER.info("Downloaded update for AutoModpack."),
                    () -> LOGGER.error("Failed to download update for AutoModpack.")
            );

            downloadManager.joinAll();
            downloadManager.cancelAllAndShutdown();

            newAutomodpackJar = THIS_MOD_JAR.getParent().resolve(automodpackUpdateJar.getFileName());

            var updateType = UpdateType.AUTOMODPACK;
            var relauncher = new ReLauncher(updateType);

            Runnable callback = () -> {
                CustomFileUtils.executeOrder66(THIS_MOD_JAR);
                LOGGER.info("Successfully updated AutoModpack! Restarting...");
            };

            CustomFileUtils.copyFile(automodpackUpdateJar, newAutomodpackJar);
            CustomFileUtils.executeOrder66(automodpackUpdateJar); // Delete temp file

            relauncher.restart(true, callback);
        } catch (Exception e) {
            LOGGER.error("Failed to update! " + e);
        }
    }
}
