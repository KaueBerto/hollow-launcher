package pl.skidam.automodpack_loader_core.utils;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.io.TempDir;
import pl.skidam.automodpack_core.utils.CustomFileUtils;
import pl.skidam.automodpack_core.utils.Sha256;
import pl.skidam.automodpack_loader_core.SelfUpdater;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;
import static pl.skidam.automodpack_core.GlobalVariables.*;

@Timeout(15)
class ManifestDownloadTest {
    @TempDir Path temp;

    private void download(String sha256, boolean success) throws Exception {
        Path source = temp.resolve("source.bin");
        Path target = temp.resolve("download.bin");
        Files.writeString(source, "abc");
        var manager = new DownloadManager(3);
        AtomicInteger successes = new AtomicInteger();
        AtomicInteger failures = new AtomicInteger();
        try {
            manager.download(target, CustomFileUtils.getHash(source), sha256,
                List.of(source.toUri().toString()), successes::incrementAndGet, failures::incrementAndGet);
            manager.joinAll();
            assertEquals(success ? 1 : 0, successes.get());
            assertEquals(success ? 0 : 1, failures.get());
            if (success) assertEquals("abc", Files.readString(target));
            else assertFalse(Files.exists(target));
        } finally {
            manager.cancelAllAndShutdown();
        }
    }

    @Test void validSha256AcceptsDownload() throws Exception {
        Path file = temp.resolve("expected");
        Files.writeString(file, "abc");
        download(Sha256.hash(file), true);
    }

    @Test void wrongSha256RejectsEvenWithCorrectSha1() throws Exception {
        download("0".repeat(64), false);
    }

    @Test void malformedSha256DoesNotFallBack() throws Exception {
        download("", false);
    }

    @Test void legacyManifestAllowsSha1Download() throws Exception {
        download(null, true);
    }

    @Test void upstreamUpdaterCannotReplaceFork() {
        String previous = AM_VERSION;
        try {
            AM_VERSION = "4.0.6-averonsync.0.1";
            // Returns before accessing loader/config or performing any network requests.
            assertFalse(SelfUpdater.update());
            assertFalse(SelfUpdater.update(new pl.skidam.automodpack_core.config.Jsons.ModpackContentFields()));
        } finally {
            AM_VERSION = previous;
        }
    }
}
