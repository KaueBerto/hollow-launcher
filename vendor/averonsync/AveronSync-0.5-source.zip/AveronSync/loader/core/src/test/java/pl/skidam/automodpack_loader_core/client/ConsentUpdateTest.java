package pl.skidam.automodpack_loader_core.client;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import pl.skidam.automodpack_core.config.*;
import pl.skidam.automodpack_loader_core.screen.*;

import java.net.InetSocketAddress;
import java.nio.file.*;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;
import static pl.skidam.automodpack_core.GlobalVariables.*;

class ConsentUpdateTest {
    @TempDir Path temp;

    private static class CapturingScreens extends PreloadScreenImpl {
        int prompts;
        @Override public void danger(Object... args) { prompts++; }
    }

    private static class CapturingUpdater extends ModpackUpdater {
        int updates;
        CapturingUpdater(Path pack, AveronSyncConsent consent) {
            super(new Jsons.ModpackContentFields(), new Jsons.ModpackAddresses(
                    new InetSocketAddress("localhost", 25565), new InetSocketAddress("localhost", 25565), false),
                    null, pack, consent);
        }
        @Override public void startUpdate(Set<Jsons.ModpackContentFields.ModpackContentItem> files) { updates++; }
    }

    @Test void promptsOnceThenAllowsNewPacksUpdatesAndPreload() throws Exception {
        var screens = new CapturingScreens();
        var original = ScreenManager.INSTANCE;
        var oldPreload = preload;
        var oldConfig = clientConfig;
        clientConfig = new Jsons.ClientConfigFieldsV2();
        try {
            ScreenManager.INSTANCE = screens;
            preload = false;
            Path consentFile = temp.resolve("consent.json");
            var consent = new AveronSyncConsent(consentFile);
            var first = new CapturingUpdater(temp.resolve("pack1"), consent);
            first.processModpackUpdate(null);
            assertEquals(1, screens.prompts);
            assertEquals(0, first.updates);
            assertFalse(consent.isAccepted()); // Showing or declining the screen saves nothing.
            first.acceptTerms();
            var second = new CapturingUpdater(temp.resolve("pack2"), new AveronSyncConsent(consentFile));
            second.processModpackUpdate(null);
            assertEquals(1, second.updates);
            assertEquals(1, screens.prompts);
            // Existing pack update, even after restart and independently of changed file hashes.
            Files.writeString(temp.resolve("pack2").resolve(hostModpackContentFile.getFileName()), "{}");
            second.processModpackUpdate(new ModpackUtils.UpdateCheckResult(true, Set.of()));
            assertEquals(2, second.updates);
            preload = true;
            var third = new CapturingUpdater(temp.resolve("pack3"), new AveronSyncConsent(consentFile));
            third.processModpackUpdate(null);
            assertEquals(1, third.updates);
            assertEquals(1, screens.prompts);
        } finally {
            ScreenManager.INSTANCE = original;
            preload = oldPreload;
            clientConfig = oldConfig;
        }
    }

    @Test void earlyStartupCannotSilentlyAcceptTerms() {
        var screens = new CapturingScreens();
        var original = ScreenManager.INSTANCE;
        var oldPreload = preload;
        var oldConfig = clientConfig;
        clientConfig = new Jsons.ClientConfigFieldsV2();
        try {
            ScreenManager.INSTANCE = screens;
            preload = true;
            var consent = new AveronSyncConsent(temp.resolve("consent.json"));
            var updater = new CapturingUpdater(temp.resolve("pack"), consent);
            updater.processModpackUpdate(null);
            assertEquals(0, updater.updates);
            assertEquals(0, screens.prompts);
            assertFalse(consent.isAccepted());
        } finally {
            ScreenManager.INSTANCE = original;
            preload = oldPreload;
            clientConfig = oldConfig;
        }
    }
}
