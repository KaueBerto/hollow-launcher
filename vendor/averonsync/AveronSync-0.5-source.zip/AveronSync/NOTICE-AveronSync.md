# AveronSync — avisos e origem

Modificações iniciadas em 26/10/2026 para o projeto AveronSync.

Base: AutoModpack 4.0.6, de Skidam e colaboradores.
Repositório original: https://github.com/Skidamek/AutoModpack
Tag: v4.0.6
Commit: 2ff957d03ffb4253fea0c0cbda4d0def4e9528d6

AveronSync é um fork independente. O código e os créditos originais foram
preservados. O arquivo LICENSE contém a LGPL versão 3 fornecida pelo upstream.
As modificações deste fork são disponibilizadas sob a mesma licença.
O texto da LGPL incorpora os termos da GPLv3, incluídos em COPYING-GPL-3.0.txt e disponíveis em
https://www.gnu.org/licenses/gpl-3.0.html.

Mudanças: seleção de Minecraft 1.21.1/NeoForge, identidade textual inicial,
extensão SHA-256 do manifesto e verificação no cliente, bloqueio do atualizador
oficial, testes e documentação. A conversão multiversão de fontes para o alvo
foi feita pelo Stonecutter.

As dependências mantêm suas próprias licenças e avisos. As imagens, ícone,
músicas e demais recursos visuais herdados ainda não foram substituídos por
uma identidade visual própria completa.

Versão 0.2: termos próprios em português brasileiro e inglês, aceite persistente
por instalação, atualizações seguintes sem novo aviso ou temporizador e correções
do empacotamento incremental ao trocar a versão do artefato.

Versão 0.3: comandos /async whitelist para administrar a whitelist nativa do
Minecraft no servidor dedicado, com restrição a operadores de nível 3 e testes
do roteamento de comandos e ativação da lista.

Versão 0.4: remoção dos comandos de whitelist próprios introduzidos na 0.3.
A sincronização e o aceite persistente dos termos são mantidos.
