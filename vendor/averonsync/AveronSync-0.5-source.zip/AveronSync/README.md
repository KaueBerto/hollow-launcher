# AveronSync

Fork independente do **AutoModpack 4.0.6**, de Skidam e colaboradores, para
**Minecraft 1.21.1 / NeoForge**.

Versão atual: **4.0.6-averonsync.0.5**.

## O que mudou

- Identidade inicial AveronSync nos metadados e na tela de download.
- SHA-256 por arquivo no manifesto, com verificação no cliente.
- Termos próprios com aceite único salvo por instalação, sem contagem
  regressiva ou nova confirmação em cada atualização do modpack.
- Atualizador oficial desativado para impedir a substituição do fork.
- Os comandos próprios de whitelist da versão 0.3 foram removidos na 0.4.
- Fila FIFO antes da entrada no mundo, com posição na tela de conexão,
  controle de admissões simultâneas e intervalo entre entradas.

Os IDs internos e o protocolo da base 4.0.6 foram mantidos. Use AveronSync no
lugar do AutoModpack na instalação. O protocolo da versão 5 do AutoModpack
não é equivalente ao desta base.

## Compilar

Tenha JDK 21 para Gradle/Minecraft e JDK 17 disponível para os módulos core.

```powershell
.\gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --console=plain
```

O JAR completo fica em `merged/`. O JAR intermediário do subprojeto Minecraft
sozinho não reúne todas as partes do carregador.

O GitHub Actions compila esse alvo, executa os testes e disponibiliza o JAR
como artefato da execução. Não publica automaticamente no Modrinth/CurseForge.

## Validação e documentação

A versão 0.5 passou em **54 testes**, incluindo 12 cenários do agendador da
fila. A integração de login foi testada com conexões de protocolo em um
servidor local NeoForge 21.1.253. A tela no cliente gráfico e o comportamento
com o modpack completo em produção ainda precisam de teste com jogadores.
Configuração, compatibilidade e evidências em [FILA-AVERONSYNC.md](FILA-AVERONSYNC.md).

A versão 0.4 passou nos **42 testes** e foi testada em servidor
Minecraft 1.21.1 / NeoForge 21.1.253. Foram confirmados o manifesto SHA-256,
TLS, entrada real e reconexão sem repetir o aceite dos termos. Ainda não foi
simulada uma nova alteração de mods no servidor após esse aceite.

- [Arquitetura, implementação e limites](README-AVERONSYNC.md)
- [Termos de sincronização](TERMOS-AVERONSYNC.md)
- [Fila e validação da versão 0.5](FILA-AVERONSYNC.md)
- [Validação da versão 0.4](VALIDACAO-0.4.md)
- [Teste real em servidor](VALIDACAO-SERVIDOR-0.4.md)
- [Avisos e origem do fork](NOTICE-AveronSync.md)
- [README original do AutoModpack](README-UPSTREAM.md)

## Origem e licença

Base: [Skidamek/AutoModpack, tag v4.0.6](https://github.com/Skidamek/AutoModpack/tree/v4.0.6),
commit `2ff957d03ffb4253fea0c0cbda4d0def4e9528d6`.

O histórico e os créditos originais foram preservados. A licença LGPLv3 está
em [LICENSE](LICENSE), acompanhada do texto da [GPLv3](COPYING-GPL-3.0.txt).
Os recursos visuais herdados ainda não foram substituídos integralmente.
