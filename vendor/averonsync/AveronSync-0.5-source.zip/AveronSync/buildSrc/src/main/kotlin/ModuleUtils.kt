import java.io.File

fun getLoaderModuleName(name: String): String {
    // 1. Expected format: {name}-mc{mcversion}-{loader}-{version}.jar
    // 2. Fallback format: {mcversion}-{loader}
    val mcVersion = name.substringAfterLast("-mc", "").substringBefore("-")
        .ifEmpty { name.substringBefore("-") }
        .ifEmpty { error("Could not determine Minecraft version from: $name") }

    return when {
        name.contains("fabric") -> "fabric-core"
        name.contains("neoforge") -> when {
            mcVersion in setOf("1.20.6", "1.20.4", "1.20.1", "1.19.4", "1.19.2", "1.18.2") -> "neoforge-fml2"
            mcVersion in setOf("1.21.8", "1.21.5", "1.21.4", "1.21.3", "1.21.1") -> "neoforge-fml4"
            mcVersion in setOf("1.21.11", "1.21.10") -> "neoforge-fml10"
            // Stonecutter targets may resolve to a concrete patch version in the jar name.
            mcVersion == "26.1" || mcVersion.startsWith("26.1.") ||
                mcVersion == "26.2" || mcVersion.startsWith("26.2.") -> "neoforge-fml10"
            else -> error("Unknown neoforge loader module for Minecraft version: $mcVersion")
        }
        name.contains("forge") -> if (mcVersion == "1.18.2") "forge-fml40" else "forge-fml47"
        else -> error("Unknown loader type")
    }
}

fun getAllDependentLoaderModules(name: String): List<String> {
    val loaderModule = getLoaderModuleName(name)
    val list = mutableListOf("core", "loader-core", "loader-$loaderModule")
    if (loaderModule == "fabric-core") { // Special case for fabric.
        list.add("loader-fabric-15")
        list.add("loader-fabric-16")
    }
    return list
}

fun getMergedJarPath(buildDirLibs: File, version: String): File {
    return buildDirLibs.listFiles()
        ?.singleOrNull { file -> file.isFile && file.name.endsWith("-$version.jar") }
        ?: error("No unique jar for version $version found to merge in build/libs directory! ${buildDirLibs.absolutePath}")
}
