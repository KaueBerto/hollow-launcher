# AveronSync 0.4 — remoção dos comandos de whitelist

Data: 26/10/2026. Alvo: Minecraft 1.21.1 / NeoForge 21.1.169.
Versão: `4.0.6-averonsync.0.4`.

Removidos o registro de `/async whitelist`, a implementação dos comandos,
os sete testes exclusivos dessa função, as dependências de teste adicionadas
somente para ela e o guia de whitelist da versão 0.3.

Os comandos originais `/automodpack` e `/amp`, a sincronização SHA-256 e o
aceite único dos termos continuam presentes. A atualização não edita a
whitelist do Minecraft nem os dados de outros mods. Caso a whitelist nativa
tenha sido ativada anteriormente, remover este comando não a desativa.

Verificação: compilação com
`./gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --console=plain`.
Os 42 testes restantes (33 no core e 9 no loader-core) passaram. O total
diminuiu pela remoção dos sete testes da função retirada.

O JAR final foi inspecionado para conferir a versão 0.4 no bootstrap e no mod
interno, a ausência das classes de whitelist e do registro do comando, a
presença dos termos e a integridade dos arquivos JAR. Os relatórios das
versões anteriores são históricos e não descrevem funções disponíveis na 0.4.

Ainda não foi executado um servidor real nesta etapa. Nenhuma instalação
de servidor do usuário foi alterada.

Posteriormente, a instalação e a entrada real foram testadas; consulte
[VALIDACAO-SERVIDOR-0.4.md](VALIDACAO-SERVIDOR-0.4.md).

Artefato: `averonsync-mc1.21.1-neoforge-4.0.6-averonsync.0.4.jar`.
Evidências: `../evidencias-0.4/`; hashes: `../SHA256SUMS-0.4.txt`.
