package pl.skidam.automodpack.client.ui;

import net.minecraft.Util;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.util.FormattedCharSequence;
import pl.skidam.automodpack.client.audio.AudioManager;
import pl.skidam.automodpack.client.ui.versioned.VersionedMatrices;
import pl.skidam.automodpack.client.ui.versioned.VersionedScreen;
import pl.skidam.automodpack.client.ui.versioned.VersionedText;
import pl.skidam.automodpack_core.config.Jsons;
import pl.skidam.automodpack_loader_core.client.ModpackUpdater;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/** One-time local consent for AveronSync synchronization, without a countdown. */
public class DangerScreen extends VersionedScreen {
    private final Screen parent;
    private final ModpackUpdater updater;
    private final Set<Jsons.ModpackContentFields.ModpackContentItem> filesToUpdate;
    private List<FormattedCharSequence> lines = List.of();
    private Button acceptButton;
    private boolean acknowledged;
    private boolean saveFailed;
    private int scroll;
    private int textTop;
    private int textBottom;
    private int textLeft;
    private int textWidth;

    public DangerScreen(Screen parent, ModpackUpdater updater) {
        this(parent, updater, Set.of());
    }

    public DangerScreen(Screen parent, ModpackUpdater updater, Collection<?> filesToUpdate) {
        super(VersionedText.translatable("averonsync.terms.title"));
        this.parent = parent;
        this.updater = updater;
        this.filesToUpdate = filesToUpdate.stream()
                .filter(Jsons.ModpackContentFields.ModpackContentItem.class::isInstance)
                .map(Jsons.ModpackContentFields.ModpackContentItem.class::cast)
                .collect(Collectors.toUnmodifiableSet());
        if (AudioManager.isMusicPlaying()) AudioManager.stopMusic();
    }

    @Override
    protected void init() {
        super.init();
        textWidth = Math.min(520, Math.max(80, this.width - 32));
        textLeft = (this.width - textWidth) / 2;
        textTop = 48;
        textBottom = Math.max(textTop + 12, this.height - 66);
        var body = VersionedText.literal("");
        for (int i = 1; i <= 6; i++) {
            if (i > 1) body.append("\n\n");
            body.append(VersionedText.translatable("averonsync.terms.section" + i));
        }
        lines = this.font.split(body, textWidth);
        scroll = Math.min(scroll, maxScroll());

        int buttonWidth = Math.min(150, (this.width - 30) / 2);
        var cancel = addRenderableWidget(buttonWidget(this.width / 2 - buttonWidth - 4,
                this.height - 26, buttonWidth, 20,
                VersionedText.translatable("averonsync.terms.decline"),
                button -> this.minecraft.setScreen(parent)));
        acceptButton = addRenderableWidget(buttonWidget(this.width / 2 + 4, this.height - 26,
                buttonWidth, 20, VersionedText.translatable("averonsync.terms.accept"),
                button -> accept()));
        acceptButton.active = acknowledged;
        addRenderableWidget(buttonWidget(textLeft, this.height - 50, textWidth, 20,
                acknowledgementText(), button -> {
                    acknowledged = !acknowledged;
                    button.setMessage(acknowledgementText());
                    acceptButton.active = acknowledged;
                }));
        setInitialFocus(cancel);
    }

    private net.minecraft.network.chat.MutableComponent acknowledgementText() {
        return VersionedText.literal(acknowledged ? "[x] " : "[ ] ")
                .append(VersionedText.translatable("averonsync.terms.acknowledge"));
    }

    private void accept() {
        if (!acknowledged || !acceptButton.active) return;
        try {
            updater.acceptTerms();
            acceptButton.active = false;
            Util.backgroundExecutor().execute(() -> updater.startUpdate(filesToUpdate));
        } catch (IOException e) {
            saveFailed = true;
        }
    }

    private int maxScroll() {
        return Math.max(0, lines.size() * (this.font.lineHeight + 3) - (textBottom - textTop));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) (vertical * 24)));
        return true;
    }

    @Override
    public void versionedRender(VersionedMatrices matrices, int mouseX, int mouseY, float delta) {
        drawCenteredTextWithShadow(matrices, this.font,
                VersionedText.translatable("averonsync.terms.title"), this.width / 2, 12, 0xFF70D6CF);
        drawCenteredTextWithShadow(matrices, this.font,
                VersionedText.translatable(saveFailed ? "averonsync.terms.saveFailed" : "averonsync.terms.once"),
                this.width / 2, 28, saveFailed ? 0xFFFF7777 : TextColors.GRAY);
        var graphics = matrices.getContext();
        graphics.enableScissor(textLeft, textTop, textLeft + textWidth, textBottom);
        for (int i = 0; i < lines.size(); i++) {
            int y = textTop + i * (this.font.lineHeight + 3) - scroll;
            if (y + this.font.lineHeight >= textTop && y < textBottom) {
                graphics.drawString(this.font, lines.get(i), textLeft, y, TextColors.WHITE);
            }
        }
        graphics.disableScissor();
        if (maxScroll() > 0) {
            graphics.fill(textLeft + textWidth + 3, textTop, textLeft + textWidth + 5, textBottom, 0xFF444444);
            int thumbHeight = Math.max(8, (textBottom - textTop) * (textBottom - textTop) / (lines.size() * (this.font.lineHeight + 3)));
            int thumbY = textTop + scroll * (textBottom - textTop - thumbHeight) / maxScroll();
            graphics.fill(textLeft + textWidth + 3, thumbY, textLeft + textWidth + 5, thumbY + thumbHeight, 0xFF70D6CF);
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
