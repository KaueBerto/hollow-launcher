package pl.skidam.automodpack.networking.packet;

import io.netty.buffer.Unpooled;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientHandshakePacketListenerImpl;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import pl.skidam.automodpack.mixin.core.ClientLoginNetworkHandlerAccessor;
import java.util.concurrent.CompletableFuture;

public final class QueueC2SPacket {
    public static CompletableFuture<FriendlyByteBuf> receive(Minecraft client, ClientHandshakePacketListenerImpl handler, FriendlyByteBuf buf) {
        int position = buf.readVarInt();
        int total = buf.readVarInt();
        if (position < 0 || position > 1000 || total < 0 || total > 1000) throw new IllegalArgumentException("Invalid queue status");
        var accessor = (ClientLoginNetworkHandlerAccessor) handler;
        return client.submit(() -> {
            if (accessor.getConnection().isConnected()) {
                accessor.averonsync$getUpdateStatus().accept(position == 0
                        ? Component.translatable("averonsync.queue.admitted")
                        : Component.translatable("averonsync.queue.waiting", position, total));
            }
            return new FriendlyByteBuf(Unpooled.buffer()).writeByte(1);
        });
    }
}
