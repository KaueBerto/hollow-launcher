package pl.skidam.automodpack.networking.server;

import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.login.ClientboundLoginDisconnectPacket;
import net.minecraft.server.MinecraftServer;
import pl.skidam.automodpack_core.queue.AdmissionQueue;
import pl.skidam.automodpack_core.queue.QueueSettings;

import java.util.*;
import static pl.skidam.automodpack_core.GlobalVariables.serverConfig;

/** All access is on the Minecraft server thread. Never sleeps or blocks a tick. */
public final class AveronSyncEntryQueue {
    private static final Map<MinecraftServer, AveronSyncEntryQueue> SERVERS = new IdentityHashMap<>();
    private record Session(Connection connection) {}
    private final AdmissionQueue queue;
    private final pl.skidam.automodpack_core.queue.AttemptLimiter attempts = new pl.skidam.automodpack_core.queue.AttemptLimiter();
    private final Map<UUID, Session> sessions = new HashMap<>();

    private AveronSyncEntryQueue() {
        queue = (serverConfig.entryQueue == null ? new QueueSettings() : serverConfig.entryQueue).createQueue();
    }
    public static boolean enabled(MinecraftServer server) {
        return server.isDedicatedServer() && (serverConfig.entryQueue == null || serverConfig.entryQueue.enabled);
    }
    public static AveronSyncEntryQueue get(MinecraftServer server) {
        return SERVERS.computeIfAbsent(server, ignored -> new AveronSyncEntryQueue());
    }
    public static void shutdown(MinecraftServer server) { SERVERS.remove(server); }
    public static long now() { return System.nanoTime() / 1_000_000; }

    public static void tick(MinecraftServer server) {
        AveronSyncEntryQueue manager = SERVERS.get(server);
        if (manager == null) return;
        long now = now();
        Set<Connection> joinedConnections = Collections.newSetFromMap(new IdentityHashMap<>());
        for (var player : server.getPlayerList().getPlayers()) joinedConnections.add(player.connection.getConnection());
        Iterator<Map.Entry<UUID, Session>> iterator = manager.sessions.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            Session session = entry.getValue();
            // Match the connection, including when an offline authentication mod changes the UUID.
            boolean joined = joinedConnections.contains(session.connection());
            if (!session.connection().isConnected() || joined) {
                manager.queue.remove(entry.getKey(), now);
                iterator.remove();
            }
        }
        boolean room = server.getPlayerCount() + manager.queue.activeCount() < server.getMaxPlayers();
        for (var expired : manager.queue.advance(now, room)) {
            Session session = manager.sessions.remove(expired.id());
            if (session != null) disconnect(session.connection(), "Tempo de espera esgotado. Tente conectar novamente.");
        }
    }

    public UUID enqueue(Connection connection, String name) {
        var remote = connection.getRemoteAddress();
        String address = remote instanceof java.net.InetSocketAddress inet
                ? inet.getHostString() : String.valueOf(remote);
        if (!attempts.allow(address, now())) {
            disconnect(connection, "Muitas tentativas de entrada. Aguarde um minuto.");
            return null;
        }
        AdmissionQueue.Rejection reason = queue.rejection(name);
        if (reason != null) {
            disconnect(connection, reason == AdmissionQueue.Rejection.DUPLICATE
                    ? "Ja existe uma conexao sua na fila." : "A fila esta cheia. Tente novamente em alguns instantes.");
            return null;
        }
        var ticket = queue.enqueue(name, now());
        sessions.put(ticket.id(), new Session(connection));
        return ticket.id();
    }
    public AdmissionQueue.Snapshot snapshot(UUID id) { return queue.snapshot(id); }
    public void cancel(UUID id) { queue.remove(id, now()); sessions.remove(id); }
    public static void disconnect(Connection connection, String text) {
        Component reason = Component.literal("[AveronSync] " + text);
        connection.send(new ClientboundLoginDisconnectPacket(reason));
        connection.disconnect(reason);
    }
}
