# Validação — AveronSync 0.1

Data: 26/10/2026. Base upstream: AutoModpack `v4.0.6`, commit
`2ff957d03ffb4253fea0c0cbda4d0def4e9528d6`.
Branch local: `averonsync/1.21.1-neoforge-v0.1`.

## Resultado executado

Com JDK 21, JDK 17 para os toolchains do core e Gradle Wrapper 9.6.1:

```powershell
.\gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --console=plain
```

Resultado final: **BUILD SUCCESSFUL**. Foram verificados **37 testes, zero
falhas, zero erros e zero ignorados**: 30 no core e 7 no loader-core. São
27 testes herdados e 10 novos; um teste herdado também ganhou asserções para
os hashes SHA-256 do manifesto gerado. A compilação final reutilizou os
resultados de testes cujas entradas não mudaram.

Os testes novos exercitam vetores SHA-256 conhecidos (incluindo arquivo vazio
e arquivo maior que o buffer), adulteração e hashes inválidos, serialização
do novo campo, leitura de formato antigo, aprovação/rejeição pelo gerenciador
real de downloads, cache com tamanho/data preservados, edição local permitida
e bloqueio do atualizador oficial. Os testes de download usam URLs `file:`
temporárias; não simulam uma sessão completa do protocolo Netty/TLS.

## Artefato

JAR completo gerado pelo empacotamento/otimização do upstream:

`averonsync-mc1.21.1-neoforge-4.0.6-averonsync.0.1.jar`

SHA-256:
`c19114a9c00035bafc74da48c6c0eea9a5c8391d9407fd531b17d2df32873087`

Verificação adicional do JAR final e seu mod interno:

- Integridade dos arquivos ZIP/JAR sem erros.
- Metadados do bootstrap e do mod interno com nome AveronSync e versão do fork.
- Classe de SHA-256 presente no bootstrap.
- Serviços NeoForge de localização antecipada e dependências presentes.
- Tradução brasileira do título AveronSync presente no mod interno.
- Texto LGPL original, texto GPLv3 oficial e aviso do fork incluídos no JAR.

O instalável é o JAR de `merged/`, também copiado para a pasta de entrega.
Ele contém bootstrap, mod interno e Zstd. O JAR intermediário do subprojeto
Minecraft não é a entrega completa.

## Limites e próximos passos

Não foram executados Minecraft gráfico nem uma sessão cliente/servidor real.
A interface foi compilada; sua aparência e comportamento dentro do jogo
ainda precisam de validação. Também faltam testes reais de instalação,
reinício, cancelamento, reconexão, arquivos editáveis e falhas de rede em
um modpack de teste NeoForge 21.1.169.

O empacotamento emite avisos herdados do Shadow sobre recursos duplicados.
Os serviços esperados foram encontrados no JAR final; a inicialização real
do NeoForge permanece pendente.

A identidade visual é parcial: título, cor, percentual e metadados foram
alterados; ícone, texturas e demais telas ainda usam recursos do upstream.
O manifesto tem SHA-256 opcional para compatibilidade. Exigência do novo
formato, assinatura de manifesto, canal de atualização próprio e publicação
do fork não foram implementados. IDs internos continuam compartilhados com
AutoModpack; a instalação usa um ou outro.

O starter da conversa anterior não pôde ser recuperado. O binário desta
entrega foi compilado aqui a partir dos fontes da tag oficial modificados;
não foi inferido de um ZIP anterior.

O log da compilação e o resumo das suítes estão em `../evidencias/` na pasta
de entrega local. Para continuar o desenvolvimento, consulte
`README-AVERONSYNC.md` e o repositório local com histórico completo.
