# AveronSync · Termos de sincronização

Versão dos termos: 1. Aceite local e único por instalação.

1. O AveronSync sincroniza o modpack dos servidores aos quais você escolhe se conectar. Ao aceitar, você autoriza o download e a instalação dos arquivos fornecidos por esses servidores.

2. A sincronização pode adicionar, substituir e remover arquivos gerenciados do modpack, incluindo mods, configurações e pacotes de recursos. Arquivos definidos como editáveis seguem a política de preservação do modpack. Mantenha cópias dos arquivos que quiser guardar.

3. Você também autoriza as próximas atualizações automáticas nesta instalação, inclusive quando o servidor trocar ou adicionar mods. Esses arquivos podem conter código executável, inclusive JARs sem correspondência pública no Modrinth ou CurseForge. Atualizações não repetem este aceite nem exigem aguardar 10 segundos.

4. Conecte-se a servidores cuja administração você conhece e em que confia. A verificação por hash confere a integridade do arquivo em relação ao manifesto; ela não garante que o conteúdo seja seguro. A verificação da identidade do servidor continua separada.

5. O aceite fica salvo somente nesta instalação do jogo e não é enviado como cadastro ou assinatura. Você pode revogá-lo apagando automodpack/averonsync-consent.json com o jogo fechado. Na próxima sincronização, os termos serão apresentados novamente.

6. Se você não concordar, escolha “Não aceito”: essa sincronização não será iniciada. Estes termos explicam a autorização de sincronização do AveronSync e não substituem as licenças dos mods, as regras do servidor ou os termos do Minecraft.
