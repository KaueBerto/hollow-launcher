"""Import user-supplied Cubees Blockbench assets for the native cosmetic renderer.

Does not execute plugin configs, HTML or archive instructions. Generated artwork is
kept outside Git; supplying these ZIPs does not change the original authors' rights.
"""
from pathlib import Path
import argparse, base64, hashlib, json, math, re, struct, zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'src/main/resources/assets/averonsync'

def vector(value, default):
    value = value if value is not None else default
    result = [float(v) for v in value]
    if len(result) != 3 or not all(math.isfinite(v) for v in result):
        raise ValueError('Invalid model vector')
    return result

def run(archives):
    models = []
    for archive in archives:
        with zipfile.ZipFile(archive) as z:
            for entry in z.infolist():
                if not entry.filename.endswith('.bbmodel'): continue
                if entry.file_size > 4_000_000: raise ValueError('Model too large')
                pet = Path(entry.filename).stem.removeprefix('cubee-')
                if not re.fullmatch('[a-z_]+', pet): raise ValueError('Invalid pet ID')
                raw = json.loads(z.read(entry))
                textures = []
                for index, texture in enumerate(raw['textures']):
                    source = texture.get('source', '')
                    if not source.startswith('data:image/png;base64,'): raise ValueError('External texture rejected')
                    data = base64.b64decode(source.split(',', 1)[1], validate=True)
                    if data[:8] != b'\x89PNG\r\n\x1a\n': raise ValueError('Invalid PNG')
                    width, height = struct.unpack('>II', data[16:24])
                    uvw, uvh = float(texture['uv_width']), float(texture['uv_height'])
                    if not (0 < uvw <= width <= 2048 and 0 < uvh <= height <= 4096): raise ValueError('Invalid texture bounds')
                    path = f'textures/pets/{pet}/{index}.png'
                    destination = OUT / path
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(data)
                    textures.append(dict(path='averonsync:' + path, width=width, height=height,
                                         uvWidth=uvw, uvHeight=uvh, frameTime=max(1, texture.get('frame_time', 1)),
                                         frames=int(height / uvh), emissive=-1))
                names = [t['name'].removesuffix('.png') for t in raw['textures']]
                for index, name in enumerate(names):
                    if name + '_e' in names: textures[index]['emissive'] = names.index(name + '_e')
                cubes = {}
                for cube in raw['elements']:
                    if cube.get('type', 'cube') != 'cube': raise ValueError('Unsupported mesh')
                    faces = {}
                    for direction, face in cube.get('faces', {}).items():
                        texture = face.get('texture')
                        if texture is None: continue
                        if not isinstance(texture, int) or not 0 <= texture < len(textures): raise ValueError('Invalid face texture')
                        uv = [float(v) for v in face['uv']]
                        if len(uv) != 4 or not all(math.isfinite(v) for v in uv): raise ValueError('Invalid UV')
                        faces[direction] = dict(texture=texture, uv=uv, rotation=face.get('rotation', 0))
                    cubes[cube['uuid']] = dict(from_=vector(cube['from'], [0, 0, 0]), to=vector(cube['to'], [0, 0, 0]),
                        origin=vector(cube.get('origin'), [0, 0, 0]), rotation=vector(cube.get('rotation'), [0, 0, 0]),
                        inflate=float(cube.get('inflate', 0)), faces=faces)
                used = set()
                def node(value):
                    if isinstance(value, str):
                        if value not in cubes: raise ValueError('Unknown cube reference')
                        used.add(value)
                        return dict(id=value, origin=[0, 0, 0], rotation=[0, 0, 0], cubes=[cubes[value]], children=[])
                    return dict(id=value['uuid'], origin=vector(value.get('origin'), [0, 0, 0]),
                                rotation=vector(value.get('rotation'), [0, 0, 0]), cubes=[],
                                children=[node(c) for c in value.get('children', []) if not isinstance(c, dict) or c.get('export', True)])
                nodes = [node(n) for n in raw['outliner']]
                # Keep editor-hidden bones: visibility is editor state, while scale keyframes
                # control the authored runtime visibility (e.g. wings/emote attachments).
                animations = {}
                for animation in raw.get('animations', []):
                    tracks = {}
                    for ident, animator in animation.get('animators', {}).items():
                        if animator.get('type') != 'bone':
                            if animator.get('keyframes'): raise ValueError('Unsupported effect animator')
                            continue
                        channels = {}
                        for key in animator.get('keyframes', []):
                            channel = key['channel']; interpolation = key.get('interpolation', 'linear')
                            if channel not in ['position', 'rotation', 'scale'] or interpolation not in ['linear', 'step', 'catmullrom']:
                                raise ValueError(f'Unsupported animation {channel}/{interpolation}')
                            if len(key['data_points']) != 1 or key.get('easing', 'linear') != 'linear':
                                raise ValueError('Unsupported animation easing')
                            point = key['data_points'][0]
                            channels.setdefault(channel, []).append(dict(time=float(key['time']),
                                value=vector([point.get(k, 1 if channel == 'scale' else 0) for k in ['x', 'y', 'z']], [0, 0, 0]),
                                interpolation=interpolation))
                        tracks[ident] = {k: sorted(v, key=lambda f: f['time']) for k, v in channels.items()}
                    animations[animation['name']] = dict(length=float(animation['length']), tracks=tracks)
                if not {'idle', 'walk', 'pet', 'emote'} <= animations.keys(): raise ValueError('Missing animation')
                model = dict(id=pet, textures=textures, nodes=nodes, animations=animations)
                destination = OUT / f'pets/{pet}.json'; destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(json.dumps(model, separators=(',', ':')), encoding='utf-8')
                icon = next((n for n in z.namelist() if '/ItemsAdder/' in n and n.endswith('/cubee-' + pet + '.png')), None)
                if icon:
                    destination = OUT / f'textures/pets/icons/{pet}.png'; destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(z.read(icon))
                models.append(dict(id=pet, sourceArchive=archive.name, modelSha256=hashlib.sha256(z.read(entry)).hexdigest(),
                                   cubes=len(cubes), importedCubes=len(used), textures=len(textures), animations=list(animations)))
    assert len(models) == 16 and len({m['id'] for m in models}) == 16, 'Expected the 16 supplied Cubees'
    (OUT / 'pets/import-report.json').write_text(json.dumps(models, indent=2), encoding='utf-8')
    print(json.dumps({'importedPets':len(models), 'cubes':sum(m['cubes'] for m in models), 'output':str(OUT)}))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('archives', nargs=2, type=Path)
    run(parser.parse_args().archives)
