package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import pl.skidam.automodpack_core.pets.PetCatalog;
import java.util.*;

/** Server-to-client cosmetic state only. There is no client authority over VIP entitlement. */
public record AveronSyncPetPayload(List<Entry> entries, boolean openMenu, String selected) implements CustomPacketPayload {
    public record Entry(UUID owner, String pet, long expiresAt, String action, long actionAt) {}
    public static final Type<AveronSyncPetPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath("averonsync", "vip_pets"));
    public static final StreamCodec<RegistryFriendlyByteBuf, AveronSyncPetPayload> CODEC = StreamCodec.of(AveronSyncPetPayload::write, AveronSyncPetPayload::read);
    public AveronSyncPetPayload { entries = List.copyOf(entries); if (entries.size() > 256) throw new IllegalArgumentException("Too many pets"); }
    private static void write(RegistryFriendlyByteBuf buf, AveronSyncPetPayload data) {
        buf.writeBoolean(data.openMenu); buf.writeUtf(data.selected, 48); buf.writeVarInt(data.entries.size());
        for (var entry : data.entries) {
            buf.writeUUID(entry.owner); buf.writeUtf(entry.pet, 48); buf.writeLong(entry.expiresAt);
            buf.writeUtf(entry.action, 8); buf.writeLong(entry.actionAt);
        }
    }
    private static AveronSyncPetPayload read(RegistryFriendlyByteBuf buf) {
        boolean menu = buf.readBoolean(); String selected = buf.readUtf(48);
        if (!selected.isEmpty() && !PetCatalog.contains(selected)) throw new IllegalArgumentException("Unknown selected pet");
        int count = buf.readVarInt(); if (count < 0 || count > 256) throw new IllegalArgumentException("Invalid pet count");
        List<Entry> result = new ArrayList<>(count); Set<UUID> seen = new HashSet<>();
        for (int i = 0; i < count; i++) {
            UUID owner = buf.readUUID(); String pet = buf.readUtf(48); long expiry = buf.readLong();
            String action = buf.readUtf(8); long actionAt = buf.readLong();
            if (!PetCatalog.contains(pet) || !Set.of("idle", "pet", "emote").contains(action) || !seen.add(owner)) throw new IllegalArgumentException("Invalid pet entry");
            result.add(new Entry(owner, pet, expiry, action, actionAt));
        }
        return new AveronSyncPetPayload(result, menu, selected);
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
/*?}*/
