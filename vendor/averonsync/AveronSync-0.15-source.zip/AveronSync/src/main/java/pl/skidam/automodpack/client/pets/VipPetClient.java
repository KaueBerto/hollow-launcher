package pl.skidam.automodpack.client.pets;

/*? if neoforge {*/
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.common.NeoForge;
import pl.skidam.automodpack.modpack.AveronSyncPetPayload;
import pl.skidam.automodpack_core.pets.CubeeModel;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

public final class VipPetClient {
    static List<AveronSyncPetPayload.Entry> entries = List.of();
    private static final Map<String, Optional<CubeeModel>> MODELS = new HashMap<>();
    public static void init(IEventBus bus) {
        bus.addListener(VipPetClient::reloadListeners);
        NeoForge.EVENT_BUS.addListener(VipPetRenderer::render);
        NeoForge.EVENT_BUS.addListener(VipPetClient::disconnected);
    }
    private static void reloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((ResourceManagerReloadListener) manager -> { MODELS.clear(); VipPetRenderer.reset(); });
    }
    private static void disconnected(ClientPlayerNetworkEvent.LoggingOut event) { entries = List.of(); VipPetRenderer.reset(); }
    public static void accept(AveronSyncPetPayload data) {
        entries = data.entries();
        if (data.openMenu() && Minecraft.getInstance().level != null)
            Minecraft.getInstance().setScreen(new VipPetScreen(data.selected()));
    }
    static Optional<CubeeModel> model(String id) {
        return MODELS.computeIfAbsent(id, ignored -> {
            var location = ResourceLocation.fromNamespaceAndPath("averonsync", "pets/" + id + ".json");
            try (var stream = Minecraft.getInstance().getResourceManager().getResourceOrThrow(location).open()) {
                byte[] bytes = stream.readNBytes(4_000_001);
                if (bytes.length > 4_000_000) throw new IOException("Pet model too large");
                return Optional.of(CubeeModel.parse(JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject()));
            } catch (Exception e) { LOGGER.error("Could not load cosmetic pet {}; hiding it until resource reload", id, e); return Optional.empty(); }
        });
    }
    private VipPetClient() {}
}
/*?}*/
