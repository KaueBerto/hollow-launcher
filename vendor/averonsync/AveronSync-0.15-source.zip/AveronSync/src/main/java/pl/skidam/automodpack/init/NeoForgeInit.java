package pl.skidam.automodpack.init;

/*? if neoforge {*/
/*? if >1.20.5 {*/
import net.neoforged.fml.common.EventBusSubscriber;
/*?}*/
import pl.skidam.automodpack.client.ScreenImpl;
import pl.skidam.automodpack.client.audio.AudioManager;
import pl.skidam.automodpack.modpack.Commands;
import pl.skidam.automodpack.networking.ModPackets;
import pl.skidam.automodpack_core.loader.LoaderManagerService;
import pl.skidam.automodpack_loader_core.screen.ScreenManager;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

import static pl.skidam.automodpack_core.GlobalVariables.*;

@Mod(MOD_ID + "_mod")
public class NeoForgeInit {
    public NeoForgeInit(IEventBus eventBus) {
         eventBus.addListener(pl.skidam.automodpack.modpack.AveronSyncVipPets::registerPayloads);
         preload = false;
         ScreenManager.INSTANCE = new ScreenImpl();

         long start = System.currentTimeMillis();
         LOGGER.info("Launching AutoModpack...");

         Common.init();

         if (LOADER_MANAGER.getEnvironmentType() == LoaderManagerService.EnvironmentType.SERVER) {
            Common.serverInit();
         } else {
             ModPackets.registerC2SPackets();
             new AudioManager(eventBus);
             pl.skidam.automodpack.client.pets.VipPetClient.init(eventBus);
         }


         LOGGER.info("AutoModpack launched! took " + (System.currentTimeMillis() - start) + "ms");
    }

/*? if >1.20.5 {*/
   @EventBusSubscriber(modid = MOD_ID + "_mod")
/*?} else {*/
   /*@Mod.EventBusSubscriber(modid = MOD_ID + "_mod")
*//*?}*/
    public static class events {
        @SubscribeEvent(priority = net.neoforged.bus.api.EventPriority.LOWEST)
        public static void onTabName(net.neoforged.neoforge.event.entity.player.PlayerEvent.TabListNameFormat event) {
            pl.skidam.automodpack.modpack.AveronSyncVipTab.format(event);
        }

        @SubscribeEvent(priority = net.neoforged.bus.api.EventPriority.LOWEST)
        public static void onPlayerLogin(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent event) {
            if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player)
                pl.skidam.automodpack.modpack.AveronSyncVipTab.refresh(player);
            if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer player)
                pl.skidam.automodpack.modpack.AveronSyncVipPets.joined(player);
        }

        @SubscribeEvent
        public static void onServerTick(net.neoforged.neoforge.event.tick.ServerTickEvent.Post event) {
            pl.skidam.automodpack.modpack.AveronSyncVipTab.tick(event.getServer());
            pl.skidam.automodpack.modpack.AveronSyncVipPets.tick(event.getServer());
        }

        @SubscribeEvent
        public static void onServerStopped(net.neoforged.neoforge.event.server.ServerStoppedEvent event) {
            pl.skidam.automodpack.modpack.AveronSyncVipTab.shutdown(event.getServer());
            pl.skidam.automodpack.modpack.AveronSyncVipPets.shutdown(event.getServer());
        }

        @SubscribeEvent
        public static void onCommandsRegister(RegisterCommandsEvent event) {
            Commands.register(event.getDispatcher());
        }
    }
}
/*?}*/
