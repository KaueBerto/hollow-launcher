package pl.skidam.automodpack.client.pets;

/*? if neoforge {*/
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import pl.skidam.automodpack_core.pets.PetCatalog;
import pl.skidam.automodpack_core.pets.VipPetAccess;
import java.util.*;

public final class VipPetScreen extends Screen {
    private final String selected;
    private final List<Icon> icons = new ArrayList<>();
    private record Icon(String id, int x, int y) {}
    public VipPetScreen(String selected) { super(Component.literal("Pets VIP nível 1 • Averon")); this.selected = selected; }
    @Override protected void init() {
        icons.clear();
        var available=VipPetAccess.available(VipPetAccess.CURRENT_VIP_LEVEL);
        int rows=(available.size()+1)/2;
        int cell = Math.min(220, (width-28)/2), step = Math.min(40, (height-88)/Math.max(1,rows)), top = 48;
        for (int i=0;i<available.size();i++) {
            var pet = available.get(i); int x=width/2-cell-4+(i%2)*(cell+8), y=top+(i/2)*step;
            var button = Button.builder(Component.literal("     " + (selected.equals(pet.id()) ? "✓ " : "") + pet.name()), b -> send("usar " + pet.id()))
                    .bounds(x,y,cell,Math.max(18,step-3)).tooltip(Tooltip.create(Component.literal(pet.category()+" • "+pet.id()))).build();
            addRenderableWidget(button); icons.add(new Icon(pet.id(), x+4, y+2));
        }
        int buttonWidth = Math.min(104, (width-32)/4), y=height-32;
        String[] labels={"Guardar", "Carinho", "Emote", "Fechar"}; String[] commands={"guardar", "carinho", "emote", ""};
        for (int i=0;i<4;i++) {
            final String command=commands[i];
            addRenderableWidget(Button.builder(Component.literal(labels[i]), b -> { if(command.isEmpty()) onClose(); else send(command); })
                    .bounds(width/2-2*buttonWidth-6+i*(buttonWidth+4),y,buttonWidth,20).build());
        }
    }
    private void send(String command) {
        if (minecraft != null && minecraft.player != null) minecraft.player.connection.sendCommand("petvip " + command);
        onClose();
    }
    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float partial) {
        renderBackground(graphics,mouseX,mouseY,partial); super.render(graphics,mouseX,mouseY,partial);
        graphics.drawCenteredString(font,title,width/2,10,0x55FFFF);
        graphics.drawCenteredString(font,Component.literal("Um companheiro cosmético enquanto seu VIP estiver ativo."),width/2,23,0xBBBBBB);
        for (var icon:icons) graphics.blit(ResourceLocation.fromNamespaceAndPath("averonsync","textures/pets/icons/"+icon.id+".png"),icon.x,icon.y,0,0,16,16,16,16);
    }
    @Override public boolean isPauseScreen() { return false; }
}
/*?}*/
