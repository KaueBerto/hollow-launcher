package pl.skidam.automodpack.modpack;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.TagParser;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import pl.skidam.automodpack.networking.server.AveronSyncEntryQueue;
import pl.skidam.automodpack_core.queue.StarterKitDefinition;
import pl.skidam.automodpack_core.queue.VipInventoryPlan;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import static net.minecraft.commands.Commands.literal;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

public final class AveronSyncVipKitCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("kitvip")
                .requires(source -> source.getServer().isDedicatedServer())
                .executes(ctx -> claim(ctx.getSource())));
    }

    static boolean authenticated(ServerPlayer player) throws ReflectiveOperationException {
        try {
            Class<?> auth = Class.forName("com.easylogin.auth.AuthManager");
            Object manager = auth.getField("INSTANCE").get(null);
            return manager != null && Boolean.TRUE.equals(auth.getMethod("isAuthenticated", ServerPlayer.class).invoke(manager, player));
        } catch (ClassNotFoundException e) {
            // Offline nicknames require EasyLogin. Never treat missing integration as authenticated.
            return player.getServer().usesAuthentication();
        }
    }

    @SuppressWarnings("unchecked")
    static List<ItemStack> readKit(ServerPlayer player) throws Exception {
        Class.forName("com.natamus.starterkit_common_neoforge.functions.StarterGearFunctions");
        Path file = Path.of("config", "starterkit", "kits", "inactive", "Vip.txt");
        if (Files.size(file) > 1_048_576) throw new IOException("VIP kit file too large");
        String source = Files.readString(file);
        var definitions = StarterKitDefinition.parse(source);
        Class<?> reader = Class.forName("com.natamus.collective_common_neoforge.functions.GearFunctions");
        List<ItemStack> decoded = (List<ItemStack>) reader.getMethod("getItemStackListFromGearString", Level.class, String.class)
                .invoke(null, player.level(), source);
        if (decoded.size() != definitions.size()) throw new IOException("Starter Kit did not decode every VIP item");
        List<ItemStack> result = new ArrayList<>();
        for (int i = 0; i < decoded.size(); i++) {
            var tag = TagParser.parseTag(definitions.get(i));
            var id = ResourceLocation.parse(tag.getString("id"));
            var stack = decoded.get(i);
            int count = tag.getInt("count");
            if (stack.isEmpty() || !BuiltInRegistries.ITEM.containsKey(id)
                    || !BuiltInRegistries.ITEM.getKey(stack.getItem()).equals(id)
                    || count < 1 || stack.getCount() != count || count > stack.getMaxStackSize())
                throw new IOException("Invalid/missing VIP kit item: " + id);
            result.add(stack.copy());
        }
        return result;
    }

    /** Stage a full inventory result without touching the player's current items. */
    static Optional<List<ItemStack>> plan(List<ItemStack> inventory, List<ItemStack> rewards) {
        var current = inventory.stream().map(AveronSyncVipKitCommand::stack).toList();
        var extra = rewards.stream().map(AveronSyncVipKitCommand::stack).toList();
        return VipInventoryPlan.plan(current, extra, ItemStack::isSameItemSameComponents)
                .map(slots -> slots.stream().map(slot -> slot.count() == 0 ? ItemStack.EMPTY
                        : slot.kind().copyWithCount(slot.count())).toList());
    }

    private static VipInventoryPlan.Stack<ItemStack> stack(ItemStack item) {
        return item.isEmpty() ? new VipInventoryPlan.Stack<>(null, 0, 64)
                : new VipInventoryPlan.Stack<>(item.copy(), item.getCount(), item.getMaxStackSize());
    }

    private static void setInventory(ServerPlayer player, List<ItemStack> slots) {
        for (int i = 0; i < 36; i++) player.getInventory().setItem(i, slots.get(i).copy());
        player.getInventory().setChanged();
        player.containerMenu.broadcastChanges();
    }

    private static int claim(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        var player = source.getPlayerOrException();
        String name = player.getGameProfile().getName();
        try {
            if (!authenticated(player)) return fail(source, "Entre no EasyLogin antes de resgatar o kit.");
            var manager = AveronSyncEntryQueue.get(source.getServer());
            var vips = manager.vips(); var claims = manager.kitClaims();
            if (vips == null || claims == null) return fail(source, "Cadastro VIP indisponivel. Avise a administracao.");
            long now = System.currentTimeMillis();
            if (!vips.isVip(name, now)) return fail(source, "Voce precisa de um VIP ativo para resgatar este kit.");
            if (claims.nextClaimAt(name) > now) return fail(source, "Kit ja resgatado. Novo resgate a partir de "
                    + java.time.Instant.ofEpochMilli(claims.nextClaimAt(name)) + " (UTC), com VIP ativo.");
            var items = readKit(player);
            List<ItemStack> before = new ArrayList<>();
            for (int i = 0; i < 36; i++) before.add(player.getInventory().getItem(i).copy());
            var planned = plan(before, items);
            if (planned.isEmpty()) return fail(source, "Falta espaco no inventario. Libere espaco e tente novamente.");
            if (!claims.reserve(vips, name, now)) return fail(source, "VIP expirou ou kit ja resgatado.");
            try { setInventory(player, planned.get()); }
            catch (RuntimeException deliveryFailure) {
                // Only release the reservation after every original inventory slot is restored.
                setInventory(player, before);
                claims.rollback(name);
                throw deliveryFailure;
            }
            LOGGER.info("VIP kit delivered to {} ({} stacks); next redemption {}", name, items.size(), claims.nextClaimAt(name));
            source.sendSuccess(() -> Component.literal("[AveronSync] Kit VIP recebido! Proximo resgate em 30 dias, com VIP ativo."), false);
            return 1;
        } catch (Exception e) {
            LOGGER.error("VIP kit claim failed for {}", name, e);
            return fail(source, "Nao foi possivel entregar o kit VIP. Avise a administracao; nao repita o comando em sequencia.");
        }
    }
    private static int fail(CommandSourceStack source, String message) {
        source.sendFailure(Component.literal("[AveronSync] " + message)); return 0;
    }
    private AveronSyncVipKitCommand() {}
}
