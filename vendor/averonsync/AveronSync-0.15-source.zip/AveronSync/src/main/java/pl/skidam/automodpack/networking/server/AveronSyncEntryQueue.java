package pl.skidam.automodpack.networking.server;

import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.login.ClientboundLoginDisconnectPacket;
import net.minecraft.server.MinecraftServer;
import pl.skidam.automodpack_core.queue.AdmissionQueue;
import pl.skidam.automodpack_core.queue.QueueSettings;
import pl.skidam.automodpack_core.queue.VipRegistry;
import pl.skidam.automodpack_core.queue.VipKitClaims;

import java.util.*;
import static pl.skidam.automodpack_core.GlobalVariables.serverConfig;

/** All access is on the Minecraft server thread. Never sleeps or blocks a tick. */
public final class AveronSyncEntryQueue {
    private static final Map<MinecraftServer, AveronSyncEntryQueue> SERVERS = new IdentityHashMap<>();
    private record Session(Connection connection, com.mojang.authlib.GameProfile profile) {}
    private final AdmissionQueue queue;
    private final VipRegistry vips;
    private final VipKitClaims kitClaims;
    private final pl.skidam.automodpack_core.queue.AttemptLimiter attempts = new pl.skidam.automodpack_core.queue.AttemptLimiter();
    private final Map<UUID, Session> sessions = new HashMap<>();

    private AveronSyncEntryQueue() {
        VipRegistry loaded = null;
        try {
            loaded = new VipRegistry(pl.skidam.automodpack_core.GlobalVariables.serverConfigFile.resolveSibling("averonsync-vips.json"));
        } catch (java.io.IOException e) {
            pl.skidam.automodpack_core.GlobalVariables.LOGGER.error("VIP registry could not be loaded; VIP priority disabled; original file preserved", e);
        }
        vips = loaded;
        VipKitClaims loadedClaims = null;
        try {
            loadedClaims = new VipKitClaims(pl.skidam.automodpack_core.GlobalVariables.serverConfigFile.resolveSibling("averonsync-vip-kit-claims.json"));
        } catch (java.io.IOException e) {
            pl.skidam.automodpack_core.GlobalVariables.LOGGER.error("VIP kit claims could not be loaded; kit redemption disabled; original file preserved", e);
        }
        kitClaims = loadedClaims;
        queue = (serverConfig.entryQueue == null ? new QueueSettings() : serverConfig.entryQueue)
                .createQueue(name -> vips != null && vips.isVip(name, System.currentTimeMillis()));
    }
    public VipRegistry vips() { return vips; }
    public VipKitClaims kitClaims() { return kitClaims; }
    public static boolean enabled(MinecraftServer server) {
        return server.isDedicatedServer() && (serverConfig.entryQueue == null || serverConfig.entryQueue.enabled);
    }
    public static AveronSyncEntryQueue get(MinecraftServer server) {
        return SERVERS.computeIfAbsent(server, ignored -> new AveronSyncEntryQueue());
    }
    public static void shutdown(MinecraftServer server) { SERVERS.remove(server); }
    public static long now() { return System.nanoTime() / 1_000_000; }

    public static void tick(MinecraftServer server) {
        AveronSyncEntryQueue manager = SERVERS.get(server);
        if (manager == null) return;
        long now = now();
        Set<Connection> joinedConnections = Collections.newSetFromMap(new IdentityHashMap<>());
        for (var player : server.getPlayerList().getPlayers()) joinedConnections.add(player.connection.getConnection());
        Iterator<Map.Entry<UUID, Session>> iterator = manager.sessions.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            Session session = entry.getValue();
            // Match the connection, including when an offline authentication mod changes the UUID.
            boolean joined = joinedConnections.contains(session.connection());
            if (!session.connection().isConnected() || joined || AveronSyncAdmissionAccess.bypasses(server.getPlayerList(), session.profile())) {
                manager.queue.remove(entry.getKey(), now);
                iterator.remove();
            }
        }
        var settings = serverConfig.entryQueue == null ? new QueueSettings() : serverConfig.entryQueue;
        boolean room = settings.hasRoom(AveronSyncAdmissionAccess.regularOnline(server.getPlayerList()), manager.queue.activeCount(), server.getMaxPlayers());
        for (var expired : manager.queue.advance(now, room)) {
            Session session = manager.sessions.remove(expired.id());
            if (session != null) disconnect(session.connection(), "Tempo de espera esgotado. Tente conectar novamente.");
        }
    }

    public UUID enqueue(Connection connection, com.mojang.authlib.GameProfile profile) {
        String name = profile.getName();
        var remote = connection.getRemoteAddress();
        String address = remote instanceof java.net.InetSocketAddress inet
                ? inet.getHostString() : String.valueOf(remote);
        if (!attempts.allow(address, now())) {
            disconnect(connection, "Muitas tentativas de entrada. Aguarde um minuto.");
            return null;
        }
        AdmissionQueue.Rejection reason = queue.rejection(name);
        if (reason != null) {
            disconnect(connection, reason == AdmissionQueue.Rejection.DUPLICATE
                    ? "Ja existe uma conexao sua na fila." : "A fila esta cheia. Tente novamente em alguns instantes.");
            return null;
        }
        var ticket = queue.enqueue(name, now());
        sessions.put(ticket.id(), new Session(connection, profile));
        return ticket.id();
    }
    public AdmissionQueue.Snapshot snapshot(UUID id) { return queue.snapshot(id); }
    public void cancel(UUID id) { queue.remove(id, now()); sessions.remove(id); }
    public static void disconnect(Connection connection, String text) {
        Component reason = Component.literal("[AveronSync] " + text);
        connection.send(new ClientboundLoginDisconnectPacket(reason));
        connection.disconnect(reason);
    }
}
