package pl.skidam.automodpack_core.queue;

import java.util.*;
import java.util.regex.Pattern;

/** Strict subset of Starter Kit's gear format: inventory items, no equipment replacement/effects. */
public final class StarterKitDefinition {
    private static final Pattern LINE = Pattern.compile("^(\\d+|'(?:head|chest|legs|feet|offhand|effects)')\\s*:\\s*'(.*)'\\s*,?\\s*$");
    public static List<String> parse(String source) {
        if (source.length() > 1_048_576) throw new IllegalArgumentException("VIP kit file too large");
        Set<String> slots = new HashSet<>();
        List<String> items = new ArrayList<>();
        for (String line : source.split("\\R")) {
            line = line.trim();
            if (line.isEmpty()) continue;
            var match = LINE.matcher(line);
            if (!match.matches()) throw new IllegalArgumentException("Invalid VIP kit line");
            String key = match.group(1), nbt = match.group(2);
            if (!key.startsWith("'")) {
                int index = Integer.parseInt(key);
                if (index > 35) throw new IllegalArgumentException("VIP kit slot outside inventory");
                key = Integer.toString(index);
            } else if (!nbt.isEmpty()) throw new IllegalArgumentException("VIP kit cannot replace equipment or apply effects");
            if (!slots.add(key)) throw new IllegalArgumentException("Duplicate VIP kit slot");
            if (!nbt.isEmpty()) items.add(nbt);
        }
        if (items.isEmpty()) throw new IllegalArgumentException("VIP kit is empty");
        return List.copyOf(items);
    }
    private StarterKitDefinition() {}
}
