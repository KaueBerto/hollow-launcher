package pl.skidam.automodpack_core.pets;

import static pl.skidam.automodpack_core.pets.PetAnimation.Vec;

/** Blockbench 4.10 animation channels use different signs from model bind rotations.
 * Reference: Blockbench v4.10.4 BoneAnimator.displayRotation/displayPosition.
 */
public final class BlockbenchPose {
    public static Vec rotation(Vec bind, Vec animated) {
        return new Vec(bind.x() - animated.x(), bind.y() - animated.y(), bind.z() + animated.z());
    }
    public static Vec position(Vec animated) { return new Vec(-animated.x(), animated.y(), animated.z()); }

    /** Quad vertices in top-left, bottom-left, bottom-right, top-right UV order.
     * Reference: Blockbench BufferGeometry.setShape and CubePreviewController.updateUV.
     */
    public static Vec[] face(String name, Vec from, Vec to) {
        double x0=from.x(), y0=from.y(), z0=from.z(), x1=to.x(), y1=to.y(), z1=to.z();
        // Match Blockbench's minimal thickness for authored eye/wing planes.
        if (x0==x1) x1+=.001;
        if (y0==y1) y1+=.001;
        if (z0==z1) z1+=.001;
        return switch (name) {
            case "north" -> new Vec[]{new Vec(x1,y1,z0),new Vec(x1,y0,z0),new Vec(x0,y0,z0),new Vec(x0,y1,z0)};
            case "south" -> new Vec[]{new Vec(x0,y1,z1),new Vec(x0,y0,z1),new Vec(x1,y0,z1),new Vec(x1,y1,z1)};
            case "east" -> new Vec[]{new Vec(x1,y1,z1),new Vec(x1,y0,z1),new Vec(x1,y0,z0),new Vec(x1,y1,z0)};
            case "west" -> new Vec[]{new Vec(x0,y1,z0),new Vec(x0,y0,z0),new Vec(x0,y0,z1),new Vec(x0,y1,z1)};
            case "up" -> new Vec[]{new Vec(x0,y1,z0),new Vec(x0,y1,z1),new Vec(x1,y1,z1),new Vec(x1,y1,z0)};
            case "down" -> new Vec[]{new Vec(x0,y0,z1),new Vec(x0,y0,z0),new Vec(x1,y0,z0),new Vec(x1,y0,z1)};
            default -> throw new IllegalArgumentException("Unknown cube face");
        };
    }
    public static double[][] uv(double[] uv, int degrees) {
        double[][] points={{uv[0],uv[1]},{uv[0],uv[3]},{uv[2],uv[3]},{uv[2],uv[1]}};
        int shift=Math.floorMod(degrees/90,4);
        return new double[][]{points[shift],points[(shift+1)%4],points[(shift+2)%4],points[(shift+3)%4]};
    }
    private BlockbenchPose() {}
}
