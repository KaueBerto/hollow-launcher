package pl.skidam.automodpack_core.pets;

import java.util.*;

/** Numeric Blockbench tracks: linear, step and Catmull-Rom, in source model coordinates. */
public final class PetAnimation {
    public record Vec(double x, double y, double z) {
        public Vec { if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) throw new IllegalArgumentException("Non-finite vector"); }
        public static final Vec ZERO = new Vec(0, 0, 0), ONE = new Vec(1, 1, 1);
        public Vec add(Vec other) { return new Vec(x + other.x, y + other.y, z + other.z); }
    }
    public record Frame(double time, Vec value, String interpolation) {
        public Frame {
            if (!Double.isFinite(time) || time < 0 || !Set.of("linear", "step", "catmullrom").contains(interpolation))
                throw new IllegalArgumentException("Invalid frame");
        }
    }
    public static Vec sample(List<Frame> frames, double time, Vec fallback) {
        if (frames.isEmpty()) return fallback;
        if (time <= frames.get(0).time()) return frames.get(0).value();
        int last = frames.size() - 1;
        if (time >= frames.get(last).time()) return frames.get(last).value();
        int low = 0, high = last;
        while (high - low > 1) { int mid = (low + high) >>> 1; if (frames.get(mid).time() <= time) low = mid; else high = mid; }
        var a = frames.get(low); var b = frames.get(high);
        if (a.interpolation().equals("step")) return a.value();
        double t = (time - a.time()) / (b.time() - a.time());
        Vec before = frames.get(Math.max(0, low - 1)).value(), after = frames.get(Math.min(last, high + 1)).value();
        boolean smooth = a.interpolation().equals("catmullrom") || b.interpolation().equals("catmullrom");
        return new Vec(axis(before.x, a.value().x, b.value().x, after.x, t, smooth),
                axis(before.y, a.value().y, b.value().y, after.y, t, smooth),
                axis(before.z, a.value().z, b.value().z, after.z, t, smooth));
    }
    private static double axis(double p0, double p1, double p2, double p3, double t, boolean smooth) {
        if (!smooth) return p1 + (p2 - p1) * t;
        return .5 * ((2*p1) + (-p0+p2)*t + (2*p0-5*p1+4*p2-p3)*t*t + (-p0+3*p1-3*p2+p3)*t*t*t);
    }
    private PetAnimation() {}
}
