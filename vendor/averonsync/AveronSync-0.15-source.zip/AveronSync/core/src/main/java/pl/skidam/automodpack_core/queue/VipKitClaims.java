package pl.skidam.automodpack_core.queue;

import java.io.IOException;
import java.nio.file.Path;

/** Durable 30-day claim cooldown; reserving before delivery prevents repeated grants. */
public final class VipKitClaims {
    private final VipRegistry claims;
    public VipKitClaims(Path file) throws IOException { claims = new VipRegistry(file); }
    public long nextClaimAt(String name) { return claims.expiresAt(name); }
    public boolean reserve(VipRegistry vips, String name, long now) throws IOException {
        if (!vips.isVip(name, now) || claims.isVip(name, now)) return false;
        claims.grant(name, now);
        return true;
    }
    /** Only call after restoring the inventory on a synchronous delivery failure. */
    public void rollback(String name) throws IOException { claims.revoke(name); }
}
