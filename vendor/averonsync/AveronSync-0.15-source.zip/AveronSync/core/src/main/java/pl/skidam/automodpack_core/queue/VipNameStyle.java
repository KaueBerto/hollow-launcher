package pl.skidam.automodpack_core.queue;

import java.util.*;
import java.util.function.UnaryOperator;

/** Recolors only the displayed name, even when it crosses styled component boundaries. */
public final class VipNameStyle {
    public record Part<T>(String text, T style) {}

    public static <T> List<Part<T>> color(List<Part<T>> parts, String name, UnaryOperator<T> recolor) {
        if (name == null || name.isEmpty()) return parts;
        String text = parts.stream().map(Part::text).collect(java.util.stream.Collectors.joining());
        int start = text.indexOf(name);
        // An ambiguous component is better left untouched than coloring a prefix or another name.
        if (start < 0 || text.indexOf(name, start + 1) >= 0) return parts;
        int end = start + name.length(), offset = 0;
        List<Part<T>> result = new ArrayList<>();
        for (var part : parts) {
            int length = part.text().length();
            int from = Math.max(0, start - offset), to = Math.min(length, end - offset);
            if (from < to) {
                if (from > 0) result.add(new Part<>(part.text().substring(0, from), part.style()));
                result.add(new Part<>(part.text().substring(from, to), recolor.apply(part.style())));
                if (to < length) result.add(new Part<>(part.text().substring(to), part.style()));
            } else result.add(part);
            offset += length;
        }
        return List.copyOf(result);
    }

    private VipNameStyle() {}
}
