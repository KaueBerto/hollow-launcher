package pl.skidam.automodpack_core.pets;

import java.util.*;

public final class PetCatalog {
    public record Pet(String id, String name, String category) {}
    public static final List<Pet> ALL = List.of(
            new Pet("basalt_delta", "Deltas de basalto", "Nether"),
            new Pet("blackstone", "Pedra-negra", "Nether"),
            new Pet("crimson_fungus", "Fungo carmesim", "Nether"),
            new Pet("magma", "Magma", "Nether"),
            new Pet("nether_portal", "Portal do Nether", "Nether"),
            new Pet("nether_waste", "Ruínas do Nether", "Nether"),
            new Pet("soul_valley", "Vale das almas", "Nether"),
            new Pet("warped_fungus", "Fungo distorcido", "Nether"),
            new Pet("badlands", "Terras áridas", "Biomas II"),
            new Pet("beach", "Praia", "Biomas II"),
            new Pet("birch", "Bétula", "Biomas II"),
            new Pet("cherry_blossom", "Cerejeira", "Biomas II"),
            new Pet("dark_oak", "Carvalho escuro", "Biomas II"),
            new Pet("deep_dark", "Profundezas sombrias", "Biomas II"),
            new Pet("dripstone", "Espeleotema", "Biomas II"),
            new Pet("taiga", "Taiga", "Biomas II"));
    public static Optional<Pet> find(String id) { return ALL.stream().filter(p -> p.id().equals(id)).findFirst(); }
    public static boolean contains(String id) { return find(id).isPresent(); }
    private PetCatalog() {}
}
