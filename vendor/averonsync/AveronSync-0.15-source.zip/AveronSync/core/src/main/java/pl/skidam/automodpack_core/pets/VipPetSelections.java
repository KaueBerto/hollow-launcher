package pl.skidam.automodpack_core.pets;

import com.google.gson.*;
import pl.skidam.automodpack_core.queue.VipRegistry;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Server-thread-only selection persistence; entitlement is always checked separately. */
public final class VipPetSelections {
    private final Path file;
    private Map<String, String> selected = new TreeMap<>();
    public VipPetSelections(Path file) throws IOException {
        this.file = file.toAbsolutePath();
        if (!Files.exists(file)) return;
        try {
            if (Files.size(file) > 1_048_576) throw new IllegalArgumentException("Pet selections too large");
            var root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            if (root.get("version").getAsInt() != 1) throw new IllegalArgumentException("Unknown version");
            for (var entry : root.getAsJsonObject("players").entrySet()) {
                String name = VipRegistry.normalize(entry.getKey()), pet = entry.getValue().getAsString();
                if (!PetCatalog.contains(pet) || selected.putIfAbsent(name, pet) != null)
                    throw new IllegalArgumentException("Unknown pet or duplicate nickname");
            }
        } catch (RuntimeException e) { throw new IOException("Invalid VIP pet selections; original file preserved", e); }
    }
    public String get(String nickname) { return selected.get(VipRegistry.normalize(nickname)); }
    public void set(String nickname, String pet) throws IOException {
        String name = VipRegistry.normalize(nickname);
        if (pet != null && !PetCatalog.contains(pet)) throw new IllegalArgumentException("Unknown pet");
        var updated = new TreeMap<>(selected);
        if (pet == null) updated.remove(name); else updated.put(name, pet);
        if (updated.equals(selected)) return;
        JsonObject root = new JsonObject(), players = new JsonObject();
        root.addProperty("version", 1); updated.forEach(players::addProperty); root.add("players", players);
        Files.createDirectories(file.getParent());
        Path temp = Files.createTempFile(file.getParent(), "averonsync-pets-", ".tmp");
        try {
            Files.writeString(temp, new GsonBuilder().setPrettyPrinting().create().toJson(root));
            if (Files.exists(file) && Files.getFileAttributeView(file, java.nio.file.attribute.PosixFileAttributeView.class) != null)
                Files.setPosixFilePermissions(temp, Files.getPosixFilePermissions(file));
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
            selected = updated;
        } finally { Files.deleteIfExists(temp); }
    }
}
