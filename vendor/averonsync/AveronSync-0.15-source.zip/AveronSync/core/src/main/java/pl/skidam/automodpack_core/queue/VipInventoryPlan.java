package pl.skidam.automodpack_core.queue;

import java.util.*;
import java.util.function.BiPredicate;

/** Immutable inventory simulation. The Minecraft adapter supplies component-aware item equality. */
public final class VipInventoryPlan {
    public record Stack<T>(T kind, int count, int maxSize) {
        public Stack {
            if (count < 0 || maxSize < 1 || (count > 0 && kind == null)) throw new IllegalArgumentException("Invalid stack");
        }
        Stack<T> withCount(int value) { return new Stack<>(kind, value, maxSize); }
    }

    public static <T> Optional<List<Stack<T>>> plan(List<Stack<T>> inventory, List<Stack<T>> rewards,
                                                   BiPredicate<T, T> sameItemAndComponents) {
        List<Stack<T>> result = new ArrayList<>(inventory);
        for (var reward : rewards) {
            int remaining = reward.count();
            if (remaining == 0) continue;
            for (int i = 0; i < result.size() && remaining > 0; i++) {
                var slot = result.get(i);
                if (slot.count() == 0 || !sameItemAndComponents.test(slot.kind(), reward.kind())) continue;
                int amount = Math.min(remaining, Math.max(0, Math.min(64, slot.maxSize()) - slot.count()));
                result.set(i, slot.withCount(slot.count() + amount)); remaining -= amount;
            }
            for (int i = 0; i < result.size() && remaining > 0; i++) {
                if (result.get(i).count() > 0) continue;
                int amount = Math.min(remaining, Math.min(64, reward.maxSize()));
                result.set(i, reward.withCount(amount)); remaining -= amount;
            }
            if (remaining > 0) return Optional.empty();
        }
        return Optional.of(List.copyOf(result));
    }
    private VipInventoryPlan() {}
}
