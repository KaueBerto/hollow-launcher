package pl.skidam.automodpack_core.pets;

import java.util.*;

/** The existing 30-day VIP is level 1. Higher levels require an explicit future policy. */
public final class VipPetAccess {
    public static final int CURRENT_VIP_LEVEL = 1;
    private static final Set<String> LEVEL_ONE = Set.of("badlands", "birch", "dripstone");
    public static boolean allows(int level, String pet) { return level == 1 && LEVEL_ONE.contains(pet); }
    public static List<PetCatalog.Pet> available(int level) { return PetCatalog.ALL.stream().filter(p -> allows(level,p.id())).toList(); }
    public static String visibleSelection(int level, String selected) { return selected != null && allows(level,selected) ? selected : ""; }
    private VipPetAccess() {}
}
