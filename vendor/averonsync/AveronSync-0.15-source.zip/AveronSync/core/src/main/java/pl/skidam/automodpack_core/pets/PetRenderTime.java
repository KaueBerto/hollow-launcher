package pl.skidam.automodpack_core.pets;

/** Keeps sub-frame precision even when the world has accumulated millions of ticks. */
public final class PetRenderTime {
    public static double ticks(long gameTime, float partialTick) {
        // long + float is evaluated as float before assignment, rounding old worlds to 4+ ticks.
        return (double) gameTime + (double) partialTick;
    }

    private PetRenderTime() {}
}
