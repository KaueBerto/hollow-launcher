package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import static org.junit.jupiter.api.Assertions.*;

class VipAdmissionQueueTest {
    @TempDir Path temp;

    @Test void vipsMoveAheadWhileBothGroupsRemainFifoAndPositionsMatchAdmission() {
        Set<String> vip = Set.of("vip1", "vip2");
        var queue = new AdmissionQueue(10, 1, 5, 1000, 100, vip::contains);
        var regular1 = queue.enqueue("regular1", 0);
        var vip1 = queue.enqueue("VIP1", 1);
        var regular2 = queue.enqueue("regular2", 2);
        var vip2 = queue.enqueue("VIP2", 3);
        var expected = List.of(vip1, vip2, regular1, regular2);
        for (int i = 0; i < expected.size(); i++) assertEquals(i + 1, queue.snapshot(expected.get(i).id()).position());
        long now = 4;
        for (var ticket : expected) {
            queue.advance(now, true);
            assertEquals(AdmissionQueue.State.ACTIVE, queue.snapshot(ticket.id()).state());
            queue.remove(ticket.id(), now);
            now += 5;
        }
    }

    @Test void grantRevokeAndExpiryReorderWaitersWithoutReconnect() throws Exception {
        var registry = new VipRegistry(temp.resolve("vips.json"));
        var wall = new AtomicLong(100);
        var queue = new AdmissionQueue(10, 1, 5, 1000, 100,
                name -> registry.isVip(name, wall.get()));
        var first = queue.enqueue("first", 0);
        var second = queue.enqueue("second", 1);
        assertEquals(2, queue.snapshot(second.id()).position());
        long expiry = registry.grant("SECOND", wall.get());
        assertEquals(1, queue.snapshot(second.id()).position());
        registry.revoke("SECOND");
        assertEquals(1, queue.snapshot(first.id()).position());
        registry.grant("SECOND", wall.get());
        wall.set(expiry);
        assertEquals(1, queue.snapshot(first.id()).position());
        queue.advance(2, true);
        assertEquals(AdmissionQueue.State.ACTIVE, queue.snapshot(first.id()).state());
    }

    @Test void vipDoesNotBypassCapacitySettlingOrFullServerOrPreemptActivePlayer() {
        var queue = new AdmissionQueue(2, 1, 5, 1000, 100, name -> name.startsWith("vip"));
        var regular = queue.enqueue("regular", 0);
        queue.advance(0, true);
        var vip = queue.enqueue("vip", 1);
        assertEquals(AdmissionQueue.Rejection.FULL, queue.rejection("vip2"));
        assertEquals(AdmissionQueue.Rejection.DUPLICATE, queue.rejection("VIP"));
        queue.advance(50, true);
        assertEquals(AdmissionQueue.State.WAITING, queue.snapshot(vip.id()).state());
        queue.remove(regular.id(), 50);
        queue.advance(54, true);
        assertEquals(AdmissionQueue.State.WAITING, queue.snapshot(vip.id()).state());
        queue.advance(55, false);
        assertEquals(AdmissionQueue.State.WAITING, queue.snapshot(vip.id()).state());
        queue.advance(56, true);
        assertEquals(AdmissionQueue.State.ACTIVE, queue.snapshot(vip.id()).state());
    }

    @Test void vipStillExpiresFromQueueAndDoesNotBlockFollowingPlayer() {
        var queue = new AdmissionQueue(10, 1, 5, 100, 50, name -> name.startsWith("vip"));
        var vip = queue.enqueue("vip", 0);
        var regular = queue.enqueue("regular", 50);
        assertEquals(List.of(vip), queue.advance(100, false));
        assertEquals(1, queue.snapshot(regular.id()).position());
        queue.advance(101, true);
        assertEquals(AdmissionQueue.State.ACTIVE, queue.snapshot(regular.id()).state());
    }

    @Test void opsOnlyClosureDoesNotAdmitVips() {
        var settings = new QueueSettings();
        settings.opsOnly = true;
        var queue = settings.createQueue(name -> true);
        var vip = queue.enqueue("vip", 0);
        queue.advance(0, settings.hasRoom(0, queue.activeCount(), 100));
        assertEquals(AdmissionQueue.State.WAITING, queue.snapshot(vip.id()).state());
        assertEquals(1, queue.snapshot(vip.id()).position());
    }
}
