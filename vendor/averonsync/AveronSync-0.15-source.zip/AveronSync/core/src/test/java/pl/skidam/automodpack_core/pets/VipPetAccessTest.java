package pl.skidam.automodpack_core.pets;

import org.junit.jupiter.api.Test;
import java.util.*;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

class VipPetAccessTest {
    @Test void levelOneContainsOnlyTheThreeRequestedPets() {
        assertEquals(List.of("badlands","birch","dripstone"),VipPetAccess.available(1).stream().map(PetCatalog.Pet::id).toList());
        for (var pet:PetCatalog.ALL) assertEquals(Set.of("badlands","birch","dripstone").contains(pet.id()),VipPetAccess.allows(1,pet.id()));
    }
    @Test void undefinedLevelsNeverUnlockTheCatalogImplicitly() {
        for(int level:new int[]{-1,0,2,3,Integer.MAX_VALUE}) {
            assertTrue(VipPetAccess.available(level).isEmpty());
            for(var pet:PetCatalog.ALL)assertFalse(VipPetAccess.allows(level,pet.id()));
        }
        assertFalse(VipPetAccess.allows(1,"unknown"));
    }
    @Test void oldSelectionsAreKeptInStorageButCannotBeDisplayedOrEquipped() throws Exception {
        var folder=Files.createTempDirectory("vip-pet-policy-");
        try {
            var store=new VipPetSelections(folder.resolve("pets.json"));store.set("magow","magma");
            assertEquals("magma",store.get("magow"));assertEquals("",VipPetAccess.visibleSelection(1,store.get("magow")));
            assertEquals("",VipPetAccess.visibleSelection(1,null));
            store.set("magow","birch");assertEquals("birch",VipPetAccess.visibleSelection(1,store.get("magow")));
            assertEquals(16,PetCatalog.ALL.size());assertTrue(PetCatalog.contains("magma"));
        } finally {Files.deleteIfExists(folder.resolve("pets.json"));Files.deleteIfExists(folder);}
    }
}
