package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class VipInventoryPlanTest {
    private VipInventoryPlan.Stack<String> item(String id, int count) { return new VipInventoryPlan.Stack<>(id, count, 64); }
    private List<VipInventoryPlan.Stack<String>> empty(int slots) {
        return new ArrayList<>(Collections.nCopies(slots, new VipInventoryPlan.Stack<>(null, 0, 64)));
    }
    @Test void mergesStacksAndPreservesEveryOriginalInput() {
        var inventory = empty(36); inventory.set(0, item("bread", 48)); inventory.set(1, item("diamond", 3));
        var rewards = List.of(item("bread", 32));
        var plan = VipInventoryPlan.plan(inventory, rewards, String::equals).orElseThrow();
        assertEquals(item("bread", 64), plan.get(0)); assertEquals(item("bread", 16), plan.get(2));
        assertEquals(item("diamond", 3), plan.get(1));
        assertEquals(48, inventory.get(0).count()); assertEquals(0, inventory.get(2).count());
        assertEquals(32, rewards.get(0).count());
    }
    @Test void fullInventoryRejectsWithoutPartialChanges() {
        var inventory = Collections.nCopies(36, item("diamond", 64));
        assertTrue(VipInventoryPlan.plan(inventory, List.of(item("bread", 32)), String::equals).isEmpty());
        assertTrue(inventory.stream().allMatch(s -> s.kind().equals("diamond") && s.count() == 64));
    }
    @Test void compatibleStackFitsWithoutAnEmptySlot() {
        var inventory = new ArrayList<>(Collections.nCopies(36, item("diamond", 64)));
        inventory.set(10, item("bread", 32));
        var plan = VipInventoryPlan.plan(inventory, List.of(item("bread", 32)), String::equals).orElseThrow();
        assertEquals(64, plan.get(10).count()); assertEquals(32, inventory.get(10).count());
    }
    @Test void toolsRespectTheirSingleItemStackLimit() {
        var reward = new VipInventoryPlan.Stack<>("sword", 2, 1);
        var plan = VipInventoryPlan.plan(empty(2), List.of(reward), String::equals).orElseThrow();
        assertEquals(1, plan.get(0).count()); assertEquals(1, plan.get(1).count());
        assertTrue(VipInventoryPlan.plan(empty(1), List.of(reward), String::equals).isEmpty());
    }
    @Test void differentComponentsAreNotMerged() {
        var inventory = empty(1); inventory.set(0, item("sword:enchanted", 1));
        assertTrue(VipInventoryPlan.plan(inventory, List.of(item("sword:plain", 1)), String::equals).isEmpty());
        assertEquals(item("sword:enchanted", 1), inventory.get(0));
    }
    @Test void laterOverflowRejectsTheWholeKitWithoutMutatingEarlierStacks() {
        var inventory = List.of(item("bread", 32));
        assertTrue(VipInventoryPlan.plan(inventory, List.of(item("bread", 32), item("torch", 16)), String::equals).isEmpty());
        assertEquals(item("bread", 32), inventory.get(0));
    }
}
