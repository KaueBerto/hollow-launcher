package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.io.IOException;
import static org.junit.jupiter.api.Assertions.*;

class VipKitClaimsTest {
    @TempDir Path temp;
    @Test void nonVipCannotReserveAndNoClaimFileIsCreated() throws Exception {
        var vips = new VipRegistry(temp.resolve("vips.json"));
        Path file = temp.resolve("claims.json");
        var claims = new VipKitClaims(file);
        assertFalse(claims.reserve(vips, "Alice", 100));
        assertFalse(Files.exists(file));
    }
    @Test void claimSurvivesRestartAndCaseChanges() throws Exception {
        var vips = new VipRegistry(temp.resolve("vips.json"));
        Path file = temp.resolve("claims.json");
        var claims = new VipKitClaims(file);
        vips.grant("Alice", 100);
        assertTrue(claims.reserve(vips, "ALICE", 101));
        assertFalse(claims.reserve(vips, "Alice", 102));
        var reopened = new VipKitClaims(file);
        assertFalse(reopened.reserve(vips, "alice", 103));
        assertEquals(101 + VipRegistry.DURATION_MILLIS, reopened.nextClaimAt("ALICE"));
    }
    @Test void renewOrRemoveAndRegrantCannotResetClaimCooldown() throws Exception {
        var vips = new VipRegistry(temp.resolve("vips.json"));
        var claims = new VipKitClaims(temp.resolve("claims.json"));
        vips.grant("Alice", 100);
        assertTrue(claims.reserve(vips, "Alice", 101));
        vips.revoke("Alice"); vips.grant("Alice", 200);
        assertFalse(claims.reserve(vips, "Alice", 201));
    }
    @Test void nextClaimNeedsBothElapsedCooldownAndActiveVip() throws Exception {
        var vips = new VipRegistry(temp.resolve("vips.json"));
        var claims = new VipKitClaims(temp.resolve("claims.json"));
        vips.grant("Alice", 100); claims.reserve(vips, "Alice", 100);
        long next = 100 + VipRegistry.DURATION_MILLIS;
        assertFalse(claims.reserve(vips, "Alice", next));
        vips.grant("Alice", next);
        assertTrue(claims.reserve(vips, "Alice", next));
    }
    @Test void failedReservationDoesNotConsumeClaim() throws Exception {
        var vips = new VipRegistry(temp.resolve("vips.json")); vips.grant("Alice", 100);
        Path parent = temp.resolve("blocked");
        var claims = new VipKitClaims(parent.resolve("claims.json"));
        Files.writeString(parent, "not a directory");
        assertThrows(IOException.class, () -> claims.reserve(vips, "Alice", 101));
        assertEquals(0, claims.nextClaimAt("Alice"));
    }
    @Test void rollbackAfterRestoringInventoryAllowsRetry() throws Exception {
        var vips = new VipRegistry(temp.resolve("vips.json")); vips.grant("Alice", 100);
        var claims = new VipKitClaims(temp.resolve("claims.json"));
        assertTrue(claims.reserve(vips, "Alice", 101));
        claims.rollback("Alice");
        assertTrue(claims.reserve(vips, "Alice", 102));
    }
}
