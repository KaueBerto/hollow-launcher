package pl.skidam.automodpack_core.pets;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.Vec;

class BlockbenchPoseTest {
    @Test void topAndBottomUseBlockbenchTopLeftRatherThanQuarterTurnedUvs() {
        Vec from=new Vec(-1,-2,-3),to=new Vec(4,5,6);
        assertArrayEquals(new Vec[]{new Vec(-1,5,-3),new Vec(-1,5,6),new Vec(4,5,6),new Vec(4,5,-3)},BlockbenchPose.face("up",from,to));
        assertArrayEquals(new Vec[]{new Vec(-1,-2,6),new Vec(-1,-2,-3),new Vec(4,-2,-3),new Vec(4,-2,6)},BlockbenchPose.face("down",from,to));
        assertEquals(new Vec(4,5,-3),BlockbenchPose.face("north",from,to)[0]);
        assertEquals(new Vec(-1,5,6),BlockbenchPose.face("south",from,to)[0]);
        assertEquals(new Vec(4,5,6),BlockbenchPose.face("east",from,to)[0]);
        assertEquals(new Vec(-1,5,-3),BlockbenchPose.face("west",from,to)[0]);
    }
    @Test void mirroredUvsAndAuthoredQuarterTurnsKeepTheirOrientation() {
        var uv=BlockbenchPose.uv(new double[]{44,10,34,0},0);
        assertArrayEquals(new double[]{44,10},uv[0]);assertArrayEquals(new double[]{44,0},uv[1]);
        assertArrayEquals(new double[]{34,0},uv[2]);assertArrayEquals(new double[]{34,10},uv[3]);
        var rotated=BlockbenchPose.uv(new double[]{44,10,34,0},90);
        assertArrayEquals(uv[1],rotated[0]);assertArrayEquals(uv[2],rotated[1]);
        assertArrayEquals(uv[3],rotated[2]);assertArrayEquals(uv[0],rotated[3]);
    }
    @Test void flatEyeAndWingPlanesRetainTheEditorsMinimumThickness() {
        var from=new Vec(1,2,3);var to=new Vec(4,5,3);
        assertEquals(3,BlockbenchPose.face("north",from,to)[0].z());
        assertEquals(3.001,BlockbenchPose.face("south",from,to)[0].z(),1e-12);
    }
    @Test void animationSignsChangeWithoutFlippingBindPose() {
        assertEquals(new Vec(5,70,50),BlockbenchPose.rotation(new Vec(15,50,20),new Vec(10,-20,30)));
        assertEquals(new Vec(-2,3,4),BlockbenchPose.position(new Vec(2,3,4)));
        assertEquals(new Vec(15,50,20),BlockbenchPose.rotation(new Vec(15,50,20),Vec.ZERO));
    }
    @Test void originalPackScalesOffsetsAndCrouchPoseAreDifferent() {
        var nether=PetFollowMotion.settings("magma");var biomes=PetFollowMotion.settings("taiga");
        assertEquals(.56,nether.scale());assertEquals(.65,biomes.scale());
        assertEquals(new Vec(.7,.75,-.3),PetFollowMotion.target(Vec.ZERO,0,nether,false));
        var turned=PetFollowMotion.target(Vec.ZERO,90,nether,false);
        assertEquals(.3,turned.x(),1e-9);assertEquals(.7,turned.z(),1e-9);
        assertEquals(new Vec(.95,.3,1.5),PetFollowMotion.target(Vec.ZERO,0,biomes,true));
        assertEquals(PetFollowMotion.target(Vec.ZERO,0,nether,false),PetFollowMotion.target(Vec.ZERO,0,nether,true));
    }
    @Test void followIsFrameRateIndependentAndSnapsOnlyAcrossLargeTeleports() {
        Vec start=Vec.ZERO,target=new Vec(2,0,0);
        Vec once=PetFollowMotion.step(start,target,.1,7);
        Vec twice=PetFollowMotion.step(PetFollowMotion.step(start,target,.05,7),target,.05,7);
        assertEquals(once.x(),twice.x(),1e-12);assertTrue(once.x()>0&&once.x()<2);
        assertEquals(start,PetFollowMotion.step(start,target,0,7));
        assertEquals(new Vec(100,0,0),PetFollowMotion.step(start,new Vec(100,0,0),.05,7));
    }
}
