package pl.skidam.automodpack_core.pets;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.*;

class PetRenderTimeTest {
    @Test void oldWorldsStillAdvanceOnEveryRenderedFrame() {
        for (long worldAge : new long[]{0, 1L << 24, 51_702_498L, 1L << 31}) {
            double previous = PetRenderTime.ticks(worldAge, 0);
            for (int frame = 1; frame <= 120; frame++) {
                double time = PetRenderTime.ticks(worldAge + frame / 3, (frame % 3) / 3f);
                assertTrue(time > previous, "Render clock froze at world age " + worldAge);
                assertEquals(1.0 / 60, (time - previous) / 20, 1e-7);
                previous = time;
            }
        }
    }

    @Test void partialTicksStayContinuousAcrossTheTickBoundary() {
        long worldAge = 51_702_498L;
        double before = PetRenderTime.ticks(worldAge, .99f);
        double after = PetRenderTime.ticks(worldAge + 1, .01f);
        assertEquals(.02, after - before, 1e-7);
        assertEquals(.5, PetRenderTime.ticks(worldAge, .75f) - PetRenderTime.ticks(worldAge, .25f), 1e-9);
    }

    @Test void animationAndFollowBothMoveBetweenTicksAtProductionWorldAge() {
        long worldAge = 51_702_498L;
        var track = List.of(new Frame(0, Vec.ZERO, "linear"), new Frame(10, new Vec(10, 0, 0), "linear"));
        double first = PetRenderTime.ticks(worldAge, .1f);
        double next = PetRenderTime.ticks(worldAge, .4f);
        double firstClipTime = (first / 20) % 10;
        double nextClipTime = (next / 20) % 10;
        assertTrue(sample(track, nextClipTime, Vec.ZERO).x() > sample(track, firstClipTime, Vec.ZERO).x());
        Vec moved = PetFollowMotion.step(Vec.ZERO, new Vec(2, 0, 0), (next - first) / 20, 7);
        assertTrue(moved.x() > 0 && moved.x() < 2, "Following must advance within a single server tick");
    }
}
