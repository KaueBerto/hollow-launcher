package pl.skidam.automodpack_core.pets;

import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.*;

class VipPetsTest {
    @TempDir Path temp;
    @Test void selectionIsCaseInsensitivePersistentAndCanBeHidden() throws Exception {
        var file = temp.resolve("pets.json"); var selections = new VipPetSelections(file);
        selections.set("MagoW", "magma"); assertEquals("magma", selections.get("magow"));
        assertEquals("magma", new VipPetSelections(file).get("MAGOW"));
        selections.set("magow", null); assertNull(new VipPetSelections(file).get("magow"));
    }
    @Test void rejectsUnknownPetsAndInvalidNicknameWithoutChangingFile() throws Exception {
        var file = temp.resolve("pets.json"); var selections = new VipPetSelections(file);
        selections.set("magow", "magma"); String before = Files.readString(file);
        assertThrows(IllegalArgumentException.class, () -> selections.set("magow", "../../evil"));
        assertThrows(IllegalArgumentException.class, () -> selections.set("../magow", "magma"));
        assertEquals(before, Files.readString(file)); assertEquals("magma", selections.get("magow"));
    }
    @Test void failedWriteKeepsPreviousSelectionInMemory() throws Exception {
        var parent = temp.resolve("folder"); var selections = new VipPetSelections(parent.resolve("pets.json"));
        selections.set("magow", "magma"); Files.delete(parent.resolve("pets.json")); Files.delete(parent); Files.writeString(parent, "blocked");
        assertThrows(java.io.IOException.class, () -> selections.set("magow", "taiga"));
        assertEquals("magma", selections.get("magow"));
    }
    @Test void invalidSelectionFileIsPreserved() throws Exception {
        var file=temp.resolve("pets.json"); String text="{\"version\":1,\"players\":{\"magow\":\"unknown\"}}";
        Files.writeString(file,text); assertThrows(java.io.IOException.class, () -> new VipPetSelections(file)); assertEquals(text,Files.readString(file));
    }
    @Test void linearStepAndClampingMatchAuthoredKeys() {
        var a=new Frame(0,new Vec(0,0,0),"linear"); var b=new Frame(2,new Vec(2,4,6),"linear");
        assertEquals(new Vec(1,2,3),sample(List.of(a,b),1,Vec.ZERO));
        assertEquals(a.value(),sample(List.of(a,b),-1,Vec.ONE)); assertEquals(b.value(),sample(List.of(a,b),3,Vec.ONE));
        assertEquals(a.value(),sample(List.of(new Frame(0,a.value(),"step"),b),1.99,Vec.ONE));
        assertEquals(b.value(),sample(List.of(a,b),2,Vec.ONE)); assertEquals(Vec.ONE,sample(List.of(),0,Vec.ONE));
    }
    @Test void catmullRomInterpolatesWithoutSnappingToKeys() {
        var keys=List.of(new Frame(0,new Vec(0,0,0),"catmullrom"),new Frame(1,new Vec(1,2,3),"catmullrom"),
                new Frame(2,new Vec(2,4,6),"catmullrom"),new Frame(3,new Vec(3,6,9),"catmullrom"));
        assertEquals(new Vec(1.5,3,4.5),sample(keys,1.5,Vec.ZERO));
    }
    @Test void importedModelsContainAllSixteenPetsAndEveryAnimationParses() throws Exception {
        var root=Path.of("..","src","main","resources","assets","averonsync","pets");
        org.junit.jupiter.api.Assumptions.assumeTrue(Files.isDirectory(root), "Private Cubees artwork must be imported for asset validation");
        int cubes=0;
        for (var pet:PetCatalog.ALL) {
            var model=CubeeModel.parse(JsonParser.parseString(Files.readString(root.resolve(pet.id()+".json"))).getAsJsonObject());
            assertEquals(pet.id(),model.id()); cubes+=count(model.nodes());
            for (var clip:model.animations().values()) for(var track:clip.tracks().values()) for(var channel:track.entrySet())
                for(double t:new double[]{0,clip.length()/3,clip.length()/2,clip.length()})
                    assertNotNull(sample(channel.getValue(),t,Vec.ZERO));
        }
        assertEquals(16,PetCatalog.ALL.size()); assertEquals(559,cubes);
    }
    private int count(List<CubeeModel.Node> nodes) { return nodes.stream().mapToInt(n -> n.cubes().size()+count(n.children())).sum(); }
}
