package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.io.IOException;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

class VipRegistryTest {
    @TempDir Path temp;
    private static final long DAY = 86_400_000L;

    @Test void persistsAndMatchesMixedCaseWithoutNeedingAnOnlinePlayer() throws Exception {
        Path file = temp.resolve("vips.json");
        var registry = new VipRegistry(file);
        assertFalse(Files.exists(file));
        assertFalse(registry.isVip("SnowA32", 100));
        assertEquals(100 + 30 * DAY, registry.grant("SnowA32", 100));
        var reopened = new VipRegistry(file);
        assertTrue(reopened.isVip("SNOWa32", 101));
        assertEquals(1, reopened.active(101).size());
        assertTrue(reopened.active(101).containsKey("snowa32"));
    }

    @Test void expiresAtExactBoundaryAndRenewsFromCurrentTimeAfterExpiration() throws Exception {
        var registry = new VipRegistry(temp.resolve("vips.json"));
        registry.grant("Player", 100);
        assertTrue(registry.isVip("Player", 100 + 30 * DAY - 1));
        assertFalse(registry.isVip("Player", 100 + 30 * DAY));
        assertTrue(registry.active(100 + 30 * DAY).isEmpty());
        assertEquals(100 + 61 * DAY, registry.grant("player", 100 + 31 * DAY));
    }

    @Test void activeRenewalResetsToThirtyDaysWithoutAccumulatingAndRemovalSurvivesReopen() throws Exception {
        Path file = temp.resolve("vips.json");
        var registry = new VipRegistry(file);
        registry.grant("Alice", 100);
        assertEquals(200 + 30 * DAY, registry.grant("ALICE", 200));
        assertEquals(200 + 30 * DAY, registry.grant("ALICE", 200));
        assertEquals(200 + 30 * DAY, new VipRegistry(file).expiresAt("alice"));
        assertTrue(registry.revoke("alice"));
        assertFalse(registry.revoke("alice"));
        assertFalse(new VipRegistry(file).isVip("Alice", 300));
    }

    @Test void rejectsInvalidInputWithoutWriting() throws Exception {
        Path file = temp.resolve("vips.json");
        var registry = new VipRegistry(file);
        for (String nickname : new String[]{"", "Alice Bob", "../admin", "a:b", "12345678901234567"})
            assertThrows(IllegalArgumentException.class, () -> registry.grant(nickname, 0));
        assertThrows(ArithmeticException.class, () -> registry.grant("Alice", Long.MAX_VALUE));
        assertFalse(Files.exists(file));
        assertEquals("rl", VipRegistry.normalize("Rl"));
    }

    @Test void corruptedFilesAreNotSilentlyResetOrOverwritten() throws Exception {
        Path file = temp.resolve("vips.json");
        for (String json : new String[]{"broken", "null", "{}", "{\"version\":2,\"players\":{}}",
                "{\"version\":1,\"players\":{\"Alice\":-1}}",
                "{\"version\":1,\"players\":{\"Alice\":1,\"ALICE\":2}}",
                "{\"version\":1,\"players\":{\"Alice\":\"123\"}}",
                "{\"version\":1,\"players\":{\"Alice\":1.5}}"}) {
            Files.writeString(file, json);
            assertThrows(IOException.class, () -> new VipRegistry(file));
            assertEquals(json, Files.readString(file));
        }
    }

    @Test void failedSaveDoesNotGrantOrRevokeInMemory() throws Exception {
        Path parent = temp.resolve("config");
        var registry = new VipRegistry(parent.resolve("vips.json"));
        Files.writeString(parent, "not a directory");
        assertThrows(IOException.class, () -> registry.grant("Alice", 0));
        assertFalse(registry.isVip("Alice", 0));
    }

    @Test void failedRevokeKeepsExistingVipInMemory() throws Exception {
        Path parent = temp.resolve("config"), file = parent.resolve("vips.json");
        var registry = new VipRegistry(file);
        registry.grant("Alice", 0);
        Files.move(file, temp.resolve("previous-vips.json"));
        Files.delete(parent);
        Files.writeString(parent, "not a directory");
        assertThrows(IOException.class, () -> registry.revoke("Alice"));
        assertTrue(registry.isVip("Alice", 0));
    }
}
