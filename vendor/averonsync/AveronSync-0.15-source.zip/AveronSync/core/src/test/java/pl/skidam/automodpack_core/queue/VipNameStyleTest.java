package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class VipNameStyleTest {
    @Test void preservesCharacterNamePrefixAndSuffixStyles() {
        var parts = List.of(new VipNameStyle.Part<>("[Mage] Arannis [Guild]", "original"));
        var result = VipNameStyle.color(parts, "Arannis", style -> "aqua");
        assertEquals(List.of(new VipNameStyle.Part<>("[Mage] ", "original"),
                new VipNameStyle.Part<>("Arannis", "aqua"),
                new VipNameStyle.Part<>(" [Guild]", "original")), result);
        assertEquals("[Mage] Arannis [Guild]", parts.get(0).text());
    }

    @Test void colorsNameAcrossComponentsAndRetainsOtherStyleProperties() {
        var parts = List.of(new VipNameStyle.Part<>("[Mage] Ara", "bold"),
                new VipNameStyle.Part<>("nnis!", "italic"));
        assertEquals(List.of(new VipNameStyle.Part<>("[Mage] ", "bold"),
                new VipNameStyle.Part<>("Ara", "bold+aqua"),
                new VipNameStyle.Part<>("nnis", "italic+aqua"),
                new VipNameStyle.Part<>("!", "italic")),
                VipNameStyle.color(parts, "Arannis", style -> style + "+aqua"));
    }

    @Test void missingOrAmbiguousNameLeavesOriginalUntouched() {
        var parts = List.of(new VipNameStyle.Part<>("Arannis Arannis", "original"));
        assertSame(parts, VipNameStyle.color(parts, "Arannis", style -> "aqua"));
        assertSame(parts, VipNameStyle.color(parts, "magow", style -> "aqua"));
        assertSame(parts, VipNameStyle.color(parts, "", style -> "aqua"));
        assertSame(parts, VipNameStyle.color(parts, null, style -> "aqua"));
    }

    @Test void acceptsUnicodeCharacterNameWithoutChangingAccountNickname() {
        var parts = List.of(new VipNameStyle.Part<>("Éowyn 🐉", "original"));
        assertEquals(List.of(new VipNameStyle.Part<>("Éowyn 🐉", "aqua")),
                VipNameStyle.color(parts, "Éowyn 🐉", style -> "aqua"));
    }
}
