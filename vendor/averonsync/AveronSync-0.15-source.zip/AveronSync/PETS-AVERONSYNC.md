# Pets cosméticos VIP — AveronSync 0.15

Minecraft 1.21.1 NeoForge. Integra o cadastro VIP existente por nick e duração fixa
de 30 dias. Não instala MCPets, MythicMobs, ModelEngine, ItemsAdder ou Oraxen.

## Uso

- `/petvip`: menu do VIP nível 1 com Terras áridas (`badlands`), Bétula (`birch`) e Espeleotema (`dripstone`).
- `/petvip usar <id>`: equipa um pet, substituindo o anterior; há sugestões no comando.
- `/petvip guardar`: desequipa.
- `/petvip carinho` e `/petvip emote`: reproduzem as animações correspondentes; intervalo de dois segundos.
- `/petvip listar`: nomes e identificadores, sem abrir o menu.

O administrador continua usando `/async vip add <nick>` e `/async vip remove <nick>`.
O VIP atual de 30 dias é tratado como nível 1. Só os três pets acima aparecem
no menu, lista e sugestões. O servidor também recusa os outros IDs digitados
diretamente. Os 16 pets, modelos e animações continuam no código e no JAR para
futuros níveis; nenhum nível adicional é concedido implicitamente. Escolhas antigas
de pets fora do nível 1 são preservadas no arquivo, mas ficam ocultas e inativas.
VIP ativo e autenticação EasyLogin são exigidos no servidor. Em servidor online
sem EasyLogin, vale a autenticação nativa; em offline sem EasyLogin o recurso recusa acesso.
OP não recebe VIP automaticamente. O menu envia comandos normais; o cliente não
decide a validade do VIP. Remoção/expiração ocultam o pet em até 20 ticks e não
apagam a escolha. Renovação permite usar novamente o pet selecionado.

Seleção salva em `automodpack/averonsync-vip-pets.json`, por nick sem distinguir
maiúsculas/minúsculas. Escrita atômica; falha de gravação preserva o estado em
memória. Arquivo inválido desativa os pets sem apagar o arquivo. Após corrigir um
arquivo manualmente, reinicie para recarregar; prefira os comandos durante o jogo.

## Visual e desempenho

Pets são desenhos animados no cliente ao lado do proprietário: não são entidades
do mundo. Não têm hitbox, IA, dano, drops, inventário, montaria, habilidades ou
carregamento de chunks. Desaparecem ao morrer, ficar invisível/espectador, sair
ou perder o VIP; reaparecem enquanto o proprietário autenticado estiver disponível.
Mudança de dimensão usa a presença do proprietário no mundo atual.

O servidor sincroniza seleção, proprietário, vencimento e ações somente quando
o estado muda. O cliente interpola o movimento do proprietário; não há pacote
de posição por tick. Distância visual de 32 blocos, máximo de 32 pets por quadro.
Ocultação de interface não muda o benefício. Estado visual é descartado ao desconectar.

Renderização nativa dos cubos Blockbench, hierarquia de ossos, UV por face,
rotação, posição e escala. Suporta interpolação linear, step e Catmull-Rom;
idle/walk são cíclicos, carinho/emote são ações de uma reprodução. Texturas em
spritesheet e sobreposições emissivas são preservadas. Recursos são recarregáveis
pelo gerenciador normal do Minecraft. Compatibilidade visual com shaders deve
ser validada no pack completo; não foi afirmada a partir dos testes unitários.

## Importar os pacotes fornecidos

Os ZIPs originais são pacotes de plugins. O importador lê somente modelos
`.bbmodel`, PNGs embutidos e ícones específicos. Não executa HTML, configurações
de plugins ou instruções existentes nos ZIPs.

```
python tools/import_cubees.py "caminho/Cubees v6 - Nether Biomes Pack.zip" "caminho/Cubees_v16-Biomes_II.zip"
```

Gera 16 modelos, 559 cubos, texturas e animações em
`src/main/resources/assets/averonsync/pets` e `textures/pets`. Um relatório contém
os hashes dos modelos de origem. Arte importada é ignorada pelo Git: não deve
entrar automaticamente na publicação do código ou nos fontes do launcher.
Os direitos e condições originais da arte Cubees continuam com seus titulares;
a licença do código AveronSync não altera a licença da arte fornecida.

O build local inclui esses recursos no JAR. Cliente e servidor precisam da 0.15
para esta política. A implantação sem reinício não troca a versão em execução.

## Correções da adaptação (0.13)

Corrigidas as orientações UV das faces superior/inferior usando a ordem de
vértices do Blockbench. Canais animados aplicam a convenção do Blockbench 4.10:
rotação X/Y e translação X com sinais invertidos; pose de repouso não é invertida.
Referências: [geometria do Blockbench](https://github.com/JannisX11/blockbench/blob/master/js/util/three_custom.js)
e [animação 4.10.4](https://github.com/JannisX11/blockbench/blob/v4.10.4/js/animations/timeline_animators.js).

Tamanhos originais: Nether 0.56, Biomas II 0.65. Alvo normal acompanha os valores
dos YAMLs fornecidos: 0.7 ao lado, -0.3 à frente, 0.75 acima. Acompanhamento usa
suavização cosmética com recuperação em teleportes maiores que seis blocos.
Biomas II desloca o pet para a frente ao agachar, voltado para o dono; Nether
pausa o deslocamento ao agachar. Isso aproxima o comportamento, mas não emula
o motor MythicMobs: clique direto, sons e auras temporárias ainda não foram
reproduzidos. Carinho/emote continuam acionados pelo menu/comandos.

## Fluidez em mundos antigos (0.15)

O relógio de renderização agora converte o tempo inteiro do mundo para double antes de somar o partial tick. A expressão anterior long + float era calculada como float, mesmo atribuída a double. Com cerca de 51 milhões de ticks, o arredondamento pulava quatro ticks por vez (aproximadamente 5 atualizações por segundo), congelando também o movimento de seguir o dono entre esses saltos. A precisão fracionária agora é preservada a cada quadro.

Três testes de regressão cobrem mundos antigos, a transição entre ticks e o avanço conjunto da animação e do movimento. Os 16 modelos e a política de três pets do VIP nível 1 são preservados. A validação visual com jogadores após a atualização continua necessária.
