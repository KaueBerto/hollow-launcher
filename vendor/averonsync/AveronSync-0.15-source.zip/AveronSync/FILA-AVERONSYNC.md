# Fila de entrada — AveronSync 0.9

A versão 0.9 acrescenta prioridade VIP por nick e validade persistida.
Comandos, armazenamento e limitações de identidade estão em [VIP-AVERONSYNC.md](VIP-AVERONSYNC.md).

## Comportamento

A fila atua em servidor dedicado Minecraft 1.21.1 / NeoForge. Depois de
terminar a negociação do modpack, cada conexão recebe uma posição na fila.
VIPs ativos aguardando têm prioridade; dentro de cada grupo (VIP e comum),
vale a ordem de chegada. Downloads ainda em andamento
não reservam posição. O single-player não usa a fila.

Por padrão, uma conexão avança por vez. O servidor conserva a permissão
até detectar a entrada efetiva daquela conexão na lista de jogadores,
desconexão ou expiração. Após liberar essa permissão, aguarda pelo menos
5 segundos para a próxima entrada. O jogador que acabou de entrar não
precisa sair do servidor para liberar a próxima pessoa.

Se o servidor estiver cheio, as conexões permanecem aguardando. A fila não
substitui a capacidade máxima de jogadores nem as verificações nativas de
acesso. A confirmação de entrada compara a conexão real, sem depender de
um UUID permanecer igual durante a autenticação em modo offline.

O cliente mostra `AveronSync — Fila: posição X de Y. Aguarde...` na tela de
conexão existente, mantendo seu botão de cancelar. A posição é enviada
aproximadamente uma vez por segundo e requer resposta do cliente. Ao
cancelar/desconectar, a posição é removida no próximo tick. A fila não
repete o aceite dos termos.

## Exceção de OP (0.7)

Um OP reconhecido pela lista nativa do servidor entra sem posição na fila,
sem o intervalo entre admissões e sem o limite de jogadores comuns, inclusive
quando `max-players` está ocupado. Ele também não conta nas vagas comuns,
tanto na fila quanto na verificação nativa de capacidade. A consulta
`/async limite` mostra jogadores comuns e OPs separadamente.

Isso vale para qualquer nível de OP reconhecido por `PlayerList.isOp`.
O campo `bypassesPlayerLimit` em `ops.json` não precisa estar ativado e não
é alterado. As permissões do comando `/async limite` continuam exigindo
nível 3. Sem OP, não existe nova exceção de fila; permissões de bypass
nativo que já existiam continuam sendo respeitadas pela etapa nativa.

Promover alguém que ainda aguarda na fila remove a posição assim que o
servidor reconhece o novo OP. Revogar OP faz novas tentativas seguirem a
fila e faz o jogador conectado voltar a contar na capacidade comum. Uma
entrada já liberada não é revogada; ninguém é expulso para ajustar vagas.

A exceção atua depois da negociação do modpack. Não pula sincronização,
verificação do certificado, banimentos ou a política nativa de whitelist.
Em modo offline, usa o perfil/UUID reconhecido pelo servidor, com as mesmas
limitações da identidade offline; não substitui o mod de autenticação.

## Limitar jogadores online pelo comando (0.6)

Somente no servidor dedicado, com OP nível 3 ou pelo console:

- `/async limite 20`: limita as novas admissões a 20 jogadores online.
- `/async limite 0`: permite novas entradas somente de OPs (adicionado na 0.8).
- `/async limite`: mostra jogadores online, limite efetivo e estado da fila.
- `/async limite off`: remove o limite personalizado e segue `max-players`.

A alteração é aplicada no próximo tick, sem reiniciar, e salva em
`entryQueue.maxOnlinePlayers`. O valor padrão `0` segue o limite nativo.
O comando aceita números a partir de 0 e não permite superar `max-players`
de `server.properties`. Não altera o limite anunciado na lista de servidores.

Ao ocupar todas as vagas, novos jogadores aguardam na fila. Jogadores
conectados e admissões já liberadas contam no cálculo. Reduzir o limite
não expulsa ninguém nem revoga uma admissão já liberada; novas permissões
aguardam até que o total fique abaixo do limite. A ordem da fila permanece.
Ao aumentar o limite, a próxima entrada ainda respeita o intervalo e o
número máximo de admissões simultâneas configurados.

Se a fila estiver desabilitada, o comando recusa um limite personalizado.
Uma falha de gravação exibe erro e mantém o limite anterior em memória.
Não foi adicionado nenhum comando de whitelist.

### Somente OPs (0.8)

`/async limite 0` salva `entryQueue.opsOnly: true` e fecha as novas admissões
comuns no próximo tick. OPs seguem entrando diretamente. Quem já está
conectado permanece; admissões já liberadas podem concluir. Os jogadores
comuns que aguardam mantêm a ordem, sujeitos aos tempos máximos de espera
e capacidade da fila que já estavam configurados.

Para reabrir, usar `/async limite 20` (ou outro número positivo), ou
`/async limite off` para voltar à capacidade nativa. Ambos salvam
`opsOnly: false`. `/async limite` identifica o estado como `somente OPs`.
A alteração exige fila habilitada e OP nível 3 ou console.

O campo antigo `maxOnlinePlayers: 0`, sozinho, continua significando seguir
`max-players`; não fecha servidores que atualizem com configuração antiga.
O estado de fechamento é persistido separadamente em `opsOnly`.

## Configurar

No servidor, editar `automodpack/automodpack-server.json`, preservando os
outros campos, e reiniciar:

```json
"entryQueue": {
  "enabled": true,
  "maxOnlinePlayers": 0,
  "opsOnly": false,
  "maxQueuedPlayers": 100,
  "maxConcurrentAdmissions": 1,
  "admissionIntervalSeconds": 5,
  "maxWaitSeconds": 600,
  "admissionTimeoutSeconds": 120
}
```

O trecho é um campo do JSON existente. `maxQueuedPlayers` conta tanto
conexões aguardando quanto admissões em andamento. `maxWaitSeconds` vale
para a espera na fila; `admissionTimeoutSeconds` começa quando a conexão
recebe permissão e limita o tempo até aparecer na lista de jogadores.
O cliente que não responde a uma atualização por 30 segundos é desconectado.
Os parâmetros do agendador são lidos na inicialização. O limite online pode
ser alterado ao vivo pelo comando acima; não é necessário reiniciar para isso.

Valores são limitados: capacidade 1–1000, admissões 1–capacidade, intervalo
1–300 segundos, espera 10–3600 segundos, admissão 10–300 segundos. Campos
ausentes usam os padrões acima. `entryQueue: null` também usa os padrões.

## Compatibilidade e proteção básica

Instalar o AveronSync **0.8 em ambos os lados** para testar esta atualização. O canal
de login `automodpack:queue` é novo. Quem não entende esse canal recebe uma
mensagem solicitando atualização e não atravessa a fila. Desativar
`entryQueue.enabled` mantém o fluxo de login anterior.

Uma segunda conexão com o mesmo nickname, sem distinguir maiúsculas e
minúsculas, é rejeitada enquanto a primeira aguarda ou entra. Existe limite
fixo de 10 tentativas de ingresso na fila por endereço em cada janela de
60 segundos. Pessoas atrás do mesmo NAT compartilham esse limite; o mapa
é limitado a 4096 endereços. Esse controle ocorre após a negociação do
modpack e não é uma proteção contra DDoS ou excesso de handshakes iniciais.

Em `online-mode=false`, o nome não autentica a pessoa. A fila não altera a
whitelist nem os mods de login. A compatibilidade com EasyLogin e
OfflineWhitelist instalados no servidor real ainda precisa ser validada.

## Validação realizada

Na 0.8, passaram **62 testes automatizados** (53 core + 9 loader-core).
Dois testes novos verificam fechamento das vagas comuns e persistência/
reabertura sem mudar a interpretação de configurações antigas. No NeoForge
local 21.1.253, cinco cenários de protocolo passaram: limite zero segura
jogador comum com capacidade nativa disponível, OP entra enquanto fechado,
consulta identifica o modo, número positivo libera a fila existente e `off`
reabre seguindo a capacidade nativa. Os ensaios não usam cliente gráfico.
A versão 0.8 ainda não foi instalada na VPS nem publicada no GitHub.

Na 0.7, os 60 testes automatizados passaram. No NeoForge local 21.1.253,
sondas de protocolo confirmaram OP sem fila com fila cheia e capacidade
nativa zero, jogador comum aguardando, fila cheia recusando jogador comum,
OP banido recusado, promoção durante a fila liberando a entrada, revogação
de OP fazendo a próxima tentativa aguardar e banimento por IP recusando OP.
O teste usa OPs com `bypassesPlayerLimit: false`. O ensaio de promoção usa
nomes em minúsculas, evitando diferenças de UUID por caixa de nome no
fallback offline do comando nativo `/op` para perfis ainda não armazenados.
Também passaram os 6 cenários de regressão do limite para jogadores comuns:
espera abaixo da capacidade nativa, aumento/redução ao vivo, liberação de
vaga, remoção do limite personalizado, consulta e entradas inválidas.

Os ensaios usam sondas de login: não simulam jogadores carregados no mundo
nem medem a contagem de OPs com clientes gráficos conectados. A validação
completa com jogadores no modpack da VPS permanece pendente. A 0.7 foi
instalada na VPS em 29/10/2026; a inicialização e a consulta de limite foram
verificadas. [Relatório da instalação](VALIDACAO-SERVIDOR-0.7.md).

Na 0.6: **60 testes automatizados aprovados** (51 core + 9 loader-core).
Os 6 novos testes cobrem vagas reservadas, mudanças de limite, capacidade
nativa, persistência, configuração antiga e falha de gravação. No servidor
local NeoForge 21.1.253, o comando foi executado pelo console com sondas
de login reais: limite personalizado abaixo da capacidade nativa, aumento
liberando a fila, redução preservando conexões já liberadas, desconexão
abrindo vaga, consulta, `off` e entradas inválidas. O ensaio não usa clientes
gráficos nem substitui o teste com jogadores online no modpack completo.
O teste de persistência relê o JSON salvo; não simula reinício completo do
servidor. Em 29/10/2026, a atualização 0.6 foi instalada na VPS e o comando
de consulta foi validado no console. [Relatório da instalação](VALIDACAO-SERVIDOR-0.6.md).

Histórico de validação da 0.5:

- Compilação do JAR completo com Java 21 e testes `core`/`loader-core`:
  **54 testes aprovados**, incluindo 12 testes novos do agendador.
- Rajada de 100 inscrições preserva ordem e limite de admissões; testes
  cobrem cancelamento, duplicidade, capacidade, servidor cheio, expiração,
  intervalo, paralelismo configurável, limite por endereço e configuração antiga.
- Servidor local isolado com NeoForge **21.1.253**, porta de loopback:
  negociação real do login, primeira admissão, posições 1/2, rejeição de
  duplicidade e fila cheia, cancelamento com atualização das posições,
  liberação após desconexão com intervalo observado de cerca de 2 segundos
  (configuração reduzida para teste), rejeição de canal não suportado,
  expiração de espera e recuperação após admissão travada.
- Servidor configurado como cheio: uma conexão permaneceu **35,75 segundos**
  aguardando, recebeu **36 atualizações** de posição e não sofreu o timeout
  padrão de login durante essa espera.

Os clientes desse ensaio são sondas de protocolo; não renderizam a tela nem
entram no mundo como um cliente Minecraft completo. O teste de reconhecimento
de entrada efetiva no mundo e a compatibilidade com todos os mods exigem
uma sessão com jogadores. Em 28/10/2026, a versão 0.5 foi instalada na VPS
com backup e reinício completo do sistema. A inicialização do Minecraft,
as configurações da fila, o JAR e o certificado foram verificados. O teste
com cliente gráfico 0.5 no servidor de produção permanece pendente.

## Limites desta entrega

O controle é de **entrada no mundo**, sem fila própria para downloads de
arquivos. O limite global de banda herdado (`bandwidthLimit`) permanece
disponível, mas limitar usuários simultâneos baixando exige uma etapa
separada. Não há medição automática de TPS/MSPT para pausar a fila, prioridade
VIP, reserva de posição após reiniciar o cliente ou persistência após reiniciar
o servidor. Os valores padrão precisam ser ajustados em teste com o modpack real.
