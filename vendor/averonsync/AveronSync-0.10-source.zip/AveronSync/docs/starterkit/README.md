# Kit VIP preparado para Starter Kit 8.1

Arquivo de kit para implantação; não incluído automaticamente no JAR.
O kit está em `config/starterkit/kits/inactive/Vip.txt` para não ser oferecido
na seleção inicial dos jogadores comuns. Mantenha-o inativo: o AveronSync 0.10
lê esse arquivo diretamente para o comando `/kitvip`.

Itens definidos pelo usuário:

- 1 `hollowmines:copper_sword`
- 1 `hollowmines:copper_pickaxe`
- 1 `hollowmines:copper_axe`
- 32 `minecraft:bread`
- 16 `minecraft:golden_carrot`
- 20 `legendarysurvivaloverhaul:bandage`
- 1 `legendarysurvivaloverhaul:canteen_purified`
- 16 `minecraft:torch`

IDs de cobre confirmados nos recursos do AveronOrigins instalado:
o namespace escolhido é `hollowmines`, não `hollowblacksmith`.
Os IDs de bandagem e cantil foram confirmados no Legendary Survival Overhaul.

O resgate exige VIP ativo e autenticação, adiciona os itens sem substituir o
inventário e tem intervalo persistente de 30 dias por nick. Para administrar:
`/async vip add Nick`, `/async vip info Nick` e `/async vip remove Nick`.
