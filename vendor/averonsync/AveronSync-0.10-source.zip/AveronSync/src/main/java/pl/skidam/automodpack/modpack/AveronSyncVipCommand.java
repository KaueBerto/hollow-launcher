package pl.skidam.automodpack.modpack;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import pl.skidam.automodpack.networking.server.AveronSyncEntryQueue;
import pl.skidam.automodpack_core.queue.VipRegistry;
import static net.minecraft.commands.Commands.*;

/** VIP only reorders waiting admissions; it never grants OP or a capacity bypass. */
public final class AveronSyncVipCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("async")
                .requires(source -> source.hasPermission(3) && source.getServer().isDedicatedServer())
                .then(literal("vip")
                        .then(literal("add").then(argument("nick", StringArgumentType.word())
                                .executes(ctx -> update(ctx.getSource(), StringArgumentType.getString(ctx, "nick"), true))))
                        .then(literal("remove").then(argument("nick", StringArgumentType.word())
                                .executes(ctx -> update(ctx.getSource(), StringArgumentType.getString(ctx, "nick"), false))))
                        .then(literal("info").then(argument("nick", StringArgumentType.word())
                                .executes(ctx -> info(ctx.getSource(), StringArgumentType.getString(ctx, "nick")))))
                        .then(literal("list").executes(ctx -> list(ctx.getSource())))));
    }

    private static VipRegistry registry(CommandSourceStack source) {
        var registry = AveronSyncEntryQueue.get(source.getServer()).vips();
        if (registry == null) source.sendFailure(Component.literal("[AveronSync] Arquivo VIP invalido ou inacessivel. Consulte o log e reinicie apos corrigir."));
        return registry;
    }

    private static String date(long timestamp) {
        return java.time.Instant.ofEpochMilli(timestamp).toString();
    }

    private static int update(CommandSourceStack source, String nickname, boolean grant) {
        var registry = registry(source);
        if (registry == null) return 0;
        try {
            String name = VipRegistry.normalize(nickname);
            if (!grant) {
                boolean removed = registry.revoke(name);
                source.sendSuccess(() -> Component.literal("[AveronSync] " + (removed ? "VIP removido: " : "Sem cadastro VIP: ") + name), true);
            } else {
                long expiry = registry.grant(name, System.currentTimeMillis());
                source.sendSuccess(() -> Component.literal("[AveronSync] VIP salvo para " + name + ", valido ate " + date(expiry)
                        + " (UTC). Prioridade aplicada a fila; limite de jogadores mantido."), true);
            }
            return 1;
        } catch (java.io.IOException | RuntimeException e) {
            pl.skidam.automodpack_core.GlobalVariables.LOGGER.error("Unable to update VIP registry", e);
            source.sendFailure(Component.literal("[AveronSync] Nao foi possivel salvar o VIP. Confira nick e acesso ao arquivo. Estado anterior preservado."));
            return 0;
        }
    }

    private static int info(CommandSourceStack source, String nickname) {
        var registry = registry(source);
        if (registry == null) return 0;
        try {
            String name = VipRegistry.normalize(nickname);
            long expiry = registry.expiresAt(name);
            String status = expiry > System.currentTimeMillis() ? "ativo ate " + date(expiry) + " (UTC)"
                    : expiry > 0 ? "expirado em " + date(expiry) + " (UTC)" : "nao cadastrado";
            source.sendSuccess(() -> Component.literal("[AveronSync] VIP " + name + ": " + status), false);
            return 1;
        } catch (IllegalArgumentException e) {
            source.sendFailure(Component.literal("[AveronSync] " + e.getMessage()));
            return 0;
        }
    }

    private static int list(CommandSourceStack source) {
        var registry = registry(source);
        if (registry == null) return 0;
        var entries = registry.active(System.currentTimeMillis());
        source.sendSuccess(() -> Component.literal("[AveronSync] VIPs ativos: " + entries.size()), false);
        entries.forEach((name, expiry) -> source.sendSuccess(() -> Component.literal(name + " - " + date(expiry) + " (UTC)"), false));
        return 1;
    }
    private AveronSyncVipCommand() {}
}
