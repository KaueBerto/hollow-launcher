package pl.skidam.automodpack_core.queue;

import org.junit.jupiter.api.Test;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

class StarterKitDefinitionTest {
    @Test void selectedVipKitContainsExactlyTheRequestedEightStacks() throws Exception {
        var file = Path.of("..", "docs", "starterkit", "config", "starterkit", "kits", "inactive", "Vip.txt");
        var source = Files.readString(file);
        var items = StarterKitDefinition.parse(source);
        assertEquals(8, items.size());
        assertTrue(items.get(0).contains("hollowmines:copper_sword"));
        assertTrue(items.get(1).contains("hollowmines:copper_pickaxe"));
        assertTrue(items.get(2).contains("hollowmines:copper_axe"));
        assertEquals("{count:32,id:\"minecraft:bread\"}", items.get(3));
        assertEquals("{count:16,id:\"minecraft:golden_carrot\"}", items.get(4));
        assertEquals("{count:20,id:\"legendarysurvivaloverhaul:bandage\"}", items.get(5));
        assertEquals("{count:1,id:\"legendarysurvivaloverhaul:canteen_purified\"}", items.get(6));
        assertEquals("{count:16,id:\"minecraft:torch\"}", items.get(7));
        assertEquals(items, StarterKitDefinition.parse(source.replace("\n", "\r\n")));
    }
    @Test void rejectsDuplicateSlotsAndOutOfInventorySlots() {
        assertThrows(IllegalArgumentException.class, () -> StarterKitDefinition.parse("0 : 'a',\n0 : 'b',"));
        assertThrows(IllegalArgumentException.class, () -> StarterKitDefinition.parse("0 : 'a',\n00 : 'b',"));
        assertThrows(IllegalArgumentException.class, () -> StarterKitDefinition.parse("36 : 'a',"));
        assertThrows(IllegalArgumentException.class, () -> StarterKitDefinition.parse("-1 : 'a',"));
    }
    @Test void rejectsEquipmentEffectsEmptyAndMalformedDefinitions() {
        for (String source : new String[]{"", "0 : '',", "'head' : 'item',", "'effects' : 'effect',", "invalid", "x : 'item',"})
            assertThrows(IllegalArgumentException.class, () -> StarterKitDefinition.parse(source));
    }
}
