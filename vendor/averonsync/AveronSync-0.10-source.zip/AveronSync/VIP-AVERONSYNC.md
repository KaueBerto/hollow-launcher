# Prioridade VIP na fila

Implementação para Minecraft 1.21.1 NeoForge. A versão 0.10 acrescenta kit VIP;
pets continuam fora desta etapa.

## Comandos

Console ou OP de nível 3+, no servidor dedicado:

- `/async vip add SnowA32`: concede ou renova o VIP por exatamente 30 dias a partir de agora, sem acumular o prazo restante.
- `/async vip remove SnowA32`: remove o cadastro VIP.
- `/async vip info SnowA32`: consulta validade e estado.
- `/async vip list`: lista os VIPs ativos e seus vencimentos em UTC.

Não exige que o jogador esteja online ou já tenha entrado no servidor.
Nicks são tratados sem diferença entre maiúsculas e minúsculas. A validade
é fixa em 30 dias de 24 horas e continua passando com o servidor desligado.
O comando não aceita outra duração. Renovar define um novo vencimento de
30 dias a partir da renovação; não soma os dias que restavam.

## Fila

VIPs aguardando passam antes dos demais; dentro de cada grupo, vale a ordem
de chegada. Cadastro, renovação, remoção e expiração afetam a posição sem
reconectar. Admissões já liberadas não são interrompidas. O intervalo entre
entradas, timeout, capacidade da fila e limite de jogadores continuam valendo.
VIP não entra em servidor cheio e não ignora `/async limite 0` (somente OPs).
OPs mantêm o bypass existente, sem depender de VIP.

## Resgate de kit (0.10)

O jogador usa `/kitvip`. Requer VIP ativo e autenticação pelo EasyLogin.
Em servidor online sem EasyLogin, usa a autenticação nativa; em modo offline
sem a integração disponível, o resgate é recusado.

O conteúdo vem de `config/starterkit/kits/inactive/Vip.txt`, usando o leitor
de itens Collective do Starter Kit 8.1. O arquivo permanece inativo para não
aparecer na seleção inicial. Não o mova para a pasta de kits ativos.
Os itens são adicionados, sem substituir inventário, armadura ou mão secundária.
Inventário sem espaço ou kit inválido não consomem o resgate. Itens desconhecidos,
arquivo ausente ou integração ausente bloqueiam a entrega; não há fallback para Default.

Um resgate a cada 30 dias reais por nick, salvo em
`automodpack/averonsync-vip-kit-claims.json`. Renovar/remover/reconceder VIP não
zera esse intervalo. O cadastro VIP precisa estar ativo no momento de resgatar.
A reserva é salva antes da entrega para impedir duplicação; falhas síncronas
restauram o inventário antes de liberar nova tentativa. Se o processo cair
exatamente durante a entrega, a reserva é mantida e requer revisão administrativa.

## Armazenamento

Arquivo servidor `automodpack/averonsync-vips.json`, separado do manifesto e
da configuração do modpack. Só é criado no primeiro cadastro. Escritas usam
substituição atômica quando disponível e só atualizam o estado em memória
depois de salvar. Arquivo inválido desativa a prioridade VIP sem apagá-lo;
o log informa o erro. Após corrigir o arquivo, reinicie o servidor para carregá-lo.
Edição manual com o servidor aberto não é recarregada; use os comandos.

## Identidade

A fila usa o nick anunciado na conexão, antes da entrada no mundo. Em
`online-mode=false`, essa fase ainda não confirma a senha do EasyLogin:
alguém que use o mesmo nick pode receber sua prioridade na fila, mas ainda
precisa passar pela autenticação normal para jogar. O kit, ao contrário da fila,
consulta o EasyLogin antes de entregar itens. Não concede OP ou pets nem altera
o funcionamento do login.

## Validação

Testes cobrem prioridade e posições, FIFO em cada grupo, concessão/revogação
durante a espera, vencimento, persistência, falha de gravação e arquivos inválidos,
além de capacidade, timeout e intervalo de admissão.
