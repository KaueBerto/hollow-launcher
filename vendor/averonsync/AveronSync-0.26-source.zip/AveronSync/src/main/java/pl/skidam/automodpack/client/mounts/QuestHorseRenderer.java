package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.*;
import pl.skidam.automodpack.client.pets.VipPetRenderer;
import pl.skidam.automodpack.modpack.*;
import pl.skidam.automodpack_core.pets.*;
import java.nio.charset.StandardCharsets;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

public final class QuestHorseRenderer extends EntityRenderer<QuestHorseEntity> {
    private static final class Motion {
        final pl.skidam.automodpack_core.mounts.HorsePoseBlend blend=new pl.skidam.automodpack_core.mounts.HorsePoseBlend();
        final pl.skidam.automodpack_core.mounts.HorseLeanBlend lean=new pl.skidam.automodpack_core.mounts.HorseLeanBlend();
    }
    private static final java.util.Map<QuestHorseEntity,Motion> MOTION=new java.util.WeakHashMap<>();
    private static final java.util.Set<QuestHorseEntity> PREVIEWS=java.util.Collections.newSetFromMap(new java.util.WeakHashMap<>());
    public static void markPreview(QuestHorseEntity horse){PREVIEWS.add(horse);}
    private static CubeeModel model;
    private static boolean attempted;
    public static void init(IEventBus bus) {
        bus.addListener(QuestHorseRenderer::register);
        bus.addListener(QuestHorseRenderer::reload);
    }
    private static void register(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(AveronSyncHorseContent.HORSE.get(), QuestHorseRenderer::new);
    }
    private static void reload(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((ResourceManagerReloadListener) manager -> { model = null; attempted = false; MOTION.clear(); });
    }
    public QuestHorseRenderer(EntityRendererProvider.Context context) { super(context); shadowRadius = .7F; }
    private static CubeeModel model() {
        if (!attempted) {
            attempted = true;
            try (var input = Minecraft.getInstance().getResourceManager().getResourceOrThrow(
                    ResourceLocation.parse("averonsync:mounts/horse_bay.json")).open()) {
                byte[] bytes = input.readNBytes(4_000_001);
                if (bytes.length > 4_000_000) throw new java.io.IOException("Horse model too large");
                model = CubeeModel.parseHorse(JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject());
            } catch (Exception e) { LOGGER.error("Could not load quest horse artwork", e); }
        }
        return model;
    }
    @Override public void render(QuestHorseEntity horse, float yaw, float partial, PoseStack poses, MultiBufferSource buffers, int light) {
        CubeeModel model = model();
        if (model != null && !horse.isInvisible()) {
            double age = PetRenderTime.ticks(horse.level().getGameTime(), partial);
            String clip=horse.baseClip();double time=Math.max(0,(age-horse.baseAt())/20.0);
            var layers=new java.util.ArrayList<VipPetRenderer.ModelLayer>();
            Motion motion=MOTION.computeIfAbsent(horse,ignored->new Motion());
            var transition=motion.blend.update(model,clip,horse.baseAt(),age);
            if(transition!=null)layers.add(new VipPetRenderer.ModelLayer(transition.pose(),0,transition.weight()));
            double twitchTime=(age-horse.twitchAt())/20.0;
            String[] twitches={"tailwhip","right_ear_twitch","left_ear_twitch","ruffle_head"};
            for(int i=0;i<4;i++) if ((horse.twitches()&(1<<i))!=0) layer(layers,model,twitches[i],twitchTime,1,false);
            var action=horse.action();String actionClip=action.name().toLowerCase(java.util.Locale.ROOT);
            if (action!=pl.skidam.automodpack_core.mounts.HorseControls.Action.NONE)
                layer(layers,model,actionClip,(age-horse.actionAt())/20.0,1,action==pl.skidam.automodpack_core.mounts.HorseControls.Action.JUMP||action==pl.skidam.automodpack_core.mounts.HorseControls.Action.FALLING);
            for(var lean:motion.lean.update(horse.lean(),age))
                layers.add(new VipPetRenderer.ModelLayer(model.animations().get(pl.skidam.automodpack_core.mounts.HorseLeanBlend.clip(lean.lean())),0,lean.weight()));
            poses.pushPose();
            poses.mulPose(Axis.YP.rotationDegrees((PREVIEWS.contains(horse)?360:180)-yaw));
            poses.scale(1F/16,1F/16,1F/16);
            VipPetRenderer.renderModel(poses,buffers,model,clip,time,age,light,layers);
            poses.popPose();
        }
        super.render(horse, yaw, partial, poses, buffers, light);
    }
    private static void layer(java.util.List<VipPetRenderer.ModelLayer> layers,CubeeModel model,String name,double time,double weight,boolean hold) {
        var clip=model.animations().get(name);
        if(clip==null || time<0 || (!hold && time>clip.length()+.2))return;
        weight*=Math.min(1,time*10);
        if(!hold)weight*=Math.min(1,Math.max(0,(clip.length()+.2-time)/.2));
        layers.add(new VipPetRenderer.ModelLayer(clip,Math.min(time,clip.length()),weight));
    }
    @Override public ResourceLocation getTextureLocation(QuestHorseEntity horse) {
        return ResourceLocation.parse("averonsync:textures/mounts/horse_bay/2.png");
    }
}
/*?}*/
