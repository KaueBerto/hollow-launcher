package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import pl.skidam.automodpack.modpack.*;
import pl.skidam.automodpack_core.pets.VipPetAccess;

public final class MountScreen extends Screen {
    private final int screenId;
    private MountMenuState state;
    private QuestHorseEntity preview;
    private boolean pending;
    private boolean pets,lastPetAccess;
    private int ticks;
    private int left,top,panelWidth,panelHeight;
    public MountScreen(int id) {this(id,false);}
    public MountScreen(int id,boolean pets) { super(Component.literal("Companheiros"));screenId=id;this.pets=pets; }
    int screenId(){return screenId;}
    void update(MountMenuState value){state=value;pending=false;rebuildWidgets();}
    @Override protected void init() {
        panelWidth=Math.min(360,width-20);panelHeight=Math.min(252,height-20);
        left=(width-panelWidth)/2;top=(height-panelHeight)/2;
        int tabWidth=(panelWidth-32)/2;
        var horsesTab=Button.builder(Component.literal("Cavalos"),b->{pets=false;pending=false;rebuildWidgets();})
                .bounds(left+12,top+31,tabWidth,20).build();horsesTab.active=pets;addRenderableWidget(horsesTab);
        var petsTab=Button.builder(Component.literal("Pets"),b->{pets=true;pending=false;rebuildWidgets();})
                .bounds(left+20+tabWidth,top+31,tabWidth,20).build();petsTab.active=!pets;addRenderableWidget(petsTab);
        lastPetAccess=petAccess();
        if(pets){initPets();return;}
        if(minecraft!=null && minecraft.level!=null && (preview==null || preview.level()!=minecraft.level)) {
            preview=AveronSyncHorseContent.HORSE.get().create(minecraft.level);
            if(preview!=null){preview.setTamed(true);QuestHorseRenderer.markPreview(preview);}
        }
        String label=pending?"Aguarde…":state==null?"Carregando…":"Selecionar";
        int buttonWidth=(panelWidth-32)/2;
        var button=Button.builder(Component.literal(label),b->{
            pending=true;rebuildWidgets();MountMenuClient.send(screenId,MountMenuRequest.SELECT);
        }).bounds(left+12,top+panelHeight-32,buttonWidth,20).build();
        button.active=!pending && state!=null && state.enabled() && state.unlocked();
        if(state!=null && !button.active && !pending)button.setTooltip(Tooltip.create(Component.literal("Indisponível")));
        addRenderableWidget(button);
        addRenderableWidget(Button.builder(Component.literal("Fechar"),b->onClose()).bounds(left+20+buttonWidth,top+panelHeight-32,buttonWidth,20).build());
    }
    private boolean petAccess(){return state!=null && state.enabled() && state.petUntil()>System.currentTimeMillis();}
    private void initPets() {
        var available=VipPetAccess.available(VipPetAccess.CURRENT_VIP_LEVEL);
        int step=(panelWidth-24)/available.size();
        for(int i=0;i<available.size();i++) {
            var pet=available.get(i);
            String selected=state!=null && pet.id().equals(state.selectedPet())?"✓ ":"";
            var button=Button.builder(Component.literal(selected+pet.name()),b->sendPet("usar "+pet.id()))
                    .bounds(left+14+i*step,top+118,step-4,20).build();
            button.active=petAccess();
            if(!button.active)button.setTooltip(Tooltip.create(Component.literal("VIP ativo necessário.")));
            addRenderableWidget(button);
        }
        int size=(panelWidth-42)/4;
        String[] labels={"Guardar","Carinho","Emote","Fechar"};String[] actions={"guardar","carinho","emote",""};
        for(int i=0;i<labels.length;i++) {
            final String action=actions[i];
            var button=Button.builder(Component.literal(labels[i]),b->{if(action.isEmpty())onClose();else sendPet(action);})
                    .bounds(left+12+i*(size+6),top+panelHeight-32,size,20).build();
            button.active=action.isEmpty() || (petAccess() && state!=null && !state.selectedPet().isEmpty());
            addRenderableWidget(button);
        }
    }
    private void sendPet(String command) {
        if(minecraft!=null && minecraft.player!=null)minecraft.player.connection.sendCommand("petvip "+command);
        onClose();
    }
    @Override public void tick() {
        super.tick();
        if(minecraft==null || minecraft.player==null){onClose();return;}
        if(pets && petAccess()!=lastPetAccess)rebuildWidgets();
        if(++ticks%20==0)MountMenuClient.send(screenId,MountMenuRequest.QUERY);
    }
    @Override public boolean keyPressed(int key,int scan,int modifiers) {
        if(MountMenuClient.OPEN.matches(key,scan)){onClose();return true;}
        return super.keyPressed(key,scan,modifiers);
    }
    @Override public void renderBackground(GuiGraphics g,int mouseX,int mouseY,float partial) {
        // Screen's default background runs the vanilla blur post-process.
        // Keep this menu sharp without changing the player's global settings.
        g.fill(0,0,width,height,0x66000000);
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial) {
        renderBackground(g,mouseX,mouseY,partial);
        g.fill(left-1,top-1,left+panelWidth+1,top+panelHeight+1,0xFF285957);
        g.fill(left,top,left+panelWidth,top+panelHeight,0xF0142026);
        g.fill(left,top,left+panelWidth,top+2,0xFF63DED0);
        g.drawString(font,title,left+14,top+13,0xFFE8F8F4,false);
        g.drawString(font,Component.literal("G / Esc"),left+panelWidth-54,top+14,0xFF8BA5A6,false);
        int previewRight=left+panelWidth-12;
        int previewBottom=top+panelHeight-44;
        g.fill(left+12,top+60,previewRight,previewBottom,0xFF0D171D);
        if(pets)renderPets(g);
        else {
            g.drawCenteredString(font,Component.literal("Cavalo castanho"),left+panelWidth/2,top+67,0xFFF1E7C9);
            if(preview!=null)InventoryScreen.renderEntityInInventoryFollowsMouse(g,left+12,top+80,previewRight,previewBottom,
                    Math.max(20,Math.min(32,(previewBottom-top-86)/3)),.0625F,mouseX,mouseY,preview);
        }
        super.render(g,mouseX,mouseY,partial);
    }
    private void renderPets(GuiGraphics g) {
        var available=VipPetAccess.available(VipPetAccess.CURRENT_VIP_LEVEL);int step=(panelWidth-24)/available.size();
        for(int i=0;i<available.size();i++) {
            var pet=available.get(i);int x=left+12+i*step,center=x+step/2;
            boolean selected=state!=null && pet.id().equals(state.selectedPet());
            g.fill(x+2,top+64,x+step-2,top+panelHeight-49,selected?0xFF285957:0xFF17262E);
            g.pose().pushPose();g.pose().translate(center-16,top+76,0);g.pose().scale(2,2,1);
            g.blit(ResourceLocation.parse("averonsync:textures/pets/icons/"+pet.id()+".png"),0,0,0,0,16,16,16,16);
            g.pose().popPose();
            if(selected)g.drawCenteredString(font,Component.literal("Selecionado"),center,top+151,0xFF63DED0);
        }
    }
    @Override public boolean isPauseScreen(){return false;}
    @Override public void removed(){MountMenuClient.closed();super.removed();}
}
/*?}*/
