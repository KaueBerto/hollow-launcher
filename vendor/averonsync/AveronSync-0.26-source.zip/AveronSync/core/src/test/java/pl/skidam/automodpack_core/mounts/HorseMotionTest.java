package pl.skidam.automodpack_core.mounts;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HorseMotionTest {
    @Test void vanillaGroundPhysicsConvergesToTargetWithoutAmplifyingSpeed() {
        for(double friction:new double[]{.6,.8,.98})for(double target:new double[]{.1,.2,1.25}) {
            double velocity=0,distance=0;
            for(int tick=0;tick<300;tick++) {
                velocity+=HorseMotion.riddenSpeed(target,friction)*.21600002/(friction*friction*friction);
                distance=velocity;velocity*=.91*friction;
            }
            assertEquals(target,distance,1e-9);
        }
    }
    @Test void rejectsNonFiniteOrNegativeMotionValues() {
        assertThrows(IllegalArgumentException.class,()->HorseMotion.riddenSpeed(Double.NaN,.6));
        assertThrows(IllegalArgumentException.class,()->HorseMotion.riddenSpeed(-1,.6));
        assertThrows(IllegalArgumentException.class,()->HorseMotion.riddenSpeed(1,0));
    }
}
