package pl.skidam.automodpack_core.mounts;

import pl.skidam.automodpack_core.pets.CubeeModel;
import java.util.*;
import static pl.skidam.automodpack_core.pets.PetAnimation.*;

/** Four-tick transitions capture the currently displayed pose, including a
 * transition interrupted by another gait. All channels include bind defaults. */
public final class HorsePoseBlend {
    public record Transition(CubeeModel.Clip pose,double weight) {}
    private String clip;
    private long clipAt;
    private double transitionAt;
    private CubeeModel.Clip previous;
    public Transition update(CubeeModel model,String next,long nextAt,double age) {
        if(clip!=null && (!clip.equals(next) || clipAt!=nextAt)) {
            var tracks=new HashMap<String,Map<String,List<Frame>>>();
            capture(model,model.nodes(),tracks,age);
            previous=new CubeeModel.Clip(1,Map.copyOf(tracks));transitionAt=age;
        }
        clip=next;clipAt=nextAt;
        double weight=Math.max(0,Math.min(1,1-(age-transitionAt)/4));
        if(previous==null || weight<=0) {previous=null;return null;}
        return new Transition(previous,weight);
    }
    private void capture(CubeeModel model,List<CubeeModel.Node> nodes,Map<String,Map<String,List<Frame>>> tracks,double age) {
        var base=model.animations().get(clip);double time=Math.max(0,(age-clipAt)/20)%base.length();
        double oldWeight=previous==null?0:Math.max(0,Math.min(1,1-(age-transitionAt)/4));
        for(var node:nodes) {
            var channels=new HashMap<String,List<Frame>>();
            for(String channel:List.of("position","rotation","scale")) {
                Vec value=base.sample(node.id(),channel,time);
                if(oldWeight>0)value=mix(value,previous.sample(node.id(),channel,0),oldWeight);
                channels.put(channel,List.of(new Frame(0,value,"linear")));
            }
            tracks.put(node.id(),Map.copyOf(channels));capture(model,node.children(),tracks,age);
        }
    }
    public static Vec mix(Vec a,Vec b,double weight) {
        return new Vec(a.x()+(b.x()-a.x())*weight,a.y()+(b.y()-a.y())*weight,a.z()+(b.z()-a.z())*weight);
    }
    public static long phaseStart(String old,long oldAt,String next,long now) {
        double before=period(old),after=period(next);
        if(before==0 || after==0)return now;
        double phase=Math.floorMod(now-oldAt,(long)before)/before;
        return now-Math.round(phase*after);
    }
    private static double period(String clip) {
        return switch(clip) {case "walk"->20;case "gallop"->10;case "backpedal"->30;default->0;};
    }
}
