package pl.skidam.automodpack_core.mounts;

/** Converts target blocks/tick into vanilla's acceleration input, rather than
 * treating the plugin's speed as a horse acceleration attribute (2.2x on stone). */
public final class HorseMotion {
    public static double riddenSpeed(double target,double friction) {
        if(!Double.isFinite(target) || target<0 || !Double.isFinite(friction) || friction<=0 || friction>1)
            throw new IllegalArgumentException("Invalid horse motion parameters");
        return target*(1-.91*friction)*friction*friction*friction/.21600002;
    }
    private HorseMotion() {}
}
