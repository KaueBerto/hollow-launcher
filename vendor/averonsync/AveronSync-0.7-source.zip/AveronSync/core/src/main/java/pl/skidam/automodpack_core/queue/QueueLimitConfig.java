package pl.skidam.automodpack_core.queue;

import java.io.IOException;
import java.nio.file.*;
import pl.skidam.automodpack_core.config.ConfigTools;
import pl.skidam.automodpack_core.config.Jsons;

/** Save a copied configuration first; failed writes never change the running limit. */
public final class QueueLimitConfig {
    public static Jsons.ServerConfigFieldsV2 save(Path file, Jsons.ServerConfigFieldsV2 current, int limit) throws IOException {
        if (limit < 0) throw new IllegalArgumentException("Negative online limit");
        var updated = ConfigTools.GSON.fromJson(ConfigTools.GSON.toJson(current), Jsons.ServerConfigFieldsV2.class);
        if (updated.entryQueue == null) updated.entryQueue = new QueueSettings();
        updated.entryQueue.maxOnlinePlayers = limit;
        Path target = file.toAbsolutePath();
        Files.createDirectories(target.getParent());
        Path temp = Files.createTempFile(target.getParent(), "averonsync-limit-", ".tmp");
        try {
            Files.writeString(temp, ConfigTools.GSON.toJson(updated));
            if (Files.exists(target)) {
                var posix = Files.getFileAttributeView(target, java.nio.file.attribute.PosixFileAttributeView.class);
                if (posix != null) Files.setPosixFilePermissions(temp, posix.readAttributes().permissions());
            }
            try { Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
        return updated;
    }
}
