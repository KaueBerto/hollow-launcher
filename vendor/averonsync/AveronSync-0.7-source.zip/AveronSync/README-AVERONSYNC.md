# AveronSync 0.7 — fila com limite de jogadores e exceção para OPs

Fork local do **AutoModpack 4.0.6**, com alvo **Minecraft 1.21.1 / NeoForge
21.1.169**. Versão do artefato: `4.0.6-averonsync.0.7`.

Base exata: tag `v4.0.6`, commit
`2ff957d03ffb4253fea0c0cbda4d0def4e9528d6` do
[repositório oficial](https://github.com/Skidamek/AutoModpack/tree/v4.0.6).
Branch: `averonsync/1.21.1-neoforge-v0.1`.

O starter v0.1 mencionado na conversa anterior não estava acessível. A leitura
da conversa retornou referências às respostas antigas, sem seu conteúdo ou
anexos. Nenhum starter AveronSync foi encontrado no workspace, na busca por
nome nas outras pastas Codex ou nos arquivos correspondentes de Downloads.
Esta implementação foi criada diretamente a partir dos fontes oficiais;
nenhum ZIP anterior foi tratado como fork ou binário compilado.

## Arquitetura

| Parte | Responsabilidade |
|---|---|
| `core` | Configuração, manifesto, hashes, autenticação, protocolo e hospedagem Netty |
| `loader/core` | Atualização antes do jogo, downloads, cache e posicionamento dos arquivos |
| `loader/neoforge/fml4` | Entrada antecipada do NeoForge e empacotamento do bootstrap |
| `src/main` | Integração Minecraft, conexão ao servidor, comandos e interface |
| Stonecutter / Gradle | Conversão de fontes multiversão e montagem do JAR final com bibliotecas |

O fork mantém os IDs `automodpack` e `automodpack_mod`, namespaces de recursos,
protocolo, pacotes Java e diretório `automodpack/`. Isso reduz mudanças no
bootstrap e permite a migração gradual. Por compartilhar os IDs, AveronSync
substitui AutoModpack na instalação; eles não devem ser instalados juntos.
O remoto `upstream` aponta para o original. O código do AveronSync é publicado
no repositório privado `KaueBerto/AveronSync`; o remoto `origin` aponta para ele.

## Versão 0.7

OPs reconhecidos pelo servidor não entram na fila e não consomem vagas
comuns. A verificação nativa de capacidade também permite a entrada de
OP quando `max-players` está ocupado. Não se altera `ops.json` nem o campo
`bypassesPlayerLimit`: a exceção é calculada usando `PlayerList.isOp`.
Banimentos de jogador/IP e as verificações nativas de whitelist permanecem.
Ver [FILA-AVERONSYNC.md](FILA-AVERONSYNC.md).

## Versão 0.6

Adiciona `/async limite <quantidade>`, consulta `/async limite` e remoção
do limite personalizado `/async limite off`. O limite é salvo de forma
atômica na configuração e aplicado à fila no próximo tick, contando
jogadores online e admissões já reservadas. Exige OP nível 3 ou console.
Não expulsa jogadores ao reduzir o limite. Ver [FILA-AVERONSYNC.md](FILA-AVERONSYNC.md).

## Versão 0.5

Adiciona uma fila de admissão no login, depois da verificação do modpack e
antes de iniciar a configuração NeoForge/entrada no mundo. Mantém as
conexões aguardando com posição na tela de conexão existente. O agendador
fica em `core/queue`, e o adaptador Minecraft em `AveronSyncEntryQueue`.
O servidor atualiza o agendador a cada tick; nenhuma espera bloqueia o tick.
Configuração, compatibilidade e limites em [FILA-AVERONSYNC.md](FILA-AVERONSYNC.md).

## Versão 0.4

Os comandos próprios de whitelist da versão 0.3 foram removidos. A gestão de
acesso fica a cargo do Minecraft ou de um mod específico escolhido pelo
administrador. Esta atualização não modifica o arquivo `whitelist.json`,
nem ativa ou desativa a whitelist no servidor. Os relatórios das versões
anteriores ficam preservados como histórico.

## Termos e atualizações na versão 0.2

O primeiro uso exibe os [termos próprios](TERMOS-AVERONSYNC.md), com texto
rolável, uma caixa de aceite e o botão de continuar. Não há espera de 10
segundos. O aceite fica salvo em `automodpack/averonsync-consent.json`, nesta
instalação do jogo. Ele autoriza também as atualizações seguintes dos
servidores aos quais o jogador escolhe se conectar, incluindo novos mods e
JARs sem correspondência pública nas plataformas.

Depois de aceitar, trocar/adicionar/remover mods, atualizar o pack, mudar seu
nome ou atualizar o próprio AveronSync não repete a pergunta. Outras
instalações do jogo têm seu próprio aceite. Apagar o arquivo revoga o aceite.
Se ele estiver ausente ou corrompido, a tela volta a aparecer. Recusar não
salva consentimento nem inicia a sincronização. Falha ao salvar é exibida na
tela e impede continuar. A versão dos termos é independente da versão do mod.

Durante a inicialização antecipada, um aceite pendente adia a sincronização
até a conexão interativa, quando a tela pode ser mostrada. Após o aceite,
as atualizações na inicialização também são permitidas. A verificação de
certificado/identidade do servidor permanece separada; o fluxo excepcional
de ignorar essa verificação conserva seu próprio aviso e temporizador.

## Implementado

- Seleção do alvo 1.21.1 NeoForge e conversão de fontes pelo Stonecutter.
- Nome AveronSync nos metadados do mod e do bootstrap; créditos preservados.
- Tela de download com título traduzido em português brasileiro e inglês,
  cor turquesa, nome do pack, percentual e créditos. Cancelamento e música
  continuam disponíveis. A coleta de progresso ocorre por tick, eliminando
  o laço contínuo anterior.
- Campo `sha256` por arquivo no manifesto existente `automodpack-content.json`.
  SHA-1 e Murmur continuam usados como no upstream para transporte e serviços
  externos. Manifestos antigos carregados no servidor são regenerados quando
  não possuem SHA-256.
- Verificação SHA-256 ao finalizar downloads, ao reutilizar um arquivo já
  presente no destino, nos reenvios, nas checagens de atualização e nas
  comparações/cópias de arquivos não editáveis para o diretório de execução.
- Cache SHA-1 não dispensa SHA-256 quando o manifesto o fornece.
- Ausência do campo permite compatibilidade com servidores antigos; valor
  vazio, malformado ou divergente é rejeitado. Arquivos editáveis preservam
  a política de alterações locais do upstream após sua instalação.
- Atualizador oficial bloqueado para a versão do fork, inclusive com
  configurações antigas que ativem atualização ou sincronização de versão.
- Testes para hashes conhecidos, arquivos grandes/vazios, adulteração,
  serialização e compatibilidade, downloads com hash correto/incorreto,
  proteção contra cache desatualizado, arquivos editáveis e atualizador.
- Licença original e aviso do fork incorporados no JAR final.

SHA-256 confere integridade em relação ao manifesto recebido. Nesta etapa
não há assinatura própria de manifestos nem modo que exija SHA-256 de todos
os servidores; a autenticação/TLS e confirmação de confiança herdadas permanecem.

## Compilar e testar

Use JDK 21 para Gradle/Minecraft e JDK 17 disponível para os módulos core,
conforme os toolchains herdados. O wrapper baixa Gradle e as dependências.

```powershell
.\gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --console=plain
```

O JAR instalável é o de `merged/`, que reúne bootstrap, mod interno e Zstd.
O JAR de `versions/1.21.1-neoforge/build/libs/` sozinho é apenas uma parte.

Os fontes já estão convertidos para o alvo selecionado. Para futuras trocas
de versão, use a tarefa gerada pelo Stonecutter `Set active project to ...`;
a declaração de versão ativa isolada não converte os fontes existentes.
[Documentação do Stonecutter](https://stonecutter.kikugie.dev/).

## Validação e pendências

Consulte `VALIDACAO-0.4.md` para os resultados executados nesta entrega.
A versão 0.4 foi instalada em um servidor NeoForge 21.1.253: inicialização,
manifesto SHA-256, TLS e entrada real foram confirmados. O usuário confirmou
a reconexão sem repetir os termos. Ainda faltam revisão visual dentro do
jogo em diferentes escalas, cancelamento/reconexão sob falhas de rede reais,
identidade visual completa (ícones, texturas e demais telas), política de
manifesto obrigatório/assinado e canal próprio de distribuição de releases.

Leia `LICENSE` e `NOTICE-AveronSync.md` para a origem e os avisos.
O README original do AutoModpack está preservado em `README-UPSTREAM.md`.
