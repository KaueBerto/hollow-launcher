# AveronSync 0.6 — instalação no servidor

Instalada em 29/10/2026. Minecraft 1.21.1 / NeoForge 21.1.253 terminou de
iniciar às 13:28:13, horário de São Paulo. O Minecraft foi salvo, parado e
reiniciado pelo Wings. Os serviços de voz continuaram em execução.

## Verificações

- Backup com Minecraft parado: mundo, mods, configurações e dados de
  sincronização. O JAR 0.5 foi preservado fora da pasta `mods`.
- JAR instalado e versão do manifesto: `4.0.6-averonsync.0.6`.
- SHA-256: `784e84358eb17f041d7291d8c8b1dd8f312d602967df28ab3abf3c3e69d208e7`.
- Os demais JARs mantiveram os mesmos bytes do backup. Valores de
  `server.properties` e configurações anteriores de sincronização preservados.
- Fila ativa, capacidade 100, uma admissão por vez e intervalo 5 segundos.
- `maxOnlinePlayers: 0`: segue o `max-players` nativo, atualmente 20.
- `/async limite` executado no console: `Online: 0/20. Limite personalizado:
  desativado. Fila: ativa.` Não foi imposto um novo limite arbitrário.
- Manifesto: 1271 arquivos antes/depois, todos os SHA-256 conferidos.
  Duas entradas tiveram o hash atualizado durante a regeneração: o relatório
  `config/rpg_series/loot_fallback_report.json` e
  `mods/averonorigins-1.8.0-ritual-preview.1.jar`. O JAR de AveronOrigins
  instalado manteve os mesmos bytes do backup; o manifesto anterior estava
  desatualizado em relação a ele. Nenhuma entrada foi adicionada ou removida.
- TLS 1.3 respondeu mantendo o certificado anterior.

## Testes e limite da validação

Os 60 testes automatizados passaram localmente. A fila e o comando de
alteração de limite também foram testados em servidor local com sondas de
protocolo, conforme [documentação da fila](FILA-AVERONSYNC.md).

Em produção foi executada a consulta do limite, sem mudar a quantidade de
vagas escolhida pelo administrador. A sessão com cliente gráfico 0.6,
entrada no mundo e comportamento com jogadores simultâneos permanecem
pendentes. Usar a mesma versão do AveronSync no cliente e no servidor.
