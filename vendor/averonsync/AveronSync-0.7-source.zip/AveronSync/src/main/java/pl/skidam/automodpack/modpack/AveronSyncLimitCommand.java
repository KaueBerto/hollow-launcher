package pl.skidam.automodpack.modpack;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import pl.skidam.automodpack_core.queue.QueueLimitConfig;
import pl.skidam.automodpack_core.queue.QueueSettings;
import static net.minecraft.commands.Commands.*;
import static pl.skidam.automodpack_core.GlobalVariables.*;

public final class AveronSyncLimitCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("async")
                .requires(source -> source.hasPermission(3) && source.getServer().isDedicatedServer())
                .then(literal("limite")
                        .executes(ctx -> status(ctx.getSource()))
                        .then(argument("jogadores", IntegerArgumentType.integer(1))
                                .executes(ctx -> set(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "jogadores"))))
                        .then(literal("off").executes(ctx -> set(ctx.getSource(), 0)))));
    }

    private static int status(CommandSourceStack source) {
        var settings = serverConfig.entryQueue == null ? new QueueSettings() : serverConfig.entryQueue;
        int limit = settings.effectivePlayerLimit(source.getServer().getMaxPlayers());
        int regular = pl.skidam.automodpack.networking.server.AveronSyncAdmissionAccess.regularOnline(source.getServer().getPlayerList());
        int operators = source.getServer().getPlayerCount() - regular;
        source.sendSuccess(() -> Component.literal("[AveronSync] Online: " + regular
                + "/" + limit + " comuns. OPs online: " + operators + ". Limite personalizado: " + (settings.maxOnlinePlayers <= 0 ? "desativado" : settings.maxOnlinePlayers)
                + ". Fila: " + (settings.enabled ? "ativa" : "desativada") + "."), false);
        return 1;
    }

    private static int set(CommandSourceStack source, int limit) {
        if (limit > source.getServer().getMaxPlayers()) {
            source.sendFailure(Component.literal("[AveronSync] O limite nao pode superar max-players ("
                    + source.getServer().getMaxPlayers() + ").")); return 0;
        }
        if (limit > 0 && serverConfig.entryQueue != null && !serverConfig.entryQueue.enabled) {
            source.sendFailure(Component.literal("[AveronSync] Ative entryQueue.enabled na configuracao antes de definir o limite.")); return 0;
        }
        try { serverConfig = QueueLimitConfig.save(serverConfigFile, serverConfig, limit); }
        catch (java.io.IOException | RuntimeException e) {
            LOGGER.error("Unable to save AveronSync online limit", e);
            source.sendFailure(Component.literal("[AveronSync] Falha ao salvar. O limite anterior foi mantido.")); return 0;
        }
        source.sendSuccess(() -> Component.literal(limit == 0
                ? "[AveronSync] Limite personalizado removido. A fila segue max-players. Configuracao salva."
                : "[AveronSync] Limite de " + limit + " jogadores salvo e aplicado. Novas entradas aguardam vaga na fila. Quem ja esta online permanece conectado."), true);
        return 1;
    }
}
