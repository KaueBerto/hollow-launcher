package pl.skidam.automodpack.networking.server;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.players.PlayerList;

/** Uses the server's native OP list; no client-provided permission flag is trusted. */
public final class AveronSyncAdmissionAccess {
    public static boolean bypasses(PlayerList players, GameProfile profile) {
        return players.getServer().isDedicatedServer() && profile != null && players.isOp(profile);
    }

    public static int regularOnline(PlayerList players) {
        int count = 0;
        for (var player : players.getPlayers()) if (!bypasses(players, player.getGameProfile())) count++;
        return count;
    }
}
