# Fila de entrada — AveronSync 0.6

## Comportamento

A fila atua em servidor dedicado Minecraft 1.21.1 / NeoForge. Depois de
terminar a negociação do modpack, cada conexão recebe uma posição FIFO.
O primeiro cliente pronto entra primeiro. Downloads ainda em andamento
não reservam posição. O single-player não usa a fila.

Por padrão, uma conexão avança por vez. O servidor conserva a permissão
até detectar a entrada efetiva daquela conexão na lista de jogadores,
desconexão ou expiração. Após liberar essa permissão, aguarda pelo menos
5 segundos para a próxima entrada. O jogador que acabou de entrar não
precisa sair do servidor para liberar a próxima pessoa.

Se o servidor estiver cheio, as conexões permanecem aguardando. A fila não
substitui a capacidade máxima de jogadores nem as verificações nativas de
acesso. A confirmação de entrada compara a conexão real, sem depender de
um UUID permanecer igual durante a autenticação em modo offline.

O cliente mostra `AveronSync — Fila: posição X de Y. Aguarde...` na tela de
conexão existente, mantendo seu botão de cancelar. A posição é enviada
aproximadamente uma vez por segundo e requer resposta do cliente. Ao
cancelar/desconectar, a posição é removida no próximo tick. A fila não
repete o aceite dos termos.

## Limitar jogadores online pelo comando (0.6)

Somente no servidor dedicado, com OP nível 3 ou pelo console:

- `/async limite 20`: limita as novas admissões a 20 jogadores online.
- `/async limite`: mostra jogadores online, limite efetivo e estado da fila.
- `/async limite off`: remove o limite personalizado e segue `max-players`.

A alteração é aplicada no próximo tick, sem reiniciar, e salva em
`entryQueue.maxOnlinePlayers`. O valor padrão `0` segue o limite nativo.
O comando aceita números a partir de 1 e não permite superar `max-players`
de `server.properties`. Não altera o limite anunciado na lista de servidores.

Ao ocupar todas as vagas, novos jogadores aguardam na fila. Jogadores
conectados e admissões já liberadas contam no cálculo. Reduzir o limite
não expulsa ninguém nem revoga uma admissão já liberada; novas permissões
aguardam até que o total fique abaixo do limite. A ordem da fila permanece.
Ao aumentar o limite, a próxima entrada ainda respeita o intervalo e o
número máximo de admissões simultâneas configurados.

Se a fila estiver desabilitada, o comando recusa um limite personalizado.
Uma falha de gravação exibe erro e mantém o limite anterior em memória.
Não foi adicionado nenhum comando de whitelist.

## Configurar

No servidor, editar `automodpack/automodpack-server.json`, preservando os
outros campos, e reiniciar:

```json
"entryQueue": {
  "enabled": true,
  "maxOnlinePlayers": 0,
  "maxQueuedPlayers": 100,
  "maxConcurrentAdmissions": 1,
  "admissionIntervalSeconds": 5,
  "maxWaitSeconds": 600,
  "admissionTimeoutSeconds": 120
}
```

O trecho é um campo do JSON existente. `maxQueuedPlayers` conta tanto
conexões aguardando quanto admissões em andamento. `maxWaitSeconds` vale
para a espera na fila; `admissionTimeoutSeconds` começa quando a conexão
recebe permissão e limita o tempo até aparecer na lista de jogadores.
O cliente que não responde a uma atualização por 30 segundos é desconectado.
Os parâmetros do agendador são lidos na inicialização. O limite online pode
ser alterado ao vivo pelo comando acima; não é necessário reiniciar para isso.

Valores são limitados: capacidade 1–1000, admissões 1–capacidade, intervalo
1–300 segundos, espera 10–3600 segundos, admissão 10–300 segundos. Campos
ausentes usam os padrões acima. `entryQueue: null` também usa os padrões.

## Compatibilidade e proteção básica

Instalar o AveronSync **0.6 em ambos os lados** para testar esta atualização. O canal
de login `automodpack:queue` é novo. Quem não entende esse canal recebe uma
mensagem solicitando atualização e não atravessa a fila. Desativar
`entryQueue.enabled` mantém o fluxo de login anterior.

Uma segunda conexão com o mesmo nickname, sem distinguir maiúsculas e
minúsculas, é rejeitada enquanto a primeira aguarda ou entra. Existe limite
fixo de 10 tentativas de ingresso na fila por endereço em cada janela de
60 segundos. Pessoas atrás do mesmo NAT compartilham esse limite; o mapa
é limitado a 4096 endereços. Esse controle ocorre após a negociação do
modpack e não é uma proteção contra DDoS ou excesso de handshakes iniciais.

Em `online-mode=false`, o nome não autentica a pessoa. A fila não altera a
whitelist nem os mods de login. A compatibilidade com EasyLogin e
OfflineWhitelist instalados no servidor real ainda precisa ser validada.

## Validação realizada

Na 0.6: **60 testes automatizados aprovados** (51 core + 9 loader-core).
Os 6 novos testes cobrem vagas reservadas, mudanças de limite, capacidade
nativa, persistência, configuração antiga e falha de gravação. No servidor
local NeoForge 21.1.253, o comando foi executado pelo console com sondas
de login reais: limite personalizado abaixo da capacidade nativa, aumento
liberando a fila, redução preservando conexões já liberadas, desconexão
abrindo vaga, consulta, `off` e entradas inválidas. O ensaio não usa clientes
gráficos nem substitui o teste com jogadores online no modpack completo.
O teste de persistência relê o JSON salvo; não simula reinício completo do
servidor. A atualização 0.6 ainda não foi instalada na VPS.

Histórico de validação da 0.5:

- Compilação do JAR completo com Java 21 e testes `core`/`loader-core`:
  **54 testes aprovados**, incluindo 12 testes novos do agendador.
- Rajada de 100 inscrições preserva ordem e limite de admissões; testes
  cobrem cancelamento, duplicidade, capacidade, servidor cheio, expiração,
  intervalo, paralelismo configurável, limite por endereço e configuração antiga.
- Servidor local isolado com NeoForge **21.1.253**, porta de loopback:
  negociação real do login, primeira admissão, posições 1/2, rejeição de
  duplicidade e fila cheia, cancelamento com atualização das posições,
  liberação após desconexão com intervalo observado de cerca de 2 segundos
  (configuração reduzida para teste), rejeição de canal não suportado,
  expiração de espera e recuperação após admissão travada.
- Servidor configurado como cheio: uma conexão permaneceu **35,75 segundos**
  aguardando, recebeu **36 atualizações** de posição e não sofreu o timeout
  padrão de login durante essa espera.

Os clientes desse ensaio são sondas de protocolo; não renderizam a tela nem
entram no mundo como um cliente Minecraft completo. O teste de reconhecimento
de entrada efetiva no mundo e a compatibilidade com todos os mods exigem
uma sessão com jogadores. Em 28/10/2026, a versão 0.5 foi instalada na VPS
com backup e reinício completo do sistema. A inicialização do Minecraft,
as configurações da fila, o JAR e o certificado foram verificados. O teste
com cliente gráfico 0.5 no servidor de produção permanece pendente.

## Limites desta entrega

O controle é de **entrada no mundo**, sem fila própria para downloads de
arquivos. O limite global de banda herdado (`bandwidthLimit`) permanece
disponível, mas limitar usuários simultâneos baixando exige uma etapa
separada. Não há medição automática de TPS/MSPT para pausar a fila, prioridade
VIP, reserva de posição após reiniciar o cliente ou persistência após reiniciar
o servidor. Os valores padrão precisam ser ajustados em teste com o modpack real.
