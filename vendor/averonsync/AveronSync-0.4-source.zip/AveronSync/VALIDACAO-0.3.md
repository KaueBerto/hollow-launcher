# AveronSync 0.3 — whitelist

Data: 26/10/2026. Alvo: Minecraft 1.21.1 / NeoForge 21.1.169.
Artefato: `averonsync-mc1.21.1-neoforge-4.0.6-averonsync.0.3.jar`.

## Implementado

- `/async whitelist Nickname`: adiciona o jogador e ativa a whitelist nativa.
- `/async whitelist add Nickname`: forma explícita de inclusão.
- `/async whitelist remove Nickname`: remove o jogador.
- `/async whitelist list` ou `/async whitelist`: mostra o estado e a lista.
- Console ou OP com nível de permissão 3, apenas em servidor dedicado.
- Validação de nickname antes de montar os comandos nativos.
- Nomes resolvidos e persistidos pelo Minecraft em `whitelist.json`.
- Inclusão idempotente e ativação somente após inclusão bem-sucedida, ou
  quando o nome já estiver autorizado.
- Remover o último jogador não desativa a whitelist.
- Permissão verificada no subcomando mesmo se outro mod já tiver criado
  um comando raiz chamado `async`.

Os comandos delegam às operações nativas `whitelist add/on/remove/list`,
usando a mesma origem e permissões do administrador, sem elevar privilégios.
As regras de OP, `online-mode`, `enforce-whitelist` e os efeitos da ativação
continuam sendo os do Minecraft. Consulte `WHITELIST.md` para uso e limites.
Os termos com aceite único da versão 0.2 continuam presentes.

## Verificação

Comando:
`./gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --console=plain`.

Resultado: compilação concluída e **49 testes sem falhas**: 33 no core,
9 no loader-core e 7 novos testes de comandos no subprojeto Minecraft.

Os testes novos usam o dispatcher Brigadier real e uma implementação de
operações de servidor em memória. Cobrem a sintaxe solicitada, restrição a
administradores, comando raiz compartilhado, duplicatas, ativação da lista,
inclusão/remoção/listagem, palavras reservadas como nickname, nomes inválidos,
tentativas de injetar comandos e falha ao localizar um jogador.

O adaptador que chama as operações do Minecraft foi compilado contra a API
do NeoForge/Minecraft alvo. A inspeção do JAR final confere a classe de
comandos, o registro no mod, os metadados da versão 0.3 e a integridade do
bootstrap e do mod interno.

**Não foi executado um servidor Minecraft real nesta etapa.** Ainda precisam
ser testados no jogo o comando por OP/console, persistência após reinício e
conexões de contas autorizadas e não autorizadas. A entrega contém o JAR
compilado e os fontes; nenhuma instalação ou configuração de servidor do
usuário foi alterada.

Evidências: `../evidencias-0.3/`. Hashes dos artefatos:
`../SHA256SUMS-0.3.txt` na entrega local.
