package pl.skidam.automodpack_loader_core.utils;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import pl.skidam.automodpack_core.config.ConfigTools;
import pl.skidam.automodpack_core.config.Jsons.ModpackContentFields;
import pl.skidam.automodpack_core.utils.ClientCacheUtils;
import pl.skidam.automodpack_core.utils.CustomFileUtils;
import pl.skidam.automodpack_core.utils.Sha256;
import pl.skidam.automodpack_loader_core.client.ModpackUtils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static pl.skidam.automodpack_core.GlobalVariables.hostModpackContentFile;

class ManifestVerificationTest {
    @TempDir Path temp;

    @Test void sha1MetadataCacheCannotHideSha256Mismatch() throws Exception {
        Path pack = Files.createDirectories(temp.resolve("pack"));
        Path file = pack.resolve("file.bin");
        Files.writeString(file, "abc");
        String sha1 = CustomFileUtils.getHash(file);
        var item = new ModpackContentFields.ModpackContentItem("/file.bin", "3", "other", false, false, sha1, null, Sha256.hash(file));
        var manifest = new ModpackContentFields(Set.of(item));
        ConfigTools.saveModpackContent(pack.resolve(hostModpackContentFile.getFileName()), manifest);
        ClientCacheUtils.updateCache(file, sha1);
        assertFalse(ModpackUtils.isUpdate(manifest, pack).requiresUpdate());
        var originalTime = Files.getLastModifiedTime(file);
        Files.writeString(file, "abd");
        Files.setLastModifiedTime(file, originalTime);
        assertEquals(sha1, ClientCacheUtils.getVerifiedCacheHash(file));
        var result = ModpackUtils.isUpdate(manifest, pack);
        assertTrue(result.requiresUpdate());
        assertEquals(Set.of(item), result.filesToUpdate());
    }

    @Test void editableFileKeepsUserChanges() throws Exception {
        Path pack = Files.createDirectories(temp.resolve("pack"));
        Path file = pack.resolve("options.txt");
        Files.writeString(file, "abc");
        var item = new ModpackContentFields.ModpackContentItem("/options.txt", "3", "other", true, false, CustomFileUtils.getHash(file), null, Sha256.hash(file));
        var manifest = new ModpackContentFields(Set.of(item));
        ConfigTools.saveModpackContent(pack.resolve(hostModpackContentFile.getFileName()), manifest);
        Files.writeString(file, "user settings");
        assertFalse(ModpackUtils.isUpdate(manifest, pack).requiresUpdate());
    }
}
