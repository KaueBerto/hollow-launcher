package pl.skidam.automodpack_core.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

class AveronSyncConsentTest {
    @TempDir Path temp;

    @Test void persistsAcrossRestartsAndCanBeRevoked() throws Exception {
        Path file = temp.resolve("game/automodpack/averonsync-consent.json");
        var consent = new AveronSyncConsent(file);
        assertFalse(consent.isAccepted());
        consent.accept();
        assertTrue(new AveronSyncConsent(file).isAccepted());
        consent.accept();
        assertTrue(new AveronSyncConsent(file).isAccepted());
        Files.delete(file);
        assertFalse(consent.isAccepted());
    }

    @Test void missingCorruptOrUnacceptedStateDoesNotImplyConsent() throws Exception {
        Path file = temp.resolve("consent.json");
        var consent = new AveronSyncConsent(file);
        for (String data : new String[]{"null", "{}", "broken", "{\"termsVersion\":0}", "{\"termsVersion\":2}"}) {
            Files.writeString(file, data);
            assertFalse(consent.isAccepted(), data);
        }
    }

    @Test void writeFailureCannotBeMistakenForAcceptance() throws Exception {
        Path blocked = temp.resolve("not-a-directory");
        Files.writeString(blocked, "blocked");
        var consent = new AveronSyncConsent(blocked.resolve("consent.json"));
        assertThrows(java.io.IOException.class, consent::accept);
        assertFalse(consent.isAccepted());
    }
}
