package pl.skidam.automodpack_core.utils;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import pl.skidam.automodpack_core.config.ConfigTools;
import pl.skidam.automodpack_core.config.Jsons.ModpackContentFields.ModpackContentItem;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;

class Sha256Test {
    @TempDir Path temp;
    private static final String ABC = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";

    @Test void knownVectorsAndLargeFile() throws Exception {
        Path file = temp.resolve("data");
        Files.writeString(file, "abc");
        assertEquals(ABC, Sha256.hash(file));
        Files.write(file, new byte[0]);
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", Sha256.hash(file));
        byte[] bytes = new byte[200000];
        java.util.Arrays.fill(bytes, (byte) 'a');
        Files.write(file, bytes);
        assertEquals("2287d207f24a941ff3b56c04c8a25ad56b63e3023207b3bb5b4ac0c9869d74be", Sha256.hash(file));
    }

    @Test void rejectsTamperedMissingAndMalformedFiles() throws Exception {
        Path file = temp.resolve("data");
        Files.writeString(file, "abc");
        assertTrue(Sha256.matchesOptional(file, ABC.toUpperCase(Locale.ROOT)));
        for (String invalid : new String[]{"", " ", "0".repeat(64), "g".repeat(64), ABC + "0"}) {
            assertFalse(Sha256.matchesOptional(file, invalid));
        }
        Files.writeString(file, "abd");
        assertFalse(Sha256.matchesOptional(file, ABC));
        Files.delete(file);
        assertFalse(Sha256.matchesOptional(file, ABC));
    }

    @Test void oldManifestRemainsReadableAndNewFieldRoundTrips() {
        String legacy = "{\"file\":\"/mods/demo.jar\",\"sha1\":\"legacy\",\"size\":\"3\"}";
        var oldItem = ConfigTools.GSON.fromJson(legacy, ModpackContentItem.class);
        assertNull(oldItem.sha256);
        assertTrue(Sha256.matchesOptional(temp.resolve("unused"), oldItem.sha256));
        var item = new ModpackContentItem("/mods/demo.jar", "3", "mod", false, false, "legacy", null, ABC);
        var decoded = ConfigTools.GSON.fromJson(ConfigTools.GSON.toJson(item), ModpackContentItem.class);
        assertEquals(ABC, decoded.sha256);
        assertEquals("legacy", decoded.sha1);
        assertEquals(item.file, decoded.file);
    }
}
