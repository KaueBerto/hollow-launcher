# AveronSync

Fork independente do **AutoModpack 4.0.6**, de Skidam e colaboradores, para
**Minecraft 1.21.1 / NeoForge**.

Versão atual: **4.0.6-averonsync.0.8**.

## O que mudou

- Identidade inicial AveronSync nos metadados e na tela de download.
- SHA-256 por arquivo no manifesto, com verificação no cliente.
- Termos próprios com aceite único salvo por instalação, sem contagem
  regressiva ou nova confirmação em cada atualização do modpack.
- Atualizador oficial desativado para impedir a substituição do fork.
- Os comandos próprios de whitelist da versão 0.3 foram removidos na 0.4.
- Fila FIFO antes da entrada no mundo, com posição na tela de conexão,
  controle de admissões simultâneas e intervalo entre entradas.
- `/async limite <quantidade>` define e salva o limite de jogadores online,
  aplicando o controle de vagas à fila sem reiniciar. Exige OP nível 3 ou console.
- OPs entram sem fila, ignoram o limite de jogadores e não ocupam as vagas
  comuns. Banimentos e as verificações nativas de acesso permanecem.
- `/async limite 0` fecha novas entradas para jogadores comuns, mantendo-os
  na fila; OPs continuam entrando. Um limite positivo ou `off` reabre a fila.

Os IDs internos e o protocolo da base 4.0.6 foram mantidos. Use AveronSync no
lugar do AutoModpack na instalação. O protocolo da versão 5 do AutoModpack
não é equivalente ao desta base.

## Compilar

Tenha JDK 21 para Gradle/Minecraft e JDK 17 disponível para os módulos core.

```powershell
.\gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --console=plain
```

O JAR completo fica em `merged/`. O JAR intermediário do subprojeto Minecraft
sozinho não reúne todas as partes do carregador.

O GitHub Actions compila esse alvo, executa os testes e disponibiliza o JAR
como artefato da execução. Não publica automaticamente no Modrinth/CurseForge.

## Validação e documentação

A versão 0.8 adiciona o modo somente OPs, com persistência própria para
preservar a interpretação de configurações antigas. A VPS e o GitHub seguem
na versão 0.7 até a instalação/publicação desta atualização.

A versão 0.7 passou nos **60 testes automatizados** e nos cenários de login
local de bypass de OP, promoção/revogação, limite e banimentos. O teste com
cliente gráfico continua pendente. A 0.7 foi instalada na VPS em 29/10/2026,
com backup dos componentes atualizados, reinício do Minecraft e consulta
do comando confirmada no console.

A versão 0.6 passou em **60 testes**, incluindo 6 novos testes de capacidade
e persistência do limite. O comando também foi testado no console de um
servidor NeoForge local com conexões de protocolo. Em 29/10/2026, a versão
0.6 foi instalada na VPS com backup e reinício do Minecraft. O comando de
consulta respondeu no console; o teste com cliente gráfico ainda está pendente.

A versão 0.5 passou em **54 testes**, incluindo 12 cenários do agendador da
fila. A integração de login foi testada com conexões de protocolo em um
servidor local NeoForge 21.1.253. A tela no cliente gráfico e o comportamento
com o modpack completo em produção ainda precisam de teste com jogadores.
Configuração, compatibilidade e evidências em [FILA-AVERONSYNC.md](FILA-AVERONSYNC.md).

A versão 0.4 passou nos **42 testes** e foi testada em servidor
Minecraft 1.21.1 / NeoForge 21.1.253. Foram confirmados o manifesto SHA-256,
TLS, entrada real e reconexão sem repetir o aceite dos termos. Ainda não foi
simulada uma nova alteração de mods no servidor após esse aceite.

- [Arquitetura, implementação e limites](README-AVERONSYNC.md)
- [Termos de sincronização](TERMOS-AVERONSYNC.md)
- [Fila e exceção para OPs na versão 0.7](FILA-AVERONSYNC.md)
- [Instalação e verificação da versão 0.7 no servidor](VALIDACAO-SERVIDOR-0.7.md)
- [Instalação e verificação da versão 0.6 no servidor](VALIDACAO-SERVIDOR-0.6.md)
- [Validação da versão 0.4](VALIDACAO-0.4.md)
- [Teste real em servidor](VALIDACAO-SERVIDOR-0.4.md)
- [Avisos e origem do fork](NOTICE-AveronSync.md)
- [README original do AutoModpack](README-UPSTREAM.md)

## Origem e licença

Base: [Skidamek/AutoModpack, tag v4.0.6](https://github.com/Skidamek/AutoModpack/tree/v4.0.6),
commit `2ff957d03ffb4253fea0c0cbda4d0def4e9528d6`.

O histórico e os créditos originais foram preservados. A licença LGPLv3 está
em [LICENSE](LICENSE), acompanhada do texto da [GPLv3](COPYING-GPL-3.0.txt).
Os recursos visuais herdados ainda não foram substituídos integralmente.
