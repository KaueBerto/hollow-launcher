package pl.skidam.automodpack_core.queue;

import java.nio.file.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import pl.skidam.automodpack_core.config.ConfigTools;
import pl.skidam.automodpack_core.config.Jsons;
import static org.junit.jupiter.api.Assertions.*;

class QueueLimitTest {
    @TempDir Path temp;

    @Test void onlineAndReservedSlotsBothCountTowardsLimit() {
        var settings = new QueueSettings(); settings.maxOnlinePlayers = 20;
        assertTrue(settings.hasRoom(18, 1, 100));
        assertFalse(settings.hasRoom(19, 1, 100));
        assertFalse(settings.hasRoom(20, 0, 100));
        assertFalse(settings.hasRoom(Integer.MAX_VALUE, 1, 100));
    }

    @Test void opsOnlyClosesOrdinaryAdmissionsEvenWhenNativeCapacityIsAvailable() {
        var settings = new QueueSettings(); settings.maxOnlinePlayers = 20; settings.opsOnly = true;
        assertEquals(0, settings.effectivePlayerLimit(100));
        assertFalse(settings.hasRoom(0, 0, 100));
        settings.opsOnly = false; assertTrue(settings.hasRoom(0, 0, 100));
    }

    @Test void opsOnlyPersistsAndCanBeReopenedWithoutChangingLegacyZeroMeaning() throws Exception {
        var current = new Jsons.ServerConfigFieldsV2();
        Path path = temp.resolve("server.json");
        QueueLimitConfig.save(path, current, 0, true);
        assertFalse(current.entryQueue.opsOnly);
        var loaded = ConfigTools.GSON.fromJson(Files.readString(path), Jsons.ServerConfigFieldsV2.class);
        assertTrue(loaded.entryQueue.opsOnly); assertFalse(loaded.entryQueue.hasRoom(0, 0, 20));
        var reopened = QueueLimitConfig.save(path, loaded, 5);
        assertFalse(reopened.entryQueue.opsOnly); assertEquals(5, reopened.entryQueue.effectivePlayerLimit(20));
        var nativeLimit = QueueLimitConfig.save(path, reopened, 0);
        assertFalse(nativeLimit.entryQueue.opsOnly); assertEquals(20, nativeLimit.entryQueue.effectivePlayerLimit(20));
    }

    @Test void loweringAndIncreasingLimitImmediatelyChangesAdmissionWithoutRemovingPlayers() {
        var settings = new QueueSettings(); settings.maxOnlinePlayers = 10;
        assertFalse(settings.hasRoom(12, 0, 100));
        settings.maxOnlinePlayers = 15; assertTrue(settings.hasRoom(12, 0, 100));
        settings.maxOnlinePlayers = 5; assertFalse(settings.hasRoom(12, 0, 100));
        assertTrue(settings.hasRoom(4, 0, 100));
    }

    @Test void followsNativeCapacityByDefaultAndCannotExceedIt() {
        var settings = new QueueSettings(); assertEquals(0, settings.maxOnlinePlayers);
        assertEquals(30, settings.effectivePlayerLimit(30));
        settings.maxOnlinePlayers = 100; assertEquals(30, settings.effectivePlayerLimit(30));
        assertFalse(settings.hasRoom(0, 0, 0));
    }

    @Test void savedLimitSurvivesReloadAndPreservesOtherConfiguration() throws Exception {
        var current = new Jsons.ServerConfigFieldsV2(); current.modpackName = "Example";
        current.entryQueue.admissionIntervalSeconds = 7;
        Path path = temp.resolve("automodpack/server.json");
        var saved = QueueLimitConfig.save(path, current, 20);
        assertEquals(0, current.entryQueue.maxOnlinePlayers);
        assertEquals(20, saved.entryQueue.maxOnlinePlayers);
        var loaded = ConfigTools.GSON.fromJson(Files.readString(path), Jsons.ServerConfigFieldsV2.class);
        assertEquals(20, loaded.entryQueue.maxOnlinePlayers);
        assertEquals(7, loaded.entryQueue.admissionIntervalSeconds); assertEquals("Example", loaded.modpackName);
        QueueLimitConfig.save(path, loaded, 0);
        assertEquals(0, ConfigTools.GSON.fromJson(Files.readString(path), Jsons.ServerConfigFieldsV2.class).entryQueue.maxOnlinePlayers);
    }

    @Test void saveFailureDoesNotChangeRunningConfiguration() throws Exception {
        var current = new Jsons.ServerConfigFieldsV2(); current.entryQueue.maxOnlinePlayers = 20;
        Path blocked = temp.resolve("blocked"); Files.writeString(blocked,"file");
        assertThrows(java.io.IOException.class, () -> QueueLimitConfig.save(blocked.resolve("server.json"),current,5));
        assertEquals(20,current.entryQueue.maxOnlinePlayers);
    }

    @Test void nullLegacyQueueSettingsAreCreatedAndNegativeLimitIsRejected() throws Exception {
        var current = new Jsons.ServerConfigFieldsV2(); current.entryQueue = null;
        var saved = QueueLimitConfig.save(temp.resolve("server.json"),current,10);
        assertEquals(10,saved.entryQueue.maxOnlinePlayers); assertNull(current.entryQueue);
        assertThrows(IllegalArgumentException.class, () -> QueueLimitConfig.save(temp.resolve("server.json"),saved,-1));
    }
}
