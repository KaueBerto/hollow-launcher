package pl.skidam.automodpack_core.queue;

/** Serialized under entryQueue in automodpack/automodpack-server.json. */
public final class QueueSettings {
    public boolean enabled = true;
    public int maxOnlinePlayers = 0; // 0 follows the native max-players setting
    public boolean opsOnly = false;

    public int effectivePlayerLimit(int nativeLimit) {
        if (opsOnly) return 0;
        return maxOnlinePlayers <= 0 ? Math.max(0, nativeLimit) : Math.max(0, Math.min(nativeLimit, maxOnlinePlayers));
    }

    public boolean hasRoom(int online, int admitted, int nativeLimit) {
        return (long) online + admitted < effectivePlayerLimit(nativeLimit);
    }
    public int maxQueuedPlayers = 100;
    public int maxConcurrentAdmissions = 1;
    public int admissionIntervalSeconds = 5;
    public int maxWaitSeconds = 600;
    public int admissionTimeoutSeconds = 120;

    public AdmissionQueue createQueue() {
        int capacity = Math.max(1, Math.min(1000, maxQueuedPlayers));
        return new AdmissionQueue(capacity, Math.max(1, Math.min(capacity, maxConcurrentAdmissions)),
                Math.max(1, Math.min(300, admissionIntervalSeconds)) * 1000L,
                Math.max(10, Math.min(3600, maxWaitSeconds)) * 1000L,
                Math.max(10, Math.min(300, admissionTimeoutSeconds)) * 1000L);
    }
}
