# AveronSync 0.7 — instalação no servidor

Instalada em 29/10/2026. Minecraft 1.21.1 / NeoForge 21.1.253 terminou de
iniciar às 14:21:23, horário de São Paulo. O Minecraft foi salvo, parado e
reiniciado pelo Wings; os serviços de voz permaneceram em execução.

## Verificações

- Backup com Minecraft parado: JAR anterior, configuração e manifesto de
  sincronização, arquivos operacionais de acesso, propriedades e log.
  Os backups completos anteriores foram preservados; o mundo não foi
  duplicado novamente nesta atualização, para economizar disco.
- JAR instalado e manifesto: `4.0.6-averonsync.0.7`.
- SHA-256: `19bd47a8810280f0db65292faa75618e931cc563dc5debc3e4e143f65d6df349`.
- Os demais JARs mantiveram os hashes registrados antes da troca. As
  propriedades do Minecraft e as configurações da fila foram preservadas.
- Fila ativa: capacidade 100, uma admissão por vez e intervalo 5 segundos.
- Limite personalizado `0`, seguindo a capacidade nativa de 20 jogadores comuns.
- `/async limite` respondeu: `Online: 0/20 comuns. OPs online: 0.
  Limite personalizado: desativado. Fila: ativa.`
- Manifesto com 1271 arquivos, todos os SHA-256 conferidos. Nenhum arquivo
  adicionado/removido; somente o relatório gerado
  `config/rpg_series/loot_fallback_report.json` mudou durante a inicialização.
- TLS 1.3 respondeu mantendo o certificado anterior.

## Testes e limites

Os 60 testes automatizados passaram localmente. Também passaram 7 cenários
de protocolo para OPs e 6 de regressão de fila/limite em NeoForge local.
Os cenários de OP incluem fila cheia, capacidade nativa zero, promoção,
revogação e rejeição por banimento de jogador/IP.

Em produção foram confirmadas a inicialização e a consulta no console.
A entrada real de um OP com cliente gráfico e a contagem de vagas com
jogadores conectados continuam pendentes. Usar a versão 0.7 no cliente e
no servidor. As verificações nativas de acesso continuam aplicáveis.
