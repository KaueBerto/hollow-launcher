package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.server.*;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import pl.skidam.automodpack_core.mounts.ParroLevels;
import pl.skidam.automodpack_core.mounts.ParroRegistry;
import java.io.IOException;
import java.util.*;
import static net.minecraft.commands.Commands.*;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

/**
 * Parro ownership and summoning. An admin (or a quest running as OP 2) grants the Parro
 * permanently with {@code /async parro dar}; the owner calls and stores it from menu G or
 * {@code /parro}. Like the pack's MCPets pet it is not saved in the world: one active per
 * owner, stored on logout, dimension change or shutdown. Experience and saddle persist.
 */
public final class AveronSyncParro {
    /** MCPets default: the Parro can be called again 30 seconds after dying. */
    private static final long RESPAWN_COOLDOWN_MS = 30_000;
    private static final Map<MinecraftServer, State> SERVERS = new IdentityHashMap<>();
    private static final class State {
        final UUID session = UUID.randomUUID();
        final Map<UUID, ParroEntity> active = new HashMap<>();
        final Map<UUID, Long> diedAt = new HashMap<>();
        ParroRegistry registry;
        State(MinecraftServer server) {
            try { registry = new ParroRegistry(server.getWorldPath(LevelResource.ROOT).resolve("data/averonsync-parro.json")); }
            catch (IOException e) { LOGGER.error("Parro disabled: cannot read data/averonsync-parro.json (original preserved)", e); }
        }
    }
    private static State state(MinecraftServer server) { return SERVERS.computeIfAbsent(server, State::new); }
    static boolean authenticated(ServerPlayer player) { return AveronSyncQuestHorses.authenticated(player); }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("async").then(literal("parro").requires(s -> s.hasPermission(2))
                .then(literal("dar").then(argument("jogador", EntityArgument.player())
                        .executes(c -> grant(c.getSource(), EntityArgument.getPlayer(c, "jogador")))))
                .then(literal("remover").then(argument("jogador", EntityArgument.player())
                        .executes(c -> revoke(c.getSource(), EntityArgument.getPlayer(c, "jogador")))))
                .then(literal("info").then(argument("jogador", EntityArgument.player())
                        .executes(c -> info(c.getSource(), EntityArgument.getPlayer(c, "jogador")))))));
        dispatcher.register(literal("parro")
                .executes(c -> status(c.getSource()))
                .then(literal("chamar").executes(c -> summon(c.getSource().getPlayerOrException())))
                .then(literal("guardar").executes(c -> store(c.getSource().getPlayerOrException()))));
    }
    private static int fail(CommandSourceStack source, String message) {
        if (source.getEntity() instanceof ServerPlayer player) player.displayClientMessage(Component.literal(message), true);
        else source.sendFailure(Component.literal("[AveronSync] " + message));
        return 0;
    }
    private static int grant(CommandSourceStack source, ServerPlayer player) {
        State state = state(source.getServer());
        if (state.registry == null) return fail(source, "Cadastro do Parro indisponível. Veja o log.");
        try {
            boolean added = state.registry.grant(player.getUUID());
            source.sendSuccess(() -> Component.literal("[AveronSync] " + (added ? "Parro entregue a " : "Já tinha um Parro: ")
                    + player.getGameProfile().getName()), true);
            if (added) player.displayClientMessage(Component.literal("Você ganhou o Parro! Chame pelo menu G ou /parro chamar."), false);
            return 1;
        } catch (IOException e) { LOGGER.error("Could not grant Parro", e); return fail(source, "Não foi possível salvar. Nada foi entregue."); }
    }
    private static int revoke(CommandSourceStack source, ServerPlayer player) {
        State state = state(source.getServer());
        if (state.registry == null) return fail(source, "Cadastro do Parro indisponível. Veja o log.");
        try {
            dismiss(state, player.getUUID(), false);
            boolean removed = state.registry.revoke(player.getUUID());
            source.sendSuccess(() -> Component.literal("[AveronSync] " + (removed ? "Parro removido de " : "Sem Parro: ") + player.getGameProfile().getName()), true);
            return 1;
        } catch (IOException e) { LOGGER.error("Could not revoke Parro", e); return fail(source, "Não foi possível salvar. Estado anterior preservado."); }
    }
    private static int info(CommandSourceStack source, ServerPlayer player) {
        State state = state(source.getServer());
        var entry = state.registry == null ? Optional.<ParroRegistry.Entry>empty() : state.registry.get(player.getUUID());
        String text = entry.map(e -> ParroLevels.forExperience(e.experience()).name() + ", " + ParroLevels.formatXp(e.experience())
                + " xp" + (e.saddled() ? ", com sela" : "") + (state.active.containsKey(player.getUUID()) ? ", chamado" : "")).orElse("sem Parro");
        source.sendSuccess(() -> Component.literal("[AveronSync] " + player.getGameProfile().getName() + ": " + text), false);
        return 1;
    }
    private static int status(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        source.sendSuccess(() -> Component.literal(menuStatus(player)), false);
        return 1;
    }

    /** Menu G: 0 = no Parro, 1 = stored, 2 = called. */
    public static int menuState(ServerPlayer player) {
        State state = state(player.server);
        if (state.registry == null || !state.registry.owns(player.getUUID())) return 0;
        var active = state.active.get(player.getUUID());
        return active != null && !active.isRemoved() ? 2 : 1;
    }
    public static String menuStatus(ServerPlayer player) {
        State state = state(player.server);
        var entry = state.registry == null ? Optional.<ParroRegistry.Entry>empty() : state.registry.get(player.getUUID());
        if (entry.isEmpty()) return "Você ainda não tem o Parro.";
        var active = state.active.get(player.getUUID());
        double xp = active != null ? active.experience() : entry.get().experience();
        return ParroLevels.forExperience(xp).name() + " • " + ParroLevels.formatXp(xp) + " xp" + (entry.get().saddled() ? " • Com sela" : "");
    }

    static int summon(ServerPlayer player) {
        if (!authenticated(player)) return fail(player.createCommandSourceStack(), "Faça login primeiro.");
        State state = state(player.server);
        if (state.registry == null) return fail(player.createCommandSourceStack(), "Parro indisponível. Avise a administração.");
        var entry = state.registry.get(player.getUUID());
        if (entry.isEmpty()) return fail(player.createCommandSourceStack(), "Você ainda não tem o Parro.");
        var current = state.active.get(player.getUUID());
        if (current != null && !current.isRemoved()) return fail(player.createCommandSourceStack(), "Seu Parro já está com você.");
        long died = state.diedAt.getOrDefault(player.getUUID(), 0L), wait = died + RESPAWN_COOLDOWN_MS - System.currentTimeMillis();
        if (wait > 0) return fail(player.createCommandSourceStack(), "O Parro está se recuperando. Aguarde " + (wait / 1000 + 1) + "s.");
        if (!player.isAlive() || player.isSpectator() || player.isPassenger()) return fail(player.createCommandSourceStack(), "Desmonte e fique no chão.");
        ParroEntity parro = AveronSyncHorseContent.PARRO.get().create(player.serverLevel());
        if (parro == null) return 0;
        parro.setup(player.getUUID(), state.session, entry.get().experience(), entry.get().saddled());
        if (!place(player, parro)) return fail(player.createCommandSourceStack(), "Sem espaço livre perto de você.");
        state.active.put(player.getUUID(), parro);
        if (!player.serverLevel().addFreshEntity(parro)) { state.active.remove(player.getUUID()); parro.discard(); return 0; }
        parro.spawnAnimation();
        return 1;
    }
    /** MCPets SpawnRange 3: a free, solid spot within three blocks of the owner. */
    private static boolean place(ServerPlayer player, ParroEntity parro) {
        ServerLevel level = player.serverLevel();
        BlockPos origin = player.blockPosition();
        for (int radius = 2; radius <= 3; radius++) for (int dx = -radius; dx <= radius; dx++) for (int dz = -radius; dz <= radius; dz++)
            for (int dy : new int[]{0, 1, -1}) {
                BlockPos pos = origin.offset(dx, dy, dz);
                if (!level.hasChunkAt(pos) || !level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP)) continue;
                parro.moveTo(pos.getX() + .5, pos.getY(), pos.getZ() + .5, player.getYRot(), 0);
                var box = parro.getBoundingBox();
                if (level.noCollision(parro, box) && !level.containsAnyLiquid(box) && level.getWorldBorder().isWithinBounds(box)) return true;
            }
        return false;
    }
    static int store(ServerPlayer player) {
        State state = state(player.server);
        if (!state.active.containsKey(player.getUUID())) return fail(player.createCommandSourceStack(), "Seu Parro não está chamado.");
        dismiss(state, player.getUUID(), true);
        return 1;
    }
    private static void save(State state, ParroEntity parro) {
        if (state.registry == null || parro.owner() == null || !parro.takeExperienceDirty()) return;
        try { state.registry.setExperience(parro.owner(), parro.experience()); }
        catch (IOException | IllegalStateException e) { LOGGER.error("Could not save Parro experience", e); }
    }
    private static void dismiss(State state, UUID owner, boolean effects) {
        ParroEntity parro = state.active.remove(owner);
        if (parro == null) return;
        save(state, parro);
        if (!parro.isRemoved()) {
            if (effects && parro.level() instanceof ServerLevel level)
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.POOF, parro.getX(), parro.getY() + .8, parro.getZ(), 30, .6, .6, .6, .02);
            parro.ejectPassengers(); parro.discard();
        }
    }
    static void saddleChanged(ServerPlayer player, boolean saddled) {
        State state = state(player.server);
        if (state.registry == null) return;
        try { state.registry.setSaddled(player.getUUID(), saddled); }
        catch (IOException | IllegalStateException e) { LOGGER.error("Could not save Parro saddle", e); }
    }
    static void parroDied(ParroEntity parro) {
        if (!(parro.level() instanceof ServerLevel level)) return;
        State state = SERVERS.get(level.getServer());
        if (state == null || parro.owner() == null || !state.active.remove(parro.owner(), parro)) return;
        save(state, parro);
        state.diedAt.put(parro.owner(), System.currentTimeMillis());
        var owner = level.getServer().getPlayerList().getPlayer(parro.owner());
        if (owner != null) owner.displayClientMessage(Component.literal("Seu Parro desmaiou. Chame de novo em 30s."), true);
    }

    @SubscribeEvent public static void joining(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide || !(event.getEntity() instanceof ParroEntity parro)) return;
        State state = state(((ServerLevel) event.getLevel()).getServer());
        var expected = parro.owner() == null ? null : state.active.get(parro.owner());
        // Never restore a saved Parro from the world: only the summoned one of this session.
        if (!state.session.equals(parro.session()) || expected != parro) event.setCanceled(true);
    }
    @SubscribeEvent public static void interacting(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof ParroEntity parro)) return;
        event.setCancellationResult(parro.mobInteract(event.getEntity(), event.getHand()));
        event.setCanceled(true);
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent event) {
        State state = SERVERS.get(event.getEntity().getServer());
        if (state != null) dismiss(state, event.getEntity().getUUID(), false);
    }
    @SubscribeEvent public static void changedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        State state = SERVERS.get(event.getEntity().getServer());
        if (state != null && state.active.containsKey(event.getEntity().getUUID())) {
            dismiss(state, event.getEntity().getUUID(), false);
            event.getEntity().displayClientMessage(Component.literal("Parro guardado. Chame de novo com /parro chamar."), true);
        }
    }
    @SubscribeEvent public static void tick(ServerTickEvent.Post event) {
        State state = SERVERS.get(event.getServer());
        if (state == null || event.getServer().getTickCount() % 20 != 0) return;
        for (UUID owner : List.copyOf(state.active.keySet())) {
            var player = event.getServer().getPlayerList().getPlayer(owner);
            var parro = state.active.get(owner);
            if (player == null || !player.isAlive() || player.isSpectator() || !authenticated(player) || parro.isRemoved()
                    || (!parro.isAlive() && !parro.isDeadOrDying()) || parro.level() != player.level() || parro.distanceToSqr(player) > 96 * 96)
                dismiss(state, owner, false);
            else if (event.getServer().getTickCount() % 200 == 0) save(state, parro);
        }
    }
    @SubscribeEvent public static void stopping(ServerStoppingEvent event) {
        State state = SERVERS.get(event.getServer());
        if (state != null) for (UUID owner : List.copyOf(state.active.keySet())) dismiss(state, owner, false);
    }
    @SubscribeEvent public static void stopped(ServerStoppedEvent event) { SERVERS.remove(event.getServer()); }
    private AveronSyncParro() {}
}
/*?}*/
