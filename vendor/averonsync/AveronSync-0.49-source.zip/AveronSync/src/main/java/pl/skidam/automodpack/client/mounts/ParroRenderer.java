package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.util.Mth;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.*;
import pl.skidam.automodpack.client.pets.VipPetRenderer;
import pl.skidam.automodpack.modpack.*;
import pl.skidam.automodpack_core.pets.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

/** Draws the Parro's two ModelEngine blueprints with the shared Blockbench renderer. */
public final class ParroRenderer extends EntityRenderer<ParroEntity> {
    private static final Map<String, Optional<CubeeModel>> MODELS = new HashMap<>();
    /** ModelEngine "hold" clips keep their last pose; "loop" clips repeat. */
    private static final Set<String> HOLD = Set.of("transform", "death");
    public static void init(IEventBus bus) {
        bus.addListener(ParroRenderer::register);
        bus.addListener(ParroRenderer::reload);
    }
    private static void register(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(AveronSyncHorseContent.PARRO.get(), ParroRenderer::new);
    }
    private static void reload(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((ResourceManagerReloadListener) manager -> MODELS.clear());
    }
    public ParroRenderer(EntityRendererProvider.Context context) { super(context); shadowRadius = .65F; }
    static CubeeModel model(String id) {
        return MODELS.computeIfAbsent(id, key -> {
            try (var input = Minecraft.getInstance().getResourceManager().getResourceOrThrow(
                    ResourceLocation.fromNamespaceAndPath("averonsync", "parro/" + key + ".json")).open()) {
                byte[] bytes = input.readNBytes(4_000_001);
                if (bytes.length > 4_000_000) throw new java.io.IOException("Parro model too large");
                return Optional.of(CubeeModel.parseParro(JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject()));
            } catch (Exception e) {
                LOGGER.error("Could not load Parro artwork {}", key, e);
                return Optional.empty();
            }
        }).orElse(null);
    }
    @Override public void render(ParroEntity parro, float yaw, float partial, PoseStack poses, MultiBufferSource buffers, int light) {
        boolean saddled = parro.saddled();
        shadowRadius = saddled ? .8F : .65F;
        CubeeModel model = model(saddled ? "parro_saddle" : "parro");
        if (model != null && !parro.isInvisible()) {
            double age = PetRenderTime.ticks(parro.level().getGameTime(), partial);
            String base = parro.baseClip();
            if (!model.animations().containsKey(base)) base = base.equals("run") ? "walk" : "idle";
            double baseTime = Math.max(0, (age - parro.baseAt()) / 20.0);
            List<VipPetRenderer.ModelLayer> layers = new ArrayList<>();
            String air = parro.airClip();
            if (!air.isEmpty()) layer(layers, model, air, (age - parro.airAt()) / 20.0, true);
            String action = parro.action();
            if (!action.isEmpty()) layer(layers, model, action, (age - parro.actionAt()) / 20.0, HOLD.contains(action));
            poses.pushPose();
            float heading = Mth.rotLerp(partial, parro.yBodyRotO, parro.yBodyRot);
            poses.mulPose(Axis.YP.rotationDegrees(180 - heading));
            poses.scale(1F / 16, 1F / 16, 1F / 16);
            VipPetRenderer.renderModel(poses, buffers, model, base, baseTime, age, light, layers);
            poses.popPose();
        }
        super.render(parro, yaw, partial, poses, buffers, light);
    }
    /** {@code sustain}: keep the last frame (hold) or repeat (loop) instead of fading out. */
    private static void layer(List<VipPetRenderer.ModelLayer> layers, CubeeModel model, String name, double time, boolean sustain) {
        var clip = model.animations().get(name);
        if (clip == null || time < 0) return;
        boolean loop = name.equals("jump3") && sustain;
        if (!sustain && time > clip.length() + .2) return;
        double weight = Math.min(1, time * 10);
        if (!sustain) weight *= Math.min(1, Math.max(0, (clip.length() + .2 - time) / .2));
        double at = loop ? time % clip.length() : Math.min(time, clip.length() - 1e-4);
        layers.add(new VipPetRenderer.ModelLayer(clip, at, weight));
    }
    @Override public ResourceLocation getTextureLocation(ParroEntity parro) {
        return ResourceLocation.parse("averonsync:textures/parro/" + (parro.saddled() ? "parro_saddle" : "parro") + "/0.png");
    }
}
/*?}*/
