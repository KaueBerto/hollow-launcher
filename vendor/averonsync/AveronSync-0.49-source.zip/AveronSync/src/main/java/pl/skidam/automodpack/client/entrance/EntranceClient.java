package pl.skidam.automodpack.client.entrance;

/*? if neoforge {*/
import com.google.gson.JsonParser;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.*;
import net.neoforged.neoforge.common.NeoForge;
import pl.skidam.automodpack.client.pets.VipPetRenderer;
import pl.skidam.automodpack.modpack.AveronSyncEntrancePayload;
import pl.skidam.automodpack_core.entrance.EntranceCatalog;
import pl.skidam.automodpack_core.pets.CubeeModel;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

/**
 * Client half of the join/leave animations: draws the imported Blockbench model at
 * a fixed spot with the player's skin on the limb bones, plays the pack's sounds and
 * particles, and hides the real player while their join animation runs. Visual only.
 */
public final class EntranceClient {
    private static final int MAX_ACTIVE = 16;
    private static final double RENDER_RANGE = 64;
    static final class Active {
        final UUID player; final EntranceCatalog.Theme theme; final boolean in;
        final double x, y, z; final float yaw, scale; final long started = System.nanoTime();
        final Object level; int firedTick = -1;
        VipPetRenderer.Skin skin;
        Active(AveronSyncEntrancePayload p, Object level) {
            player = p.player(); theme = EntranceCatalog.find(p.theme()).orElseThrow(); in = p.in();
            x = p.x(); y = p.y(); z = p.z(); yaw = p.yaw(); scale = p.scale(); this.level = level;
        }
        double ticks() { return (System.nanoTime() - started) / 50_000_000.0; }
        boolean finished() { return ticks() > theme.ticks(in); }
        String model() { return theme.model(in); }
    }
    private static final List<Active> ACTIVE = new ArrayList<>();
    private static final Map<String, Optional<CubeeModel>> MODELS = new HashMap<>();
    private static final Set<String> FAILED = new HashSet<>();

    public static void init(IEventBus bus) {
        bus.addListener(EntranceClient::reloadListeners);
        NeoForge.EVENT_BUS.addListener(EntranceClient::render);
        NeoForge.EVENT_BUS.addListener(EntranceClient::tick);
        NeoForge.EVENT_BUS.addListener(EntranceClient::hidePlayer);
        NeoForge.EVENT_BUS.addListener(EntranceClient::disconnected);
    }
    private static void reloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((ResourceManagerReloadListener) manager -> { MODELS.clear(); FAILED.clear(); });
    }
    private static void disconnected(ClientPlayerNetworkEvent.LoggingOut event) { ACTIVE.clear(); }

    public static void accept(AveronSyncEntrancePayload data) {
        var mc = Minecraft.getInstance();
        ACTIVE.removeIf(a -> a.player.equals(data.player()));
        if (ACTIVE.size() >= MAX_ACTIVE) ACTIVE.remove(0);
        var active = new Active(data, mc.level);
        active.skin = skin(active.player, null);
        ACTIVE.add(active);
    }

    /** Current skin from the tab list; kept from before when the player already left. */
    private static VipPetRenderer.Skin skin(UUID player, VipPetRenderer.Skin previous) {
        var connection = Minecraft.getInstance().getConnection();
        var info = connection == null ? null : connection.getPlayerInfo(player);
        if (info == null) {
            if (previous != null) return previous;
            PlayerSkin fallback = DefaultPlayerSkin.get(player);
            return new VipPetRenderer.Skin(fallback.texture().toString(), fallback.model() == PlayerSkin.Model.SLIM);
        }
        PlayerSkin s = info.getSkin();
        return new VipPetRenderer.Skin(s.texture().toString(), s.model() == PlayerSkin.Model.SLIM);
    }

    static Optional<CubeeModel> model(String id) {
        return MODELS.computeIfAbsent(id, ignored -> {
            var location = ResourceLocation.fromNamespaceAndPath("averonsync", "entrance/" + id + ".json");
            try (var stream = Minecraft.getInstance().getResourceManager().getResourceOrThrow(location).open()) {
                byte[] bytes = stream.readNBytes(4_000_001);
                if (bytes.length > 4_000_000) throw new java.io.IOException("Entrance model too large");
                return Optional.of(CubeeModel.parseEntrance(JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject()));
            } catch (Exception e) { LOGGER.error("Could not load entrance animation {}; skipping it until resource reload", id, e); return Optional.empty(); }
        });
    }

    private static void tick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event) {
        var mc = Minecraft.getInstance();
        if (mc.level == null || mc.isPaused()) return;
        ACTIVE.removeIf(a -> a.finished() || a.level != mc.level);
        for (var active : ACTIVE) {
            int now = (int) active.ticks();
            while (active.firedTick < now) {
                active.firedTick++;
                if (mc.player != null && mc.player.distanceToSqr(active.x, active.y, active.z) <= RENDER_RANGE * RENDER_RANGE)
                    EntranceEffects.fire(mc.level, active.model(), active.firedTick, active.x, active.y, active.z, active.yaw, active.scale);
            }
        }
    }

    /** Hides the real player under their own join animation while they stay on the spot. */
    private static void hidePlayer(RenderPlayerEvent.Pre event) {
        var player = event.getEntity();
        for (var active : ACTIVE) {
            if (!active.in || !active.player.equals(player.getUUID()) || active.finished()) continue;
            double dx = player.getX() - active.x, dz = player.getZ() - active.z;
            double r = 1.5 * Math.max(1, active.scale);
            if (dx * dx + dz * dz < r * r && Math.abs(player.getY() - active.y) < 2 * Math.max(1, active.scale)) { event.setCanceled(true); return; }
        }
    }

    private static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES || ACTIVE.isEmpty()) return;
        var mc = Minecraft.getInstance(); if (mc.level == null || mc.player == null) return;
        var camera = event.getCamera().getPosition();
        var buffers = mc.renderBuffers().bufferSource();
        for (var active : ACTIVE) {
            if (active.level != mc.level || active.finished() || FAILED.contains(active.model())) continue;
            if (mc.player.distanceToSqr(active.x, active.y, active.z) > RENDER_RANGE * RENDER_RANGE) continue;
            if (!event.getFrustum().isVisible(new AABB(active.x - 4 * active.scale, active.y - active.scale, active.z - 4 * active.scale, active.x + 4 * active.scale, active.y + 5 * active.scale, active.z + 4 * active.scale))) continue;
            var model = model(active.model()); if (model.isEmpty()) continue;
            active.skin = skin(active.player, active.skin);
            var clip = model.get().animations().get("play");
            // The pack's animations hold their last pose ("hold") until the model is removed.
            double seconds = Math.min(active.ticks() / 20.0, clip.length() - 1e-4);
            var poses = event.getPoseStack(); poses.pushPose();
            try {
                poses.translate(active.x - camera.x, active.y - camera.y, active.z - camera.z);
                poses.mulPose(Axis.YP.rotationDegrees(180 - active.yaw));
                // Same size as the player: AveronOrigins races change minecraft:scale.
                poses.scale(active.scale / 16f, active.scale / 16f, active.scale / 16f);
                // The pack lights the spot (light block mask) while the animation plays.
                int sky = LightTexture.sky(LevelRenderer.getLightColor(mc.level, BlockPos.containing(active.x, active.y + 1, active.z)));
                VipPetRenderer.renderModel(poses, buffers, model.get(), "play", seconds, active.ticks(), LightTexture.pack(15, sky), List.of(), active.skin);
            } catch (RuntimeException e) {
                if (FAILED.add(active.model())) LOGGER.error("Failed to render entrance animation {}; disabled for this session", active.model(), e);
            } finally { poses.popPose(); }
        }
    }
    private EntranceClient() {}
}
/*?}*/
