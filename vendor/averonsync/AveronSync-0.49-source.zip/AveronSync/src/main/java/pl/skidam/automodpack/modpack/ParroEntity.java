package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.*;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.*;
import net.minecraft.network.syncher.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.*;
import net.minecraft.sounds.*;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.*;
import net.minecraft.world.damagesource.*;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.*;
import pl.skidam.automodpack_core.mounts.ParroLevels;
import java.util.*;

/**
 * Native port of the DepartmentQDE x Mister Spooky "Parro" pet (MythicMobs/parro.yml and
 * skills/parro_skills.yml). Companion form follows its owner with hops and glides, fights,
 * levels up and can be petted; a saddle turns it into a rideable mount that leaps and glides.
 * Never targets or damages players (server policy). Timings and factors follow the skills file;
 * where MythicMobs/ModelEngine semantics cannot be reproduced exactly, the closest native
 * behaviour is used (see PARRO-AVERONSYNC.md).
 */
public final class ParroEntity extends PathfinderMob {
    public static final String[] ACTIONS = {"", "summon", "spawn", "transform", "transform_back", "jump1", "attack1", "attack2",
            "attack2_r", "attack2_l", "petting1", "petting2", "hurt", "death"};
    public static final String[] BASES = {"idle", "walk", "run", "swim"};
    public static final String[] AIRS = {"", "jump2", "jump3", "jump22"};
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Boolean> SADDLED = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> BASE = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> BASE_AT = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> ACTION = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> ACTION_AT = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> AIR = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> AIR_AT = SynchedEntityData.defineId(ParroEntity.class, EntityDataSerializers.LONG);
    /** ModelEngine hitboxes: companion 20x22 px, saddled 24x26 px. Seat = saddle "mount" bone. */
    private static final EntityDimensions PET_SIZE = EntityDimensions.scalable(1.25F, 1.375F), SADDLE_SIZE = EntityDimensions.scalable(1.5F, 1.625F);
    private static final double SEAT_Y = 24.5 / 16;
    private static final double PET_SPEED = .25, SADDLE_SPEED = .29, CHASE_SPEED = .45;

    private record Task(long at, Runnable run) {}
    private final List<Task> tasks = new ArrayList<>();
    private UUID session;
    private double experience;
    private boolean experienceDirty;
    private ParroLevels.Level stage = ParroLevels.LEVELS[0];
    // Pack auras, as remaining ticks.
    private int lock, spawning, petting, pettingCd, inAttack, gcd, attack1Cd, attack2Cd, followCd, air, wingfold,
            calm, landStop, noAirstate, xpCd, ambientCd, flapCd, runCycle, jumpGlide, waterBoost;
    private boolean inAir, highAir, bigAir, chasing, returning, swimMode;
    private ParroInput keys = ParroInput.NONE, lastKeys = ParroInput.NONE;
    private long inputAt = Long.MIN_VALUE;
    public record ParroInput(int front, int side, boolean jump, boolean sneak, boolean attack) {
        public static final ParroInput NONE = new ParroInput(0, 0, false, false, false);
    }

    public ParroEntity(EntityType<? extends PathfinderMob> type, Level world) {
        super(type, world);
        setPersistenceRequired();
    }

    // ---- synchronized state -------------------------------------------------------------
    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(OWNER, Optional.empty()); builder.define(SADDLED, false);
        builder.define(BASE, 0); builder.define(BASE_AT, 0L); builder.define(ACTION, 0); builder.define(ACTION_AT, 0L);
        builder.define(AIR, 0); builder.define(AIR_AT, 0L);
    }
    @Override public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (SADDLED.equals(key)) refreshDimensions();
    }
    public UUID owner() { return entityData.get(OWNER).orElse(null); }
    public boolean saddled() { return entityData.get(SADDLED); }
    public String baseClip() { return BASES[Math.clamp(entityData.get(BASE), 0, BASES.length - 1)]; }
    public long baseAt() { return entityData.get(BASE_AT); }
    public String action() { return ACTIONS[Math.clamp(entityData.get(ACTION), 0, ACTIONS.length - 1)]; }
    public long actionAt() { return entityData.get(ACTION_AT); }
    public String airClip() { return AIRS[Math.clamp(entityData.get(AIR), 0, AIRS.length - 1)]; }
    public long airAt() { return entityData.get(AIR_AT); }
    void setup(UUID owner, UUID session, double experience, boolean saddled) {
        entityData.set(OWNER, Optional.of(owner)); this.session = session; this.experience = experience;
        entityData.set(SADDLED, saddled); refreshDimensions();
        applyLevel(ParroLevels.forExperience(experience), true);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(saddled ? SADDLE_SPEED : PET_SPEED);
    }
    UUID session() { return session; }
    double experience() { return experience; }
    boolean takeExperienceDirty() { boolean dirty = experienceDirty; experienceDirty = false; return dirty; }
    public ParroLevels.Level stage() { return stage; }
    private void play(String action) {
        entityData.set(ACTION, Math.max(0, Arrays.asList(ACTIONS).indexOf(action)));
        entityData.set(ACTION_AT, level().getGameTime());
    }
    private void setAir(int air) {
        if (entityData.get(AIR) == air) return;
        entityData.set(AIR, air); entityData.set(AIR_AT, level().getGameTime());
    }
    private void setBase(int base) {
        if (entityData.get(BASE) == base) return;
        entityData.set(BASE, base); entityData.set(BASE_AT, level().getGameTime());
    }
    private void later(int ticks, Runnable run) { tasks.add(new Task(level().getGameTime() + ticks, run)); }

    @Override public EntityDimensions getDefaultDimensions(Pose pose) { return saddled() ? SADDLE_SIZE : PET_SIZE; }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 10));
    }

    // ---- helpers ------------------------------------------------------------------------
    private ServerPlayer ownerPlayer() {
        UUID id = owner();
        return id == null || !(level() instanceof ServerLevel server) ? null : server.getServer().getPlayerList().getPlayer(id);
    }
    private void sound(String id, float volume, float pitch) {
        level().playSound(null, getX(), getY(), getZ(), SoundEvent.createVariableRangeEvent(ResourceLocation.withDefaultNamespace(id)),
                SoundSource.NEUTRAL, volume, pitch);
    }
    private void particles(ParticleOptions type, double y, int count, double hs, double vs, double speed) {
        if (level() instanceof ServerLevel server) server.sendParticles(type, getX(), getY() + y, getZ(), count, hs, vs, hs, speed);
    }
    private void particleRing(ParticleOptions type, double radius, int points, int amount, double hs, double vs, double y) {
        if (!(level() instanceof ServerLevel server)) return;
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            server.sendParticles(type, getX() + Math.cos(a) * radius, getY() + y, getZ() + Math.sin(a) * radius, amount, hs, vs, hs, 0);
        }
    }
    private void effect(Holder<MobEffect> type, int ticks, int amplifier) { addEffect(new MobEffectInstance(type, ticks, amplifier, false, false, false)); }
    private void lockFor(int ticks) { lock = Math.max(lock, ticks); getNavigation().stop(); setDeltaMovement(0, getDeltaMovement().y, 0); }
    private boolean locked() { return lock > 0 || petting > 0 || spawning > 0 || landStop > 0; }
    private boolean inWater() { return isInWater() || level().getFluidState(BlockPos.containing(getX(), getY() - .2, getZ())).is(FluidTags.WATER); }
    private double altitude() {
        var hit = level().clip(new ClipContext(position(), position().add(0, -300, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.ANY, this));
        return hit.getType() == HitResult.Type.MISS ? 300 : position().y - hit.getLocation().y;
    }
    /** Never players, armor stands, the owner's other pets or another Parro. */
    private boolean attackable(Entity entity) {
        if (!(entity instanceof LivingEntity living) || !living.isAlive() || living == this) return false;
        if (living instanceof Player || living instanceof ArmorStand || living instanceof ParroEntity) return false;
        if (living instanceof OwnableEntity pet && pet.getOwnerUUID() != null && pet.getOwnerUUID().equals(owner())) return false;
        return living.isAttackable() && !living.isInvulnerable();
    }
    private List<LivingEntity> victims(double radius) {
        Vec3 look = Vec3.directionFromRotation(0, getYRot());
        return level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(radius), e -> attackable(e)
                && e.distanceTo(this) <= radius + e.getBbWidth() / 2
                && e.position().subtract(position()).multiply(1, 0, 1).dot(look) >= -1e-3 && hasLineOfSight(e));
    }
    private boolean targetWithin(double distance) { var t = getTarget(); return t != null && t.isAlive() && distanceTo(t) <= distance; }

    // ---- levels and experience (pr_exp_award / pr_exp_show / pr_level_up) ------------------
    private void applyLevel(ParroLevels.Level value, boolean initial) {
        double ratio = initial ? 1 : getHealth() / Math.max(1, getMaxHealth());
        stage = value;
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(value.maxHealth());
        setHealth((float) Math.max(1, value.maxHealth() * ratio));
    }
    void addExperience(double amount) {
        var owner = ownerPlayer(); if (owner == null) return;
        var before = stage;
        experience = Math.max(0, experience + amount); experienceDirty = true;
        var after = ParroLevels.forExperience(experience);
        if (amount > 0) owner.playNotifySound(SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.NEUTRAL, .6F, 1.5F);
        owner.displayClientMessage(levelName(after).copy().append(Component.literal(" " + ParroLevels.formatXp(experience) + " xp").withStyle(net.minecraft.ChatFormatting.GREEN)), true);
        if (after != before) {
            applyLevel(after, false);
            if (after.number() > before.number()) {
                owner.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, .9F, 1.3F);
                owner.connection.send(new ClientboundSetTitlesAnimationPacket(5, 40, 10));
                owner.connection.send(new ClientboundSetSubtitleTextPacket(levelName(after)));
                owner.connection.send(new ClientboundSetTitleTextPacket(Component.literal("LEVEL UP!").withStyle(net.minecraft.ChatFormatting.YELLOW, net.minecraft.ChatFormatting.BOLD)));
            }
        }
    }
    static Component levelName(ParroLevels.Level level) {
        return Component.literal("Parro").withStyle(net.minecraft.ChatFormatting.WHITE)
                .append(Component.literal(" Lv." + level.number()).withStyle(net.minecraft.ChatFormatting.GRAY));
    }
    private void awardHit() {
        if (xpCd > 0) return;
        xpCd = ParroLevels.XP_COOLDOWN_TICKS;
        later(2, () -> addExperience(ParroLevels.XP_PER_HIT));
    }

    // ---- combat (pr_attack1 / pr_attack2 / pr_saddle_attack) -----------------------------
    private void strike(double factor, double radius, double knockback, double lift) {
        var owner = ownerPlayer();
        var hit = victims(radius);
        if (hit.isEmpty()) return;
        awardHit();
        float damage = (float) ParroLevels.damage(stage, factor);
        for (var victim : hit) {
            victim.invulnerableTime = 0;
            // Damage is credited to the owner, like the pack's sudoskill pr_owner_strike.
            victim.hurt(damageSources().source(DamageTypes.MOB_ATTACK, this, owner == null ? this : owner), damage);
            if (knockback > 0) {
                Vec3 away = victim.position().subtract(position()).multiply(1, 0, 1).normalize().scale(knockback);
                victim.push(away.x, lift, away.z); victim.hurtMarked = true;
            }
        }
    }
    private void faceVictim(double radius) {
        var near = victims(radius);
        if (near.isEmpty()) return;
        var victim = near.get(0);
        float wanted = (float) Math.toDegrees(Math.atan2(-(victim.getX() - getX()), victim.getZ() - getZ()));
        float yaw = getYRot() + Math.clamp(net.minecraft.util.Mth.wrapDegrees(wanted - getYRot()), -135F, 135F);
        setYRot(yaw); yBodyRot = yaw; yHeadRot = yaw;
    }
    private boolean attackReady() { return inAttack <= 0 && gcd <= 0 && spawning <= 0 && petting <= 0; }
    private void attack1() {
        if (attack1Cd > 0 || !attackReady()) return;
        boolean saddled = saddled();
        attack1Cd = 10; gcd = 10; inAttack = 10;
        clearAir();
        if (!onGround()) {
            setDeltaMovement(0, getDeltaMovement().y, 0); removeEffect(MobEffects.SLOW_FALLING); wingfold = 10;
        }
        faceVictim(saddled ? 3.5 : 3);
        play("attack1");
        later(saddled ? 8 : 7, () -> {
            if (saddled) { sound("entity.parrot.fly", .9F, .7F); sound("entity.player.attack.crit", .8F, .7F); sound("entity.parrot.hurt", .7F, .7F); }
            else { sound("entity.parrot.fly", .8F, 1.2F); sound("entity.player.attack.crit", .8F, 1.3F); sound("entity.parrot.hurt", .6F, 1.4F); }
            strike(saddled ? 1.2 : 1, saddled ? 3.5 : 3, 0, 0);
        });
    }
    private void attack2() {
        if (attack2Cd > 0 || !attackReady() || !onGround() || inWater()) return;
        boolean saddled = saddled();
        attack2Cd = 20; gcd = 20; inAttack = 20;
        clearAir();
        faceVictim(saddled ? 3.5 : 3);
        if (!saddled) {
            play("attack2");
            for (int i = 0; i < 20; i++) later(i, () -> {
                Vec3 forward = Vec3.directionFromRotation(0, getYRot()).scale(.5 * getAttributeValue(Attributes.MOVEMENT_SPEED));
                setDeltaMovement(forward.x, getDeltaMovement().y, forward.z);
            });
            int[] pecks = {3, 7, 11, 14};
            float[] pitches = {1.4F, 1.2F, 1.3F};
            for (int i = 0; i < pecks.length; i++) {
                int index = i;
                later(pecks[i], () -> {
                    if (index < 3) sound("entity.player.attack.weak", .7F, pitches[index]);
                    if (index == 0) sound("entity.parrot.fly", .7F, 1.3F);
                    if (index == 3) { sound("entity.player.attack.crit", .8F, 1.1F); sound("entity.parrot.hurt", .6F, 1.2F); }
                    strike(.5, 3, index == 3 ? .8 : 0, index == 3 ? .3 : 0);
                });
            }
        } else {
            play(random.nextBoolean() ? "attack2_r" : "attack2_l");
            later(8, () -> {
                sound("entity.parrot.fly", 1, .6F); sound("entity.player.attack.knockback", 1, .6F);
                strike(1.2, 3.5, 1.5, .6);
                Vec3 back = Vec3.directionFromRotation(0, getYRot()).scale(-.75);
                setDeltaMovement(getDeltaMovement().add(back.x, 0, back.z));
            });
        }
    }
    private void dispatchAttack() {
        if (isVehicle() || returning || calm > 0 || !targetWithin(3)) return;
        boolean ground = onGround(), water = inWater();
        if (!saddled() && victims(3).isEmpty()) return;
        if (ground && !water) { if (random.nextBoolean()) attack1(); else attack2(); }
        else attack1();
    }
    /** pr_saddle_attack, signalled when the rider swings. */
    private void riderAttack() {
        if (spawning > 0 || inAttack > 0) return;
        if (onGround() && !inWater()) { if (random.nextBoolean()) attack1(); else attack2(); }
        else attack1();
    }
    private void chooseTarget(ServerPlayer owner) {
        if (returning || calm > 0) { setTarget(null); return; }
        var current = getTarget();
        boolean ownerNear = owner.distanceTo(this) <= 14;
        if (current != null && (!attackable(current) || current.distanceTo(this) > 16 || !ownerNear)) { setTarget(null); current = null; }
        if (current != null) return;
        long now = owner.tickCount;
        List<LivingEntity> wanted = new ArrayList<>();
        if (now - owner.getLastHurtMobTimestamp() < 200) wanted.add(owner.getLastHurtMob());
        wanted.add(owner.getLastHurtByMob());
        wanted.add(getLastHurtByMob());
        for (var candidate : wanted) if (candidate != null && attackable(candidate) && candidate.distanceTo(this) <= 16) { setTarget(candidate); return; }
        if (!ownerNear) return;
        var monster = level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(16),
                e -> e instanceof Enemy && attackable(e) && e.distanceTo(this) <= 16 && hasLineOfSight(e))
                .stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(this))).orElse(null);
        if (monster != null) setTarget(monster);
    }

    // ---- hops and glide (pr_pet_hop / pr_hop / pr_hop_air / pr_hop_ride / pr_ride_glide) ---
    private void hop(Entity towards, double push) {
        followCd = 20; play("jump1");
        later(3, () -> {
            if (towards != null && towards.isAlive()) getLookControl().setLookAt(towards, 360, 360);
            if (towards != null) {
                float yaw = (float) Math.toDegrees(Math.atan2(-(towards.getX() - getX()), towards.getZ() - getZ()));
                setYRot(yaw); yBodyRot = yaw; yHeadRot = yaw;
            }
            double jump = saddled() ? .45 : towards != null && distanceTo(towards) <= 5 ? .28 : .4;
            Vec3 forward = Vec3.directionFromRotation(0, getYRot()).scale(push);
            setDeltaMovement(getDeltaMovement().add(forward.x, 0, forward.z).add(0, jump - getDeltaMovement().y, 0));
            hasImpulse = true; air = 100;
        });
    }
    private void petHop(ServerPlayer owner) {
        if (!onGround() || isVehicle() || followCd > 0 || inAttack > 0 || locked()) return;
        boolean moving = getNavigation().isInProgress() || getDeltaMovement().horizontalDistanceSqr() > 1e-4;
        if (!moving) return;
        var target = getTarget();
        boolean saddled = saddled();
        double ownerDistance = distanceTo(owner);
        if (target != null && !returning) {
            double d = distanceTo(target);
            if (!saddled && d <= 5 && d > 3) { hop(target, 1.0); return; }
            if (!saddled && d <= 16 && d > 5) { hop(target, 1.15); return; }
            if (saddled && !chasing && d <= 16 && d > 10) { hop(target, 1.2); return; }
        }
        if (returning) { hop(owner, saddled ? 1.2 : 1.15); return; }
        if (!targetWithin(16) && ownerDistance > 6) hop(owner, saddled ? 1.2 : 1.15);
    }
    private void rideHop(ServerPlayer rider) {
        if (followCd > 0) return;
        followCd = 20; jumpGlide = 600; play("jump1");
        later(3, () -> {
            Vec3 forward = Vec3.directionFromRotation(0, getYRot()).scale(1.2);
            double lift = rider.getXRot() < 0 ? -rider.getXRot() * .0045 : 0;
            setDeltaMovement(getDeltaMovement().x + forward.x, .85 + lift, getDeltaMovement().z + forward.z);
            hasImpulse = true;
        });
    }
    private void airState(boolean ridden) {
        boolean ground = onGround(), water = inWater();
        if (!ground && !water && petting <= 0 && inAttack <= 0 && spawning <= 0 && noAirstate <= 0) {
            inAir = true;
            double alt = altitude();
            highAir = alt >= 4; bigAir |= alt >= 8;
            double vy = getDeltaMovement().y;
            if (highAir && vy > 0) setAir(1);
            else if (highAir && vy < 0 && alt >= 3) {
                setAir(2);
                if (wingfold <= 0 && flapCd <= 0) {
                    flapCd = saddled() ? 10 : 5;
                    later(12, () -> {
                        if (onGround()) return;
                        if (saddled()) { sound("entity.phantom.flap", 2.5F, 1.1F); sound("entity.phantom.flap", 2, 1.3F); sound("entity.parrot.fly", .7F, .5F); }
                        else { sound("entity.parrot.fly", 2.5F, 1.4F); sound("entity.parrot.fly", 2, 1.6F); }
                    });
                }
            } else if (!highAir && vy > 0 && alt >= 2) setAir(3);
        }
        if (!ridden && air > 0 && wingfold <= 0 && !ground && !water && getDeltaMovement().y < 0) {
            effect(MobEffects.SLOW_FALLING, 8, 0);
            Vec3 v = getDeltaMovement();
            double horizontal = v.horizontalDistance();
            setDeltaMovement(horizontal < 1.9 ? v.x * 1.16 : v.x, v.y - .06, horizontal < 1.9 ? v.z * 1.16 : v.z);
        }
        if (ridden && !ground && !water && highAir && wingfold <= 0) {
            effect(MobEffects.SLOW_FALLING, 8, 0);
            // pr_ride_glide adds 0.55 (0.35 without a jump) forward each tick; capped to a glide speed.
            double add = jumpGlide > 0 ? .55 : .35, cap = jumpGlide > 0 ? 1.1 : .8;
            Vec3 forward = Vec3.directionFromRotation(0, getYRot()).scale(add);
            Vec3 v = getDeltaMovement().add(forward.x, jumpGlide > 0 ? -.008 : -.03, forward.z);
            double horizontal = v.horizontalDistance();
            if (horizontal > cap) v = new Vec3(v.x * cap / horizontal, v.y, v.z * cap / horizontal);
            setDeltaMovement(v);
        }
        if (ridden && !ground && !water && !highAir && jumpGlide > 0 && getDeltaMovement().y < 0)
            setDeltaMovement(getDeltaMovement().multiply(.85, 1, .85));
        if (wingfold > 0 && !ground) setDeltaMovement(getDeltaMovement().multiply(.75, 1, .75).add(0, -.18, 0));
        if (ground && !ridden) removeEffect(MobEffects.SLOW_FALLING);
        if (ground && ridden) { removeEffect(MobEffects.SLOW_FALLING); if (followCd <= 0) jumpGlide = 0; }
        if (ground && inAir && petting <= 0 && inAttack <= 0 && spawning <= 0) land(ridden);
        if (water && inAir) {
            clearAir();
            if (saddled() && bigAir) {
                particleRing(ParticleTypes.SPLASH, 1.5, 16, 4, .2, .2, .3); particleRing(ParticleTypes.SPLASH, 2.5, 24, 4, .2, .2, .3);
                particles(ParticleTypes.BUBBLE, 0, 30, 1, .5, 0);
                sound("entity.generic.splash", 1, .6F); sound("entity.player.splash.high_speed", .8F, .7F);
            }
            highAir = false; bigAir = false; jumpGlide = 0;
        }
    }
    private void clearAir() { inAir = false; air = 0; setAir(0); }
    private void land(boolean ridden) {
        clearAir();
        if (saddled() && bigAir) landingImpact();
        if (!highAir && !ridden) { landStop = 7; noAirstate = 20; }
        highAir = false; bigAir = false;
    }
    private void landingImpact() {
        BlockState below = level().getBlockState(BlockPos.containing(getX(), getY() - .2, getZ()));
        if (below.is(BlockTags.LEAVES) || below.is(Blocks.VINE) || below.is(Blocks.SCAFFOLDING) || below.is(Blocks.COBWEB)
                || below.is(Blocks.LILY_PAD) || below.is(Blocks.SNOW) || below.is(BlockTags.WALL_CORALS)) return;
        sound("entity.generic.big_fall", .5F, .8F); sound("block.rooted_dirt.fall", .5F, .5F); sound("block.gravel.break", .5F, .5F);
        BlockState crack = below.is(Blocks.GRASS_BLOCK) ? Blocks.GRASS_BLOCK.defaultBlockState()
                : below.is(BlockTags.SAND) ? Blocks.SAND.defaultBlockState()
                : below.is(Blocks.SNOW_BLOCK) || below.is(Blocks.POWDER_SNOW) ? Blocks.SNOW_BLOCK.defaultBlockState()
                : below.is(BlockTags.BASE_STONE_OVERWORLD) || below.is(Blocks.COBBLESTONE) || below.is(Blocks.STONE_BRICKS) ? Blocks.STONE.defaultBlockState()
                : below.is(BlockTags.DIRT) || below.is(Blocks.DIRT_PATH) || below.is(Blocks.FARMLAND) ? Blocks.DIRT.defaultBlockState() : null;
        if (crack == null) return;
        var particle = new BlockParticleOption(ParticleTypes.BLOCK, crack);
        particleRing(particle, 1.5, 16, 3, .2, .1, .1); particleRing(particle, 2.5, 24, 3, .2, .1, .1);
    }

    // ---- saddle (pr_transform / pr_restore_saddle_apply / pr_untransform) ----------------
    void spawnAnimation() {
        if (saddled()) restoreSaddle(); else { spawning = 25; lockFor(25); play("summon"); }
    }
    private void restoreSaddle() {
        entityData.set(SADDLED, true); refreshDimensions();
        spawning = 38; lockFor(38); calm = 60; setTarget(null); play("spawn");
        later(17, () -> { sound("entity.phantom.flap", 1.2F, 1.1F); sound("entity.phantom.flap", 1, 1.3F); });
        later(26, () -> { sound("entity.phantom.flap", 1.2F, 1.1F); sound("entity.phantom.flap", 1, 1.3F); });
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(SADDLE_SPEED); chasing = false;
    }
    private void transform(ServerPlayer player, InteractionHand hand) {
        spawning = 43; lockFor(43); play("transform");
        later(10, () -> {
            ItemStack held = player.getItemInHand(hand);
            if (held.is(Items.SADDLE) && player.isAlive() && player.distanceTo(this) < 8) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                AveronSyncParro.saddleChanged(player, true);
                restoreSaddle();
                sound("entity.camel.saddle", 1, .9F); sound("entity.parrot.ambient", 2, .5F); sound("entity.parrot.fly", 1.5F, .5F);
            } else {
                play("transform_back"); later(10, () -> { spawning = 0; lock = 0; });
            }
        });
    }
    private void untransform(ServerPlayer player) {
        sound("entity.sheep.shear", 1, 1);
        ItemStack saddle = new ItemStack(Items.SADDLE);
        if (!player.getInventory().add(saddle)) player.drop(saddle, false);
        AveronSyncParro.saddleChanged(player, false);
        particles(new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(Items.SADDLE)), SEAT_Y, 20, .3, .3, .05);
        ejectPassengers();
        spawning = 30; lockFor(30); play("transform");
        later(10, () -> {
            entityData.set(SADDLED, false); refreshDimensions(); play("transform_back");
            getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(PET_SPEED); chasing = false;
        });
    }

    // ---- petting (pr_pet_petting / pr_petting1 / pr_petting2) ----------------------------
    private void pet(Player player) {
        if (!onGround() || inWater() || pettingCd > 0) return;
        pettingCd = 50;
        boolean first = random.nextBoolean(), saddled = saddled();
        petting = first ? 52 : 47; lockFor(petting); calm = 60; setTarget(null); clearAir();
        play(first ? "petting1" : "petting2");
        for (int i = 0; i < 4; i++) later(i * 10, () -> particles(ParticleTypes.HEART, 1, 4, .5, .5, 0));
        if (!saddled) sound("entity.parrot.eat", .7F, 1);
        later(15, () -> sound("entity.sniffer.happy", .6F, 1.5F));
        if (first) {
            if (!saddled) for (int i = 0; i < 3; i++) later(10 + i * 7, () -> { sound("entity.parrot.fly", .5F, 1.2F); sound("entity.parrot.fly", .4F, 1.4F); });
            else for (int i = 0; i < 4; i++) later(18 + i * 4, () -> sound("entity.parrot.fly", .5F, .7F));
        } else {
            later(42, () -> sound("entity.parrot.fly", saddled ? .5F : .3F, saddled ? .7F : 1.4F));
            if (saddled) for (int i = 0; i < 2; i++) later(22 + i * 11, () -> { sound("entity.phantom.flap", .9F, 1.1F); sound("entity.phantom.flap", .7F, 1.3F); });
        }
    }

    // ---- interaction ----------------------------------------------------------------------
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hasPassenger(player)) return InteractionResult.PASS;
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer) || !AveronSyncParro.authenticated(serverPlayer)) return InteractionResult.FAIL;
        boolean isOwner = player.getUUID().equals(owner());
        ItemStack held = player.getItemInHand(hand);
        if (isOwner && player.isSecondaryUseActive() && held.is(Items.STICK)) {
            // Pack debug action: sneak + stick resets experience to level 1.
            addExperience(-experience);
            player.displayClientMessage(Component.literal("Parro XP reset -> Lv.1").withStyle(net.minecraft.ChatFormatting.GREEN), true);
            return InteractionResult.CONSUME;
        }
        if (!saddled()) {
            if (held.is(Items.SADDLE)) {
                if (isOwner && spawning <= 0 && onGround() && !inWater()) transform(serverPlayer, hand);
                return InteractionResult.CONSUME;
            }
            if (!isVehicle()) pet(player);
            return InteractionResult.CONSUME;
        }
        if (held.is(Items.SHEARS)) {
            if (isOwner && spawning <= 0 && onGround() && !inWater()) untransform(serverPlayer);
            return InteractionResult.CONSUME;
        }
        if (player.isSecondaryUseActive()) { if (spawning <= 0 && !isVehicle()) pet(player); return InteractionResult.CONSUME; }
        if (isOwner && spawning <= 0 && !player.isPassenger() && player.startRiding(this)) {
            lock = 0; getNavigation().stop(); setTarget(null); chasing = false;
            sound("entity.camel.saddle", .5F, 1);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.FAIL;
    }

    // ---- riding (pr_mount / pr_saddle_controller / pr_ride_speed) ------------------------
    public boolean acceptInput(ServerPlayer player, ParroInput input) {
        if (getControllingPassenger() != player || !AveronSyncParro.authenticated(player)) return false;
        keys = input; inputAt = level().getGameTime(); return true;
    }
    @Override public LivingEntity getControllingPassenger() {
        return saddled() && getFirstPassenger() instanceof Player player && player.getUUID().equals(owner()) ? player : null;
    }
    @Override public boolean isControlledByLocalInstance() { return !level().isClientSide; }
    @Override protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().isEmpty() && passenger instanceof Player player && player.getUUID().equals(owner()) && saddled();
    }
    @Override protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (!level().isClientSide) {
            keys = ParroInput.NONE; inputAt = Long.MIN_VALUE;
            // pr_restore_goals: settle, calm down and resume walking.
            setDeltaMovement(0, getDeltaMovement().y, 0); getNavigation().stop(); setTarget(null); calm = Math.max(calm, 15); lockFor(10);
            setBase(0);
        }
    }
    private ParroInput input() { return inputAt == Long.MIN_VALUE || level().getGameTime() - inputAt > 10 ? ParroInput.NONE : keys; }
    @Override protected void tickRidden(Player player, Vec3 travel) {
        setRot(player.getYRot(), 0); yBodyRot = getYRot(); yHeadRot = getYRot();
    }
    @Override protected Vec3 getRiddenInput(Player player, Vec3 vanilla) {
        var in = input();
        if (spawning > 0 || lock > 0) return Vec3.ZERO;
        double front = in.front();
        // In the air without forward input the glide still carries the mount forward.
        if (!onGround() && front == 0 && jumpGlide > 0 && !highAir) front = 1;
        if (highAir && front > 0) front = 0;
        return new Vec3(in.side() * .5, 0, front < 0 ? front * .5 : front);
    }
    @Override protected float getRiddenSpeed(Player player) {
        double speed = getAttributeValue(Attributes.MOVEMENT_SPEED);
        if (inWater()) return (float) (speed * .4);
        // The pack gives the driver Speed II on the ground, Speed IV right after a leap and
        // Speed III/IV while gliding; ModelEngine moves the mount with the driver's speed.
        int amplifier = onGround() ? 1 : followCd > 0 || (highAir && jumpGlide > 0) ? 3 : highAir ? 2 : 1;
        return (float) (speed * (1 + .2 * (amplifier + 1)));
    }
    @Override protected Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dimensions, float scale) {
        return new Vec3(0, SEAT_Y * scale, 0);
    }

    // ---- damage ---------------------------------------------------------------------------
    @Override public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.IS_FALL)) return false;
        Entity attacker = source.getEntity();
        if (attacker != null && attacker.getUUID().equals(owner())) return false;
        if (attacker instanceof Player) return false;
        if (!level().isClientSide && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            amount /= (float) stage.resistance();
            if (saddled()) amount *= .4F;
        }
        boolean hit = super.hurt(source, amount);
        if (hit && !level().isClientSide && isAlive()) {
            calm = 0; play("hurt"); sound("entity.parrot.hurt", .9F, saddled() ? .5F : 1);
        }
        return hit;
    }
    @Override public boolean causeFallDamage(float distance, float multiplier, DamageSource source) { return false; }
    @Override public void die(DamageSource source) {
        if (!level().isClientSide) { play("death"); AveronSyncParro.parroDied(this); }
        super.die(source);
    }
    @Override protected void dropEquipment() {}
    @Override protected void dropCustomDeathLoot(ServerLevel server, DamageSource source, boolean recent) {}
    @Override public boolean shouldDropExperience() { return false; }
    @Override public boolean canBeLeashed() { return false; }
    @Override protected SoundEvent getAmbientSound() { return null; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return null; }
    @Override protected SoundEvent getDeathSound() { return SoundEvent.createVariableRangeEvent(ResourceLocation.withDefaultNamespace("entity.parrot.death")); }
    @Override protected void playStepSound(BlockPos pos, BlockState state) {}
    @Override public boolean removeWhenFarAway(double distance) { return false; }

    // ---- main loop ------------------------------------------------------------------------
    @Override public void tick() {
        super.tick();
        if (level().isClientSide || !isAlive()) return;
        long now = level().getGameTime();
        for (var task : List.copyOf(tasks)) if (task.at <= now) { tasks.remove(task); if (isAlive()) task.run.run(); }
        countDown();
        var owner = ownerPlayer();
        if (owner == null) return;
        boolean ridden = getControllingPassenger() instanceof ServerPlayer;
        if (ridden) tickRiddenState((ServerPlayer) getControllingPassenger());
        else tickCompanion(owner);
        if (locked()) { getNavigation().stop(); setDeltaMovement(0, getDeltaMovement().y, 0); }
        airState(ridden);
        tickWater(ridden);
        if (tickCount % 20 == 0 && getHealth() < getMaxHealth()) heal((float) stage.regeneration());
        tickSounds(now);
        Vec3 motion = getDeltaMovement();
        boolean moving = motion.horizontalDistanceSqr() > 1e-5 || (getNavigation().isInProgress() && !locked());
        setBase(swimMode ? 3 : !moving ? 0 : saddled() && (ridden || chasing) ? 2 : 1);
    }
    private void countDown() {
        lock--; spawning--; petting--; pettingCd--; inAttack--; gcd--; attack1Cd--; attack2Cd--; followCd--; air--; wingfold--;
        calm--; landStop--; noAirstate--; xpCd--; ambientCd--; flapCd--; runCycle--; jumpGlide--; waterBoost--;
    }
    private void tickRiddenState(ServerPlayer rider) {
        var in = input();
        if (in.sneak()) { rider.stopRiding(); return; }
        if (in.jump() && onGround() && !inWater() && spawning <= 0) rideHop(rider);
        if (in.attack() && !lastKeys.attack()) riderAttack();
        lastKeys = in;
    }
    private void tickCompanion(ServerPlayer owner) {
        lastKeys = ParroInput.NONE;
        if (owner.level() != level()) return;
        double distance = distanceTo(owner);
        if (tickCount % 20 == 0 && distance > 24) {
            Vec3 spot = owner.position().add(random.nextDouble() * 10 - 5, 0, random.nextDouble() * 10 - 5);
            BlockPos pos = BlockPos.containing(spot);
            for (int dy = 2; dy >= -2; dy--) {
                BlockPos at = pos.offset(0, dy, 0);
                if (level().getBlockState(at.below()).isFaceSturdy(level(), at.below(), net.minecraft.core.Direction.UP)
                        && level().noCollision(this, getBoundingBox().move(at.getX() + .5 - getX(), at.getY() - getY(), at.getZ() + .5 - getZ()))) {
                    teleportTo(at.getX() + .5, at.getY(), at.getZ() + .5); getNavigation().stop(); break;
                }
            }
            distance = distanceTo(owner);
        }
        if (!returning && distance > 20) { returning = true; setTarget(null); }
        else if (returning && distance <= 12) returning = false;
        if (tickCount % 5 == 0) chooseTarget(owner);
        if (locked()) return;
        dispatchAttack();
        if (saddled() && !inWater()) {
            if (!chasing && !returning && targetWithin(10)) {
                chasing = true; getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(CHASE_SPEED);
            } else if (chasing && !targetWithin(12)) {
                chasing = false; getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(SADDLE_SPEED);
            }
        }
        var target = getTarget();
        if (target != null && inAttack <= 0) {
            getLookControl().setLookAt(target, 30, 30);
            if (tickCount % 6 == 0 && distanceTo(target) > (saddled() ? 3 : 2)) getNavigation().moveTo(target, 1);
        } else if (tickCount % 8 == 0 && distance > 6) getNavigation().moveTo(owner, 1);
        if (tickCount % 12 == 0) petHop(owner);
        if (air > 0 && !onGround() && !inWater()) {
            var look = targetWithin(32) ? target : owner;
            getLookControl().setLookAt(look, 360, 360);
        }
    }
    private void tickWater(boolean ridden) {
        boolean water = inWater();
        if (water != swimMode) { swimMode = water; chasing = false; if (saddled()) getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(SADDLE_SPEED); }
        if (water && tickCount % 5 == 0 && waterBoost <= 0) {
            waterBoost = 8;
            if (!ridden) effect(MobEffects.DOLPHINS_GRACE, 8, 2);
            effect(MobEffects.WATER_BREATHING, 8, 0);
        }
    }
    private void tickSounds(long now) {
        boolean moving = getDeltaMovement().horizontalDistanceSqr() > 1e-4;
        if (inWater() && moving && tickCount % (saddled() ? 6 : 10) == 0) sound("entity.generic.swim", .2F, saddled() ? .6F : 1.2F);
        if (saddled() && onGround() && moving && runCycle <= 0) {
            runCycle = 19;
            later(9, () -> { if (onGround() && getDeltaMovement().horizontalDistanceSqr() > 1e-4) sound("entity.camel.step", .9F, 1); });
            later(19, () -> { if (onGround() && getDeltaMovement().horizontalDistanceSqr() > 1e-4) sound("entity.camel.step", .9F, 1); });
        }
        if (tickCount % 30 == 0 && random.nextFloat() < .7F && inAttack <= 0 && petting <= 0 && spawning <= 0 && ambientCd <= 0) {
            ambientCd = 160;
            int pick = random.nextInt(3);
            if (!saddled()) { if (pick == 2) sound("entity.parrot.fly", .4F, 1); else sound("entity.parrot.ambient", .5F, pick == 0 ? 1.1F : .9F); }
            else { if (pick == 2) sound("entity.parrot.fly", .5F, .5F); else sound("entity.parrot.ambient", .6F, .5F); }
        }
    }
    @Override public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (session != null) tag.putUUID("AveronParroSession", session);
    }
    @Override public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        session = tag.hasUUID("AveronParroSession") ? tag.getUUID("AveronParroSession") : null;
    }
}
/*?}*/
