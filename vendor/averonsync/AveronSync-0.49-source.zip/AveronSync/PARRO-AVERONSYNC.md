# Parro — AveronSync 0.49

Pet e montaria **Parro Pet - Mister Spooky v1.0.1** (DepartmentQDE x Mister Spooky),
comprado pelo dono do servidor. Recriado de forma nativa no NeoForge 1.21.1: não instala
MCPets, MythicMobs, ModelEngine, ItemsAdder ou Nexo. Os YAMLs do pack foram lidos como
referência e portados à mão para `ParroEntity.java`. Nada do YAML é executado.

## Como ganhar e usar

- `/async parro dar <jogador>` (OP 2, console ou missão): dá o Parro de forma permanente.
  Dar de novo não zera o XP nem tira a sela.
- `/async parro remover <jogador>` e `/async parro info <jogador>`.
- O jogador usa **G → aba Parro** (Chamar/Guardar) ou `/parro chamar`, `/parro guardar`. `/parro` sozinho mostra o nível.
- Só um Parro chamado por dono. Ele é guardado ao sair do servidor, ao trocar de dimensão,
  quando o servidor desliga ou se ficar a mais de 96 blocos. Não fica salvo no mundo.
- Quando o Parro desmaia (morre), só pode ser chamado de novo depois de 30 segundos.

Salvo em `data/averonsync-parro.json` no mundo: dono, XP e se a sela fica (o `pr_saddle_kept`
do pack). A escrita é atômica. Se o arquivo for inválido, o Parro é desativado e o arquivo é mantido.

## Comportamento (do `parro.yml` e do `parro_skills.yml`)

| Pack | AveronSync |
|---|---|
| Níveis do MCPets 1/2/3 com 0/100/300 XP | Iguais: vida 20/40/60, regeneração 0,5/1/1,5 por segundo, resistência 1/1,05/1,1, dano ×1/×1,2/×1,5 e poder ×1/×1,2/×1,5 |
| +3 XP por acerto (no máximo 1 a cada 10 ticks) | Igual, com barra "Parro Lv.N 123 xp", som de XP e título "LEVEL UP!" |
| Segue o dono aos saltos (`pr_pet_hop`) e plana na descida com Slow Falling | Igual, com as mesmas forças de salto e de impulso |
| Teleporta acima de 24 blocos; modo retorno acima de 20 até ficar a 12 | Igual |
| Ataca o alvo do dono, quem bate no dono e monstros num raio de 16 | Igual, mas **nunca jogadores** (decisão do servidor). Jogadores também não ferem o Parro |
| `attack1` (0,5 s) e `attack2` (1 s, quatro bicadas e empurrão) | Mesmos tempos, raios (3 / 3,5 com sela) e multiplicadores (0,5×, 1×, 1,2×) |
| Clique: carinho (`petting1/2`), corações e sons | Igual (qualquer jogador; com sela, Shift + clique) |
| Sela na mão (dono): vira montaria (`transform` → `spawn`) | Igual; a sela é consumida |
| Tesoura (dono): tira a sela, que volta para o inventário | Igual |
| Shift + graveto (dono): zera o XP para o nível 1 | Igual (só o dono) |
| Montado: WASD, Espaço salta (0,85 + impulso de 1,2 e inclinação do olhar), plana a partir de 4 blocos de altura | Igual; Shift desce, clicar ataca |
| Rápido com sela: velocidade 0,29, perseguição 0,45 | Igual |
| Água: nada, Dolphin's Grace e Water Breathing | Igual |
| Queda grande (8+): impacto com som e anel de partículas do bloco | Igual |
| Sem dano de queda; recebe 40% do dano com sela | Igual |
| Sons ambientes, de passos (camel step) e de batida de asa ao planar | Iguais |

## Diferenças inevitáveis

- **Menu:** o menu do MCPets virou a aba Parro no menu G.
- **Planeio montado:** o `pr_ride_glide` soma 0,55 bloco/tick por tick. Sem os limites do
  ModelEngine, isso passaria de 100 blocos/s, então limitei a 1,1 bloco/tick (0,8 sem salto).
- **Velocidade montado:** o pack dá Speed ao cavaleiro, e o ModelEngine usa a velocidade dele
  para mover a montaria. Aqui o mesmo bônus (Speed II/III/IV) é aplicado direto na montaria.
- **Empurrão dos ataques:** o `throw` do MythicMobs foi aproximado em 0,8 bloco/tick (bicadas) e
  1,5 (ataque com sela).
- **Assento:** o assento fica fixo no osso `mount` do modelo, sem acompanhar a animação.
- **Valores que o pack não informa:** a regeneração por segundo e a espera de 30 segundos foram assumidas.

## Importar o pack

```
python tools/import_parro.py "caminho/Parro Pet - Mister Spooky v1.0.1.zip"
```

Lê só os dois `.bbmodel` (formato Blockbench 5) e o ícone. Os ossos de metadado do ModelEngine
(`hitbox`, `shadow`, `mount`) não são desenhados; o `mount` dá a altura do assento (24,5 px).
Gera `assets/averonsync/parro/` e `textures/parro/`, ignorados pelo Git, mais um relatório com
os hashes. Os direitos da arte continuam com DepartmentQDE e Mister Spooky.

## Validação

- `.\gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build` (Java 21): build ok.
  `ParroTest` passa nos 5 testes (níveis, XP, cadastro e leitura dos 2 modelos com todas as animações).
- **Ainda não testado no jogo:** movimento, saltos, planeio, ataques, sela e animações precisam
  ser conferidos no cliente e em servidor dedicado.
- O canal do menu mudou para `averonsync-mount-menu-6` e há um canal novo, `averonsync-parro-1`.
  Cliente e servidor precisam estar na mesma versão.
