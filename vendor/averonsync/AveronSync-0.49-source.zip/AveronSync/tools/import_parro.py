"""Import the owner's licensed "Parro Pet - Mister Spooky" (DepartmentQDE) pack.

Reads only the two ModelEngine .bbmodel blueprints (Blockbench 5 format, bones in
"groups") and the item icon. MCPets/MythicMobs YAML is never executed; its
behaviour was ported by hand to ParroEntity.java. ModelEngine metadata bones
(hitbox, shadow, mount) are omitted from rendering; "mount" gives the rider seat.
Generated artwork stays outside Git.
"""
from pathlib import Path
import argparse, base64, hashlib, json, math, struct, zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'src/main/resources/assets/averonsync'
BLUEPRINTS = {
    'parro': 'ModelEngine/blueprints/DQDE Pet Parro/parro_yellow_blue.bbmodel',
    'parro_saddle': 'ModelEngine/blueprints/DQDE Pet Parro/parro_yellow_blue_saddle.bbmodel',
}
ICON = 'Resource Pack Drop/ItemsAdder/contents/dqde_pet_parro/textures/parro_yellow_blue.png'
METADATA_BONES = {'hitbox', 'shadow', 'mount'}

def vector(value, default):
    value = value if value is not None else default
    result = [float(v) for v in value]
    if len(result) != 3 or not all(math.isfinite(v) for v in result): raise ValueError('Invalid vector')
    return result

def convert(raw, model_id):
    groups = {g['uuid']: g for g in raw.get('groups', [])}
    textures = []
    for i, texture in enumerate(raw['textures']):
        source = texture.get('source', '')
        if not source.startswith('data:image/png;base64,'): raise ValueError('External texture rejected')
        data = base64.b64decode(source.split(',', 1)[1], validate=True)
        if data[:8] != b'\x89PNG\r\n\x1a\n': raise ValueError('Invalid PNG')
        width, height = struct.unpack('>II', data[16:24])
        if not 0 < width <= 2048 or not 0 < height <= 2048: raise ValueError('Oversized texture')
        path = f'textures/parro/{model_id}/{i}.png'
        destination = OUT / path; destination.parent.mkdir(parents=True, exist_ok=True); destination.write_bytes(data)
        uvw, uvh = float(texture['uv_width']), float(texture['uv_height'])
        textures.append(dict(path='averonsync:' + path, width=uvw, height=uvh, uvWidth=uvw, uvHeight=uvh,
                             frameTime=1, frames=1, emissive=-1))
    cubes = {}
    for cube in raw['elements']:
        if cube.get('type', 'cube') != 'cube': raise ValueError('Unsupported mesh')
        faces = {}
        for direction, face in cube.get('faces', {}).items():
            t = face.get('texture')
            if t is None: continue
            if not isinstance(t, int) or not 0 <= t < len(textures): raise ValueError('Invalid face texture')
            faces[direction] = dict(texture=t, uv=[float(v) for v in face['uv']], rotation=face.get('rotation', 0))
        cubes[cube['uuid']] = dict(from_=vector(cube['from'], [0, 0, 0]), to=vector(cube['to'], [0, 0, 0]),
            origin=vector(cube.get('origin'), [0, 0, 0]), rotation=vector(cube.get('rotation'), [0, 0, 0]),
            inflate=float(cube.get('inflate', 0)), faces=faces)
    names, seat = {}, None
    def node(value):
        nonlocal seat
        if isinstance(value, str):
            return dict(id=value, origin=[0, 0, 0], rotation=[0, 0, 0], cubes=[cubes[value]], children=[])
        group = groups[value['uuid']]
        names[group['name']] = value['uuid']
        if group['name'] == 'mount': seat = vector(group.get('origin'), [0, 0, 0])
        children = []
        for child in value.get('children', []):
            if isinstance(child, dict):
                g = groups[child['uuid']]
                if g['name'] == 'mount': node(child); continue
                if not g.get('export', True) or g['name'] in METADATA_BONES: continue
            children.append(node(child))
        return dict(id=value['uuid'], origin=vector(group.get('origin'), [0, 0, 0]),
                    rotation=vector(group.get('rotation'), [0, 0, 0]), cubes=[], children=children)
    nodes = []
    for value in raw['outliner']:
        if isinstance(value, dict) and groups[value['uuid']]['name'] in METADATA_BONES: continue
        nodes.append(node(value))
    animations, duplicates = {}, 0
    for animation in raw.get('animations', []):
        tracks = {}
        for ident, animator in animation.get('animators', {}).items():
            if animator.get('type') != 'bone':
                if animator.get('keyframes'): raise ValueError('Unsupported effect animator')
                continue
            if animator.get('rotation_global') or animator.get('quaternion_interpolation'):
                raise ValueError('Unsupported global/quaternion rotation')
            channels = {}
            for key in animator.get('keyframes', []):
                channel, interpolation = key['channel'], key.get('interpolation', 'linear')
                if channel not in ['position', 'rotation', 'scale'] or interpolation not in ['linear', 'step', 'catmullrom']:
                    raise ValueError(f'Unsupported keyframe {channel}/{interpolation}')
                if len(key['data_points']) != 1: raise ValueError('Unsupported datapoints')
                point = key['data_points'][0]
                frames = channels.setdefault(channel, {})
                t = round(float(key['time']), 4)
                if t in frames: duplicates += 1
                frames[t] = dict(time=t, value=vector([point.get(k, 1 if channel == 'scale' else 0) for k in 'xyz'], [0, 0, 0]),
                                 interpolation=interpolation)
            tracks[ident] = {c: sorted(f.values(), key=lambda f: f['time']) for c, f in channels.items()}
        animations[animation['name']] = dict(length=float(animation['length']), loop=animation.get('loop', 'once'), tracks=tracks)
    model = dict(id=model_id, textures=textures, nodes=nodes, animations=animations)
    if seat is not None: model['seat'] = seat
    return model, dict(cubes=len(cubes), textures=len(textures), animations=list(animations),
                       duplicateKeysResolvedLastWins=duplicates, seat=seat)

def run(archive):
    report = dict(source=Path(archive).name, models={})
    with zipfile.ZipFile(archive) as z:
        for model_id, entry in BLUEPRINTS.items():
            data = z.read(entry)
            if len(data) > 4_000_000: raise ValueError('Model too large')
            model, stats = convert(json.loads(data), model_id)
            destination = OUT / f'parro/{model_id}.json'; destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(json.dumps(model, separators=(',', ':')), encoding='utf-8')
            report['models'][model_id] = dict(sha256=hashlib.sha256(data).hexdigest(), **stats)
        icon = z.read(ICON)
        if icon[:8] != b'\x89PNG\r\n\x1a\n': raise ValueError('Invalid icon')
        destination = OUT / 'textures/parro/icon.png'; destination.write_bytes(icon)
        report['iconSha256'] = hashlib.sha256(icon).hexdigest()
    if report['models']['parro_saddle']['seat'] is None: raise ValueError('Missing rider seat (mount bone)')
    (OUT / 'parro/import-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('archive', type=Path)
    run(parser.parse_args().archive)
