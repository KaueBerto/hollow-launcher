package pl.skidam.automodpack_core.entrance;

import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import pl.skidam.automodpack_core.pets.CubeeModel;
import pl.skidam.automodpack_core.pets.PetAnimation.Vec;
import java.nio.file.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class EntranceTest {
    @TempDir Path temp;

    @Test void settingsPersistChoicesCaseInsensitivelyAndAccess() throws Exception {
        var file = temp.resolve("entrance.json"); var settings = new EntranceSettings(file);
        assertEquals(EntranceSettings.Access.VIP, settings.access());
        assertEquals(EntranceCatalog.RANDOM, settings.choice("Ninguem", 1));
        settings.setChoice("MagoW", "hellgate"); settings.setAccess(EntranceSettings.Access.ALL);
        var reloaded = new EntranceSettings(file);
        assertEquals("hellgate", reloaded.choice("magow", 2));
        assertEquals(EntranceSettings.Access.ALL, reloaded.access());
        settings.setChoice("magow", EntranceCatalog.OFF); assertEquals(EntranceCatalog.OFF, new EntranceSettings(file).choice("MAGOW", 2));
        settings.setChoice("magow", EntranceCatalog.RANDOM); assertEquals(EntranceCatalog.RANDOM, new EntranceSettings(file).choice("magow", 2));
        settings.setChoice("magow", null); assertTrue(new EntranceSettings(file).storedChoice("magow").isEmpty());
    }
    @Test void vipTwoDefaultsToRagdollPossessionUnlessChosen() throws Exception {
        var settings = new EntranceSettings(temp.resolve("entrance.json"));
        assertEquals("ragdollpossession", settings.choice("snow", 2));
        assertEquals(EntranceCatalog.RANDOM, settings.choice("snow", 1));
        assertEquals(EntranceCatalog.RANDOM, settings.choice("snow", 0));
        assertEquals("ragdollpossession", EntranceCatalog.resolve(settings.choice("snow", 2), new Random()).orElseThrow().id());
        settings.setChoice("snow", "risendread"); assertEquals("risendread", settings.choice("snow", 2));
        settings.setChoice("snow", EntranceCatalog.RANDOM); assertEquals(EntranceCatalog.RANDOM, settings.choice("snow", 2));
    }
    @Test void rejectsUnknownChoicesAndPreservesInvalidFile() throws Exception {
        var file = temp.resolve("entrance.json"); var settings = new EntranceSettings(file);
        settings.setChoice("magow", "risendread"); String before = Files.readString(file);
        assertThrows(IllegalArgumentException.class, () -> settings.setChoice("magow", "../evil"));
        assertEquals(before, Files.readString(file));
        String broken = "{\"version\":1,\"access\":\"vip\",\"players\":{\"magow\":\"unknown\"}}";
        Files.writeString(file, broken);
        assertThrows(java.io.IOException.class, () -> new EntranceSettings(file));
        assertEquals(broken, Files.readString(file));
    }
    @Test void resolveHonoursChoiceRandomAndOff() {
        var random = new Random(1);
        assertEquals("midnightlord", EntranceCatalog.resolve("midnightlord", random).orElseThrow().id());
        assertTrue(EntranceCatalog.resolve(EntranceCatalog.OFF, random).isEmpty());
        for (int i = 0; i < 50; i++) assertTrue(EntranceCatalog.contains(EntranceCatalog.resolve(EntranceCatalog.RANDOM, random).orElseThrow().id()));
        assertTrue(EntranceCatalog.containsModel("hellgate_in")); assertFalse(EntranceCatalog.containsModel("hellgate"));
    }
    @Test void skinBoxMatchesVanillaLayoutAndThePacksPlaceholderUv() {
        var head = PlayerSkinBox.boxUv(8, 8, 8, 0, 0);
        // The pack's grey placeholder head uses the same layout at a quarter scale.
        assertArrayEquals(new double[]{8, 8, 16, 16}, head.get("north"));
        assertArrayEquals(new double[]{16, 8, 8, 0}, head.get("up"));
        assertArrayEquals(new double[]{24, 0, 16, 8}, head.get("down"));
        assertArrayEquals(new double[]{0, 8, 8, 16}, head.get("east"));
        var placeholder = new CubeeModel.Cube(new Vec(-7, 11.5, -2), new Vec(-4, 23.5, 2), Vec.ZERO, Vec.ZERO, 0, Map.of(), "left_arm");
        var wide = PlayerSkinBox.cube(placeholder, "left_arm", false, false);
        assertEquals(new Vec(-8, 11.5, -2), wide.from()); assertEquals(new Vec(-4, 23.5, 2), wide.to());
        var slimSleeve = PlayerSkinBox.cube(placeholder, "left_arm", true, true);
        assertEquals(-7, slimSleeve.from().x()); assertEquals(.25, slimSleeve.inflate());
        assertArrayEquals(new double[]{52, 52, 55, 64}, slimSleeve.faces().get("north").uv());
    }
    @Test void importedAnimationsParseWithSkinLimbs() throws Exception {
        var root = Path.of("..", "src", "main", "resources", "assets", "averonsync", "entrance");
        org.junit.jupiter.api.Assumptions.assumeTrue(Files.isDirectory(root), "Private EliteAnimations artwork must be imported for asset validation");
        for (var theme : EntranceCatalog.ALL) for (boolean in : new boolean[]{true, false}) {
            var model = CubeeModel.parseEntrance(JsonParser.parseString(Files.readString(root.resolve(theme.model(in) + ".json"))).getAsJsonObject());
            Set<String> limbs = new HashSet<>(); collect(model.nodes(), limbs);
            assertEquals(PlayerSkinBox.LIMBS, limbs, theme.model(in));
            var clip = model.animations().get("play");
            assertTrue(clip.length() > 0 && clip.length() * 20 <= theme.ticks(in) + 5, theme.model(in));
        }
        // A pet loader must not accept an entrance model, nor the reverse.
        var text = Files.readString(root.resolve("hellgate_in.json"));
        assertThrows(IllegalArgumentException.class, () -> CubeeModel.parse(JsonParser.parseString(text).getAsJsonObject()));
    }
    private static void collect(List<CubeeModel.Node> nodes, Set<String> limbs) {
        for (var n : nodes) { for (var c : n.cubes()) if (c.skin() != null) limbs.add(c.skin()); collect(n.children(), limbs); }
    }
}
