package pl.skidam.automodpack_core.mounts;

import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import pl.skidam.automodpack_core.pets.CubeeModel;
import java.nio.file.*;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ParroTest {
    @TempDir Path temp;

    @Test void levelsFollowTheMcPetsFile() {
        assertEquals(1, ParroLevels.forExperience(0).number());
        assertEquals(1, ParroLevels.forExperience(99.9).number());
        assertEquals(2, ParroLevels.forExperience(100).number());
        assertEquals(3, ParroLevels.forExperience(300).number());
        assertEquals(60, ParroLevels.forExperience(5000).maxHealth());
        assertEquals(4, ParroLevels.damage(ParroLevels.LEVELS[0], 1), 1e-9);
        assertEquals(4 * 1.5 * 1.5 * 1.2, ParroLevels.damage(ParroLevels.LEVELS[2], 1.2), 1e-9);
        assertEquals("Parro Lv.2", ParroLevels.LEVELS[1].name());
    }
    @Test void experienceIsShortenedLikeThePack() {
        assertEquals("42", ParroLevels.formatXp(42.7));
        assertEquals("1.2k", ParroLevels.formatXp(1234));
        assertEquals("3.4m", ParroLevels.formatXp(3_456_789));
        assertEquals("5.6b", ParroLevels.formatXp(5_678_000_000L));
    }
    @Test void registryGrantIsIdempotentAndPersistsExperienceAndSaddle() throws Exception {
        var file = temp.resolve("parro.json"); var registry = new ParroRegistry(file); UUID player = UUID.randomUUID();
        assertTrue(registry.grant(player)); assertFalse(registry.grant(player));
        registry.setExperience(player, 150); registry.setSaddled(player, true);
        assertFalse(registry.grant(player), "a second grant keeps progress");
        var reloaded = new ParroRegistry(file).get(player).orElseThrow();
        assertEquals(150, reloaded.experience()); assertTrue(reloaded.saddled());
        assertTrue(registry.revoke(player)); assertFalse(new ParroRegistry(file).owns(player));
        assertThrows(IllegalStateException.class, () -> registry.setExperience(player, 1));
    }
    @Test void invalidRegistryIsPreserved() throws Exception {
        var file = temp.resolve("parro.json");
        String text = "{\"version\":1,\"players\":{\"" + UUID.randomUUID() + "\":{\"experience\":-5,\"saddled\":false}}}";
        Files.writeString(file, text);
        assertThrows(java.io.IOException.class, () -> new ParroRegistry(file));
        assertEquals(text, Files.readString(file));
    }
    @Test void importedModelsParseWithEveryStateTheSkillsUse() throws Exception {
        var root = Path.of("..", "src", "main", "resources", "assets", "averonsync", "parro");
        org.junit.jupiter.api.Assumptions.assumeTrue(Files.isDirectory(root), "Private Parro artwork must be imported for asset validation");
        var pet = CubeeModel.parseParro(JsonParser.parseString(Files.readString(root.resolve("parro.json"))).getAsJsonObject());
        var saddle = CubeeModel.parseParro(JsonParser.parseString(Files.readString(root.resolve("parro_saddle.json"))).getAsJsonObject());
        for (String clip : new String[]{"idle", "walk", "swim", "hurt", "jump1", "jump2", "jump3", "jump22", "petting1", "petting2",
                "attack1", "attack2", "transform", "transform_back", "summon", "death"}) assertTrue(pet.animations().containsKey(clip), clip);
        for (String clip : new String[]{"idle", "walk", "run", "swim", "hurt", "jump1", "jump2", "jump3", "jump22", "petting1", "petting2",
                "attack1", "attack2_r", "attack2_l", "transform", "spawn", "death"}) assertTrue(saddle.animations().containsKey(clip), clip);
        assertThrows(IllegalArgumentException.class, () -> CubeeModel.parse(JsonParser.parseString(Files.readString(root.resolve("parro.json"))).getAsJsonObject()));
    }
}
