package pl.skidam.automodpack_core.mounts;

/**
 * Levels of the Parro pet, copied from the pack's MCPets/Pets/parro.yml:
 * experience thresholds 0/100/300 and the per-level stats.
 */
public final class ParroLevels {
    /** {@code regeneration} is health per second; {@code resistance} divides damage taken. */
    public record Level(int number, int threshold, double maxHealth, double regeneration, double resistance,
                        double damageModifier, double power) {
        public String name() { return "Parro Lv." + number; }
    }
    public static final Level[] LEVELS = {
            new Level(1, 0, 20, .5, 1.0, 1.0, 1.0),
            new Level(2, 100, 40, 1.0, 1.05, 1.2, 1.2),
            new Level(3, 300, 60, 1.5, 1.1, 1.5, 1.5)};
    /** MythicMobs "Parro" Damage. */
    public static final double BASE_DAMAGE = 4;
    /** pr_exp_award: +3 experience per hit, at most once every 10 ticks. */
    public static final int XP_PER_HIT = 3, XP_COOLDOWN_TICKS = 10;
    public static Level forExperience(double xp) {
        Level result = LEVELS[0];
        for (Level level : LEVELS) if (xp >= level.threshold()) result = level;
        return result;
    }
    /** pr_exp_show: "123", "1.2k", "3.4m" or "5.6b". */
    public static String formatXp(double xp) {
        long value = (long) Math.max(0, Math.floor(xp));
        if (value < 1_000) return Long.toString(value);
        long[] units = {1_000_000_000L, 1_000_000L, 1_000L};
        String[] names = {"b", "m", "k"};
        for (int i = 0; i < units.length; i++)
            if (value >= units[i]) return (value / units[i]) + "." + (value % units[i]) / (units[i] / 10) + names[i];
        return Long.toString(value);
    }
    /** Damage of one hit: Damage x DamageModifier x Power, times the attack's factor (1.2 saddled, 0.5 peck). */
    public static double damage(Level level, double factor) { return BASE_DAMAGE * level.damageModifier() * level.power() * factor; }
    private ParroLevels() {}
}
