package pl.skidam.automodpack_core.entrance;

import java.util.*;

/** Join/leave animation themes imported from the EliteAnimations v1 (Halloween) pack. */
public final class EntranceCatalog {
    /** Durations in ticks follow the pack's AnimationsCore files (joins/leaves). */
    public record Theme(String id, String name, int inTicks, int outTicks) {
        public int ticks(boolean in) { return in ? inTicks : outTicks; }
        public String model(boolean in) { return id + (in ? "_in" : "_out"); }
    }
    public static final String RANDOM = "aleatoria", OFF = "desligada", DEFAULT = "padrao";
    /** VIP level 2 plays Ragdoll Possession unless the player picks something else. */
    public static final String VIP2_DEFAULT = "ragdollpossession";
    public static final List<Theme> ALL = List.of(
            new Theme("cadavercurse", "Maldição Cadavérica", 55, 65),
            new Theme("hellgate", "Portão do Inferno", 80, 51),
            new Theme("midnightlord", "Senhor da Meia-Noite", 45, 38),
            new Theme("ragdollpossession", "Possessão do Boneco", 45, 35),
            new Theme("risendread", "Pavor Ressurgido", 45, 45));
    public static Optional<Theme> find(String id) { return ALL.stream().filter(t -> t.id().equals(id)).findFirst(); }
    public static boolean contains(String id) { return find(id).isPresent(); }
    /** Model ids accepted by the client loader: {@code <theme>_in} or {@code <theme>_out}. */
    public static boolean containsModel(String id) {
        return ALL.stream().anyMatch(t -> t.model(true).equals(id) || t.model(false).equals(id));
    }
    /** Animation used when the player has not chosen one: by VIP level (0 = not VIP). */
    public static String defaultChoice(int vipLevel) { return vipLevel >= 2 ? VIP2_DEFAULT : RANDOM; }
    /** Choice stored for a player: a theme id, {@link #RANDOM} or {@link #OFF}. */
    public static boolean validChoice(String choice) { return RANDOM.equals(choice) || OFF.equals(choice) || contains(choice); }
    /** Resolves a stored choice to a theme; empty when animations are switched off. */
    public static Optional<Theme> resolve(String choice, Random random) {
        if (OFF.equals(choice)) return Optional.empty();
        if (choice != null && !RANDOM.equals(choice)) { var theme = find(choice); if (theme.isPresent()) return theme; }
        return Optional.of(ALL.get(random.nextInt(ALL.size())));
    }
    private EntranceCatalog() {}
}
