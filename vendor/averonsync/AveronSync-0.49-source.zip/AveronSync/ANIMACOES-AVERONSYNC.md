# Animações de entrada e saída — AveronSync 0.49

Minecraft 1.21.1 NeoForge. Recria, de forma nativa, o pack **EliteAnimations v1
(Halloween Edition)**, comprado pelo dono do servidor. Não instala nem emula
AnimationsCore, MythicMobs, ModelEngine, ItemsAdder ou Oraxen.

Cinco temas, cada um com uma animação de entrada e uma de saída:

| ID | Nome | Entrada | Saída |
|---|---|---|---|
| `cadavercurse` | Maldição Cadavérica | 55 ticks | 65 ticks |
| `hellgate` | Portão do Inferno | 80 ticks | 51 ticks |
| `midnightlord` | Senhor da Meia-Noite | 45 ticks | 38 ticks |
| `ragdollpossession` | Possessão do Boneco | 45 ticks | 35 ticks |
| `risendread` | Pavor Ressurgido | 45 ticks | 45 ticks |

As durações são as dos arquivos `AnimationsCore/joins` e `leaves` do pack.

## Uso

- `/animacao` ou `/animacao listar`: tema atual e lista de temas.
- `/animacao usar <tema>`: fixa um tema. `/animacao usar aleatoria`: sorteia a cada entrada/saída.
- `/animacao usar padrao`: apaga a escolha e volta ao padrão do seu VIP: VIP 1 sorteia; **VIP 2 usa Possessão do Boneco** (`ragdollpossession`).
- `/animacao desligar`: não mostra animação para você.
- `/animacao testar` (ou `testar entrada` / `testar saida`): toca a animação no lugar onde você está. Intervalo de 10 segundos.
- `/animacao acesso vip|todos` (OP nível 3 ou console): quem pode ter animação. Padrão: `vip`.

Com acesso `vip`, valem o VIP ativo de `/async vip add` e os OPs. A escolha fica
salva em `automodpack/averonsync-entrance.json`, por nick e sem diferenciar
maiúsculas de minúsculas. A escrita é atômica, e uma falha ao gravar mantém o
estado anterior. Arquivo inválido desativa as animações sem apagar o arquivo.

## Quando toca

- **Entrada:** uma vez por conexão, quando o jogador está autenticado (EasyLogin,
  ou autenticação nativa se não houver EasyLogin). Toca no ponto em que ele está nesse momento.
- **Saída:** ao desconectar, apenas para quem teve a entrada anunciada nessa conexão.
  Quem não chegou a autenticar não gera animação. Não toca quando o servidor está desligando.
- Jogadores invisíveis, mortos ou em espectador não geram animação.
- Quem recebe: jogadores na mesma dimensão, até 64 blocos. Na saída, o próprio
  jogador já desconectou e não vê a animação: só os outros veem.
- O canal é opcional, e só recebe quem tem o canal `averonsync:entrance`.

## Visual

O servidor não cria entidades: só envia um pacote com jogador, tema, posição e direção.
O cliente desenha o modelo Blockbench com o mesmo renderer dos pets. Os ossos de
membro do jogador do ModelEngine (`phead_`, `pbody_`, `plarm_`, `prarm_`, `plleg_`,
`prleg_`) são desenhados com a skin do próprio jogador (camada base e camada
externa, braço fino ou largo conforme a skin). Na saída, a skin é a que estava na
lista de jogadores no momento em que o pacote chegou.

O tamanho acompanha o atributo vanilla `minecraft:scale` do jogador no momento
do gatilho: raças do AveronOrigins (modificador `averonorigins:racial_scale`) ou
qualquer outro mod que use esse atributo. Modelo, partículas e área de ocultação
são multiplicados por esse valor (limitado entre 0,0625 e 16). Não há dependência
de código do AveronOrigins.

Durante a própria animação de entrada, o jogador real fica oculto enquanto
estiver a menos de 1,5 bloco do ponto. Se ele andar, volta a aparecer, e a
animação termina sozinha. A animação segura a última pose até acabar a duração
(modo `hold` do pack). O local recebe luz de bloco 15, como o `blockmask light` do pack.

Sons e partículas foram transcritos à mão do `SkillsFile_EA-Halloween.yml`.
Os projéteis `totem` e os alvos `@ModelPart` são aproximados com posições fixas
ao redor do jogador, não por um interpretador de MythicMobs. Os sons próprios do
pack ficam em `averonsync:entrance.<tema>_<in|out>`, e os demais são vanilla.

## Importar o pack

```
python tools/import_entrance.py "caminho/eliteanimations-v1-halloween_edition.zip"
```

Lê só os 10 `.bbmodel`, os PNGs embutidos neles e os 10 `.ogg`, sem executar ou copiar
configurações de plugin. Gera `assets/averonsync/entrance/*.json`,
`textures/entrance/` e `sounds/entrance/`, mais um `import-report.json` com os
hashes de origem. Esses arquivos são ignorados pelo Git, então o pack comprado
não entra na publicação do código. O build local os inclui no JAR. Os direitos da
arte e dos sons continuam com os autores do pack: confira se a licença permite
distribuí-los aos jogadores dentro do mod.

## Validação

- `.\gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --console=plain` (Java 21): build ok.
  `EntranceTest` passa os 5 testes: persistência, escolha, layout de UV da skin e leitura dos 10 modelos importados.
- **Ainda não validado no jogo:** orientação do modelo, encaixe da skin nos
  membros, efeitos e ocultação do jogador precisam ser conferidos no cliente
  (`/animacao testar`) e com dois jogadores em servidor dedicado.
