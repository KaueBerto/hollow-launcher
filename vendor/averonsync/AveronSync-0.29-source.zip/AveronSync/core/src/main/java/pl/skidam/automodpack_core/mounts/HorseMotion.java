package pl.skidam.automodpack_core.mounts;

/** Converts target blocks/tick into vanilla's acceleration input, rather than
 * treating the plugin's speed as a horse acceleration attribute (2.2x on stone). */
public final class HorseMotion {
    public static double riddenSpeed(double target,double friction) {
        if(!Double.isFinite(target) || target<0 || !Double.isFinite(friction) || friction<=0 || friction>1)
            throw new IllegalArgumentException("Invalid horse motion parameters");
        return target*(1-.91*friction)*friction*friction*friction/.21600002;
    }
    /** Shortest arc at the +/-180 boundary; never spin via zero between adjacent headings. */
    public static float renderYaw(float previous,float current,float partial) {
        float delta=(current-previous)%360;
        if(delta>=180)delta-=360;
        if(delta< -180)delta+=360;
        return previous+Math.max(0,Math.min(1,partial))*delta;
    }
    private HorseMotion() {}
}
