# Cavalo de missão — AveronSync 0.27

Minecraft 1.21.1 NeoForge. Cavalo castanho (`horse_bay`) da variante de apito
`LRD_horse_bay_mcpet` do pacote LittleRoom fornecido pelo proprietário. Não exige
VIP. Nenhuma alteração foi enviada à VPS, launcher ou GitHub nesta etapa.

## Recompensa de missão

A missão deve executar no servidor, com permissão OP 2:

```text
async cavalo recompensar <jogador>
```

Entrega somente o apito `averonsync:horse_whistle` e salva o desbloqueio permanente.
Não cria uma montaria ao entregar a recompensa. O jogador precisa estar online,
autenticado e com espaço livre. Recompensa repetida não duplica o item. Um apito
criado por `/give` sem vínculo válido não funciona. `/cavalo apito` recupera um
apito perdido após desbloquear; durante a montaria não entrega outro apito.
A missão, NPC e objetivos ainda precisam ser definidos/configurados.

## Fluxo do apito original

Usar o apito chama o cavalo e monta o dono automaticamente. O item sai do inventário
enquanto a montaria está ativa. Ao desmontar parado, o cavalo some em partículas
e o mesmo apito volta ao inventário; se estiver cheio, cai no chão. Ele permanece
vinculado ao dono mesmo se outro jogador o recolher. Uma montaria ativa por dono.
O registro/token são salvos no mundo em `data/averonsync-quest-horses.json`, com
escrita atômica e recusa de arquivo corrompido. Não depende do vencimento de VIP.

## Controles portados dos YAMLs

- W/S: avançar/recuar, sem deslocamento lateral.
- A/D: virar o cavalo, independentemente da câmera. Avanço: 4 graus por tick;
  ré: sentido invertido; parado: 3 graus por tick. Curvas usam os clipes de inclinação.
- Toque em Ctrl avançando: alterna trote/galope, intervalo de 20 ticks. Segurar
  Ctrl mantém a marcha escolhida; não alterna novamente a cada segundo. Aceleração a cada
  dois ticks: 0.50, 0.65, 0.80, 0.95, 1.10, 1.25. Desaceleração: 1.10, 0.95,
  0.80, 0.65, 0.50, 0.20. O clipe de galope muda no ponto previsto pelo YAML.
- Soltar W no galope: volta ao trote e aplica a frenagem de seis ticks do pacote.
- Ré: velocidade 0.10; trote: 0.20.
- Espaço parado: empina, toca relincho e suspende avanço por 20 ticks.
- Espaço avançando no galope: impulso horizontal/vertical 0.60/0.60. Sem salto
  carregado vanilla. Espaço no trote não dá o salto de galope.
- Espaço com A/D no galope: derrapagem com rotação adicional de 3 graus e fumaça.
- Cerca de carvalho detectada até quatro blocos à frente: salto automático no
  galope, impulso 0.85/0.65 e intervalo de 20 ticks.
- Na água: velocidade 0.50, volta ao trote e usa nado; saída toca a animação
  original e emite gotas. Sem alternância de marcha ou salto dentro da água.
- Shift sem avanço/ré: devolve o apito e recolhe a montaria.

Os números acima são os parâmetros do pacote. A física de locomoção e colisão é
executada pelo Minecraft/NeoForge, não pelo runtime proprietário ModelEngine.
A 0.18 converte esses valores de velocidade para a aceleração vanilla, evitando
a amplificação de aproximadamente 2.2x da 0.17. Em piso comum, os alvos são quatro
blocos/s no trote e 25 blocos/s no galope. Sem teste comparativo com o plugin não
há garantia de trajetória/sensação idêntica.

## Visual e áudio

O apito usa os três cubos e os ajustes de exibição do JSON original. Sua textura
original `horse_whistle.png` está embutida em `lrd_horse_appaloosa.bbmodel`; o
importador extrai essa textura e remapeia apenas seu namespace para AveronSync.
Não usa mais o ícone provisório de chifre de cabra.

O cavalo preserva 44 cubos visuais, três texturas e 20 clipes. Escala original 1.0,
hitbox de 1.5 x 3 blocos e assento `p_seat=(0,29,2)/16`, transformado pelos ossos
animados dos pais para acompanhar a sela. Mistura locomoção, ações, inclinações e
movimentos aleatórios de orelhas, cauda e cabeça. Dois pares de keyframes de nado
no mesmo instante são resolvidos mantendo a última chave na ordem original.

Passos usam os sons do pacote e os instantes das timelines de caminhada/galope.
Relinchos, bufadas e os três apitos também usam o áudio original. As timelines
MythicMobs não são executadas: os efeitos conhecidos são implementados nativamente.
Os arquivos `horse_skid` também são preservados para evolução; os YAMLs de deriva
consultados pedem fumaça, sem tocar esse som.

A física procedural de segmentos de crina/cauda do ModelEngine ainda não foi
reproduzida; há animações originais desses ossos. A variante de apito não inclui
os sistemas de selvagens, domesticação, comerciante, sujeira e escovação da outra
variante do pacote. Os outros 11 cavalos também não foram ativados.

## Autoridade e limpeza

Cliente envia somente eixos/ações de teclado e o ID da montaria, até uma
atualização por tick. O servidor valida dono, passageiro e autenticação. Não aceita
posição, velocidade ou direção fornecida pelo cliente. Sem receber controles por
10 ticks, para de avançar. Não usa a direção da câmera nem o salto carregado vanilla.

A montaria é invulnerável e não tem reprodução/inventário acessível, como a variante
mcpet. Não aparece por spawn natural. Ao desconectar, morrer, virar espectador,
perder autenticação, mudar de dimensão ou afastar-se mais de 64 blocos, é recolhida.
Montarias sem passageiro são recolhidas na verificação periódica de 20 ticks. O
apito é devolvido se o jogador ainda está disponível; o desbloqueio persistente
permite recuperar outro após uma perda. Entidades antigas em chunks/reinícios
são rejeitadas pela identidade da sessão e entidade ativa. Não busca/gera chunks
para localizar cavalos. Servidor offline exige EasyLogin; sem ele, recusa o acesso.

## Construção e verificação

```powershell
python tools/import_quest_horse.py 'C:/caminho/LITTLEROOM_horsepack_v2_1_1_21_4.rar'
.\gradlew.bat :core:test :loader-core:test :1.21.1-neoforge:build --offline --console=plain
```

Assets privados gerados ficam fora do Git; direitos continuam com LittleRoom.
O aviso `META-INF/NOTICE-LittleRoom.txt` acompanha o JAR. O JAR instalável está em
`merged/`; cliente e servidor precisam da mesma versão.

Os testes verificam os parâmetros/tempos de controle, modelo, assento animado,
vínculo de dono, escrita atômica e persistência. A fixture dedicada local fica
fora do produto em `work/horse-native-tests` no workspace. Relatórios ficam em
`work/horse-smoke-server`; a fixture nunca é empacotada no JAR de distribuição.

Falta conferir com cliente gráfico os controles e o alinhamento final e fazer um
comparativo com o plugin original e o modpack completo/Icy's Better Horses.
O helper de controle gráfico não inicializou nesta sessão; validação visual não
foi declarada como concluída. A missão específica continua pendente de definição.

Resultado da validação local 0.17: 122 testes do core e 9 do bootstrap passaram.
O servidor dedicado local iniciou e encerrou normalmente, com a fixture aprovando
montagem automática, consumo/devolução do apito, movimento real no servidor,
direção independente da câmera, galope, vínculo de dono, rejeição de mais de um
pacote no mesmo tick, limpeza e persistência. A fixture nunca é distribuída.

## Correções da 0.18

O teste nativo da 0.17 mediu pico de 54.99 blocos/s. O conversor de atrito/arrasto
da 0.18 evita alimentar a física de cavalo com velocidade como aceleração direta.
O controle agora alterna marcha por nova pressão de Shift, preservando a marcha
se a tecla continuar pressionada.

As mudanças de locomoção preservam a fase do passo entre caminhada/galope/ré e
misturam a pose anterior durante quatro ticks, inclusive se outra transição
interrompê-la. Inclinações de curva misturam as poses durante cinco ticks, sem
descartar a inclinação anterior ao inverter a direção. A sela usa a mesma mistura
de base/curvas e o mesmo peso de entrada/saída das ações do renderer. Ao ficar
bloqueado por uma parede, a montaria troca para idle depois de confirmar três
ticks sem deslocamento. A frenagem mantém caminhada enquanto ainda há movimento.

Testes adicionais cobrem Shift segurado, equilíbrio da física sobre diferentes
atritos, continuidade/interrupção de poses, fase dos passos e reversão de curva.

## Correção do apito na 0.19

A textura original do apito agora fica em `textures/item/horse_whistle.png` e os
campos do modelo apontam para `averonsync:item/horse_whistle`. A pasta anterior
`textures/mounts` serve aos desenhos de entidade carregados diretamente, mas não
é descoberta automaticamente pelo atlas padrão de itens/blocos. A 0.18 registrava
`Missing textures in model averonsync:horse_whistle#inventory` no cliente por esse
motivo. O modelo 3D e os bytes do PNG original foram preservados.

## Controles e dica na 0.20

Corrida usa a tecla de sprint do Minecraft (Ctrl por padrão), separada de Shift.
Shift parado continua desmontando. A dica `Ctrl: correr • Shift parado: sair`
é exibida uma vez na action bar ao montar e usa o prazo nativo de 60 ticks
(cerca de três segundos) para desaparecer, sem renovação por tick.
Não há instruções de montaria no chat. Avisos de uso do apito e respostas aos
comandos de jogador também usam action bar; o console mantém seus registros.
O protocolo de controles passou para `averonsync-horse-2`; cliente e servidor
precisam da versão 0.20.

## Menu de montarias na 0.21

G abre o menu; G ou Esc fecha. A tecla pode ser remapeada em Controles > AveronSync.
A tela mostra uma prévia 3D local do cavalo castanho, o desbloqueio da missão,
a disponibilidade do apito e se há uma montaria em uso. A prévia não é adicionada
ao mundo. Atualmente só o castanho está disponível; nenhum cavalo VIP foi liberado.

Chamar procura no inventário o apito vinculado ao próprio jogador e reutiliza o
fluxo de chamada, consumo e montagem. Guardar exige cavalo parado no chão e
devolve o apito. Recuperar apito só é oferecido depois do desbloqueio, quando
não há item no inventário nem montaria ativa. Não concede a missão ou VIP.

O servidor valida novamente cada ação, incluindo autenticação e identidade do
jogador. O cliente não envia nick, UUID de proprietário, entidade ou ID de
recompensa. Consulta limitada a uma a cada cinco ticks; ações a cada dez ticks.
A tela consulta o estado a cada segundo enquanto aberta e não pausa o jogo.
Respostas atrasadas são ignoradas após fechar ou abrir outra instância da tela.

A fixture dedicada local aprovou os dois codecs, pedidos inválidos, limite de
consultas, bloqueio por missão, chamada pelo menu, recusa de guardar em movimento,
recolhimento parado e recuperação de apito. Conferência gráfica da tela fica
para o teste no cliente de dev; nenhum teste gráfico foi declarado como concluído.

## Fundo nítido na 0.22

O menu de montarias substitui o fundo padrão de Screen por uma camada preta com
40% de opacidade. Não chama o pós-processamento de blur e não muda as opções
globais de desfoque do jogador.

## Tela somente de seleção na 0.23

A tela G mostra apenas o nome, a prévia do cavalo e Selecionar/Fechar. Textos de
missão, apito, status e as ações Chamar/Guardar/Recuperar saíram dessa tela. As
permissões existentes no servidor foram preservadas. Selecionar confirma o
castanho em `PlayerPersisted.averonsync_selected_mount` e fecha a tela, sem
invocar, consumir ou gerar itens. O castanho ainda é a única opção disponível;
a chamada continua pelo apito.

A prévia recebe uma marca somente no cliente. O renderer acrescenta 180 graus
exclusivamente às entidades dessa prévia; a direção e a renderização dos cavalos
no mundo não mudaram. A tela continua sem pós-processamento de blur.

O protocolo do menu passou a `averonsync-mount-menu-2`. A fixture dedicada local
verifica seleção persistida, ausência de invocação/consumo ao selecionar e
preservação do bloqueio de acesso. A conferência visual cabe ao teste no dev.

## Aba Pets no menu G (0.24)

O menu G reúne Cavalos e Pets. A aba Pets permite selecionar Terras áridas, Bétula e Espeleotema, guardar, fazer carinho e executar emote. Exige VIP ativo, validado no servidor pelos comandos existentes. A consulta de acesso é atualizada a cada segundo e a expiração também desativa os botões localmente. Não concede VIP nem altera desbloqueios de cavalos. Mantém a tela sem desfoque e a rotação de 180 graus da prévia do cavalo.

## Curvas e trajetória (0.27)

Curvas normais giram também a velocidade horizontal retida do tick anterior. Corpo e trajetória passam a virar juntos, preservando o módulo da velocidade e a componente vertical. A derrapagem explícita com pulo e curva mantém a inércia. Não altera velocidade, teclas, pacotes ou permissões.
