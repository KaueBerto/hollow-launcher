package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import java.util.UUID;
import net.minecraft.network.syncher.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.*;
import net.minecraft.world.phys.*;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import pl.skidam.automodpack_core.mounts.HorseControls;
import pl.skidam.automodpack_core.mounts.HorseSeatPose;
import pl.skidam.automodpack_core.mounts.HorseMotion;
import pl.skidam.automodpack_core.mounts.HorsePoseBlend;
import pl.skidam.automodpack_core.mounts.HorseLeanBlend;

/** Temporary, owner-only quest mount. No breeding, storage, drops or independent population. */
public final class QuestHorseEntity extends Horse {
    private static final EntityDataAccessor<Integer> BASE=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> BASE_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> ACTION=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> ACTION_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> LEAN=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> LEAN_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> TWITCH=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Long> TWITCH_AT=SynchedEntityData.defineId(QuestHorseEntity.class,EntityDataSerializers.LONG);
    private UUID session;
    private static HorseSeatPose seatModel;
    private static boolean seatLoaded;
    private ItemStack whistle=ItemStack.EMPTY;
    private final HorseControls controls=new HorseControls();
    private HorseControls.Input keys=HorseControls.Input.NONE;
    private HorseControls.Output output;
    private long inputAt=Long.MIN_VALUE;
    private int acceptedAt=Integer.MIN_VALUE;
    private double lastStepAge;
    private double lastHorizontalMove;
    private int stationaryTicks;
    private final HorsePoseBlend seatBlend=new HorsePoseBlend();
    private final HorseLeanBlend seatLean=new HorseLeanBlend();
    private long tailAt=-40, headAt=-40, snortAt=-200;
    public void storeWhistle(ItemStack stack) { whistle=stack; }
    public ItemStack takeWhistle() { ItemStack result=whistle;whistle=ItemStack.EMPTY;return result; }
    @Override protected void registerGoals() { /* The original mcpet has only float, no autonomous wandering. */ }
    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(BASE,0);builder.define(BASE_AT,0L);builder.define(ACTION,0);builder.define(ACTION_AT,0L);
        builder.define(LEAN,0);builder.define(LEAN_AT,0L);builder.define(TWITCH,0);builder.define(TWITCH_AT,0L);
    }
    public String baseClip() { return new String[]{"idle","walk","gallop","backpedal","swim"}[entityData.get(BASE)]; }
    public long baseAt() { return entityData.get(BASE_AT); }
    public HorseControls.Action action() { return HorseControls.Action.values()[entityData.get(ACTION)]; }
    public long actionAt() { return entityData.get(ACTION_AT); }
    public int lean() { return entityData.get(LEAN); }
    public long leanAt() { return entityData.get(LEAN_AT); }
    public int twitches() { return entityData.get(TWITCH); }
    public long twitchAt() { return entityData.get(TWITCH_AT); }
    public boolean acceptInput(ServerPlayer player,HorseControls.Input input) {
        if (level().isClientSide || getFirstPassenger()!=player || !player.getUUID().equals(getOwnerUUID())
                || !AveronSyncQuestHorses.authenticated(player) || acceptedAt==player.server.getTickCount()) return false;
        acceptedAt=player.server.getTickCount();keys=input;inputAt=level().getGameTime();return true;
    }
    @Override public boolean isControlledByLocalInstance() { return !level().isClientSide; }
    @Override protected Vec3 getRiddenInput(Player player,Vec3 vanilla) { return new Vec3(0,0,output==null?0:output.front()); }
    @Override protected float getRiddenSpeed(Player player) {
        BlockPos ground=getBlockPosBelowThatAffectsMyMovement();
        double friction=Math.clamp(level().getBlockState(ground).getFriction(level(),ground,this),.05,1);
        return (float)HorseMotion.riddenSpeed(output==null?.2:output.speed(),friction);
    }
    @Override protected void tickRidden(Player player,Vec3 input) { setXRot(0);yHeadRot=getYRot();yBodyRot=getYRot(); }
    @Override public void onPlayerJump(int strength) { /* Space is handled by the meta-controller, not charged horse jumps. */ }
    @Override public boolean canJump() { return false; }
    @Override public boolean canBeRiddenUnderFluidType(net.neoforged.neoforge.fluids.FluidType type,Entity rider) {
        return type==net.neoforged.neoforge.common.NeoForgeMod.WATER_TYPE.value();
    }
    @Override protected void playStepSound(BlockPos pos,net.minecraft.world.level.block.state.BlockState state) { /* Timeline-synchronized below. */ }
    @Override protected net.minecraft.sounds.SoundEvent getAmbientSound() { return null; }
    @Override public void tick() {
        Vec3 start=position();
        if (!level().isClientSide) {
            long now=level().getGameTime();
            if (getFirstPassenger() instanceof ServerPlayer player) {
                HorseControls.Input input=now-inputAt>10?HorseControls.Input.NONE:keys;
                var floor=level().clip(new ClipContext(position(),position().add(0,-4,0),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,this));
                boolean high=!onGround() && getDeltaMovement().y<.2 && (floor.getType()==HitResult.Type.MISS || floor.getLocation().distanceTo(position())>3);
                Vec3 ahead=Vec3.directionFromRotation(0,getYRot());
                Vec3 from=position().add(0,.75,0);
                var hit=level().clip(new ClipContext(from,from.add(ahead.scale(4)),ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,this));
                boolean fence=hit.getType()==HitResult.Type.BLOCK && level().getBlockState(hit.getBlockPos()).is(Blocks.OAK_FENCE);
                output=controls.tick(input,new HorseControls.Environment(onGround(),isInWater(),high,fence));
                if (output.dismiss()) { AveronSyncQuestHorses.dismissOwned(player,this);return; }
                // Vanilla retains horizontal momentum from the previous tick. Turn that
                // momentum with the mount so ordinary steering does not slide sideways.
                // The explicit jump+turn drift keeps its original inertia.
                if (output.yawDelta()!=0 && !output.drift())
                    setDeltaMovement(getDeltaMovement().yRot((float)-Math.toRadians(output.yawDelta())));
                setYRot(getYRot()+output.yawDelta());yBodyRot=getYRot();yHeadRot=getYRot();
                if (output.vertical()>0) {
                    Vec3 direction=Vec3.directionFromRotation(0,getYRot()).scale(output.lunge());
                    setDeltaMovement(direction.x,output.vertical(),direction.z);hasImpulse=true;
                } else if (output.braking()>0) setDeltaMovement(getDeltaMovement().add(Vec3.directionFromRotation(0,getYRot()).scale(output.braking())));
                if (isInWater()) setDeltaMovement(getDeltaMovement().x,Math.max(getDeltaMovement().y,.025),getDeltaMovement().z);
                int base=switch(output.animation()) {case "walk"->1;case "gallop"->2;case "backpedal"->3;case "swim"->4;default->0;};
                if(onGround() && stationaryTicks>=3 && output.vertical()==0 && base!=4)base=0;
                if(base==0 && output.braking()>0 && lastHorizontalMove>.005)base=1;
                if (base!=entityData.get(BASE)) {
                    String next=new String[]{"idle","walk","gallop","backpedal","swim"}[base];
                    long at=HorsePoseBlend.phaseStart(baseClip(),baseAt(),next,now);
                    entityData.set(BASE,base);entityData.set(BASE_AT,at);lastStepAge=now-at;
                }
                int lean=output.lean()*(output.gait()==HorseControls.Gait.GALLOP?2:1);
                if (lean!=entityData.get(LEAN)) {entityData.set(LEAN,lean);entityData.set(LEAN_AT,now);}
                if (output.action()!=HorseControls.Action.NONE) {
                    entityData.set(ACTION,output.action().ordinal());entityData.set(ACTION_AT,now);
                    if (output.action()==HorseControls.Action.REAR) playSound(AveronSyncHorseSound.NEIGH.get(),1,.9F+random.nextFloat()*.3F);
                }
                if(isInWater() && (action()==HorseControls.Action.JUMP || action()==HorseControls.Action.FALLING)) entityData.set(ACTION,0);
                if(action()==HorseControls.Action.OUT_WATER) {
                    long elapsed=now-actionAt();
                    if(elapsed==10 || elapsed==15 || elapsed==20) ((ServerLevel)level()).sendParticles(ParticleTypes.FALLING_WATER,getX(),getY()+1.5,getZ(),3,.3,.5,.4,.01);
                }
                if (output.drift()) ((ServerLevel)level()).sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,getX(),getY(),getZ(),1,.15,.15,.15,.01);
                timelineSteps(now);
            } else if (tickCount>1 && tickCount%20==0) {
                var player=((ServerLevel)level()).getServer().getPlayerList().getPlayer(getOwnerUUID());
                if (player!=null) {AveronSyncQuestHorses.dismissOwned(player,this);return;}
            }
            if (tickCount%20==0) {
                int twitch=0;
                if (now-tailAt>=40 && random.nextFloat()<.25) {twitch|=1;tailAt=now;}
                if (random.nextFloat()<.25) twitch|=2;
                if (random.nextFloat()<.25) twitch|=4;
                if (now-headAt>=40 && random.nextFloat()<.25) {twitch|=8;headAt=now;}
                entityData.set(TWITCH,twitch);entityData.set(TWITCH_AT,now);
                if (now-snortAt>=200 && random.nextFloat()<.1) {playSound(AveronSyncHorseSound.SNORT.get(),.5F,.9F+random.nextFloat()*.3F);snortAt=now;}
            }
        }
        super.tick();
        if(!level().isClientSide) {
            lastHorizontalMove=position().subtract(start).horizontalDistance();
            stationaryTicks=lastHorizontalMove<.003?stationaryTicks+1:0;
        }
    }
    private void timelineSteps(long now) {
        int base=entityData.get(BASE);if (base!=1 && base!=2) return;
        double length=base==2?10:20,age=now-baseAt();
        double[] cues=base==2?new double[]{.833333,3.333333,8.333333}:new double[]{1.666667,5,11.666667,15.833333};
        for (double cue:cues) {
            double at=Math.floor(age/length)*length+cue;
            if (at>lastStepAge && at<=age && onGround()) {
                playSound(AveronSyncHorseSound.STEP.get(),.5F,.9F+random.nextFloat()*.3F);
                if (base==2) ((ServerLevel)level()).sendParticles(new BlockParticleOption(ParticleTypes.BLOCK,Blocks.DIRT.defaultBlockState()),getX(),getY()+.1,getZ(),4,.35,.05,.5,.02);
            }
        }
        lastStepAge=age;
    }
    public QuestHorseEntity(EntityType<? extends Horse> type, Level level) {
        super(type, level);
        setInvulnerable(true);
        setPersistenceRequired();
    }
    void session(UUID value) { session = value; }
    UUID session() { return session; }
    @Override protected boolean canAddPassenger(Entity passenger) {
        return (level().isClientSide || (passenger instanceof ServerPlayer player
                && player.getUUID().equals(getOwnerUUID()) && AveronSyncQuestHorses.authenticated(player)))
                && super.canAddPassenger(passenger);
    }
    @Override public boolean canBeLeashed() { return false; }
    @Override protected net.minecraft.world.phys.Vec3 getPassengerAttachmentPoint(Entity passenger, EntityDimensions dimensions, float scale) {
        if(!seatLoaded) {
            seatLoaded=true;
            try(var in=QuestHorseEntity.class.getResourceAsStream("/assets/averonsync/mounts/horse_bay.json")) {
                seatModel=HorseSeatPose.parse(com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(in,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject());
            } catch(Exception e) {pl.skidam.automodpack_core.GlobalVariables.LOGGER.error("Could not load animated horse seat",e);}
        }
        double age=level().getGameTime();
        var seat=seatModel==null?new pl.skidam.automodpack_core.pets.PetAnimation.Vec(0,29,2):
                seatModel.sample(baseClip(),Math.max(0,age-baseAt())/20,action().name().toLowerCase(java.util.Locale.ROOT),Math.max(0,age-actionAt())/20,lean(),Math.max(0,age-leanAt())/20,
                        seatBlend.update(seatModel.model(),baseClip(),baseAt(),age),seatLean.update(lean(),age));
        return new Vec3(seat.x()/16*scale,seat.y()/16*scale,seat.z()/16*scale).yRot((180-getYRot())*(float)Math.PI/180);
    }
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (!player.getUUID().equals(getOwnerUUID())) return InteractionResult.FAIL;
        if (player instanceof ServerPlayer serverPlayer && !AveronSyncQuestHorses.authenticated(serverPlayer)) return InteractionResult.FAIL;
        if (!level().isClientSide && !player.isSecondaryUseActive()) player.startRiding(this);
        return InteractionResult.sidedSuccess(level().isClientSide);
    }
    @Override public void openCustomInventoryScreen(Player player) { /* No transferable inventory. */ }
    @Override public boolean isFood(ItemStack stack) { return false; }
    @Override public boolean canMate(Animal other) { return false; }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (session != null) tag.putUUID("AveronQuestSession", session);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        session = tag.hasUUID("AveronQuestSession") ? tag.getUUID("AveronQuestSession") : null;
    }
}
/*?}*/
