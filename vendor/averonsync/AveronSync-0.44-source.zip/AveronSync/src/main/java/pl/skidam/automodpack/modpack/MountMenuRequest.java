package pl.skidam.automodpack.modpack;

/*? if neoforge {*/
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import pl.skidam.automodpack_core.mounts.HorseCoat;

/** Only an action on the sender's own mount; never a player, entity or grant ID. */
public record MountMenuRequest(int screenId,int action) implements CustomPacketPayload {
    public static final int QUERY=0,SUMMON=1,STORE=2,RECOVER=3,SELECT=4;
    public static final int SELECT_BLACK=6,SELECT_APPALOOSA=7;
    private static final HorseCoat[] COATS=HorseCoat.values();
    public static int selectAction(HorseCoat coat) { return coat==HorseCoat.BAY?SELECT:SELECT_BLACK+coat.ordinal()-1; }
    public HorseCoat requestedCoat() { return action==SELECT?HorseCoat.BAY:action>=SELECT_BLACK?COATS[action-SELECT_BLACK+1]:null; }
    public static final Type<MountMenuRequest> TYPE=new Type<>(ResourceLocation.parse("averonsync:mount_menu_request"));
    public static final StreamCodec<RegistryFriendlyByteBuf,MountMenuRequest> CODEC=StreamCodec.of(
            (buf,value)->{buf.writeVarInt(value.screenId);buf.writeByte(value.action);},
            buf->new MountMenuRequest(buf.readVarInt(),buf.readUnsignedByte()));
    public MountMenuRequest {
        if(screenId<1 || action<QUERY || action==5 || action>=SELECT_BLACK+COATS.length-1)
            throw new IllegalArgumentException("Invalid mount menu request");
    }
    @Override public Type<? extends CustomPacketPayload> type(){return TYPE;}
}
/*?}*/
