package pl.skidam.automodpack.client.mounts;

/*? if neoforge {*/
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.*;
import pl.skidam.automodpack.client.pets.VipPetRenderer;
import pl.skidam.automodpack.modpack.*;
import pl.skidam.automodpack_core.mounts.HorseDirtTexture;
import pl.skidam.automodpack_core.mounts.HorseCoat;
import pl.skidam.automodpack_core.pets.*;
import java.nio.charset.StandardCharsets;
import static pl.skidam.automodpack_core.GlobalVariables.LOGGER;

public final class QuestHorseRenderer extends EntityRenderer<QuestHorseEntity> {
    private static final ResourceLocation COAT = ResourceLocation.parse("averonsync:textures/mounts/horse_bay/2.png");
    private static final java.util.Map<HorseCoat,CubeeModel> CLEAN_MODELS=new java.util.EnumMap<>(HorseCoat.class);
    private static final java.util.Map<HorseCoat,CubeeModel> DIRTY_MODELS=new java.util.EnumMap<>(HorseCoat.class);
    private static final class Motion {
        final pl.skidam.automodpack_core.mounts.HorsePoseBlend blend=new pl.skidam.automodpack_core.mounts.HorsePoseBlend();
        final pl.skidam.automodpack_core.mounts.HorseLeanBlend lean=new pl.skidam.automodpack_core.mounts.HorseLeanBlend();
    }
    private static final java.util.Map<QuestHorseEntity,Motion> MOTION=new java.util.WeakHashMap<>();
    private static final java.util.Set<QuestHorseEntity> PREVIEWS=java.util.Collections.newSetFromMap(new java.util.WeakHashMap<>());
    public static void markPreview(QuestHorseEntity horse){PREVIEWS.add(horse);}
    private static final java.util.Map<String,java.util.Optional<CubeeModel>> MODELS=new java.util.HashMap<>();
    public static void init(IEventBus bus) {
        bus.addListener(QuestHorseRenderer::register);
        bus.addListener(QuestHorseRenderer::reload);
    }
    private static void register(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(AveronSyncHorseContent.HORSE.get(), QuestHorseRenderer::new);
    }
    private static void reload(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener((ResourceManagerReloadListener) manager -> {
            MODELS.clear(); CLEAN_MODELS.clear(); DIRTY_MODELS.clear(); MOTION.clear();
        });
    }
    public QuestHorseRenderer(EntityRendererProvider.Context context) { super(context); shadowRadius = .7F; }
    private static CubeeModel model(HorseCoat coat) {
        return MODELS.computeIfAbsent(coat.modelId(),id -> {
            try (var input = Minecraft.getInstance().getResourceManager().getResourceOrThrow(
                    ResourceLocation.fromNamespaceAndPath("averonsync","mounts/"+id+".json")).open()) {
                byte[] bytes = input.readNBytes(4_000_001);
                if (bytes.length > 4_000_000) throw new java.io.IOException("Horse model too large");
                var loaded=CubeeModel.parseHorse(JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8)).getAsJsonObject());
                if(!id.equals(loaded.id())) throw new java.io.IOException("Incorrect model id");
                return java.util.Optional.of(loaded);
            } catch (Exception e) {
                LOGGER.error("Could not load quest horse artwork {}",id,e);
                return java.util.Optional.empty();
            }
        }).orElse(null);
    }
    private static ResourceLocation cleanCoat(HorseCoat coat) {
        return ResourceLocation.fromNamespaceAndPath("averonsync",coat.texturePath());
    }
    private static ResourceLocation dirtyCoat(HorseCoat coat) {
        return ResourceLocation.fromNamespaceAndPath("averonsync","runtime/"+coat.id()+"_dirty");
    }
    private static CubeeModel buildDirtyModel(CubeeModel cleanModel,HorseCoat coatStyle) {
        var client=Minecraft.getInstance();
        var clean=cleanCoat(coatStyle);
        var dirty=dirtyCoat(coatStyle);
        client.getTextureManager().release(dirty);
        try (var input=client.getResourceManager().getResourceOrThrow(clean).open();
             var coat=NativeImage.read(input)) {
            var texture=new DynamicTexture(coat.getWidth(),coat.getHeight(),false);
            boolean registered=false;
            try {
                var pixels=texture.getPixels();
                for (int y=0;y<coat.getHeight();y++) for (int x=0;x<coat.getWidth();x++)
                    pixels.setPixelRGBA(x,y,HorseDirtTexture.tint(coat.getPixelRGBA(x,y),x,y));
                texture.upload();
                client.getTextureManager().register(dirty,texture);
                registered=true;
            } finally {
                if (!registered) texture.close();
            }
            return replaceCoat(cleanModel,clean,dirty);
        } catch (Exception e) {
            LOGGER.error("Could not create dirty horse coat",e);
            return cleanModel;
        }
    }
    private static CubeeModel replaceCoat(CubeeModel model,ResourceLocation from,ResourceLocation to) {
        var textures=model.textures().stream().map(original -> original.path().equals(from.toString())
                ?new CubeeModel.Texture(to.toString(),original.width(),original.height(),original.uvWidth(),
                        original.uvHeight(),original.frameTime(),original.frames(),original.emissive()):original).toList();
        return new CubeeModel(model.id(),textures,model.nodes(),model.animations());
    }
    @Override public void render(QuestHorseEntity horse, float yaw, float partial, PoseStack poses, MultiBufferSource buffers, int light) {
        var coat=horse.coat();
        CubeeModel baseModel = model(coat);
        CubeeModel model = null;
        if (baseModel!=null) {
            CubeeModel clean=CLEAN_MODELS.computeIfAbsent(coat,
                    key -> key==HorseCoat.BAY || !key.modelId().equals(HorseCoat.BAY.id())
                            ?baseModel:replaceCoat(baseModel,COAT,cleanCoat(key)));
            model=horse.isDirty()?DIRTY_MODELS.computeIfAbsent(coat,key -> buildDirtyModel(clean,key)):clean;
        }
        if (model != null && !horse.isInvisible()) {
            double age = PetRenderTime.ticks(horse.level().getGameTime(), partial);
            String clip=horse.baseClip();double time=Math.max(0,(age-horse.baseAt())/20.0)*pl.skidam.automodpack_core.mounts.HorsePoseBlend.rate(clip);
            var layers=new java.util.ArrayList<VipPetRenderer.ModelLayer>();
            Motion motion=MOTION.computeIfAbsent(horse,ignored->new Motion());
            var transition=motion.blend.update(model,clip,horse.baseAt(),age);
            if(transition!=null)layers.add(new VipPetRenderer.ModelLayer(transition.pose(),0,transition.weight()));
            double twitchTime=(age-horse.twitchAt())/20.0;
            String[] twitches={"tailwhip","right_ear_twitch","left_ear_twitch","ruffle_head"};
            for(int i=0;i<4;i++) if ((horse.twitches()&(1<<i))!=0) layer(layers,model,twitches[i],twitchTime,1,false);
            layer(layers,model,"groom",(age-horse.groomAt())/20.0,1,false);
            var action=horse.action();String actionClip=action.name().toLowerCase(java.util.Locale.ROOT);
            if (action!=pl.skidam.automodpack_core.mounts.HorseControls.Action.NONE)
                layer(layers,model,actionClip,(age-horse.actionAt())/20.0,1,action==pl.skidam.automodpack_core.mounts.HorseControls.Action.JUMP||action==pl.skidam.automodpack_core.mounts.HorseControls.Action.FALLING);
            for(var lean:motion.lean.update(horse.lean(),age))
                layers.add(new VipPetRenderer.ModelLayer(model.animations().get(pl.skidam.automodpack_core.mounts.HorseLeanBlend.clip(lean.lean())),0,lean.weight()));
            poses.pushPose();
            boolean preview=PREVIEWS.contains(horse);
            float heading=preview?yaw:pl.skidam.automodpack_core.mounts.HorseMotion.renderYaw(horse.yRotO,horse.getYRot(),partial);
            poses.mulPose(Axis.YP.rotationDegrees((preview?360:180)-heading));
            poses.scale(1F/16,1F/16,1F/16);
            VipPetRenderer.renderModel(poses,buffers,model,clip,time,age,light,layers);
            poses.popPose();
        }
        super.render(horse, yaw, partial, poses, buffers, light);
    }
    private static void layer(java.util.List<VipPetRenderer.ModelLayer> layers,CubeeModel model,String name,double time,double weight,boolean hold) {
        var clip=model.animations().get(name);
        if(clip==null || time<0 || (!hold && time>clip.length()+.2))return;
        weight*=Math.min(1,time*10);
        if(!hold)weight*=Math.min(1,Math.max(0,(clip.length()+.2-time)/.2));
        layers.add(new VipPetRenderer.ModelLayer(clip,Math.min(time,clip.length()),weight));
    }
    @Override public ResourceLocation getTextureLocation(QuestHorseEntity horse) {
        var coat=horse.coat();
        return horse.isDirty() && DIRTY_MODELS.containsKey(coat) && DIRTY_MODELS.get(coat)!=CLEAN_MODELS.get(coat)
                ? dirtyCoat(coat) : cleanCoat(coat);
    }
}
/*?}*/
