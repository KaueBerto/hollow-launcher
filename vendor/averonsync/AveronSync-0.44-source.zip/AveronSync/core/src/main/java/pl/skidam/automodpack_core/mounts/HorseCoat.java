package pl.skidam.automodpack_core.mounts;

public enum HorseCoat {
    BAY("horse_bay", "Castanho", "2"),
    BLACK("horse_black", "Preto", "black"),
    APPALOOSA("horse_appaloosa", "Appaloosa", "appaloosa"),
    BUCKSKIN("horse_buckskin", "Baio", "buckskin"),
    CHESTNUT("horse_chestnut", "Alazão", "chestnut"),
    CREMELLO("horse_cremello", "Cremelo", "cremello"),
    PALOMINO("horse_palomino", "Palomino", "palomino"),
    PIEBALD("horse_piebald", "Pampa", "piebald"),
    ROAN("horse_roan", "Ruão", "roan"),
    UNICORN("horse_unicorn", "Unicórnio", "2", true),
    ZOMBIE("horse_zombie", "Zumbi", "2", true),
    YAKUL("horse_yakul", "Yakul", "4", true);

    private final String id;
    private final String label;
    private final String texture;
    private final boolean ownModel;

    HorseCoat(String id, String label, String texture) {
        this(id,label,texture,false);
    }
    HorseCoat(String id, String label, String texture,boolean ownModel) {
        this.id=id;
        this.label=label;
        this.texture=texture;
        this.ownModel=ownModel;
    }
    public String id() { return id; }
    public String label() { return label; }
    public String modelId() { return ownModel?id:BAY.id; }
    public String texturePath() { return "textures/mounts/"+modelId()+"/"+texture+".png"; }
    public boolean allowed(boolean operator) { return this==BAY || operator; }

    public static HorseCoat fromId(String id) {
        for (HorseCoat coat:values()) if (coat.id.equals(id)) return coat;
        return BAY;
    }
}
