package pl.skidam.automodpack_core.mounts;

/** Pixel-aligned mud patches for the horse coat atlas. Pixels use NativeImage's ABGR layout. */
public final class HorseDirtTexture {
    private static final int CELL_SIZE = 10;

    public static int tint(int pixel, int x, int y) {
        if ((pixel >>> 24) == 0) return pixel;
        int cellX = x / CELL_SIZE, cellY = y / CELL_SIZE;
        int cell = hash(cellX, cellY);
        if ((cell & 7) < 2) return pixel;

        int centerX = 3 + ((cell >>> 3) & 3);
        int centerY = 3 + ((cell >>> 5) & 3);
        int dx = Math.abs(x % CELL_SIZE - centerX);
        int dy = Math.abs(y % CELL_SIZE - centerY);
        int irregularity = hash(x, y) & 3;
        int radius = 9 + ((cell >>> 7) & 7);
        if (dx * dx + dy * dy + irregularity > radius) return pixel;

        // Multiply the existing shading so the coat's highlights and markings remain readable.
        int red = (pixel & 255) * 60 / 100;
        int green = ((pixel >>> 8) & 255) * 70 / 100;
        int blue = ((pixel >>> 16) & 255) * 64 / 100;
        return (pixel & 0xff000000) | (blue << 16) | (green << 8) | red;
    }

    private static int hash(int x, int y) {
        int value = x * 0x1f123bb5 ^ y * 0x5f356495 ^ 0x35ac88;
        value ^= value >>> 16;
        value *= 0x7feb352d;
        return value ^ (value >>> 15);
    }

    private HorseDirtTexture() {}
}
