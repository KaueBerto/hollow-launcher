"""Convert mount Ogg Vorbis assets to mono for Minecraft positional playback.

Requires soundfile and numpy. Already-mono assets are kept byte-for-byte.
"""
import io
import soundfile


def mono_vorbis(data):
    with soundfile.SoundFile(io.BytesIO(data)) as source:
        if source.channels == 1:
            return data
        samples = source.read(dtype="float32", always_2d=True)
        rate = source.samplerate
    output = io.BytesIO()
    soundfile.write(output, samples.mean(axis=1), rate, format="OGG", subtype="VORBIS")
    encoded = output.getvalue()
    with soundfile.SoundFile(io.BytesIO(encoded)) as result:
        assert result.channels == 1 and result.samplerate == rate
        assert abs(result.frames - len(samples)) <= 1
    return encoded
